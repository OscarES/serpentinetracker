/*
 * MAD Translator
 * Universal Accelerator Parser
 * Copyright (C) 2005 Andy Wolski, Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Direct questions, comments, etc to:
 * Andy Wolski (awolski@lbl.gov), Daniel Bates (dbates@lbl.gov)
 */

#include <algorithm>

#include "MADTranslator.hpp"

#define _WRITE_NAME(_type_) (*file)<<getAttributeString(element,"name")<<" : "<<#_type_;

#define _NEW_ATTR_LIST AttributeList attributes; std::string _attrValue;

#define _ADD_ATTR_TO_LIST(_dialectname_,_uapname_) if((_attrValue = getAttributeString(element,#_uapname_)) != "null") { \
attributes.push_back(UAPAttribute(#_dialectname_,_attrValue)); }

MADTranslator::MADTranslator(std::ostream& _file)
{
  file = &_file;
  
  _INIT
  //_ADD_TYPE(root,laboratory)
  _ADD_ATTRIBUTE(l,#getPrototypeOfParent()@.length)
  _ADD_ATTRIBUTE(tilt,#getPrototypeOfParent()@.orientation.tilt)
  _ADD_ATTRIBUTE(k1,#getPrototypeOfParent()@.multipole.k1)
  _ADD_ATTRIBUTE(k2,#getPrototypeOfParent()@.multipole.k2)
  _ADD_ATTRIBUTE(k3,#getPrototypeOfParent()@.multipole.k3)

  _ADD_TYPE(parameter,.#getName()@[name=#getName()@;value=#getAttributeString(value)@])
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(value)
  _ADD_TYPE(beamline,.sector[name=#getName()@])
  _ADD_ATT_TO_TYPE(beamline_parameter,sector.arg[ref=#getValue()@])
  _ADD_TYPE(element,sector.element[ref=#getName()@])
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(repeat)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(reflection)
  _ADD_TYPE(macro,sector.sector[ref=#getName()@;reflection=#getAttributeString(reflection)@;repeat=#getAttributeString(repeat)@])
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(repeat)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(reflection)
  _ADD_UNTRANSLATABLE_TYPE(use)
  
  _ADD_TYPE(marker,.element[name=#getName()@].marker)
  
  _ADD_TYPE(drift,.element[name=#getName()@].drift)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(sbend,.element[name=#getName()@].bend)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(tilt)
  _ADD_ATT_TO_TYPE(angle,element.bend.g[value=(#getAttributeString(angle)@)/(#getAttributeString(l)@)])
  _ADD_ATT_TO_TYPE(e1,element.bend.pole_face[end='ENTRANCE'].e)
  _ADD_ATT_TO_TYPE(fint,element.bend.pole_face[end='ENTRANCE'].f_int)
  _ADD_ATT_TO_TYPE(hgap,element.bend.pole_face[end='ENTRANCE'].h_gap)
  _ADD_ATT_TO_TYPE(h1,element.bend.pole_face[end='ENTRANCE'].h)
  _ADD_ATT_TO_TYPE(e2,element.bend.pole_face[end='EXIT'].e)
  _ADD_ATT_TO_TYPE(fintx,element.bend.pole_face[end='EXIT'].f_int)
  _ADD_ATT_TO_TYPE(hgap,element.bend.pole_face[end='EXIT'].h_gap)
  _ADD_ATT_TO_TYPE(h2,element.bend.pole_face[end='EXIT'].h2)
  _ADD_STD_ATT_TO_TYPE(k1)
  _ADD_STD_ATT_TO_TYPE(k2)
  _ADD_STD_ATT_TO_TYPE(k3)

  _ADD_TYPE(rbend,.element[name=#getName()@].bend)
  _ADD_ATT_TO_TYPE(l,element.bend.length_chord)
  _ADD_ATT_TO_TYPE(angle,element.bend.g[value=sin(#getAttributeString(angle)@/2)/(#getAttributeString(l)@/2)])
  _ADD_ATT_TO_TYPE(e1,element.bend.pole_face[end='ENTRANCE'].e)
  _ADD_ATT_TO_TYPE(fint,element.bend.pole_face[end='ENTRANCE'].f_int)
  _ADD_ATT_TO_TYPE(hgap,element.bend.pole_face[end='ENTRANCE'].h_gap)
  _ADD_ATT_TO_TYPE(h1,element.bend.pole_face[end='ENTRANCE'].h)
  _ADD_ATT_TO_TYPE(e2,element.bend.pole_face[end='EXIT'].e)
  _ADD_ATT_TO_TYPE(fintx,element.bend.pole_face[end='EXIT'].f_int)
  _ADD_ATT_TO_TYPE(hgap,element.bend.pole_face[end='EXIT'].h_gap)
  _ADD_ATT_TO_TYPE(h2,element.bend.pole_face[end='EXIT'].h2)
  _ADD_STD_ATT_TO_TYPE(k1)
  _ADD_STD_ATT_TO_TYPE(k2)
  _ADD_STD_ATT_TO_TYPE(k3)

  _ADD_TYPE(quadrupole,.element[name=#getName()@].quadrupole)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(k1)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(sextupole,.element[name=#getName()@].sextupole)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(k2)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(octupole,.element[name=#getName()@].octupole)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(k3)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(multipole,.element[name=#getName()@].multipole)
  _ADD_ATT_TO_TYPE(lrad,element.multipole.length_radiation)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(k*l)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(t*)

  _ADD_TYPE(solenoid,.element[name=#getName()@].solenoid)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(ks,element.solenoid.ks)

  _ADD_TYPE(hkicker,.element[name=#getName()@].kicker)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(kick,element.kicker.kicks.x_kick)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(vkicker,.element[name=#getName()@].kicker)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(kick,element.kicker.kicks.y_kick)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(kicker,.element[name=#getName()@].kicker)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(hkick,element.kicker.kicks.x_kick)
  _ADD_ATT_TO_TYPE(vkick,element.kicker.kicks.y_kick)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(rfcavity,.element[name=#getName()@].rfcavity)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(volt,element.rfcavity.rf.gradient[value=(#getValue()@)/(#getAttributeString(l)@)])
  _ADD_ATT_TO_TYPE(lag,element.rfcavity.rf.phi0)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(harmon)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(betrf)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(pg)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(shunt)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(tfill)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(cavity)

  _ADD_TYPE(elseparator,elseparator)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_UNTRANSLATABLE_ATT_TO_TYPE(e)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(hmonitor,.element[name=#getName()@].monitor)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(vmonitor,.element[name=#getName()@].monitor)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(monitor,.element[name=#getName()@].monitor)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(instrument,.element[name=#getName()@].instrument)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(ecollimator,.element[name=#getName()@].collimator)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(xsize,element.collimator.aperture.x_limit)
  _ADD_ATT_TO_TYPE(ysize,element.collimator.aperture.y_limit)

  _ADD_TYPE(rcollimator,.element[name=#getName()@].collimator)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(xsize,element.collimator.aperture.x_limit)
  _ADD_ATT_TO_TYPE(ysize,element.collimator.aperture.y_limit)

  _ADD_TYPE(yrot,.element[name=#getName()@].patch)
  _ADD_ATT_TO_TYPE(angle,element.patch.orientation.x_ptich)

  _ADD_TYPE(srot,.element[name=#getName()@].patch)
  _ADD_ATT_TO_TYPE(angle,element.patch.orientation.y_pitch)

  _ADD_TYPE(matrix,taylor)
/*  element->addAttribute("rm(*,*)","rm(*,*)"); //any matrix element index
  element->addAttribute("tm(*,*,*)","tm(*,*,*)");*/

  _ADD_TYPE(lcav,.element[name=#getName()@].lcavity)

  _ADD_TYPE(beambeam,.element[name=#getName()@].beambeam)
  _ADD_ATT_TO_TYPE(sigx,element.beambeam.strong_bunch.sig_x)
  _ADD_ATT_TO_TYPE(sigy,element.beambeam.strong_bunch.sig_y)
  _ADD_ATT_TO_TYPE(xma,element.beambeam.orientation.x_offset)
  _ADD_ATT_TO_TYPE(yma,element.beambeam.orientation.y_offset)
  _ADD_ATT_TO_TYPE(charge,element.beambeam.strong_bunch.charge)
    
}

MADTranslator::~MADTranslator() {}

struct WriteAttribute{
private:
  std::ostream* file;
  int line_limit;
public:
  WriteAttribute(std::ostream& _file) : file(&_file), line_limit(0) {}

  void operator()(UAPAttribute& attrb) {
    std::string attrb_name = attrb.getName();
    if(attrb_name=="name")
      return;
    std::string attrb_value = attrb.getValue();
    (*file)<<","<<attrb_name;
    if(!(attrb_value == ""))
      (*file)<<"="<<attrb_value;
    if(line_limit++>4) {
      (*file)<<" &"<<std::endl;
      line_limit = 0;
    }
  }
};

struct WriteBeamlineParameter{
private:
  std::ostream* file;
  bool next_val;
  int line_limit;
public:
  WriteBeamlineParameter(std::ostream& _file)
    : file(&_file), next_val(false), line_limit(0) {}

  void operator()(UAPAttribute& attrb) {

    if(attrb.getName()=="beamline_parameter"){
      if(next_val)
        (*file)<<",";
      else{
        next_val = true;
      }
      (*file)<<attrb.getValue();

      if(line_limit++>4) {
        (*file)<<",&"<<std::endl<<"  ";
        next_val = false;
        line_limit = 0;
      }
    }
  }
};

/*******************************************************************/

int MADTranslator::WriteAttributes(AttributeList& attributes)
{
  std::for_each(attributes.begin(), attributes.end(), WriteAttribute((*file)));
  return -1;
}

/*******************************************************************/

int MADTranslator::UAP_Parameter(UAPTranslationElement& element, int n)
{
  if(n){
    (*file)<<getAttributeString(element,"name")<<" := ";
    (*file)<<getAttributeString(element,"value")<<std::endl;
  }
  return -1;
}

int MADTranslator::UAP_Beamline(UAPTranslationElement& element, int n)
{
  if(n){
    (*file)<<getAttributeString(element,"name");

    /*if(attributes.size()>0){
      (*file)<<"(";
      std::for_each(attributes.begin(), attributes.end(), WriteBeamlineParameter((*file)));
      (*file)<<")";
    }*/
    
    (*file)<<" : line=(";
    continuation_flag = false;
    line_limit = 0;
  }else
    (*file)<<")"<<std::endl;

  return -1;
}

int MADTranslator::UAP_BeamlineElement(UAPTranslationElement& element, int n)
{
  if(n){

    if(continuation_flag)
      if((line_limit++)>3){
        (*file)<<", &"<<std::endl<<"  ";
        line_limit=0;
      }else
        (*file)<<",";
    (*file)<<getAttributeString(element,"ref");
    continuation_flag = true;

  }
  return -1;
}

int MADTranslator::UAP_Macro(UAPTranslationElement& element, int n)
{
  if(n){
  
    if(continuation_flag)
      if((line_limit++)>3){
        (*file)<<", &"<<std::endl<<"  ";
        line_limit=0;
      }else
        (*file)<<",";
    (*file)<<getAttributeString(element,"name")<<"(";
    continuation_flag = false;
  }else
    (*file)<<")";

  return -1;
}

int MADTranslator::UAP_Drift(UAPTranslationElement& element, int n)
{
  if(n){
    _NEW_ATTR_LIST
    _ADD_ATTR_TO_LIST(l,drift.length.value)
    _WRITE_NAME(drift)
    WriteAttributes(attributes);
    (*file)<<std::endl;
  }
  return -1;
}

int MADTranslator::UAP_Bend(UAPTranslationElement& element, int n)
{
  if(n){
    _NEW_ATTR_LIST
    _ADD_ATTR_TO_LIST(l,bend.orientation.length_chord.value)
    _ADD_ATTR_TO_LIST(l,bend.length.value)
    _ADD_ATTR_TO_LIST(angle,bend.angle.value)
    _ADD_ATTR_TO_LIST(k1,bend.k1.value)
    _ADD_ATTR_TO_LIST(e1,bend.e1.value)
    _ADD_ATTR_TO_LIST(e2,bend.e2.value)
    _ADD_ATTR_TO_LIST(fint,bend.f_int.value)
    _ADD_ATTR_TO_LIST(hgap,bend.h_gap.value)
    _ADD_ATTR_TO_LIST(tilt,bend.orientation.tilt.value)
    _ADD_ATTR_TO_LIST(k2,bend.k2.value)
    _ADD_ATTR_TO_LIST(h1,bend.h1.value)
    _ADD_ATTR_TO_LIST(h2,bend.h2.value)
    _ADD_ATTR_TO_LIST(k3,bend.k3.value)
    _WRITE_NAME(sbend)
    WriteAttributes(attributes);
    (*file)<<std::endl;
  }
  return -1;
}

int MADTranslator::UAP_Quadrupole(UAPTranslationElement& element, int n)
{
  if(n){
    _NEW_ATTR_LIST
    _ADD_ATTR_TO_LIST(l,quadrupole.length.value)
    _ADD_ATTR_TO_LIST(k2,quadrupole.k1.value)
    _ADD_ATTR_TO_LIST(tilt,quadrupole.orientation.tilt.value)
    _WRITE_NAME(quadrupole)
    WriteAttributes(attributes);
    (*file)<<std::endl;
  }
  return -1;
}

int MADTranslator::UAP_Sextupole(UAPTranslationElement& element, int n)
{
  if(n){
    _NEW_ATTR_LIST
    _ADD_ATTR_TO_LIST(l,sextupole.length.value)
    _ADD_ATTR_TO_LIST(k2,sextupole.k2.value)
    _ADD_ATTR_TO_LIST(tilt,sextupole.orientation.tilt.value)
    _WRITE_NAME(sextupole)
    WriteAttributes(attributes);
    (*file)<<std::endl;
  }
  return -1;
}

int MADTranslator::UAP_RFCavity(UAPTranslationElement& element, int n)
{
  if(n){
    _NEW_ATTR_LIST
    _ADD_ATTR_TO_LIST(l,rfcavity.length.value)
    _ADD_ATTR_TO_LIST(volt,rfcavity.rf.gradient.value)
    _ADD_ATTR_TO_LIST(lag,rfcavity.rf.phi0.value)
    _WRITE_NAME(rfcavity)
    WriteAttributes(attributes);
    (*file)<<std::endl;
  }
  return -1;
}

int MADTranslator::UAP_Custom(UAPTranslationElement& element, int n)
{
  return 0;
}
