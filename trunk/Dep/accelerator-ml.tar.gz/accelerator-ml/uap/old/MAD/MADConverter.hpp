#ifndef INC_MADConverter_hpp_
#define INC_MADConverter_hpp_

#include "antlr/config.hpp"
#include "MADTokenTypes.hpp"
/* $ANTLR 2.7.0: "MAD_C.g" -> "MADConverter.hpp"$ */
#include "antlr/TreeParser.hpp"


/*
 * MAD Parser
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates, Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov), Andy Wolski (awolski@lbl.gov)
 */
#include <list>
#include "antlr/TokenStreamSelector.hpp"

/** Builds a UAP model for translation.
* @author Andy Wolski, Daniel Bates
* @version 1.2.2, 09/13/06
* @ingroup MAD
*/
class MADConverter : public ANTLR_USE_NAMESPACE(antlr)TreeParser, public MADTokenTypes
 {

  std::string aval;

  class UAPModelBuilder* modelBuilder;
public:
  MADConverter();
  public: class UAPNode*  convert(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void tree(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twParameter(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: std::string  twAttribValue(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twBeamline(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twBlParameters(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twBLElement(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twElement(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twAttribute(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twUse(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twConst(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void mathFunction(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twMacroCall(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
  public: void twBLElemMod(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
private:
  static const char* _tokenNames[];
  
  static const unsigned long _tokenSet_0_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_0;
  static const unsigned long _tokenSet_1_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_1;
  static const unsigned long _tokenSet_2_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_2;
};

#endif /*INC_MADConverter_hpp_*/
