/* $ANTLR 2.7.0: "MAD_C.g" -> "MADParser.cpp"$ */
#include "MADParser.hpp"
#include "antlr/NoViableAltException.hpp"
#include "antlr/SemanticException.hpp"

//  #include <iostream>

MADParser::MADParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,k)
{
  setTokenNames(_tokenNames);
}

MADParser::MADParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,2)
{
  setTokenNames(_tokenNames);
}

MADParser::MADParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,k)
{
  setTokenNames(_tokenNames);
}

MADParser::MADParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,2)
{
  setTokenNames(_tokenNames);
}

MADParser::MADParser(const ANTLR_USE_NAMESPACE(antlr)ParserSharedInputState& state)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(state,2)
{
  setTokenNames(_tokenNames);
}

void MADParser::parseMAD() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST parseMAD_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    {
    for (;;) {
      if ((LA(1)==LITERAL_use||LA(1)==IDENT)) {
        madStatement();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
      }
      else {
        goto _loop3;
      }
      
    }
    _loop3:;
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp39_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp39_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(ANTLR_USE_NAMESPACE(antlr)Token::EOF_TYPE);
    if ( inputState->guessing==0 ) {
      parseMAD_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      parseMAD_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(MAD,"MAD")))->add(parseMAD_AST)));
      currentAST.root = parseMAD_AST;
      currentAST.child = parseMAD_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&parseMAD_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        parseMAD_AST->getFirstChild() : parseMAD_AST;
      currentAST.advanceChildToEnd();
    }
    parseMAD_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_0);
    } else {
      throw ex;
    }
  }
  returnAST = parseMAD_AST;
}

void MADParser::madStatement() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madStatement_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    if ((LA(1)==IDENT) && (LA(2)==BECOMES)) {
      madAssignment();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      madStatement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
    }
    else if ((LA(1)==IDENT) && (LA(2)==COLON)) {
      madObject();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      madStatement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
    }
    else if ((LA(1)==IDENT) && (LA(2)==LPAREN)) {
      madMacro();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      madStatement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
    }
    else if ((LA(1)==LITERAL_use)) {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp40_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp40_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp40_AST));
      }
      match(LITERAL_use);
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp41_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp41_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(COMMA);
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp42_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp42_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp42_AST));
      }
      match(IDENT);
      madStatement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
    }
    else {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_1);
    } else {
      throw ex;
    }
  }
  returnAST = madStatement_AST;
}

void MADParser::madAssignment() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madAssignment_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp43_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp43_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp43_AST));
    }
    match(IDENT);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp44_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp44_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(BECOMES);
    aExpr();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    if ( inputState->guessing==0 ) {
      madAssignment_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      madAssignment_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(PARAMETER,"PARAMETER")))->add(madAssignment_AST)));
      currentAST.root = madAssignment_AST;
      currentAST.child = madAssignment_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madAssignment_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        madAssignment_AST->getFirstChild() : madAssignment_AST;
      currentAST.advanceChildToEnd();
    }
    madAssignment_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_1);
    } else {
      throw ex;
    }
  }
  returnAST = madAssignment_AST;
}

void MADParser::madObject() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madObject_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp45_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp45_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp45_AST));
    }
    match(IDENT);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp46_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp46_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(COLON);
    {
    switch ( LA(1)) {
    case LITERAL_line:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp47_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp47_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(LITERAL_line);
      {
      switch ( LA(1)) {
      case EQUALS:
      {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp48_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp48_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(EQUALS);
        break;
      }
      case LPAREN:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
      }
      }
      }
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp49_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp49_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(LPAREN);
      madElementList();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp50_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp50_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(RPAREN);
      if ( inputState->guessing==0 ) {
        madObject_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
        madObject_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(BEAMLINE,"BEAMLINE")))->add(madObject_AST)));
        currentAST.root = madObject_AST;
        currentAST.child = madObject_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madObject_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
          madObject_AST->getFirstChild() : madObject_AST;
        currentAST.advanceChildToEnd();
      }
      break;
    }
    case IDENT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp51_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp51_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp51_AST));
      }
      match(IDENT);
      {
      switch ( LA(1)) {
      case COMMA:
      {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp52_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp52_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(COMMA);
        madAttribList();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
        break;
      }
      case ANTLR_USE_NAMESPACE(antlr)Token::EOF_TYPE:
      case LITERAL_use:
      case IDENT:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
      }
      }
      }
      if ( inputState->guessing==0 ) {
        madObject_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
        madObject_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(ELEMENT,"ELEMENT")))->add(madObject_AST)));
        currentAST.root = madObject_AST;
        currentAST.child = madObject_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madObject_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
          madObject_AST->getFirstChild() : madObject_AST;
        currentAST.advanceChildToEnd();
      }
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
    }
    madObject_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_1);
    } else {
      throw ex;
    }
  }
  returnAST = madObject_AST;
}

void MADParser::madMacro() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madMacro_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp53_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp53_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp53_AST));
    }
    match(IDENT);
    madBlParamList();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp54_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp54_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(COLON);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp55_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp55_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(LITERAL_line);
    {
    switch ( LA(1)) {
    case EQUALS:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp56_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp56_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(EQUALS);
      break;
    }
    case LPAREN:
    {
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp57_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp57_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(LPAREN);
    madElementList();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp58_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp58_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(RPAREN);
    if ( inputState->guessing==0 ) {
      madMacro_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      madMacro_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(BEAMLINE,"BEAMLINE")))->add(madMacro_AST)));
      currentAST.root = madMacro_AST;
      currentAST.child = madMacro_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madMacro_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        madMacro_AST->getFirstChild() : madMacro_AST;
      currentAST.advanceChildToEnd();
    }
    madMacro_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_1);
    } else {
      throw ex;
    }
  }
  returnAST = madMacro_AST;
}

void MADParser::madElementList() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madElementList_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    madElemExpr();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    {
    for (;;) {
      if ((LA(1)==COMMA)) {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp59_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp59_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(COMMA);
        madElemExpr();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
      }
      else {
        goto _loop19;
      }
      
    }
    _loop19:;
    }
    madElementList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_2);
    } else {
      throw ex;
    }
  }
  returnAST = madElementList_AST;
}

void MADParser::madAttribList() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madAttribList_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    madAttribute();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    {
    for (;;) {
      if ((LA(1)==COMMA)) {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp60_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp60_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(COMMA);
        madAttribute();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
      }
      else {
        goto _loop28;
      }
      
    }
    _loop28:;
    }
    madAttribList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_1);
    } else {
      throw ex;
    }
  }
  returnAST = madAttribList_AST;
}

void MADParser::aExpr() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST aExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    prodExpr();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    {
    for (;;) {
      if ((LA(1)==MINUS||LA(1)==PLUS)) {
        {
        switch ( LA(1)) {
        case PLUS:
        {
          ANTLR_USE_NAMESPACE(antlr)RefAST tmp61_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
          if (inputState->guessing==0) {
            tmp61_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
            astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp61_AST));
          }
          match(PLUS);
          break;
        }
        case MINUS:
        {
          ANTLR_USE_NAMESPACE(antlr)RefAST tmp62_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
          if (inputState->guessing==0) {
            tmp62_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
            astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp62_AST));
          }
          match(MINUS);
          break;
        }
        default:
        {
          throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
        }
        }
        }
        prodExpr();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
      }
      else {
        goto _loop40;
      }
      
    }
    _loop40:;
    }
    aExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_3);
    } else {
      throw ex;
    }
  }
  returnAST = aExpr_AST;
}

void MADParser::madBeamline() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madBeamline_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp63_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp63_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp63_AST));
    }
    match(IDENT);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp64_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp64_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(COLON);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp65_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp65_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(LITERAL_line);
    {
    switch ( LA(1)) {
    case EQUALS:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp66_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp66_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(EQUALS);
      break;
    }
    case LPAREN:
    {
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp67_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp67_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(LPAREN);
    madElementList();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp68_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp68_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(RPAREN);
    if ( inputState->guessing==0 ) {
      madBeamline_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      madBeamline_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(BEAMLINE,"BEAMLINE")))->add(madBeamline_AST)));
      currentAST.root = madBeamline_AST;
      currentAST.child = madBeamline_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madBeamline_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        madBeamline_AST->getFirstChild() : madBeamline_AST;
      currentAST.advanceChildToEnd();
    }
    madBeamline_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_0);
    } else {
      throw ex;
    }
  }
  returnAST = madBeamline_AST;
}

void MADParser::madBlParamList() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madBlParamList_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp69_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp69_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(LPAREN);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp70_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp70_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp70_AST));
    }
    match(IDENT);
    {
    for (;;) {
      if ((LA(1)==COMMA)) {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp71_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp71_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(COMMA);
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp72_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        if (inputState->guessing==0) {
          tmp72_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp72_AST));
        }
        match(IDENT);
      }
      else {
        goto _loop16;
      }
      
    }
    _loop16:;
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp73_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp73_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(RPAREN);
    if ( inputState->guessing==0 ) {
      madBlParamList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      madBlParamList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(BLPARAMLIST,"BLPARAMLIST")))->add(madBlParamList_AST)));
      currentAST.root = madBlParamList_AST;
      currentAST.child = madBlParamList_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madBlParamList_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        madBlParamList_AST->getFirstChild() : madBlParamList_AST;
      currentAST.advanceChildToEnd();
    }
    madBlParamList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_4);
    } else {
      throw ex;
    }
  }
  returnAST = madBlParamList_AST;
}

void MADParser::madElemExpr() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    switch ( LA(1)) {
    case MINUS:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp74_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp74_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp74_AST));
      }
      match(MINUS);
      madElemExpr();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case NUM_DOUBLE:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp75_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp75_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp75_AST));
      }
      match(NUM_DOUBLE);
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp76_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp76_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp76_AST));
      }
      match(MULT);
      madElemExpr();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LPAREN:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp77_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp77_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(LPAREN);
      madElementList();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp78_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp78_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(RPAREN);
      if ( inputState->guessing==0 ) {
        madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
        madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(SUBLINE,"SUBLINE")))->add(madElemExpr_AST)));
        currentAST.root = madElemExpr_AST;
        currentAST.child = madElemExpr_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madElemExpr_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
          madElemExpr_AST->getFirstChild() : madElemExpr_AST;
        currentAST.advanceChildToEnd();
      }
      madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case IDENT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp79_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp79_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp79_AST));
      }
      match(IDENT);
      {
      switch ( LA(1)) {
      case LPAREN:
      {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp80_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp80_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(LPAREN);
        madElementList();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp81_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp81_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(RPAREN);
        if ( inputState->guessing==0 ) {
          madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
          madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(MACRO,"MACRO")))->add(madElemExpr_AST)));
          currentAST.root = madElemExpr_AST;
          currentAST.child = madElemExpr_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madElemExpr_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
            madElemExpr_AST->getFirstChild() : madElemExpr_AST;
          currentAST.advanceChildToEnd();
        }
        break;
      }
      case COMMA:
      case RPAREN:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
      }
      }
      }
      madElemExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_5);
    } else {
      throw ex;
    }
  }
  returnAST = madElemExpr_AST;
}

void MADParser::madElement() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madElement_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp82_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp82_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp82_AST));
    }
    match(IDENT);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp83_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp83_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(COLON);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp84_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp84_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp84_AST));
    }
    match(IDENT);
    {
    switch ( LA(1)) {
    case COMMA:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp85_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp85_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(COMMA);
      madAttribList();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      break;
    }
    case ANTLR_USE_NAMESPACE(antlr)Token::EOF_TYPE:
    {
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
    }
    if ( inputState->guessing==0 ) {
      madElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      madElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(ELEMENT,"ELEMENT")))->add(madElement_AST)));
      currentAST.root = madElement_AST;
      currentAST.child = madElement_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madElement_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        madElement_AST->getFirstChild() : madElement_AST;
      currentAST.advanceChildToEnd();
    }
    madElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_0);
    } else {
      throw ex;
    }
  }
  returnAST = madElement_AST;
}

void MADParser::madAttribute() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST madAttribute_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    {
    if ((LA(1)==IDENT) && (_tokenSet_6.member(LA(2)))) {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp86_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp86_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp86_AST));
      }
      match(IDENT);
    }
    else if ((LA(1)==IDENT) && (LA(2)==LPAREN)) {
      matrixElement();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
    }
    else {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    
    }
    {
    switch ( LA(1)) {
    case EQUALS:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp87_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp87_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(EQUALS);
      {
      if ((_tokenSet_7.member(LA(1))) && (_tokenSet_8.member(LA(2)))) {
        aExpr();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
      }
      else if ((LA(1)==IDENT) && (LA(2)==LBRACKET)) {
        aRef();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
      }
      else {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
      }
      
      }
      break;
    }
    case ANTLR_USE_NAMESPACE(antlr)Token::EOF_TYPE:
    case LITERAL_use:
    case COMMA:
    case IDENT:
    {
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
    }
    if ( inputState->guessing==0 ) {
      madAttribute_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      madAttribute_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(ATTRIBUTE,"ATTRIBUTE")))->add(madAttribute_AST)));
      currentAST.root = madAttribute_AST;
      currentAST.child = madAttribute_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&madAttribute_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        madAttribute_AST->getFirstChild() : madAttribute_AST;
      currentAST.advanceChildToEnd();
    }
    madAttribute_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_9);
    } else {
      throw ex;
    }
  }
  returnAST = madAttribute_AST;
}

void MADParser::matrixElement() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST matrixElement_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)RefToken  n = ANTLR_USE_NAMESPACE(antlr)nullToken;
  ANTLR_USE_NAMESPACE(antlr)RefAST n_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)RefToken  x = ANTLR_USE_NAMESPACE(antlr)nullToken;
  ANTLR_USE_NAMESPACE(antlr)RefAST x_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)RefToken  y = ANTLR_USE_NAMESPACE(antlr)nullToken;
  ANTLR_USE_NAMESPACE(antlr)RefAST y_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  std::string name= "";
  
  try {      // for error handling
    n = LT(1);
    if (inputState->guessing==0) {
      n_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(n));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(n_AST));
    }
    match(IDENT);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp88_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp88_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(LPAREN);
    x = LT(1);
    if (inputState->guessing==0) {
      x_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(x));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(x_AST));
    }
    match(NUM_DOUBLE);
    if ( inputState->guessing==0 ) {
      name= name+n->getText()+"("+x->getText();
    }
    {
    for (;;) {
      if ((LA(1)==COMMA)) {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp89_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        tmp89_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        match(COMMA);
        y = LT(1);
        if (inputState->guessing==0) {
          y_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(y));
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(y_AST));
        }
        match(NUM_DOUBLE);
        if ( inputState->guessing==0 ) {
          name= name+","+y->getText();
        }
      }
      else {
        goto _loop35;
      }
      
    }
    _loop35:;
    }
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp90_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp90_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(RPAREN);
    if ( inputState->guessing==0 ) {
      matrixElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      
      name= name+")";
      matrixElement_AST= ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(1))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(IDENT,name)))));
      
      currentAST.root = matrixElement_AST;
      currentAST.child = matrixElement_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&matrixElement_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        matrixElement_AST->getFirstChild() : matrixElement_AST;
      currentAST.advanceChildToEnd();
    }
    matrixElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_6);
    } else {
      throw ex;
    }
  }
  returnAST = matrixElement_AST;
}

void MADParser::aRef() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST aRef_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp91_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp91_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp91_AST));
    }
    match(IDENT);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp92_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp92_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(LBRACKET);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp93_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    if (inputState->guessing==0) {
      tmp93_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp93_AST));
    }
    match(IDENT);
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp94_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
    tmp94_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
    match(RBRACKET);
    if ( inputState->guessing==0 ) {
      aRef_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      aRef_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(ATTREF,"ATTREF")))->add(aRef_AST)));
      currentAST.root = aRef_AST;
      currentAST.child = aRef_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&aRef_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
        aRef_AST->getFirstChild() : aRef_AST;
      currentAST.advanceChildToEnd();
    }
    aRef_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_9);
    } else {
      throw ex;
    }
  }
  returnAST = aRef_AST;
}

void MADParser::prodExpr() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST prodExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    powExpr();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    {
    for (;;) {
      if ((LA(1)==MULT||LA(1)==DIV||LA(1)==MOD)) {
        {
        switch ( LA(1)) {
        case MULT:
        {
          ANTLR_USE_NAMESPACE(antlr)RefAST tmp95_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
          if (inputState->guessing==0) {
            tmp95_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
            astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp95_AST));
          }
          match(MULT);
          break;
        }
        case DIV:
        {
          ANTLR_USE_NAMESPACE(antlr)RefAST tmp96_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
          if (inputState->guessing==0) {
            tmp96_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
            astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp96_AST));
          }
          match(DIV);
          break;
        }
        case MOD:
        {
          ANTLR_USE_NAMESPACE(antlr)RefAST tmp97_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
          if (inputState->guessing==0) {
            tmp97_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
            astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp97_AST));
          }
          match(MOD);
          break;
        }
        default:
        {
          throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
        }
        }
        }
        powExpr();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
      }
      else {
        goto _loop44;
      }
      
    }
    _loop44:;
    }
    prodExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_10);
    } else {
      throw ex;
    }
  }
  returnAST = prodExpr_AST;
}

void MADParser::powExpr() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST powExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    tExpr();
    if (inputState->guessing==0) {
      astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
    }
    {
    switch ( LA(1)) {
    case POW:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp98_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp98_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp98_AST));
      }
      match(POW);
      tExpr();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      break;
    }
    case ANTLR_USE_NAMESPACE(antlr)Token::EOF_TYPE:
    case LITERAL_use:
    case COMMA:
    case IDENT:
    case RPAREN:
    case MINUS:
    case MULT:
    case PLUS:
    case DIV:
    case MOD:
    {
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
    }
    powExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_11);
    } else {
      throw ex;
    }
  }
  returnAST = powExpr_AST;
}

void MADParser::tExpr() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST tExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    {
    switch ( LA(1)) {
    case LITERAL_sqrt:
    case LITERAL_log:
    case LITERAL_exp:
    case LITERAL_sin:
    case LITERAL_cos:
    case LITERAL_tan:
    case LITERAL_asin:
    case LITERAL_abs:
    case LITERAL_max:
    case LITERAL_min:
    case LITERAL_randf:
    case LITERAL_gauss:
    case LITERAL_tgauss:
    case 46:
    case 47:
    case 48:
    {
      mathFunction();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp99_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp99_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(LPAREN);
      {
      switch ( LA(1)) {
      case IDENT:
      case LPAREN:
      case MINUS:
      case NUM_DOUBLE:
      case PLUS:
      case NUM_FLOAT:
      case LITERAL_sqrt:
      case LITERAL_log:
      case LITERAL_exp:
      case LITERAL_sin:
      case LITERAL_cos:
      case LITERAL_tan:
      case LITERAL_asin:
      case LITERAL_abs:
      case LITERAL_max:
      case LITERAL_min:
      case LITERAL_randf:
      case LITERAL_gauss:
      case LITERAL_tgauss:
      case 46:
      case 47:
      case 48:
      {
        aExpr();
        if (inputState->guessing==0) {
          astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
        }
        {
        for (;;) {
          if ((LA(1)==COMMA)) {
            ANTLR_USE_NAMESPACE(antlr)RefAST tmp100_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
            tmp100_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
            match(COMMA);
            aExpr();
            if (inputState->guessing==0) {
              astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
            }
          }
          else {
            goto _loop53;
          }
          
        }
        _loop53:;
        }
        break;
      }
      case RPAREN:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
      }
      }
      }
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp101_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp101_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(RPAREN);
      if ( inputState->guessing==0 ) {
        tExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
        tExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(FUNC,"FUNC")))->add(tExpr_AST)));
        currentAST.root = tExpr_AST;
        currentAST.child = tExpr_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&tExpr_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
          tExpr_AST->getFirstChild() : tExpr_AST;
        currentAST.advanceChildToEnd();
      }
      break;
    }
    case IDENT:
    case LPAREN:
    case MINUS:
    case NUM_DOUBLE:
    case PLUS:
    case NUM_FLOAT:
    {
      {
      switch ( LA(1)) {
      case MINUS:
      {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp102_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        if (inputState->guessing==0) {
          tmp102_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
          astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp102_AST));
        }
        match(MINUS);
        break;
      }
      case PLUS:
      {
        ANTLR_USE_NAMESPACE(antlr)RefAST tmp103_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
        if (inputState->guessing==0) {
          tmp103_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
          astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp103_AST));
        }
        match(PLUS);
        break;
      }
      case IDENT:
      case LPAREN:
      case NUM_DOUBLE:
      case NUM_FLOAT:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
      }
      }
      }
      atom();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
    }
    tExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_12);
    } else {
      throw ex;
    }
  }
  returnAST = tExpr_AST;
}

void MADParser::mathFunction() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    switch ( LA(1)) {
    case LITERAL_sqrt:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp104_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp104_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp104_AST));
      }
      match(LITERAL_sqrt);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_log:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp105_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp105_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp105_AST));
      }
      match(LITERAL_log);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_exp:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp106_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp106_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp106_AST));
      }
      match(LITERAL_exp);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_sin:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp107_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp107_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp107_AST));
      }
      match(LITERAL_sin);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_cos:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp108_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp108_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp108_AST));
      }
      match(LITERAL_cos);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_tan:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp109_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp109_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp109_AST));
      }
      match(LITERAL_tan);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_asin:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp110_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp110_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp110_AST));
      }
      match(LITERAL_asin);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_abs:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp111_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp111_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp111_AST));
      }
      match(LITERAL_abs);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_max:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp112_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp112_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp112_AST));
      }
      match(LITERAL_max);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_min:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp113_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp113_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp113_AST));
      }
      match(LITERAL_min);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_randf:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp114_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp114_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp114_AST));
      }
      match(LITERAL_randf);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_gauss:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp115_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp115_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp115_AST));
      }
      match(LITERAL_gauss);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LITERAL_tgauss:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp116_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp116_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp116_AST));
      }
      match(LITERAL_tgauss);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case 46:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp117_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp117_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp117_AST));
      }
      match(46);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case 47:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp118_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp118_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp118_AST));
      }
      match(47);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case 48:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp119_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp119_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp119_AST));
      }
      match(48);
      mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_13);
    } else {
      throw ex;
    }
  }
  returnAST = mathFunction_AST;
}

void MADParser::atom() {
  
  returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST atom_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    switch ( LA(1)) {
    case NUM_DOUBLE:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp120_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp120_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp120_AST));
      }
      match(NUM_DOUBLE);
      atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case NUM_FLOAT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp121_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp121_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp121_AST));
      }
      match(NUM_FLOAT);
      atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case IDENT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp122_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp122_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp122_AST));
      }
      match(IDENT);
      atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    case LPAREN:
    {
      {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp123_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      if (inputState->guessing==0) {
        tmp123_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
        astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp123_AST));
      }
      match(LPAREN);
      }
      aExpr();
      if (inputState->guessing==0) {
        astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
      }
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp124_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
      tmp124_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
      match(RPAREN);
      atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    if (inputState->guessing==0) {
      reportError(ex);
      consume();
      consumeUntil(_tokenSet_12);
    } else {
      throw ex;
    }
  }
  returnAST = atom_AST;
}

const char* MADParser::_tokenNames[] = {
  "<0>",
  "EOF",
  "<2>",
  "NULL_TREE_LOOKAHEAD",
  "PARAMETER",
  "ELEMENT",
  "BEAMLINE",
  "SUBLINE",
  "BLPARAMLIST",
  "MACRO",
  "ATTRIBUTE",
  "ATTREF",
  "FUNC",
  "MAD",
  "\"use\"",
  "COMMA",
  "a label",
  "COLON",
  "\"line\"",
  "EQUALS",
  "LPAREN",
  "RPAREN",
  "BECOMES",
  "MINUS",
  "NUM_DOUBLE",
  "MULT",
  "LBRACKET",
  "RBRACKET",
  "PLUS",
  "DIV",
  "MOD",
  "POW",
  "NUM_FLOAT",
  "\"sqrt\"",
  "\"log\"",
  "\"exp\"",
  "\"sin\"",
  "\"cos\"",
  "\"tan\"",
  "\"asin\"",
  "\"abs\"",
  "\"max\"",
  "\"min\"",
  "\"randf\"",
  "\"gauss\"",
  "\"tgauss\"",
  "\"user0\"",
  "\"user1\"",
  "\"user2\"",
  "WS",
  "SEMI",
  "SL_COMMENT",
  "STRING",
  "INCLUDE",
  0
};

const unsigned long MADParser::_tokenSet_0_data_[] = { 2UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_0(_tokenSet_0_data_,4);
const unsigned long MADParser::_tokenSet_1_data_[] = { 81922UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_1(_tokenSet_1_data_,4);
const unsigned long MADParser::_tokenSet_2_data_[] = { 2097152UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_2(_tokenSet_2_data_,4);
const unsigned long MADParser::_tokenSet_3_data_[] = { 2211842UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_3(_tokenSet_3_data_,4);
const unsigned long MADParser::_tokenSet_4_data_[] = { 131072UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_4(_tokenSet_4_data_,4);
const unsigned long MADParser::_tokenSet_5_data_[] = { 2129920UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_5(_tokenSet_5_data_,4);
const unsigned long MADParser::_tokenSet_6_data_[] = { 638978UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_6(_tokenSet_6_data_,4);
const unsigned long MADParser::_tokenSet_7_data_[] = { 294715392UL, 131071UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_7(_tokenSet_7_data_,4);
const unsigned long MADParser::_tokenSet_8_data_[] = { 4086415362UL, 131071UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_8(_tokenSet_8_data_,4);
const unsigned long MADParser::_tokenSet_9_data_[] = { 114690UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_9(_tokenSet_9_data_,4);
const unsigned long MADParser::_tokenSet_10_data_[] = { 279035906UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_10(_tokenSet_10_data_,4);
const unsigned long MADParser::_tokenSet_11_data_[] = { 1923203074UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_11(_tokenSet_11_data_,4);
const unsigned long MADParser::_tokenSet_12_data_[] = { 4070686722UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_12(_tokenSet_12_data_,4);
const unsigned long MADParser::_tokenSet_13_data_[] = { 1048576UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADParser::_tokenSet_13(_tokenSet_13_data_,4);


