#ifndef INC_MADLexer_hpp_
#define INC_MADLexer_hpp_

#include "antlr/config.hpp"
/* $ANTLR 2.7.0: "MAD_C.g" -> "MADLexer.hpp"$ */
#include "antlr/CommonToken.hpp"
#include "antlr/InputBuffer.hpp"
#include "antlr/BitSet.hpp"
#include "MADTokenTypes.hpp"
#include "antlr/CharScanner.hpp"

/*
 * MAD Parser
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates, Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov), Andy Wolski (awolski@lbl.gov)
 */
#include <list>
#include "antlr/TokenStreamSelector.hpp"

/** A lexer for MAD-8. (You can use this standalone, but you should really
* only use this class with the Universal Accelerator Parser library). Reads a 
* {@link antlr::TokenStream TokenStream} and invokes the appropriate methods in this class.
* @author Daniel Bates
* @version 1.4.2, 06/21/05
* @ingroup MAD
*/
class MADLexer : public ANTLR_USE_NAMESPACE(antlr)CharScanner, public MADTokenTypes
 {

  private:
    ANTLR_USE_NAMESPACE(antlr)TokenStreamSelector* selector;
    std::list<MADLexer*>* lexer_stack;

  public:
    void setSelector(ANTLR_USE_NAMESPACE(antlr)TokenStreamSelector* _selector, std::list<MADLexer*>* _lexer_stack=0){
      selector = _selector;
      lexer_stack = _lexer_stack ? _lexer_stack : new std::list<MADLexer*>;
    }

    /** Overrides default uponEOF method.
    * <p>
    * Upon the parser's requests for another token beyond the last 
    * non-EOF token, selects the next TokenStream.
    * @version 1.0
    * @since 1.3
    */

    void uponEOF(){
      if(lexer_stack->size()>0){
        selector->select(*(--lexer_stack->end()));
        lexer_stack->pop_back();
        selector->retry();
      }
    }
  private:
  void initLiterals();
public:
  bool getCaseSensitiveLiterals() const;
public:
  MADLexer(ANTLR_USE_NAMESPACE(std)istream& in);
  MADLexer(ANTLR_USE_NAMESPACE(antlr)InputBuffer& ib);
  MADLexer(const ANTLR_USE_NAMESPACE(antlr)LexerSharedInputState& state);
  ANTLR_USE_NAMESPACE(antlr)RefToken nextToken();
  public: void mWS(bool _createToken);
  public: void mBECOMES(bool _createToken);
  public: void mLPAREN(bool _createToken);
  public: void mRPAREN(bool _createToken);
  public: void mLBRACKET(bool _createToken);
  public: void mRBRACKET(bool _createToken);
  public: void mPLUS(bool _createToken);
  public: void mMINUS(bool _createToken);
  public: void mMULT(bool _createToken);
  public: void mDIV(bool _createToken);
  public: void mMOD(bool _createToken);
  public: void mPOW(bool _createToken);
  public: void mEQUALS(bool _createToken);
  public: void mCOLON(bool _createToken);
  public: void mCOMMA(bool _createToken);
  public: void mSEMI(bool _createToken);
  public: void mIDENT(bool _createToken);
  protected: void mINCLUDE(bool _createToken);
  public: void mNUM_FLOAT(bool _createToken);
  public: void mNUM_DOUBLE(bool _createToken);
  public: void mSL_COMMENT(bool _createToken);
  public: void mSTRING(bool _createToken);
private:
  
  static const unsigned long _tokenSet_0_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_0;
  static const unsigned long _tokenSet_1_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_1;
};

#endif /*INC_MADLexer_hpp_*/
