#include "MADStreamSelector.hpp"

MADStreamSelector::MADStreamSelector(MADLexer& lexer){
  push(&lexer);
  lexer.setSelector(this);
}
