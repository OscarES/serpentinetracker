#ifndef INC_MADTokenTypes_hpp_
#define INC_MADTokenTypes_hpp_

/* $ANTLR 2.7.0: "MAD_C.g" -> "MADTokenTypes.hpp"$ */
struct MADTokenTypes {
  enum {
    EOF_ = 1,
    NULL_TREE_LOOKAHEAD = 3,
    PARAMETER = 4,
    ELEMENT = 5,
    BEAMLINE = 6,
    SUBLINE = 7,
    BLPARAMLIST = 8,
    MACRO = 9,
    ATTRIBUTE = 10,
    ATTREF = 11,
    FUNC = 12,
    MAD = 13,
    LITERAL_use = 14,
    COMMA = 15,
    IDENT = 16,
    COLON = 17,
    LITERAL_line = 18,
    EQUALS = 19,
    LPAREN = 20,
    RPAREN = 21,
    BECOMES = 22,
    MINUS = 23,
    NUM_DOUBLE = 24,
    MULT = 25,
    LBRACKET = 26,
    RBRACKET = 27,
    PLUS = 28,
    DIV = 29,
    MOD = 30,
    POW = 31,
    NUM_FLOAT = 32,
    LITERAL_sqrt = 33,
    LITERAL_log = 34,
    LITERAL_exp = 35,
    LITERAL_sin = 36,
    LITERAL_cos = 37,
    LITERAL_tan = 38,
    LITERAL_asin = 39,
    LITERAL_abs = 40,
    LITERAL_max = 41,
    LITERAL_min = 42,
    LITERAL_randf = 43,
    LITERAL_gauss = 44,
    LITERAL_tgauss = 45,
    // "user0" = 46
    // "user1" = 47
    // "user2" = 48
    WS = 49,
    SEMI = 50,
    SL_COMMENT = 51,
    STRING = 52,
    INCLUDE = 53,
  };
};
#endif /*INC_MADTokenTypes_hpp_*/
