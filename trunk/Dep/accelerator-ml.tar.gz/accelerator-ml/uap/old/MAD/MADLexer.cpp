/* $ANTLR 2.7.0: "MAD_C.g" -> "MADLexer.cpp"$ */
#include "MADLexer.hpp"
#include "antlr/CharBuffer.hpp"
#include "antlr/TokenStreamException.hpp"
#include "antlr/TokenStreamIOException.hpp"
#include "antlr/TokenStreamRecognitionException.hpp"
#include "antlr/CharStreamException.hpp"
#include "antlr/CharStreamIOException.hpp"
#include "antlr/NoViableAltForCharException.hpp"


  #include <iostream>
  #include <fstream>
  #include <string>
  #include <algorithm>

MADLexer::MADLexer(ANTLR_USE_NAMESPACE(std)istream& in)
  : ANTLR_USE_NAMESPACE(antlr)CharScanner(new ANTLR_USE_NAMESPACE(antlr)CharBuffer(in))
{
  setCaseSensitive(false);
  initLiterals();
}

MADLexer::MADLexer(ANTLR_USE_NAMESPACE(antlr)InputBuffer& ib)
  : ANTLR_USE_NAMESPACE(antlr)CharScanner(ib)
{
  setCaseSensitive(false);
  initLiterals();
}

MADLexer::MADLexer(const ANTLR_USE_NAMESPACE(antlr)LexerSharedInputState& state)
  : ANTLR_USE_NAMESPACE(antlr)CharScanner(state)
{
  setCaseSensitive(false);
  initLiterals();
}

void MADLexer::initLiterals()
{
  literals["min"] = 42;
  literals["line"] = 18;
  literals["sqrt"] = 33;
  literals["use"] = 14;
  literals["log"] = 34;
  literals["user0"] = 46;
  literals["abs"] = 40;
  literals["randf"] = 43;
  literals["exp"] = 35;
  literals["tgauss"] = 45;
  literals["sin"] = 36;
  literals["gauss"] = 44;
  literals["user2"] = 48;
  literals["cos"] = 37;
  literals["max"] = 41;
  literals["asin"] = 39;
  literals["tan"] = 38;
  literals["user1"] = 47;
}
bool MADLexer::getCaseSensitiveLiterals() const
{
  return false;
}

ANTLR_USE_NAMESPACE(antlr)RefToken MADLexer::nextToken()
{
  ANTLR_USE_NAMESPACE(antlr)RefToken theRetToken;
  for (;;) {
    ANTLR_USE_NAMESPACE(antlr)RefToken theRetToken;
    int _ttype = ANTLR_USE_NAMESPACE(antlr)Token::INVALID_TYPE;
    resetText();
    try {   // for char stream error handling
      try {   // for lexical error handling
        switch ( LA(1)) {
        case static_cast<unsigned char>('\t'):
        case static_cast<unsigned char>('\n'):
        case static_cast<unsigned char>('\r'):
        case static_cast<unsigned char>(' '):
        case static_cast<unsigned char>('&'):
        {
          mWS(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('('):
        {
          mLPAREN(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>(')'):
        {
          mRPAREN(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('['):
        {
          mLBRACKET(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>(']'):
        {
          mRBRACKET(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('+'):
        {
          mPLUS(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('-'):
        {
          mMINUS(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('*'):
        {
          mMULT(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('/'):
        {
          mDIV(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('%'):
        {
          mMOD(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('^'):
        {
          mPOW(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('='):
        {
          mEQUALS(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>(','):
        {
          mCOMMA(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>(';'):
        {
          mSEMI(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('a'):
        case static_cast<unsigned char>('b'):
        case static_cast<unsigned char>('c'):
        case static_cast<unsigned char>('d'):
        case static_cast<unsigned char>('e'):
        case static_cast<unsigned char>('f'):
        case static_cast<unsigned char>('g'):
        case static_cast<unsigned char>('h'):
        case static_cast<unsigned char>('i'):
        case static_cast<unsigned char>('j'):
        case static_cast<unsigned char>('k'):
        case static_cast<unsigned char>('l'):
        case static_cast<unsigned char>('m'):
        case static_cast<unsigned char>('n'):
        case static_cast<unsigned char>('o'):
        case static_cast<unsigned char>('p'):
        case static_cast<unsigned char>('q'):
        case static_cast<unsigned char>('r'):
        case static_cast<unsigned char>('s'):
        case static_cast<unsigned char>('t'):
        case static_cast<unsigned char>('u'):
        case static_cast<unsigned char>('v'):
        case static_cast<unsigned char>('w'):
        case static_cast<unsigned char>('x'):
        case static_cast<unsigned char>('y'):
        case static_cast<unsigned char>('z'):
        {
          mIDENT(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('.'):
        {
          mNUM_FLOAT(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('0'):
        case static_cast<unsigned char>('1'):
        case static_cast<unsigned char>('2'):
        case static_cast<unsigned char>('3'):
        case static_cast<unsigned char>('4'):
        case static_cast<unsigned char>('5'):
        case static_cast<unsigned char>('6'):
        case static_cast<unsigned char>('7'):
        case static_cast<unsigned char>('8'):
        case static_cast<unsigned char>('9'):
        {
          mNUM_DOUBLE(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('!'):
        {
          mSL_COMMENT(true);
          theRetToken=_returnToken;
          break;
        }
        case static_cast<unsigned char>('"'):
        {
          mSTRING(true);
          theRetToken=_returnToken;
          break;
        }
        default:
          if ((LA(1)==static_cast<unsigned char>(':')) && (LA(2)==static_cast<unsigned char>('='))) {
            mBECOMES(true);
            theRetToken=_returnToken;
          }
          else if ((LA(1)==static_cast<unsigned char>(':')) && (true)) {
            mCOLON(true);
            theRetToken=_returnToken;
          }
        else {
          if (LA(1)==EOF_CHAR) {uponEOF(); _returnToken = makeToken(ANTLR_USE_NAMESPACE(antlr)Token::EOF_TYPE);}
        else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());}
        }
        }
        if ( !_returnToken ) goto tryAgain; // found SKIP token
        _ttype = _returnToken->getType();
        _ttype = testLiteralsTable(_ttype);
        _returnToken->setType(_ttype);
        return _returnToken;
      }
      catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& e) {
        throw ANTLR_USE_NAMESPACE(antlr)TokenStreamRecognitionException(e);
      }
    }
    catch (ANTLR_USE_NAMESPACE(antlr)CharStreamIOException& csie) {
       throw ANTLR_USE_NAMESPACE(antlr)TokenStreamIOException(csie.io);
    }
    catch (ANTLR_USE_NAMESPACE(antlr)CharStreamException& cse) {
       throw ANTLR_USE_NAMESPACE(antlr)TokenStreamException(cse.getMessage());
    }
tryAgain:;
  }
}

void MADLexer::mWS(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = WS;
  int _saveIndex;
  
  {
  switch ( LA(1)) {
  case static_cast<unsigned char>(' '):
  {
    match(static_cast<unsigned char>(' '));
    break;
  }
  case static_cast<unsigned char>('&'):
  {
    match(static_cast<unsigned char>('&'));
    break;
  }
  case static_cast<unsigned char>('\t'):
  {
    match(static_cast<unsigned char>('\t'));
    break;
  }
  case static_cast<unsigned char>('\n'):
  {
    match(static_cast<unsigned char>('\n'));
    newline();
    break;
  }
  default:
    if ((LA(1)==static_cast<unsigned char>('\r')) && (LA(2)==static_cast<unsigned char>('\n'))) {
      match("\r\n");
      newline();
    }
    else if ((LA(1)==static_cast<unsigned char>('\r')) && (true)) {
      match(static_cast<unsigned char>('\r'));
      newline();
    }
  else {
    throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());
  }
  }
  }
  _ttype = ANTLR_USE_NAMESPACE(antlr)Token::SKIP;
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mBECOMES(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = BECOMES;
  int _saveIndex;
  
  match(":=");
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mLPAREN(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = LPAREN;
  int _saveIndex;
  
  match(static_cast<unsigned char>('('));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mRPAREN(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = RPAREN;
  int _saveIndex;
  
  match(static_cast<unsigned char>(')'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mLBRACKET(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = LBRACKET;
  int _saveIndex;
  
  match(static_cast<unsigned char>('['));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mRBRACKET(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = RBRACKET;
  int _saveIndex;
  
  match(static_cast<unsigned char>(']'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mPLUS(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = PLUS;
  int _saveIndex;
  
  match(static_cast<unsigned char>('+'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mMINUS(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = MINUS;
  int _saveIndex;
  
  match(static_cast<unsigned char>('-'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mMULT(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = MULT;
  int _saveIndex;
  
  match(static_cast<unsigned char>('*'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mDIV(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = DIV;
  int _saveIndex;
  
  match(static_cast<unsigned char>('/'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mMOD(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = MOD;
  int _saveIndex;
  
  match(static_cast<unsigned char>('%'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mPOW(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = POW;
  int _saveIndex;
  
  match(static_cast<unsigned char>('^'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mEQUALS(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = EQUALS;
  int _saveIndex;
  
  match(static_cast<unsigned char>('='));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mCOLON(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = COLON;
  int _saveIndex;
  
  match(static_cast<unsigned char>(':'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mCOMMA(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = COMMA;
  int _saveIndex;
  
  match(static_cast<unsigned char>(','));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mSEMI(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = SEMI;
  int _saveIndex;
  
  match(static_cast<unsigned char>(';'));
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mIDENT(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = IDENT;
  int _saveIndex;
  
  {
  if ((LA(1)==static_cast<unsigned char>('c')) && (LA(2)==static_cast<unsigned char>('a')) && (LA(3)==static_cast<unsigned char>('l')) && (LA(4)==static_cast<unsigned char>('l')) && (LA(5)==static_cast<unsigned char>(','))) {
    mINCLUDE(false);
  }
  else if (((LA(1) >= static_cast<unsigned char>('a') && LA(1) <= static_cast<unsigned char>('z'))) && (true) && (true) && (true) && (true)) {
    {
    matchRange(static_cast<unsigned char>('a'),static_cast<unsigned char>('z'));
    }
    {
    for (;;) {
      switch ( LA(1)) {
      case static_cast<unsigned char>('a'):
      case static_cast<unsigned char>('b'):
      case static_cast<unsigned char>('c'):
      case static_cast<unsigned char>('d'):
      case static_cast<unsigned char>('e'):
      case static_cast<unsigned char>('f'):
      case static_cast<unsigned char>('g'):
      case static_cast<unsigned char>('h'):
      case static_cast<unsigned char>('i'):
      case static_cast<unsigned char>('j'):
      case static_cast<unsigned char>('k'):
      case static_cast<unsigned char>('l'):
      case static_cast<unsigned char>('m'):
      case static_cast<unsigned char>('n'):
      case static_cast<unsigned char>('o'):
      case static_cast<unsigned char>('p'):
      case static_cast<unsigned char>('q'):
      case static_cast<unsigned char>('r'):
      case static_cast<unsigned char>('s'):
      case static_cast<unsigned char>('t'):
      case static_cast<unsigned char>('u'):
      case static_cast<unsigned char>('v'):
      case static_cast<unsigned char>('w'):
      case static_cast<unsigned char>('x'):
      case static_cast<unsigned char>('y'):
      case static_cast<unsigned char>('z'):
      {
        matchRange(static_cast<unsigned char>('a'),static_cast<unsigned char>('z'));
        break;
      }
      case static_cast<unsigned char>('_'):
      {
        match(static_cast<unsigned char>('_'));
        break;
      }
      case static_cast<unsigned char>('0'):
      case static_cast<unsigned char>('1'):
      case static_cast<unsigned char>('2'):
      case static_cast<unsigned char>('3'):
      case static_cast<unsigned char>('4'):
      case static_cast<unsigned char>('5'):
      case static_cast<unsigned char>('6'):
      case static_cast<unsigned char>('7'):
      case static_cast<unsigned char>('8'):
      case static_cast<unsigned char>('9'):
      {
        matchRange(static_cast<unsigned char>('0'),static_cast<unsigned char>('9'));
        break;
      }
      default:
      {
        goto _loop79;
      }
      }
    }
    _loop79:;
    }
  }
  else {
    throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());
  }
  
  }
  _ttype = testLiteralsTable(_ttype);
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mINCLUDE(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = INCLUDE;
  int _saveIndex;
  ANTLR_USE_NAMESPACE(antlr)RefToken f;
  
  match("call");
  mCOMMA(false);
  {
  switch ( LA(1)) {
  case static_cast<unsigned char>(' '):
  {
    match(static_cast<unsigned char>(' '));
    break;
  }
  case static_cast<unsigned char>('f'):
  {
    break;
  }
  default:
  {
    throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());
  }
  }
  }
  match("filename=");
  {
  switch ( LA(1)) {
  case static_cast<unsigned char>('\t'):
  case static_cast<unsigned char>('\n'):
  case static_cast<unsigned char>('\r'):
  case static_cast<unsigned char>(' '):
  case static_cast<unsigned char>('&'):
  {
    mWS(false);
    break;
  }
  case static_cast<unsigned char>('"'):
  {
    break;
  }
  default:
  {
    throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());
  }
  }
  }
  mSTRING(true);
  f=_returnToken;
  
              std::string fName = f->getText();
              std::ifstream* input = new std::ifstream(fName.c_str());
              if (!*input) {
                std::cerr << "WARNING: The file \"" << fName 
                  << "\" could not be found." << std::endl;
              }else{
                lexer_stack->push_back(this);
                MADLexer* subLexer = new MADLexer(*input);
                subLexer->setSelector(selector,lexer_stack);
                selector->addInputStream(subLexer,fName);
                selector->select(subLexer);
                selector->retry();
              }
            
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mNUM_FLOAT(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = NUM_FLOAT;
  int _saveIndex;
  
  {
  match(static_cast<unsigned char>('.'));
  }
  {
  int _cnt83=0;
  for (;;) {
    if (((LA(1) >= static_cast<unsigned char>('0') && LA(1) <= static_cast<unsigned char>('9')))) {
      matchRange(static_cast<unsigned char>('0'),static_cast<unsigned char>('9'));
    }
    else {
      if ( _cnt83>=1 ) { goto _loop83; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());}
    }
    
    _cnt83++;
  }
  _loop83:;
  }
  {
  if ((LA(1)==static_cast<unsigned char>('e'))) {
    match(static_cast<unsigned char>('e'));
    {
    switch ( LA(1)) {
    case static_cast<unsigned char>('+'):
    {
      match(static_cast<unsigned char>('+'));
      break;
    }
    case static_cast<unsigned char>('-'):
    {
      match(static_cast<unsigned char>('-'));
      break;
    }
    case static_cast<unsigned char>('0'):
    case static_cast<unsigned char>('1'):
    case static_cast<unsigned char>('2'):
    case static_cast<unsigned char>('3'):
    case static_cast<unsigned char>('4'):
    case static_cast<unsigned char>('5'):
    case static_cast<unsigned char>('6'):
    case static_cast<unsigned char>('7'):
    case static_cast<unsigned char>('8'):
    case static_cast<unsigned char>('9'):
    {
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());
    }
    }
    }
    {
    int _cnt87=0;
    for (;;) {
      if (((LA(1) >= static_cast<unsigned char>('0') && LA(1) <= static_cast<unsigned char>('9')))) {
        matchRange(static_cast<unsigned char>('0'),static_cast<unsigned char>('9'));
      }
      else {
        if ( _cnt87>=1 ) { goto _loop87; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());}
      }
      
      _cnt87++;
    }
    _loop87:;
    }
  }
  else {
  }
  
  }
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mNUM_DOUBLE(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = NUM_DOUBLE;
  int _saveIndex;
  
  {
  int _cnt90=0;
  for (;;) {
    if (((LA(1) >= static_cast<unsigned char>('0') && LA(1) <= static_cast<unsigned char>('9')))) {
      matchRange(static_cast<unsigned char>('0'),static_cast<unsigned char>('9'));
    }
    else {
      if ( _cnt90>=1 ) { goto _loop90; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());}
    }
    
    _cnt90++;
  }
  _loop90:;
  }
  {
  if ((LA(1)==static_cast<unsigned char>('.'))) {
    {
    match(static_cast<unsigned char>('.'));
    }
    {
    for (;;) {
      if (((LA(1) >= static_cast<unsigned char>('0') && LA(1) <= static_cast<unsigned char>('9')))) {
        matchRange(static_cast<unsigned char>('0'),static_cast<unsigned char>('9'));
      }
      else {
        goto _loop94;
      }
      
    }
    _loop94:;
    }
    {
    if ((LA(1)==static_cast<unsigned char>('e'))) {
      match(static_cast<unsigned char>('e'));
      {
      switch ( LA(1)) {
      case static_cast<unsigned char>('+'):
      {
        match(static_cast<unsigned char>('+'));
        break;
      }
      case static_cast<unsigned char>('-'):
      {
        match(static_cast<unsigned char>('-'));
        break;
      }
      case static_cast<unsigned char>('0'):
      case static_cast<unsigned char>('1'):
      case static_cast<unsigned char>('2'):
      case static_cast<unsigned char>('3'):
      case static_cast<unsigned char>('4'):
      case static_cast<unsigned char>('5'):
      case static_cast<unsigned char>('6'):
      case static_cast<unsigned char>('7'):
      case static_cast<unsigned char>('8'):
      case static_cast<unsigned char>('9'):
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());
      }
      }
      }
      {
      int _cnt98=0;
      for (;;) {
        if (((LA(1) >= static_cast<unsigned char>('0') && LA(1) <= static_cast<unsigned char>('9')))) {
          matchRange(static_cast<unsigned char>('0'),static_cast<unsigned char>('9'));
        }
        else {
          if ( _cnt98>=1 ) { goto _loop98; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltForCharException(LA(1), getFilename(), getLine());}
        }
        
        _cnt98++;
      }
      _loop98:;
      }
    }
    else {
    }
    
    }
  }
  else {
  }
  
  }
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mSL_COMMENT(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = SL_COMMENT;
  int _saveIndex;
  
  match("!");
  {
  for (;;) {
    if ((_tokenSet_0.member(LA(1)))) {
      {
      match(_tokenSet_0);
      }
    }
    else {
      goto _loop102;
    }
    
  }
  _loop102:;
  }
  {
  switch ( LA(1)) {
  case static_cast<unsigned char>('\n'):
  {
    match(static_cast<unsigned char>('\n'));
    break;
  }
  case static_cast<unsigned char>('\r'):
  {
    match(static_cast<unsigned char>('\r'));
    {
    if ((LA(1)==static_cast<unsigned char>('\n'))) {
      match(static_cast<unsigned char>('\n'));
    }
    else {
    }
    
    }
    break;
  }
  default:
    {
    }
  }
  }
  
                _ttype = ANTLR_USE_NAMESPACE(antlr)Token::SKIP;
                newline();
              
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}

void MADLexer::mSTRING(bool _createToken) {
  int _ttype; ANTLR_USE_NAMESPACE(antlr)RefToken _token; int _begin=text.length();
  _ttype = STRING;
  int _saveIndex;
  
  _saveIndex=text.length();
  match(static_cast<unsigned char>('"'));
  text.erase(_saveIndex);
  {
  for (;;) {
    if ((_tokenSet_1.member(LA(1)))) {
      matchNot(static_cast<unsigned char>('"'));
    }
    else {
      goto _loop107;
    }
    
  }
  _loop107:;
  }
  _saveIndex=text.length();
  match(static_cast<unsigned char>('"'));
  text.erase(_saveIndex);
  if ( _createToken && _token==ANTLR_USE_NAMESPACE(antlr)nullToken && _ttype!=ANTLR_USE_NAMESPACE(antlr)Token::SKIP ) {
     _token = makeToken(_ttype);
     _token->setText(text.substr(_begin, text.length()-_begin));
  }
  _returnToken = _token;
}


const unsigned long MADLexer::_tokenSet_0_data_[] = { 4294958072UL, 4294967295UL, 4294967295UL, 4294967295UL, 4294967295UL, 4294967295UL, 4294967295UL, 4294967295UL, 0UL, 0UL, 0UL, 0UL, 0UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADLexer::_tokenSet_0(_tokenSet_0_data_,16);
const unsigned long MADLexer::_tokenSet_1_data_[] = { 4294967288UL, 4294967291UL, 4294967295UL, 4294967295UL, 4294967295UL, 4294967295UL, 4294967295UL, 4294967295UL, 0UL, 0UL, 0UL, 0UL, 0UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADLexer::_tokenSet_1(_tokenSet_1_data_,16);

