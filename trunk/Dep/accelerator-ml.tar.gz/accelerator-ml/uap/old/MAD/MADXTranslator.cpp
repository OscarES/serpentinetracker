/*
 * MAD-X Translator
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates, Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov), Andy Wolski (awolski@lbl.gov)
 */

#include <algorithm>

#include "MADXTranslator.hpp"

#define _WRITE_NAME(_type_) (*file)<<name<<" : "<<#_type_;

MADXTranslator::MADXTranslator(std::ostream& _file)
{
  file = &_file;
  
  _INIT
  _ADD_ATTRIBUTE(l,length)
  _ADD_ATTRIBUTE(angle,angle)
  _ADD_ATTRIBUTE(k1,k1)
  _ADD_ATTRIBUTE(k2,k2)
  _ADD_ATTRIBUTE(tilt,tilt)
  _ADD_ATTRIBUTE(k3,k3)
  
  _ADD_TYPE(parameter,parameter)
  _ADD_TYPE(beamline,beamline)
  _ADD_TYPE(element,beamline_element)
  _ADD_TYPE(macro,macro)
  _ADD_TYPE(marker,marker)
  
  _ADD_TYPE(drift,drift)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(sbend,bend)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(angle)
  _ADD_STD_ATT_TO_TYPE(k1)
  _ADD_ATT_TO_TYPE(e1,e)
  _ADD_ATT_TO_TYPE(e2,e)
  _ADD_ATT_TO_TYPE(fint,f_int)
  _ADD_ATT_TO_TYPE(hgap,h_gap)
  _ADD_STD_ATT_TO_TYPE(tilt)
  _ADD_STD_ATT_TO_TYPE(k2)
  _ADD_ATT_TO_TYPE(h1,h)
  _ADD_ATT_TO_TYPE(h2,h)
  _ADD_STD_ATT_TO_TYPE(k3)

  _ADD_TYPE(rbend,bend)
  _ADD_ATT_TO_TYPE(l,length_chord)
  _ADD_STD_ATT_TO_TYPE(angle)
  _ADD_STD_ATT_TO_TYPE(k1)
  _ADD_ATT_TO_TYPE(e1,e)
  _ADD_ATT_TO_TYPE(e2,e)
  _ADD_ATT_TO_TYPE(fint,f_int)
  _ADD_ATT_TO_TYPE(hgap,h_gap)
  _ADD_STD_ATT_TO_TYPE(tilt)
  _ADD_STD_ATT_TO_TYPE(k2)
  _ADD_ATT_TO_TYPE(h1,h)
  _ADD_ATT_TO_TYPE(h2,h)
  _ADD_STD_ATT_TO_TYPE(k3)

  _ADD_TYPE(quadrupole,quadrupole)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(k1)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(sextupole,sextupole)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(k2)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(octupole,octupole)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_STD_ATT_TO_TYPE(k3)

  _ADD_TYPE(multipole,multipole)
  _ADD_ATT_TO_TYPE(lrad,length_radiation)
  _ADD_ATT_TO_TYPE(k*l,k*l)
  _ADD_ATT_TO_TYPE(t*,t*)

  _ADD_TYPE(solenoid,solenoid)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(ks,ks)

  _ADD_TYPE(hkicker,kicker)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(kick,x_kick)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(vkicker,kicker)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(kick,y_kick)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(kicker,kicker)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(hkick,x_kick)
  _ADD_ATT_TO_TYPE(vkick,y_kick)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(rfcavity,rfcavity)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(volt,volt)
  _ADD_ATT_TO_TYPE(lag,lag)
  _ADD_ATT_TO_TYPE(harmon,harmon)
  _ADD_ATT_TO_TYPE(betrf,betrf)
  _ADD_ATT_TO_TYPE(pg,pg)
  _ADD_ATT_TO_TYPE(shunt,shunt)
  _ADD_ATT_TO_TYPE(tfill,tfill)
  _ADD_ATT_TO_TYPE(cavity,cavity)

  _ADD_TYPE(elseparator,elseparator)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(e,e)
  _ADD_STD_ATT_TO_TYPE(tilt)

  _ADD_TYPE(hmonitor,monitor)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(vmonitor,monitor)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(monitor,monitor)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(instrument,instrument)
  _ADD_STD_ATT_TO_TYPE(l)

  _ADD_TYPE(ecollimator,collimator)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(xsize,x_limit)
  _ADD_ATT_TO_TYPE(ysize,y_limit)

  _ADD_TYPE(rcollimator,collimator)
  _ADD_STD_ATT_TO_TYPE(l)
  _ADD_ATT_TO_TYPE(xsize,x_limit)
  _ADD_ATT_TO_TYPE(ysize,y_limit)

  _ADD_TYPE(yrot,patch)
  _ADD_ATT_TO_TYPE(angle,x_ptich)

  _ADD_TYPE(srot,patch)
  _ADD_ATT_TO_TYPE(angle,y_pitch)

  _ADD_TYPE(matrix,taylor)
 // element->addAttribute("rm(*,*)","rm(*,*)"); //any matrix element index
 // element->addAttribute("tm(*,*,*)","tm(*,*,*)");

  _ADD_TYPE(lcav,lcav)

  _ADD_TYPE(beambeam,beambeam)
  _ADD_ATT_TO_TYPE(sigx,sig_x)
  _ADD_ATT_TO_TYPE(sigy,sig_y)
  _ADD_ATT_TO_TYPE(xma,x_offset)
  _ADD_ATT_TO_TYPE(yma,y_offset)
  _ADD_ATT_TO_TYPE(charge,charge)
}

MADXTranslator::~MADXTranslator() {}

struct WriteAttribute{
private:
  std::ostream* file;
  int line_limit;
public:
    WriteAttribute(std::ostream& _file) : file(&_file), line_limit(0) {}
  
  void operator()(UAPAttribute& attrb) {
    std::string attrb_name = attrb.getName();
    if(attrb_name=="name")
      return;
    std::string attrb_value = attrb.getValue();
    (*file)<<","<<attrb_name;
    if(!(attrb_value == ""))
      (*file)<<"="<<attrb_value;
    if(line_limit++>4) {
      (*file)<<" "<<std::endl;
      line_limit = 0;
    }
  }
};

struct WriteBeamlineParameter{
private:
  std::ostream* file;
  bool next_val;
  int line_limit;
public:
    WriteBeamlineParameter(std::ostream& _file)
    : file(&_file), next_val(false), line_limit(0) {}
  
  void operator()(UAPAttribute& attrb) {
    
    if(attrb.getName()=="beamline_parameter"){
      if(next_val)
        (*file)<<",";
      else{
        next_val = true;
      }
      (*file)<<attrb.getValue();
      
      if(line_limit++>4) {
        (*file)<<","<<std::endl<<"  ";
        next_val = false;
        line_limit = 0;
      }
    }
  }
};

/*******************************************************************/

int MADXTranslator::WriteAttributes(AttributeList& attributes)
{
  std::for_each(attributes.begin(), attributes.end(), WriteAttribute((*file)));
  return -1;
}

/*******************************************************************/

int MADXTranslator::UAP_Parameter(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    (*file)<<name<<" := ";
    /* (*file)<<getAttributeString(attributes,"value")<<";"<<std::endl; */
  }
  return -1;
}

int MADXTranslator::UAP_Beamline(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    (*file)<<name;
    
    if(attributes.size()>0){
      (*file)<<"(";
      std::for_each(attributes.begin(), attributes.end(), WriteBeamlineParameter((*file)));
      (*file)<<")";
    }
    
    (*file)<<" : line=(";
    continuation_flag = false;
    line_limit = 0;
  }else
    (*file)<<");"<<std::endl;
  
  return -1;
}

int MADXTranslator::UAP_BeamlineElement(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    std::string xpr = name;
    std::list<std::string> elements;
    DialectUtilities::parseElements(xpr,elements);
    for(std::list<std::string>::iterator it=elements.begin(); it!=elements.end(); ++it)
    {
      if (typeOf(*it) != "beamline" && xpr.length() > (*it).length()){
        // This is a magnet referenced in an arithmetic expression.
        int word_pos = xpr.find(*it);
        std::string replace_word = "("+(*it)+")";
        xpr.replace(word_pos,(*it).length(),replace_word);
      }
    }
    
    if(continuation_flag)
      if((line_limit++)>3){
        (*file)<<", "<<std::endl<<"  ";
        line_limit=0;
      }else
        (*file)<<",";
    (*file)<<xpr;
    continuation_flag = true;
    
  }
  return -1;
}

int MADXTranslator::UAP_Macro(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    
    if(continuation_flag)
      if((line_limit++)>3){
        (*file)<<", "<<std::endl<<"  ";
        line_limit=0;
      }else
        (*file)<<",";
    (*file)<<name<<"(";
    continuation_flag = false;
  }else
    (*file)<<")";
  
  return -1;
}

int MADXTranslator::UAP_Drift(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    _WRITE_NAME(drift)
    WriteAttributes(attributes);
    (*file)<<";"<<std::endl;
  }
  return -1;
}

int MADXTranslator::UAP_Bend(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    _WRITE_NAME(sbend)
    WriteAttributes(attributes);
    (*file)<<";"<<std::endl;
  }
  return -1;
}

int MADXTranslator::UAP_Quadrupole(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    _WRITE_NAME(quadrupole)
    WriteAttributes(attributes);
    (*file)<<";"<<std::endl;
  }
  return -1;
}

int MADXTranslator::UAP_Sextupole(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    _WRITE_NAME(sextupole)
    WriteAttributes(attributes);
    (*file)<<";"<<std::endl;
  }
  return -1;
}

int MADXTranslator::UAP_RFCavity(std::string& name, AttributeList& attributes, int n)
{
  if(n){
    _WRITE_NAME(rfcavity)
    WriteAttributes(attributes);
    (*file)<<";"<<std::endl;
  }
  return -1;
}
