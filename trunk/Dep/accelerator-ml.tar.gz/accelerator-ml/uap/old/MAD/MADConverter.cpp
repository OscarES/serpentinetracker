/* $ANTLR 2.7.0: "MAD_C.g" -> "MADConverter.cpp"$ */
#include "MADConverter.hpp"
#include "antlr/Token.hpp"
#include "antlr/AST.hpp"
#include "antlr/NoViableAltException.hpp"
#include "antlr/MismatchedTokenException.hpp"
#include "antlr/SemanticException.hpp"
#include "antlr/BitSet.hpp"

  #include <iostream>
  #include <queue>
  #include "UAP/UAPNode.hpp"
  #include "UAP/UAPModelBuilder.hpp"
  #include "MAD/MADTranslator.hpp"

MADConverter::MADConverter() {
  setTokenNames(_tokenNames);
}

class UAPNode*  MADConverter::convert(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  class UAPNode* node;
  
  ANTLR_USE_NAMESPACE(antlr)RefAST convert_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  
              node = new UAPNode("UAP_root");
              modelBuilder = new UAPModelBuilder(new MADTranslator, node);
            
  
  try {      // for error handling
    tree(_t);
    _t = _retTree;
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
  return node;
}

void MADConverter::tree(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST tree_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  
  try {      // for error handling
    if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
    switch ( _t->getType()) {
    case MAD:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t113 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp1_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,MAD);
      _t = _t->getFirstChild();
      {
      for (;;) {
        if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
        if ((_tokenSet_0.member(_t->getType()))) {
          tree(_t);
          _t = _retTree;
        }
        else {
          goto _loop115;
        }
        
      }
      _loop115:;
      }
      _t = __t113;
      _t = _t->getNextSibling();
      break;
    }
    case PARAMETER:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t116 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp2_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,PARAMETER);
      _t = _t->getFirstChild();
      twParameter(_t);
      _t = _retTree;
      aval=twAttribValue(_t);
      _t = _retTree;
      
                    modelBuilder->addAttribute("value",aval);
                    modelBuilder->moveToParent();
                  
      _t = __t116;
      _t = _t->getNextSibling();
      break;
    }
    case BEAMLINE:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t117 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp3_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,BEAMLINE);
      _t = _t->getFirstChild();
      twBeamline(_t);
      _t = _retTree;
      {
      if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
      switch ( _t->getType()) {
      case BLPARAMLIST:
      {
        twBlParameters(_t);
        _t = _retTree;
        break;
      }
      case 3:
      case SUBLINE:
      case MACRO:
      case IDENT:
      case MINUS:
      case MULT:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
      }
      }
      }
      {
      for (;;) {
        if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
        if ((_tokenSet_1.member(_t->getType()))) {
          twBLElement(_t);
          _t = _retTree;
          modelBuilder->moveToParent();
        }
        else {
          goto _loop120;
        }
        
      }
      _loop120:;
      }
      modelBuilder->moveToParent();
      _t = __t117;
      _t = _t->getNextSibling();
      break;
    }
    case ELEMENT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t121 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp4_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,ELEMENT);
      _t = _t->getFirstChild();
      twElement(_t);
      _t = _retTree;
      {
      for (;;) {
        if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
        if ((_t->getType()==ATTRIBUTE)) {
          twAttribute(_t);
          _t = _retTree;
        }
        else {
          goto _loop123;
        }
        
      }
      _loop123:;
      }
      modelBuilder->moveToParent();
      _t = __t121;
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_use:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t124 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp5_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_use);
      _t = _t->getFirstChild();
      twUse(_t);
      _t = _retTree;
      modelBuilder->moveToParent();
      _t = __t124;
      _t = _t->getNextSibling();
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twParameter(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twParameter_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,IDENT);
    _t = _t->getNextSibling();
    modelBuilder->addChild("parameter",n->getText());
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

std::string  MADConverter::twAttribValue(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  std::string v;
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twAttribValue_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST f = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
              v = "";
              std::string v1 = "";
              std::string v2 = "";
              std::queue<std::string> args;
            
  
  try {      // for error handling
    if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
    switch ( _t->getType()) {
    case IDENT:
    case NUM_DOUBLE:
    case NUM_FLOAT:
    {
      n = _t==ASTNULL ? ANTLR_USE_NAMESPACE(antlr)nullAST : ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      twConst(_t);
      _t = _retTree;
      v = n->getText();
      break;
    }
    case PLUS:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t137 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp6_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,PLUS);
      _t = _t->getFirstChild();
      v1=twAttribValue(_t);
      _t = _retTree;
      {
      if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
      switch ( _t->getType()) {
      case ATTREF:
      case FUNC:
      case IDENT:
      case LPAREN:
      case MINUS:
      case NUM_DOUBLE:
      case MULT:
      case PLUS:
      case DIV:
      case POW:
      case NUM_FLOAT:
      {
        v2=twAttribValue(_t);
        _t = _retTree;
        break;
      }
      case 3:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
      }
      }
      }
      v = (v2 == "") ? v + "+" + v1 : v + v1 + "+" + v2;
      _t = __t137;
      _t = _t->getNextSibling();
      break;
    }
    case MINUS:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t139 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp7_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,MINUS);
      _t = _t->getFirstChild();
      v1=twAttribValue(_t);
      _t = _retTree;
      {
      if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
      switch ( _t->getType()) {
      case ATTREF:
      case FUNC:
      case IDENT:
      case LPAREN:
      case MINUS:
      case NUM_DOUBLE:
      case MULT:
      case PLUS:
      case DIV:
      case POW:
      case NUM_FLOAT:
      {
        v2=twAttribValue(_t);
        _t = _retTree;
        break;
      }
      case 3:
      {
        break;
      }
      default:
      {
        throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
      }
      }
      }
      v = (v2 == "") ? v + "-" + v1 : v + v1 + "-" + v2;
      _t = __t139;
      _t = _t->getNextSibling();
      break;
    }
    case MULT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t141 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp8_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,MULT);
      _t = _t->getFirstChild();
      v1=twAttribValue(_t);
      _t = _retTree;
      v2=twAttribValue(_t);
      _t = _retTree;
      v = v + v1 + "*" + v2;
      _t = __t141;
      _t = _t->getNextSibling();
      break;
    }
    case DIV:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t142 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp9_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,DIV);
      _t = _t->getFirstChild();
      v1=twAttribValue(_t);
      _t = _retTree;
      v2=twAttribValue(_t);
      _t = _retTree;
      v = v + v1 + "/" + v2;
      _t = __t142;
      _t = _t->getNextSibling();
      break;
    }
    case POW:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t143 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp10_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,POW);
      _t = _t->getFirstChild();
      v1=twAttribValue(_t);
      _t = _retTree;
      v2=twAttribValue(_t);
      _t = _retTree;
      v = v + v1 + "^" + v2;
      _t = __t143;
      _t = _t->getNextSibling();
      break;
    }
    case LPAREN:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t144 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp11_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LPAREN);
      _t = _t->getFirstChild();
      v1=twAttribValue(_t);
      _t = _retTree;
      v = v + "(" + v1 + ")";
      _t = __t144;
      _t = _t->getNextSibling();
      break;
    }
    case FUNC:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t145 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp12_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,FUNC);
      _t = _t->getFirstChild();
      f = _t==ASTNULL ? ANTLR_USE_NAMESPACE(antlr)nullAST : ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      mathFunction(_t);
      _t = _retTree;
      {
      for (;;) {
        if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
        if ((_tokenSet_2.member(_t->getType()))) {
          v1=twAttribValue(_t);
          _t = _retTree;
          args.push(v1);
        }
        else {
          goto _loop147;
        }
        
      }
      _loop147:;
      }
      _t = __t145;
      _t = _t->getNextSibling();
      
                    v = v + f->getText() + "(";
                    while(args.size() > 1){
                      v = v + args.front() + ",";
                      args.pop();
                    }
                    v = v + args.front() + ")";
                  
      break;
    }
    case ATTREF:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t148 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp13_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,ATTREF);
      _t = _t->getFirstChild();
      v1=twAttribValue(_t);
      _t = _retTree;
      v2=twAttribValue(_t);
      _t = _retTree;
      v= v + v1 + "[" + v2 + "]";
      _t = __t148;
      _t = _t->getNextSibling();
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
  return v;
}

void MADConverter::twBeamline(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twBeamline_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,IDENT);
    _t = _t->getNextSibling();
    modelBuilder->addChild("beamline",n->getText());
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twBlParameters(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twBlParameters_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST __t129 = _t;
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp14_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,BLPARAMLIST);
    _t = _t->getFirstChild();
    {
    for (;;) {
      if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
      if ((_t->getType()==IDENT)) {
        n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
        match(_t,IDENT);
        _t = _t->getNextSibling();
        modelBuilder->addAttribute("beamline_parameter",n->getText(),ALLOW_REPEATS);
      }
      else {
        goto _loop131;
      }
      
    }
    _loop131:;
    }
    _t = __t129;
    _t = _t->getNextSibling();
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twBLElement(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twBLElement_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
    switch ( _t->getType()) {
    case IDENT:
    {
      n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,IDENT);
      _t = _t->getNextSibling();
      
                    modelBuilder->addChild("element",n->getText());
                  
      break;
    }
    case MACRO:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t151 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp15_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,MACRO);
      _t = _t->getFirstChild();
      twMacroCall(_t);
      _t = _retTree;
      {
      for (;;) {
        if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
        if ((_tokenSet_1.member(_t->getType()))) {
          twBLElement(_t);
          _t = _retTree;
          modelBuilder->moveToParent();
        }
        else {
          goto _loop153;
        }
        
      }
      _loop153:;
      }
      _t = __t151;
      _t = _t->getNextSibling();
      break;
    }
    case SUBLINE:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t154 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp16_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,SUBLINE);
      _t = _t->getFirstChild();
      modelBuilder->addChild("beamline","");
      {
      for (;;) {
        if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
        if ((_tokenSet_1.member(_t->getType()))) {
          twBLElement(_t);
          _t = _retTree;
          modelBuilder->moveToParent();
        }
        else {
          goto _loop156;
        }
        
      }
      _loop156:;
      }
      _t = __t154;
      _t = _t->getNextSibling();
      break;
    }
    case MINUS:
    case MULT:
    {
      twBLElemMod(_t);
      _t = _retTree;
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twElement(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twElement_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  ANTLR_USE_NAMESPACE(antlr)RefAST m = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,IDENT);
    _t = _t->getNextSibling();
    m = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,IDENT);
    _t = _t->getNextSibling();
    modelBuilder->addChild(m->getText(),n->getText());
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twAttribute(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twAttribute_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    ANTLR_USE_NAMESPACE(antlr)RefAST __t134 = _t;
    ANTLR_USE_NAMESPACE(antlr)RefAST tmp17_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,ATTRIBUTE);
    _t = _t->getFirstChild();
    n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,IDENT);
    _t = _t->getNextSibling();
    {
    if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
    switch ( _t->getType()) {
    case ATTREF:
    case FUNC:
    case IDENT:
    case LPAREN:
    case MINUS:
    case NUM_DOUBLE:
    case MULT:
    case PLUS:
    case DIV:
    case POW:
    case NUM_FLOAT:
    {
      aval=twAttribValue(_t);
      _t = _retTree;
      break;
    }
    case 3:
    {
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
    }
    }
    }
    modelBuilder->addAttribute(n->getText(),aval);
    _t = __t134;
    _t = _t->getNextSibling();
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twUse(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twUse_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,IDENT);
    _t = _t->getNextSibling();
    modelBuilder->addChild("use",n->getText());
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twConst(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twConst_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  
  try {      // for error handling
    if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
    switch ( _t->getType()) {
    case IDENT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp18_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,IDENT);
      _t = _t->getNextSibling();
      break;
    }
    case NUM_FLOAT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp19_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,NUM_FLOAT);
      _t = _t->getNextSibling();
      break;
    }
    case NUM_DOUBLE:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp20_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,NUM_DOUBLE);
      _t = _t->getNextSibling();
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::mathFunction(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST mathFunction_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  
  try {      // for error handling
    if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
    switch ( _t->getType()) {
    case LITERAL_sqrt:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp21_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_sqrt);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_log:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp22_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_log);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_exp:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp23_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_exp);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_sin:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp24_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_sin);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_cos:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp25_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_cos);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_tan:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp26_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_tan);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_asin:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp27_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_asin);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_abs:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp28_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_abs);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_max:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp29_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_max);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_min:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp30_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_min);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_randf:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp31_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_randf);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_gauss:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp32_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_gauss);
      _t = _t->getNextSibling();
      break;
    }
    case LITERAL_tgauss:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp33_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,LITERAL_tgauss);
      _t = _t->getNextSibling();
      break;
    }
    case 46:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp34_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,46);
      _t = _t->getNextSibling();
      break;
    }
    case 47:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp35_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,47);
      _t = _t->getNextSibling();
      break;
    }
    case 48:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp36_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,48);
      _t = _t->getNextSibling();
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twMacroCall(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twMacroCall_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
  
  try {      // for error handling
    n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
    match(_t,IDENT);
    _t = _t->getNextSibling();
    modelBuilder->addChild("macro",n->getText());
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

void MADConverter::twBLElemMod(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
  
  ANTLR_USE_NAMESPACE(antlr)RefAST twBLElemMod_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
  std::string v;
  
  try {      // for error handling
    if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
    switch ( _t->getType()) {
    case MULT:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t158 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp37_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,MULT);
      _t = _t->getFirstChild();
      v=twAttribValue(_t);
      _t = _retTree;
      twBLElement(_t);
      _t = _retTree;
      
                    modelBuilder->addAttribute("repeat",v,false);
                  
      _t = __t158;
      _t = _t->getNextSibling();
      break;
    }
    case MINUS:
    {
      ANTLR_USE_NAMESPACE(antlr)RefAST __t159 = _t;
      ANTLR_USE_NAMESPACE(antlr)RefAST tmp38_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
      match(_t,MINUS);
      _t = _t->getFirstChild();
      twBLElement(_t);
      _t = _retTree;
      
      modelBuilder->addAttribute("reflection","TRUE",false);
      
      _t = __t159;
      _t = _t->getNextSibling();
      break;
    }
    default:
    {
      throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
    }
    }
  }
  catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
    reportError(ex);
    if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
  }
  _retTree = _t;
}

const char* MADConverter::_tokenNames[] = {
  "<0>",
  "EOF",
  "<2>",
  "NULL_TREE_LOOKAHEAD",
  "PARAMETER",
  "ELEMENT",
  "BEAMLINE",
  "SUBLINE",
  "BLPARAMLIST",
  "MACRO",
  "ATTRIBUTE",
  "ATTREF",
  "FUNC",
  "MAD",
  "\"use\"",
  "COMMA",
  "a label",
  "COLON",
  "\"line\"",
  "EQUALS",
  "LPAREN",
  "RPAREN",
  "BECOMES",
  "MINUS",
  "NUM_DOUBLE",
  "MULT",
  "LBRACKET",
  "RBRACKET",
  "PLUS",
  "DIV",
  "MOD",
  "POW",
  "NUM_FLOAT",
  "\"sqrt\"",
  "\"log\"",
  "\"exp\"",
  "\"sin\"",
  "\"cos\"",
  "\"tan\"",
  "\"asin\"",
  "\"abs\"",
  "\"max\"",
  "\"min\"",
  "\"randf\"",
  "\"gauss\"",
  "\"tgauss\"",
  "\"user0\"",
  "\"user1\"",
  "\"user2\"",
  "WS",
  "SEMI",
  "SL_COMMENT",
  "STRING",
  "INCLUDE",
  0
};

const unsigned long MADConverter::_tokenSet_0_data_[] = { 24688UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADConverter::_tokenSet_0(_tokenSet_0_data_,4);
const unsigned long MADConverter::_tokenSet_1_data_[] = { 42009216UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADConverter::_tokenSet_1(_tokenSet_1_data_,4);
const unsigned long MADConverter::_tokenSet_2_data_[] = { 3012630528UL, 1UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet MADConverter::_tokenSet_2(_tokenSet_2_data_,4);


