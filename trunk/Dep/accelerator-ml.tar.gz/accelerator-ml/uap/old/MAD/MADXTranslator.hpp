/*
* MAD-X Translator
* Universal Accelerator Parser
* Copyright (C) 2005 Daniel Bates, Andy Wolski
* 
* This library is free software; you can redistribute it and/or modify it
* under the terms of the GNU Lesser General Public License as published by
* the Free Software Foundation; either version 2.1 of the License, or (at
* your option) any later version. 
* 
* This library is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
* for more details. 
* 
* You should have received a copy of the GNU Lesser General Public License
* along with this library; if not, write to the Free Software Foundation, Inc., 
* 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*
* Direct questions, comments, etc to:
* Daniel Bates (dbates@lbl.gov), Andy Wolski (awolski@lbl.gov) 
*/

#ifndef MADXTranslator_hpp
#define MADXTranslator_hpp 1

#include <iostream>

#include "UAP/DialectTranslator.hpp"

/** @ingroup MAD */
class MADXTranslator : public DialectTranslator
{
public:

  MADXTranslator(std::ostream& _file = std::cout);

  ~MADXTranslator();
  
  void OutputFile(std::ostream& _file);

  int UAP_Parameter(std::string& name, AttributeList& attributes, int n);

  int UAP_Beamline(std::string& name, AttributeList& attributes, int n);

  int UAP_BeamlineElement(std::string& name, AttributeList& attributes, int n);

  int UAP_Macro(std::string& name, AttributeList& attributes, int n);

  int UAP_Drift(std::string& name, AttributeList& attributes, int n);

  int UAP_Bend(std::string& name, AttributeList& attributes, int n);

  int UAP_Quadrupole(std::string& name, AttributeList& attributes, int n);

  int UAP_Sextupole(std::string& name, AttributeList& attributes, int n);

  int UAP_RFCavity(std::string& name, AttributeList& attributes, int n);

  int UAP_Custom(UAPTranslationElement& element, int n);

private:

  int WriteAttributes(AttributeList& attributes);

  int WriteAttributeValues(AttributeList& attributes);

  int WriteMacroParameters(AttributeList& attributes);

  bool continuation_flag;

  int line_limit;
};

#endif
