/*
 * MAD Stream Selector
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov)
 */

#ifndef INC_MADStreamSelector_hpp_
#define INC_MADStreamSelector_hpp_

#include <antlr/config.hpp>
#include <antlr/TokenStreamSelector.hpp>

#include "MAD/MADLexer.hpp"

/** The <code>MADStreamSelector</code> class implements a multiplexor
* of {@link antlr::TokenStream} objects. This allows the use of the "CALL"
* command in MAD input files.
* <p>
* This class inherits all of the methods of the 
* {@link antlr::TokenStream antlr::TokenStream} class.
* <p>
* To use the stream selector with the MAD parser subsystem, a user 
* needs only to instantiate a <code>MADStreamSelector</code> with 
* a <code>MADLexer</code> object and pass this instance to the 
* <code>MADParser</code> constructor. For example:
* <p>
* <code>MADLexer lexer(cin);<br>
* MADStreamSelector selector(lexer);<br>
* MADParser parser(selector);
* </code>
* @author Daniel Bates
* @version 1.0.1, 10/21/05
* @see antlr::TokenStream
* @ingroup MAD
*/
class MADStreamSelector : public ANTLR_USE_NAMESPACE(antlr)TokenStreamSelector{
private:

public:
  /** StreamSelector constructor specifying the initial lexer. 
  * <p>
  * This method adds the specified lexer to the selector and selects it.
  * @param lexer the lexer
  * @since 1.0
  * @see antlr::CharScanner
  */
  MADStreamSelector(MADLexer& lexer);

};

#endif
