#ifndef INC_MADParser_hpp_
#define INC_MADParser_hpp_

#include "antlr/config.hpp"
/* $ANTLR 2.7.0: "MAD_C.g" -> "MADParser.hpp"$ */
#include "antlr/TokenStream.hpp"
#include "antlr/TokenBuffer.hpp"
#include "MADTokenTypes.hpp"
#include "antlr/LLkParser.hpp"


/*
 * MAD Parser
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates, Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov), Andy Wolski (awolski@lbl.gov)
 */
#include <list>
#include "antlr/TokenStreamSelector.hpp"

/** A parser for MAD-8. (You can use this standalone, but you should really
* only use this class with the Universal Accelerator Parser library). Reads a 
* {@link antlr::TokenStream TokenStream} and invokes the appropriate methods in this class.
* @author Daniel Bates
* @version 1.4, 06/21/05
* @ingroup MAD
*/
class MADParser : public ANTLR_USE_NAMESPACE(antlr)LLkParser, public MADTokenTypes
 {
protected:
  MADParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf, int k);
public:
  MADParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf);
protected:
  MADParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer, int k);
public:
  MADParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer);
  MADParser(const ANTLR_USE_NAMESPACE(antlr)ParserSharedInputState& state);
  public: void parseMAD();
  public: void madStatement();
  public: void madAssignment();
  public: void madObject();
  public: void madMacro();
  public: void madElementList();
  public: void madAttribList();
  public: void aExpr();
  public: void madBeamline();
  public: void madBlParamList();
  public: void madElemExpr();
  public: void madElement();
  public: void madAttribute();
  public: void matrixElement();
  public: void aRef();
  public: void prodExpr();
  public: void powExpr();
  public: void tExpr();
  public: void mathFunction();
  public: void atom();
private:
  static const char* _tokenNames[];
  
  static const unsigned long _tokenSet_0_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_0;
  static const unsigned long _tokenSet_1_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_1;
  static const unsigned long _tokenSet_2_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_2;
  static const unsigned long _tokenSet_3_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_3;
  static const unsigned long _tokenSet_4_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_4;
  static const unsigned long _tokenSet_5_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_5;
  static const unsigned long _tokenSet_6_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_6;
  static const unsigned long _tokenSet_7_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_7;
  static const unsigned long _tokenSet_8_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_8;
  static const unsigned long _tokenSet_9_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_9;
  static const unsigned long _tokenSet_10_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_10;
  static const unsigned long _tokenSet_11_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_11;
  static const unsigned long _tokenSet_12_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_12;
  static const unsigned long _tokenSet_13_data_[];
  static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_13;
};

#endif /*INC_MADParser_hpp_*/
