/*
 * UAP Wrapper
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * David Sagan (dcs16@cornell.edu)
 */


#ifndef INC_SAX2Wrapper_hpp_
#define INC_SAX2Wrapper_hpp_ 1

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "UAP/BasicUtilities.hpp"
#include "UAP/UAPNode.hpp"

#include <xercesc/sax2/DefaultHandler.hpp>

XERCES_CPP_NAMESPACE_USE

/** <code>SAX2Wrapper</code> is used to construct the appropriate 
* UAP tree from an SAX file.
* @author David Sagan
* @ingroup SAX
*/

class SAX2Wrapper : private DefaultHandler {
public:

  /** Creates an SAX reader.
  */
  SAX2Wrapper() {};

  /** Destructor. 
  */
  ~SAX2Wrapper() {};
  
  /** Reads in an XML file (or files if there are include statements)
  * and constructs the appropriate UAP tree.
  * The constructed UAP tree has the root &lt;UAPRoot&gt; which
  * in turn has the node &lt;input&gt;. Each child of the &lt;input&gt;
  * is named &lt;file&gt; and contains the information from one SAX input file.
  * Note: The name component of a UAPNode node will be the XML localname. 
  * Not the XML qname.
  * @param file_name The XML file to use.
  * @param root      The root node for building the UAP tree. 
  *                    If Null then a root node will be created.
  * @param convert   Converts entities like "&amp;" to "&".
  * return           True if there are no errors in parsing. False otherwise
  */
  bool XMLFileToUAPRep (const std::string& file_name, UAPNode* root, bool convert = true);

private:

  // -----------------------------------------------------------------------
  //  Implementations of the SAX DocumentHandler interface
  // -----------------------------------------------------------------------

  void endDocument();

  void endElement( const XMLCh* const uri,
                   const XMLCh* const localname,
                   const XMLCh* const qname);

  void characters(const XMLCh* const chars, const unsigned int length);

  void ignorableWhitespace (
    const XMLCh* const  chars,
    const unsigned int   length);

  void processingInstruction (
        const XMLCh* const  target,
        const XMLCh* const  data);

  void startDocument();

  void startElement( const XMLCh* const  uri,
                     const XMLCh* const  localname,
                     const XMLCh* const  qname,
                     const Attributes&   attributes);

  // -----------------------------------------------------------------------
  //  Implementations of the SAX ErrorHandler interface
  // -----------------------------------------------------------------------

  void warning(const SAXParseException& exc);
  void error(const SAXParseException& exc);
  void fatalError(const SAXParseException& exc);

  //------------------------------------------------------------------------

  bool parse_OK;
  bool finished;
  bool convert_entities;           // Convert stuff like "&amp;" to "&"?
  UAPNode* this_root;
  UAPNode* current;

  std::string StrX(const XMLCh* const toTranscode);
  void error_out (const std::string& err_type, const SAXParseException& e);

};

#endif
