/*
 * UAP Lattice Expander
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan, Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu), 
 *   Daniel Bates (dbates@lbl.gov)
 */

#include "AMLLatticeExpander.hpp"

using namespace std;
namespace BU = BasicUtilities;

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

AMLLatticeExpander::AMLLatticeExpander() {
  scratch_root = NULL;
}

AMLLatticeExpander::~AMLLatticeExpander() {
  if (scratch_root) scratch_root->deleteNode();
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

UAPNode* AMLLatticeExpander::AMLExpandLattice(UAPNode* UAPRoot) {

  // init 

  info_out.parsing_status = "Expanding AML Lattice.";
  info_out.ix_line = -1;
  info_out.everything_ok = true;

  if (scratch_root) scratch_root->deleteNode();
  scratch_root = new UAPNode("scratch_root");

  // Find the <AML_representation> node to expand.

  NodeVec aml_rep_list = UAPRoot->getChildrenByName("AML_representation");
  if (aml_rep_list.size() == 0) {
    info_out.error ("Cannot find node: \"AML_representation\"",
                 "Which should be a subnode of the root node");
    return NULL;
  }
  if (aml_rep_list.size() > 1) {
    info_out.error ("More than one \"AML_representation\" node!");
    return NULL;
  }

  // Add the <expanded_lattice> node. If it already exists then delete any subnodes.

  NodeVec expand_list = UAPRoot->getChildrenByName("expanded_lattice");
  for (NodeVecIter it = expand_list.begin(); it != expand_list.end(); it++)
    (*it)->deleteNode();
  UAPNode* expand_root = UAPRoot->addChild("expanded_lattice");

  // Make a copy of <AML_representation> and make a list of all elements, etc.

  UAPNode* aml_rep = scratch_root->addChildCopy(aml_rep_list.front());
  all_map.clear();
  make_named_lists(aml_rep);
  
  // Handle preexpansion sets and evaluate all expressions.

  InheritBookkeeper (aml_rep);
  apply_sets ("set", "value", aml_rep);
  apply_sets ("string_set", "string", aml_rep);
  UAPUtilities utilities(aml_rep);
  utilities.evaluate();
  convert_to_actual (aml_rep);

  // Add <control_list> and <global> children and transfer the global information.

  control_root = expand_root->addChild("control_list");
  global_root = expand_root->addChild("global");
  
  NodeVec global_list = aml_rep->getSubNodesByName("global");
  if (global_list.size() > 1) info_out.error ("Multiple <global> nodes");
  if (global_list.size() == 1) transfer_info_to_new_node (global_list.front(), global_root);

  // Construct the machines 
  // Connect branch and merger nodes 

  if (!expand_machines(aml_rep, expand_root)) return NULL;
  if (!connect_branch_and_merger(expand_root)) return NULL;

  // Add superpositions. 
  // Do not superimpose sub-nodes of a sector. This has already been done.
  // The parent of <superimpose> is the <element> to be superimposed.

  NodeVec supers = aml_rep->getSubNodesByName("superimpose");
  for (NodeVecIter is = supers.begin(); is != supers.end(); is++) {
    UAPNode* ele_or_sect = (*is)->getParent(); 
    if (ele_or_sect->getParent()->getName() == "sector") continue;
    superimpose_element (ele_or_sect, expand_root);
  }

  // Add controls.

  if (!add_controls(aml_rep, expand_root)) return NULL;
  AU.controllerBookkeeper (expand_root);

  // Postexpansion sets.

  apply_post_sets ("post_set", "value", aml_rep, expand_root);
  apply_post_sets ("post_string_set", "string", aml_rep, expand_root);

  if (! info_out.everything_ok) return NULL;
  return expand_root;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLLatticeExpander::InheritBookkeeper (UAPNode* root) {

  // Need a local copy of info_out since this method is static and cannot use the
  // info_out defined in the AMLLatticeExpander class.

  PrintInfoStruct info_out;

  // Find all inheritance instances and all named node.

  NodeVec inherit_list = Twig::getSubNodes(root, "(inherit)");
  NodeVec named_list = Twig::getSubNodes(root, "(name)");

  // Must inherit in the correct order in case there is a chain of inheritances.
  // First construct a tree in which the children inherit information from the parents. 
  // Since we don't want to reorder the real tree, we use the connect component
  // to store a reference from the inheritance tree to the real tree.

  bool ok = true;
  UAPNode* root_ref = new UAPNode("root");  // root of inheritance tree.
  NodeMap node_map;         // maps a name to a node in the inheritance tree.

  // Loop over all "to" nodes (nodes that inherit from a base (or "from") node).

  for (NodeVecIter il = inherit_list.begin(); il != inherit_list.end(); il++) {

    UAPNode* to_node = *il;
    string from_str = to_node->getAttributeString("inherit");
    string to_str = to_node->getAttributeString("name");

    // Change attribute name "inherit" to "inherited_from" to show that the 
    // inheritance information has been transferred.

    to_node->getAttribute("inherit")->setName("inherited_from");

    // Find corresponding from_node.

    bool found_node = false;

    if (BU::found(node_map, from_str)) {

      // If both the from_node and to_node are already in the inheritance tree
      // then we need to move things around in the tree and make the to_node
      // the child of the from_node.

      if (BU::found(node_map, to_str)) {
        UAPNode* to_node_ref = node_map[to_str];
        UAPNode* parent = to_node_ref->getParent();
        to_node_ref->detachNode();
        UAPNode* from_node_ref = node_map[from_str];
        from_node_ref->getChildren().push_back(to_node_ref);

      // If the from_node is already in the tree and the to_node is not, then
      // add the to_node as a child
 
      } else if (BU::found(node_map, from_str)) {
        UAPNode* from_node_ref = node_map[from_str];
        UAPNode* to_node_ref = from_node_ref->addChild(to_str);
        to_node_ref->setConnect(to_node);
        if (to_str != "") node_map[to_str] = to_node_ref;
      }

    // else the from_node is not in the tree so we need to find it.

    } else {

      UAPNode* from_node = NULL;
      for (NodeVecIter nl = named_list.begin(); nl != named_list.end(); nl++) {
        if ((*nl)->getAttributeString("name") != from_str) continue;
        from_node = *nl;
        break;
      }

      if (!from_node) {
        ok = false;
        info_out.error ("CANNOT FIND BASE NODE FOR INHERITANCE.", to_node->toString());

      // If the to_node is already in the tree, then
      // we need to move the to_node.

      } else if (BU::found(node_map, to_str)) {
        UAPNode* from_node_ref = root_ref->addChild(from_str);
        from_node_ref->setConnect(from_node);
        node_map[from_str] = from_node_ref;
        UAPNode* to_node_ref = node_map[to_str];
        UAPNode* parent = to_node_ref->getParent();
        to_node_ref->detachNode();
        from_node_ref->getChildren().push_back(to_node_ref);

      // If neither are in the tree then add both.

      } else {
        UAPNode* from_node_ref = root_ref->addChild(from_str);
        from_node_ref->setConnect(from_node);
        node_map[from_str] = from_node_ref;
        UAPNode* to_node_ref = from_node_ref->addChild(to_str);
        to_node_ref->setConnect(to_node);
        if (to_str != "") node_map[to_str] = to_node_ref;
      }

    }

  }

  // Now do the actual work of moving the inheritance information

  NodeVec children = root_ref->getChildren();
  for (NodeVecIter ir = children.begin(); ir != children.end(); ir++) 
    inherit_from (*ir);

  // Cleanup

  root_ref->deleteNode();
  return ok;
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::inherit_from (UAPNode* parent_ref) {

  // The actual from_node is in the connect component of parent_ref

  UAPNode* from_node = parent_ref->getConnect();

  // The connect component of the children of parent_ref is a reference to
  // The to_nodes

  NodeVec children_ref = parent_ref->getChildren();
  for (NodeVecIter ir = children_ref.begin(); ir != children_ref.end(); ir++) {
    UAPNode* child_ref = *ir;
    UAPNode* to_node = child_ref->getConnect();

    NodeVec pc = from_node->getChildren();
    for (NodeVecIter ic = pc.begin(); ic != pc.end(); ic++) 
      inherit_pusher (*ic, to_node);

    // Now push the info from the children to the gradchildren...

    inherit_from (child_ref);
  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::inherit_pusher (UAPNode* from_child, UAPNode* to_node) {

  // Existing information in the child takes priority over information in the parent. 
    
  string from_str = from_child->getName();
  UAPNode* to_child = to_node->getChildByName(from_str);
  
  if (to_child) {
    NodeVec pc = from_child->getChildren();
    for (NodeVecIter ic = pc.begin(); ic != pc.end(); ic++) 
      inherit_pusher (*ic, to_child);

  } else {
    // Since info is not in the to_node, push the info from the from_child.
    to_node->addChildCopy(from_child);
  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::make_named_lists(UAPNode* root) {

  // Transverse all sub nodes and make a complete list of named elements.

  NodeVec children = root->getChildren();
  for (NodeVecCIter in = children.begin(); in != children.end(); in++) {
    UAPNode* node = *in;
    make_named_lists (node); 
    if (!node->getAttribute("name")) continue;
    string name = node->getAttributeString("name");
    if (all_map.find(name) != all_map.end() ) {
      info_out.error ("Duplicate named element: " + name);
    }
    all_map[name] = node;
    if (node->getName() == "element")    element_map[name] = node;
    if (node->getName() == "controller") controller_map[name] = node;
    // Note: At presnet girder_map is not being used.
    if (node->getName() == "girder")     girder_map[name] = node;
  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLLatticeExpander::expand_machines (UAPNode* aml_rep, UAPNode* expand_root) {
  
  string name, ref;
  NodeVec ref_list, name_list, machine_list; 
  StrList duplicates;
  
  // Make a list of all <sector>s that have a "name" attribute. 
  // This defines these sectors 

  sector_map.clear(); 
  duplicates.clear();
  NodeVec children = aml_rep->getChildren();
  for (NodeVecCIter im = children.begin(); im != children.end(); im++) {  
    map_sub_nodes (*im, "sector", "name", sector_map, duplicates, false);
  }
  for (StrListCIter ia=duplicates.begin(); ia!=duplicates.end(); ia++) {  
    info_out.error ("Duplicate sector name: " + *ia);
  }
  
  // Make a map of all named <list>s

  NodeMap list_map; 
  duplicates.clear();
  for (NodeVecCIter im=machine_list.begin(); im!=machine_list.end(); im++) {  
    map_sub_nodes (*im, "list", "name", list_map, duplicates, false);
  }
  for (StrListCIter ia=duplicates.begin(); ia!=duplicates.end(); ia++) {  
    info_out.error ("Two <list>s have the same \"name\": " + *ia);
  }
  
  // Expand <list>s

  UAPNode* lists_root = scratch_root->addChild("lists_root");

  for (NodeMapIter it = list_map.begin(); it != list_map.end(); it++) {
    UAPNode* this_root = lists_root->addChild(it->first);
    sector_call_list.clear();
    expand_this_sector_or_list (this_root, it->second, +1, false, true, "");
  }
  
  // Setup list_map pointing to expanded lists

  map_list_children.clear();
  map_list_iter.clear();
  
  NodeVec l_child = lists_root->getChildren();
  for (NodeVecCIter it = l_child.begin(); it != l_child.end(); it++) {
    string name = (*it)->getName();
    map_list_children[name] = (*it)->getChildren();      
    map_list_iter[name] = map_list_children[name].begin();
  }
  
  // Construct a list of all the machines 

  machine_list = aml_rep->getSubNodesByName("machine");
  for (NodeVecCIter it=machine_list.begin(); it!=machine_list.end(); it++) {
    bool has_name = (*it)->getAttribute("name");
    bool has_ref  = (*it)->getAttribute("ref");
    if (has_name && has_ref) {
      info_out.error ("\"machine\" Node has both \"name\" and \"ref\" attributes!", 
                   (*it)->toString());
    }
    if (has_ref) ref_list.push_back(*it);
    if (has_name) name_list.push_back(*it);
  }
  
  // Check that for all reference machines there is a named machine 

  for (NodeVecCIter ir=ref_list.begin(); ir!=ref_list.end(); ir++) {
    UAPAttribute* attrib_ref = (*ir)->getAttribute("ref");
    ref = attrib_ref->getValue();
    bool match = false;
    for (NodeVecCIter im=name_list.begin(); im!=name_list.end(); im++) {
      name = (*im)->getAttributeString("name");
      if (ref == name) match = true;
    }
    if (!match) {                                    
      info_out.error ("Reference machine with reference to: " + ref, 
                   "Not matched any machine with that name!", (*ir)->toString());
    }
  }
  
  // The last machine is the root machine used for expansion. 
  // If this machine is a sub machine then actually its parent is the root machine.
  // Loop over all machines and expand 

  if (machine_list.size() == 0) {
    info_out.error("No machine found to expand");
    return false;
  }

  UAPNode* machine_root = machine_list.back();
  if (machine_root ->getParent()->getName() == "machine") 
                                    machine_root = machine_root->getParent();
  if (machine_root->getAttribute("ref")) {
    ref = machine_root->getAttributeString("ref");
    for (NodeVecCIter im=name_list.begin(); im!=name_list.end(); im++) {
      name = (*im)->getAttributeString("name");
      if (ref == name) {
        machine_root = *im;
        break;
      }
    }
  }

  // The root machine either has sub-machines or a sector.

  NodeVec m_list = machine_root->getChildrenByName("machine");
  if (m_list.size() > 0) {
    for (NodeVecIter im = m_list.begin(); im != m_list.end(); im++) {
      if ((*im)->getAttribute("ref")) {
        ref = (*im)->getAttributeString("ref");
        for (NodeVecCIter in = name_list.begin(); in != name_list.end(); in++) {
          name = (*in)->getAttributeString("name");
          if (name == ref) expand_this_machine(*in, aml_rep, expand_root);
        }
      } else {
        expand_this_machine (*im, aml_rep, expand_root);
      }
    }
  } else {
    expand_this_machine (machine_root, aml_rep, expand_root);
  }

  // Cleanup

  return info_out.everything_ok;
  
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::expand_this_machine (UAPNode* machine_in, UAPNode* aml_rep, 
                                                                 UAPNode* expand_root) {
  
  string value;
  NodeVec a_list;
  UAPNode* machine;
  string sector_name;
  StrList duplicates;
  
  // Add a <machine> child to expand_root

  machine = expand_root->addChild("machine");
  if (UAPAttribute* attrib = machine_in->getAttribute("name"))
                                      machine->addAttribute("name", attrib->getValue());
  UAPNode* tracking_root = machine->addChild("tracking_lattice");
      
  
  // Add the master_list node

  master_root = machine->addChild("master_list");

  // Add the beginning marker

  UAPNode* child = tracking_root->addChild("element");
  child->addAttribute("name", "beginning");
  child->addChild("marker");
  
  // Find the root sector which is the child of the machine

  if (machine_in->getChildrenByName("sector").size() != 1) {
    info_out.error ("Machine does not have exactly one sector: " + machine_in->toString());
    return;
  }

  // Start with the root sector and expand 

  UAPNode* sector_root = machine_in->getChildByName("sector");
  expand_this_sector_or_list (tracking_root, sector_root, 1, false, false, "");

  // Convert: design + err -> actual.
  // Also: Find element longitudinal positions.

  calc_s_positions (tracking_root);

  // Transfer any <beam> and <lattice> info.

  transfer_node_info_to_machine ("beam", aml_rep, machine_in, machine);
  transfer_node_info_to_machine ("lattice", aml_rep, machine_in, machine);

  // clear sector_call_list and multi_map 

  sector_call_list.clear();
  for (MultiMap::iterator it = multi_map.begin(); it != multi_map.end(); it++) 
    delete it->second;
  multi_map.clear();

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::transfer_node_info_to_machine (string who, 
                       UAPNode* aml_rep, UAPNode* machine_in, UAPNode* machine) {

  // machine_in is a sub-node of <aml_rep>.
  // machine is a sub-node of <expanded_lattice>.

  // Do not use any <who> nodes that are children of other <machine> nodes.
  // <who> nodes in <machine> take precedence.

  // First find the global <who> node

  NodeVec who_list = aml_rep->getSubNodesByName(who);

  UAPNode* global_who = NULL; 
  for (NodeVecCIter ib = who_list.begin(); ib != who_list.end(); ib++) {  
    UAPNode* this_who = *ib;
    UAPNode* parent = this_who;
    while (parent != aml_rep) {
      parent = parent->getParent();
      if (parent->getName() == "machine") break;
      if (global_who) {
        info_out.error ("Multiple global <" + who + "> nodes");
      }
      if (parent == aml_rep) global_who = this_who;
    }
  }

  // Now add on <beam> nodes that are childrent of machine_in.

  who_list = machine_in->getSubNodesByName(who);
  if (who_list.size() > 1) {
    info_out.error ("Multiple <" + who + "> nodes in machine", machine_in->toString());
  }

  // Add info from global <who> to the local <who>.

  UAPNode* who_root = machine->addChild(who);
  if (global_who) transfer_info_to_new_node (global_who, who_root);
  if (who_list.size() > 0) transfer_info_to_new_node (who_list.front(), who_root);
  convert_to_actual (who_root);
  
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::transfer_info_to_new_node (UAPNode* old_node, UAPNode* new_node) {

  // Transfer attributes
  
  AttributeVec old_att = old_node->getAttributes();
  for (AttributeVecCIter ia = old_att.begin(); ia != old_att.end(); ia++) 
    new_node->addAttribute(ia->getName(), ia->getValue());
  
  // Transfer children

  NodeVec old_children = old_node->getChildren();
  for (NodeVecCIter in = old_children.begin(); in != old_children.end(); in++) {
    UAPNode* old_child = *in;
    string name = old_child->getName();
    UAPNode* new_child = new_node->getChildByName(name);
    if (new_child)
      transfer_info_to_new_node (old_child, new_child);
    else
      new_node->addChildCopy(old_child);
  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::superimpose_sector_given_ref (UAPNode* super_sect_in, 
                                             UAPNode* ref_ele, string ref_origin) {


  bool ok;

  // Find reference point.

  double ref_len = AU.getAMLAttributeNumericValue(ref_ele, "length@actual", ok);
  double s_ref = AU.getAMLAttributeNumericValue(ref_ele, "s@actual", ok);  // s at end of element

  UAPNode* superimpose_node = super_sect_in->getChildByName("superimpose");
  if (!superimpose_node) {
    info_out.error ("Cannot find <superimpose> of element.",
                 super_sect_in->toStringTree());
    return;
  }

  string ref_origin2 = superimpose_node->getAttributeString("ref_origin");
  if (ref_origin2 != "") ref_origin = ref_origin2;

  if (ref_origin == "ENTRANCE")
    s_ref = s_ref - ref_len;
  else if (ref_origin == "" || ref_origin == "CENTER")
    s_ref = s_ref - ref_len/2;
  else if (ref_origin != "EXIT") {
    info_out.error ("Bad \"ref_origin\" attribute for superposition: " + 
                                                     superimpose_node->toString());
    return;
  }

  // call superimpose_sector_given_s

  UAPNode* machine_root = ref_ele->getParent()->getParent();
  superimpose_sector_given_s (super_sect_in, s_ref, machine_root);
  return;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::superimpose_sector_given_s (UAPNode* super_sect_in, 
                                 double s_entrance, UAPNode* machine_root, string tag) {

  bool ok;

  // Find the associated named sector.

  UAPNode* super_sect = super_sect_in;
  string sector_name = super_sect_in->getAttributeString("ref");
  if (sector_name != "") {
    super_sect = sector_map[sector_name];
    if (!super_sect) {
      info_out.error ("No sector could be found named: " + sector_name,
                   "Needed for: " + super_sect_in->toString());
      return;
    }
  }

  double length = BU::string_to_double(super_sect->getAttributeString("length"), ok);

  // Superimpose elements within this sector.

  NodeMap sector_child_eles;

  NodeVec sect_eles = super_sect->getChildren();
  for (NodeVecIter ie = sect_eles.begin(); ie != sect_eles.end(); ie++) {

    UAPNode* ele = *ie;

    // Find superimpose child of the element

    UAPNode* superimpose = ele->getChildByName("superimpose");
    if (!superimpose) {
      info_out.error ("Element does not have <superimpose> child.", ele->toStringTree());
      return;
    }

    // Check for an explicit reference element.

    UAPNode* ref_ele;
    string ref_name = superimpose->getAttributeString("ref_element");
    if (ref_name != "") {
      ref_ele = sector_child_eles[ref_name];
      if (!ref_ele) {
        info_out.error("Unknown reference element: " + superimpose->toString(),
                    "In element of sector:",
                    super_sect->toStringTree());
        return;
      }
    }

    // Check for a ref_origin

    double s_ref = s_entrance;  // Default
    string ref_origin = superimpose->getAttributeString("ref_origin");
    if (ref_origin == "CENTER") 
      s_ref = s_entrance + length / 2;
    else if (ref_origin == "EXIT") 
      s_ref = s_entrance + length;
    else if (ref_origin != "ENTRANCE") {
      info_out.error ("Bad \"ref_origin\" value: " + ref_origin,
                   ele->toStringTree());
      return;
    }

    // If the sector child is an element then superimpose it

    if (ele->getName() == "element") {

      // Superimpose the element and add it to the list of elements.

      UAPNode* added_ele;
      if (ref_name == "")
        added_ele = superimpose_element_given_s (ele, s_ref, machine_root);
      else 
        added_ele = superimpose_element_given_ref (ele, ref_ele);

      if (!added_ele) return;  // Return on info_out.
      string ele_name = ele->getAttributeString("ref");
      if (ele_name == "") ele_name = ele->getAttributeString("name");
      sector_child_eles[ele_name] = added_ele;

    // If the sector child is a sector then recursively call this routine.

    } else if (ele->getName() == "sector") {
      if (ref_name == "")
        superimpose_sector_given_s (ele, s_ref, machine_root, tag);
      else 
        superimpose_sector_given_ref (ele, ref_ele);
      

    // Else must be an info_out.

    } else {
      info_out.error ("Unknown child: " + ele->toString(),
                   "Of sector: " + super_sect_in->toString());
      return;
    }

  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::superimpose_element (UAPNode* super_ele, UAPNode* expand_root) {

  // Get the superposition info.

  if (super_ele->getName() != "element") {
    info_out.error ("Error in superimpose_element routine.", 
                 "Node argument is not an <element>: ",
                 super_ele->toString());
    return;
  }

  UAPNode* superimpose_node = super_ele->getChildByName("superimpose");
  if (!superimpose_node) {
    info_out.error ("Error in superimpose_element routine.",
                 "Cannot find superimpose node in element:",
                 superimpose_node->toStringTree()); 
    return;
  }

  // Make a list of all elements that have the name of the reference element. 

  string ref_name = superimpose_node->getAttributeString("ref_element");
  if (ref_name == "") ref_name = "beginning";

  NodeVec ref_eles = get_named_elements (ref_name, expand_root);
  if (ref_eles.empty()) {
    info_out.error ("No reference element found in lattice with name: " + ref_name,
                 "For superpostion: " + superimpose_node->toString());
    return;
  }

  // Now do a superposition for each reference element.

  for (NodeVecIter ie = ref_eles.begin(); ie != ref_eles.end(); ie++) {
    UAPNode* ref_ele = *ie;

    // Easy case: Reference element is not a multipass_lord.

    if (ref_ele->getAttributeString("lord_rank") != "MULTIPASS_LORD") {
      superimpose_element_given_ref (super_ele, ref_ele);
      continue;
    }

    // Reference element = multipass_lord -> apply superposition to all
    // multipass_slaves.

    NodeVec slaves = ref_ele->getList(SLAVE);
    for (NodeVecIter is = slaves.begin(); is != slaves.end(); is++) {
      UAPNode* slave = *is;
      superimpose_element_given_ref (super_ele, ref_ele);
      // remove reference to multipass in slave.
    }

  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

UAPNode* AMLLatticeExpander::superimpose_element_given_ref (UAPNode* ele_in, 
                                                              UAPNode* ref_ele) {

  bool ok;

  // Find reference point. s_ref = s at end of element

  double ref_len = AU.getAMLAttributeNumericValue(ref_ele, "length@actual", ok);
  double s_ref = AU.getAMLAttributeNumericValue(ref_ele, "s@actual", ok);  

  UAPNode* superimpose_node = ele_in->getChildByName("superimpose");
  if (!superimpose_node) {
    info_out.error ("Cannot find <superimpose> of element.",
                 ele_in->toStringTree());
    return NULL;
  }

  string ref_origin = superimpose_node->getAttributeString("ref_origin");
  if (ref_origin == "ENTRANCE")
    s_ref = s_ref - ref_len;
  else if (ref_origin == "" || ref_origin == "CENTER")
    s_ref = s_ref - ref_len/2;
  else if (ref_origin != "EXIT") {
    info_out.error ("Bad \"ref_origin\" attribute for superposition: " + 
                                                     superimpose_node->toString());
    return NULL;
  }

  // Let superimpose_element_given_s do the rest of the work.

  UAPNode* machine_root = ref_ele->getParent()->getParent();
  return superimpose_element_given_s (ele_in, s_ref, machine_root);

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

UAPNode* AMLLatticeExpander::superimpose_element_given_s (UAPNode* ele_in, 
                                      double s_ref, UAPNode* machine_root) {

  bool ok;

  // If ele_in has a reference then find the element definition

  UAPNode* super_ele = ele_in;
  string ele_name = ele_in->getAttributeString("ref");
  if (ele_name != "") {
    if (!BU::found(element_map, ele_name)) {
      info_out.error ("Element not found: " + ele_name,
                   "Referred to in: " + ele_in->toString());
      return NULL;
    }
    super_ele = element_map[ele_name];
  }

  // Get the tracking_lattice node, etc.

  UAPNode* tracking_root = machine_root->getChildByName("tracking_lattice");

  // Transfer the super_ele to the master list and evaluate all parameters.

  master_root = machine_root->getChildByName("master_list");
  UAPNode* super_lord = master_root->addChildCopy(super_ele);

  UAPNode* superimpose_node = ele_in->getChildByName("superimpose");
  if (!superimpose_node) {
    info_out.error ("Cannot find <superimpose> of element.",
                 ele_in->toStringTree());
    return NULL;
  }

  string ele_origin = superimpose_node->getAttributeString("ele_origin");

  // Compute ends of superimpose element. 
  // If a circular machine then the element may wrap around the origin.

  double offset = 0;
  if (UAPAttribute* off = superimpose_node->getAttribute("offset")) 
    offset = BU::string_to_double(off->getValue(), ok);

  double super_len = AU.getAMLAttributeNumericValue(super_lord, "length@actual", ok);
  if (!ok) {
    info_out.error ("Bad attribute \"length\" value of element:", super_lord->toStringTree()); 
    return NULL;
  }

  double s1 = s_ref + offset;  // s value at entrance end of superimposed element
  if (ele_origin == "EXIT")
    s1 = s1 - super_len;
  else if (ele_origin == "" || ele_origin == "CENTER")
    s1 = s1 - super_len/2;
  else if (ele_origin != "ENTRANCE") {
    info_out.error ("Bad \"ele_origin\" attribute for superposition: " + 
                                                     superimpose_node->toString());
    return NULL;
  }

  double s2 = s1 + super_len;  // s value at exit end of superimposed element

  UAPNode* ele = *(tracking_root->getChildren().begin());

  double s1_lat = AU.getAMLAttributeNumericValue (ele, "s@actual", ok);
  if (!ok) {
    info_out.error ("Bad \"s\" attribute of element:", ele->toStringTree());
    return NULL;
  }

  ele = tracking_root->getChildren().back();

  double s2_lat = AU.getAMLAttributeNumericValue (ele, "s@actual", ok);
  if (!ok) {
    info_out.error ("Bad \"s\" attribute of element:", ele->toStringTree());
    return NULL;
  }

  double len_lat = s2_lat - s1_lat;

  UAPNode* g_node = machine_root->getChildByName("lattice");
  if (g_node) g_node = g_node->getChildByName("geometry");
  string geometry = "";
  if (g_node) geometry = g_node->getAttributeString("type");
  
  if (s1 < s1_lat) {
    if (geometry != "CIRCULAR") {
      info_out.error ("Superposition extends beyond beginning of lattice");
      return NULL;
    }
    s1 = s1 + len_lat;
  }

  if (s2 > s2_lat) {
    if (geometry != "CIRCULAR") {
      info_out.error ("Superposition extends beyond end of lattice");
      return NULL;
    }
    s2 = s2 - len_lat;
  }

  // If element has zero length then just insert it into the lattice list and
  // delete the existing super_lord.

  NodeVecIter s1_iter, s2_iter;
  if (super_len == 0) {
    AU.splitElement (machine_root, s1, s1_iter);
    UAPNode* new_ele = tracking_root->addChildCopy (super_lord, *s1_iter);
    new_ele->getChildByName("superimpose")->deleteNode();
    super_lord->deleteNode();
    calc_s_positions (tracking_root);
    return new_ele;
  }

  // Here we are superimposing an element of non-zero length...
  // First, split-up any elements as needed.
  // Since iterator points to element ahead of the split, we need to split largest s first.

  if (s2 > s1) {
    AU.splitElement (machine_root, s2, s2_iter);
    AU.splitElement (machine_root, s1, s1_iter);
  } else {
    AU.splitElement (machine_root, s1, s1_iter);
    AU.splitElement (machine_root, s2, s2_iter);
  }

  // Put in the master/slave links.

  super_lord->addAttribute("lord_rank", "SUPER_LORD");
  super_lord->addChild("s")->addAttribute("actual", BU::double_to_string(s2, ok));
  super_lord->getChildByName("superimpose")->deleteNode();

  for (NodeVecIter in = s1_iter; in != s2_iter; in++) {

    // Wrap around the end if needed (for a circular lattice).
    // Also do not touch the beginning marker node.

    if (in == tracking_root->getChildren().end()) 
      in = tracking_root->getChildren().begin();

    if (in == tracking_root->getChildren().begin()) in++;

    UAPNode* this_ele = *in;

    // If this element has zero length then just leave it alone.

    if (AU.getAMLAttributeNumericValue(this_ele, "length@actual", ok) == 0) continue;

    // Easy case where the element is already a super_slave.

    if (this_ele->getAttributeString("slave_rank") == "SUPER_SLAVE") {
      this_ele->add(MASTER, super_lord);
      super_lord->add(SLAVE, this_ele);
      continue;
    }

    // If the element is not a super_slave then we must create a corresponding
    // super_lord element.

    UAPNode* super_this_ele = master_root->addChildCopy(this_ele);
    super_this_ele->addAttribute("lord_rank", "SUPER_LORD");
    super_this_ele->add(SLAVE, this_ele);

    super_lord->add(SLAVE, this_ele);

    this_ele->addAttribute("slave_rank", "SUPER_SLAVE");
    this_ele->add(MASTER, super_this_ele);
    this_ele->add(MASTER, super_lord);

    // Super slaves do not have a design or err length values.
    UAPNode* len_node = this_ele->getChildByName("length");
    len_node->removeAttribute("design");
    len_node->removeAttribute("err");

  }

  AU.form_super_slave_names(super_lord);
  calc_s_positions (tracking_root);

  return super_lord;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

NodeVec AMLLatticeExpander::get_named_elements (const string& ref_name, UAPNode* root) {

  NodeVec match_eles;

  NodeVec eles = root->getSubNodesByName("element");
  for (NodeVecIter ie = eles.begin(); ie != eles.end(); ie++) {
    UAPNode* ref_ele = *ie;
    string name = ref_ele->getAttributeString("name");
    if (name == ref_name) match_eles.push_back(ref_ele);
  }

  return match_eles;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------
//+
// Method to expand a sector named by sector_in.
// The expanded lattice is added to the tracking_root children.
//-

void AMLLatticeExpander::expand_this_sector_or_list (UAPNode* tracking_root, 
      UAPNode* sector_in, int direction, bool multipass, bool expanding_a_list, string prefix) {
  
  // Get the name of this sector 

  bool has_name = sector_in->getAttribute("name");
  bool has_ref  = sector_in->getAttribute("ref");
  string sector_name = "";
  if (has_name) sector_name = sector_in->getAttributeString("name");
  if (has_ref)  sector_name = sector_in->getAttributeString("ref");
  
  // Check that we are not in an infinite loop.
  // sector_call_list is the list of sectors that have been called.

  for (StrListCIter it = sector_call_list.begin(); it != sector_call_list.end(); it++) {
    if (sector_name == *it) {
      info_out.error ("Infinite loop expanding machine");
      throw;
    }
  }
  if (has_name || has_ref) sector_call_list.push_back(sector_name);

  // Find the sector definition.
  // That is, find the sector node that holds the definition of sector_in. 

  UAPNode* sector_def; // The named sector gives the sector definition.
  if (sector_in->getName() == "list") {
    sector_def = sector_in;
  } else if (has_name || has_ref) {
    sector_def = sector_map[sector_name];
    if (!sector_def) {
      info_out.error ("No sector could be found named: " + sector_name,
                   "Needed for: " + sector_in->toString());
      return;
    }
  // If sector_in has no name, sector_in itself contain the definition.
  } else {      
    sector_def = sector_in;
  }

  NodeVec children = sector_def->getChildren();

  // Look for a length attribute. 

  bool has_length = (sector_def->getAttribute("length") != NULL);

  // Is there a repeat count? 

  int repeat = 1;

  if (UAPAttribute* attrib = sector_in->getAttribute("repeat")) {
    if (!attrib->getInt(repeat)) {
      info_out.error ("Sector repeat attribute is not an integer", sector_in->toString());
    }
  }
  
  // Is there an argument list? 
  // If there is a problem then don't try to process this sector 

  StrMap arg_map;
    if (!get_arg_map (sector_in, sector_def, arg_map)) return;
  
  // Forward or backward? 

  bool reflect;
  if (UAPAttribute* attrib = sector_in->getAttribute("reflection")) {
    reflect = false;
    if (!attrib->getBool(reflect)) {
      info_out.error ("Sector reflection attribute is not a true or false", 
                    sector_in->toString());
    }
    if (has_length) {
      info_out.error ("A sector cannot have both \"reflection\" and \"length\" attributes.",
                    sector_in->toString());
      return;
    }
    if (reflect) direction = -direction;
  }
  
  // Multipass: A multipass attribute in a sector reference will 
  // override A multipass attribute in a sector definition.

  bool multi = false;

  if (UAPAttribute* attrib = sector_def->getAttribute("multipass")) {
    if (expanding_a_list) {
      info_out.error ("Multipass attribute not allowed a list definition",
                   "Bad <sector>: " + sector_def->toString());
    }
    if (!attrib->getBool(multi)) {
      info_out.error ("Sector multipass attribute is not a true or false",
                   "Bad <sector>: " + sector_def->toString());
    }
  }

  if (UAPAttribute* attrib = sector_in->getAttribute("multipass")) {
    if (expanding_a_list) {
      info_out.error ("Multipass attribute not allowed a list definition",
                   "Bad <sector>: " + sector_in->toString());
    }
    if (!attrib->getBool(multi)) {
      info_out.error ("Sector multipass attribute is not a true or false",
                   "Bad <sector>: " + sector_in->toString());
    }
  }

  // Sectors cannot be used as the start of a multipass region and be a 
  // subsector of a multipass region.

  if (multipass) {
    if (multi_map.find(sector_name) != multi_map.end()) { 
      info_out.error ("Sector used to start a multipass region: " + sector_name,
                   "Is also used as a subsector in a multipass region.");
    }
  }

  // We only need to do something here if this is the start of a multipass section.
  // this_multi stores the info on where we are in the multipass section of the lattice.

  if (!multipass && multi) {
    if (multi_map.find(sector_name) == multi_map.end()) { 
      this_multi = new multipass_struct;          // First time through: Init info.
      this_multi->n_pass = 1;
      multi_map[sector_name] = this_multi;
    } else {
      this_multi = multi_map[sector_name];        // Not first time through: Get old info
      this_multi->n_pass++;
      if (direction == 1) {
        this_multi->iter = (this_multi->masters).begin();
      } else {
        this_multi->iter = (this_multi->masters).end();
      }
    }
    this_multi->direction = direction;
    multipass = true;
  }

  // Does the sector have a prefix? an in_sector prefix overrides a sector prefix 

  if (UAPAttribute* attrib = sector_in->getAttribute("prefix")) {
    prefix += "." + attrib->getValue();
  } else if (attrib = sector_in->getAttribute("prefix")) {
    prefix += "." + attrib->getValue();
  }
  
  // Look for a girder child. 
  // A girder child of the reference sector overrides one in the sector definition

  UAPNode* girder = sector_in->getChildByName("girder");
  if (!girder) girder = sector_def->getChildByName("girder");

  if (girder) {
    UAPNode* girder_control = control_root->addChildCopy(girder);
    girder_list.push_back(girder_control);
  }

  // Iterate over the repeat count.
  
  bool ok;
  for (int ir = 0; ir < repeat; ir++) {

    string prefix_out = prefix;
    string str = BU::int_to_string(ir, ok);

    size_t ic = prefix_out.find("#COUNT");
    if (ic != string::npos) prefix_out.replace(ic, 6, str);

    // If this node has a length add a drift that can then get superimposed on top of.

    if (has_length) {

      double s_sector = AU.getAMLAttributeNumericValue(
                                  tracking_root->getChildren().back(), "s@actual", ok);

      UAPNode* drift = new UAPNode("element");
      string name = sector_name + "_sector";
      drift->addAttribute("name", name);
      drift->addChild("length")->addAttribute("actual", 
                                              sector_def->getAttributeString("length"));
      element_map[name] = drift;
      add_this_element_or_sector (tracking_root, drift, arg_map, direction, 
                                             multipass, expanding_a_list, prefix_out);
      element_map.erase(name);
      delete drift;

      calc_s_positions (tracking_root);      
      UAPNode* machine_root = tracking_root->getParent();
      superimpose_sector_given_s (sector_def, s_sector, machine_root, prefix_out);


    // This is for a sector without a length. 
    // Just add the children onto the lattice list.

    } else if (direction == 1) {
      for (NodeVecCIter in = children.begin(); in != children.end(); in++) {
        add_this_element_or_sector (tracking_root, *in, arg_map, direction, 
                                             multipass, expanding_a_list, prefix_out);
      }

    } else {
      for (NodeVecRevIter in = children.rbegin(); in != children.rend(); in++) { 
        add_this_element_or_sector (tracking_root, *in, arg_map, direction, 
                                             multipass, expanding_a_list, prefix_out);
      }
    }

  } 
  
  // Pop the sector name off of the sector list & the girder node off of its list.

  if (has_name || has_ref) sector_call_list.pop_back();
  if (girder) girder_list.pop_back();

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::add_this_element_or_sector (UAPNode* tracking_root, 
                    UAPNode* node, StrMap& arg_map, int direction, bool multipass, 
                    bool expanding_a_list, string prefix) {
  
  UAPAttribute* attrib;
  UAPNode* sector_node = node->getParent();
  string type_of_node = node->getName();

  // Ignore girders
  // But first check that the girder is the first child.

  if (type_of_node == "girder") {
    if (node->getChildIndexNumber() != 0) {
      info_out.error ("A girder node, if present, must be the first child of a sector.",
                   sector_node->toStringTree());
    }
    return;
  }

  // Get the node name or ref 

  string name;
  if (node->getAttribute("ref")) {
    UAPAttribute* attrib_ref = node->getAttribute("ref");
    name = attrib_ref->getValue();
    if (arg_map.find(name) != arg_map.end()) name = arg_map[name];
  } else {
    UAPAttribute* attrib_name = node->getAttribute("name");
    if (attrib_name) name = attrib_name->getValue();
  }
  
  // If this node is a <sector> then just call expand_this_sector 

  if (type_of_node == "sector") {
    expand_this_sector_or_list (tracking_root, node, direction, multipass, 
                                                                 expanding_a_list, prefix);
    return;
  }
  
  // If this is a <list> then find the next element in the list

  if (type_of_node == "element" && map_list_iter.find(name) != map_list_iter.end()) {
    if (expanding_a_list) {
      info_out.error ("A reference is not allowed inside a <list>",
                   "Referenced in <list>: " + sector_node->toStringTree());
      return;   
    }
    if (map_list_iter.find(name) == map_list_iter.end()) {
      info_out.error ("List not found: " + name,
                   "Referenced in sector: " + sector_call_list.back());
      return;   
    }
    
    UAPNode* node = *map_list_iter[name];     
    string list_name = name;
    name = node->getName();
    if (element_map.find(name) == element_map.end()) {
      info_out.error ("Element not found: " + name,
                   "Referenced in list: " + sector_node->toStringTree());
      return;   
    }
    
    UAPNode* element = element_map[name];
    element = tracking_root->addChildCopy(element);
    if (multipass) add_multipass_element (element);
    
    // Increment the iterator.
    NodeVecCIter temp = ++map_list_iter[list_name];
    if (temp == map_list_children[list_name].end()) 
      temp = map_list_children[list_name].begin();
    map_list_iter.erase(list_name);
    map_list_iter[list_name] = temp;
    
    return;
  }
  
  // If an <element> then put it on the lattice list 

  if (type_of_node == "element") {
    
    if (expanding_a_list) {
      tracking_root->addChild(name);
      return;
    }
    
    if (element_map.find(name) == element_map.end()) {
      info_out.error ("Element not found: " + name,
                   "Referenced in sector: " + sector_call_list.back());
      return;   
    }
    
    UAPNode* element = element_map[name];
    element = tracking_root->addChildCopy(element);
    if (multipass) add_multipass_element (element);

    // Add girder lord/slave links

    for (NodeVecCIter ig = girder_list.begin(); ig != girder_list.end(); ig++) {
      element->add(MASTER, *ig);
      (*ig)->add(SLAVE, element);
    }

    // Does the element need a prefix?

    if (attrib = node->getAttribute("prefix")) prefix += "." + attrib->getValue();
    if (prefix != "") {
      prefix.erase(0,1);  // erase beginning "."
      element->addAttribute("prefix", prefix);
    }
    return;
  }
  
  // If a branch or merger node then put it on the lattice list 

  if (type_of_node == "branch" || type_of_node == "merger") {
    if (!node->getAttribute("name")) {
      info_out.error ("In sector: " + sector_call_list.back(),
                   "<merger> or <branch> subnode within <sector> node must ",
                   "have \"name\" attribute: " + node->toString());
      return;   
    }
    if (expanding_a_list) {
      info_out.error ("In list: " + sector_call_list.front(),
                   "<merger> or <branch> subnode not allowed when expanding a <list>");
      return;   
    }
    tracking_root->addChildCopy(node);

    return;
  }
  
  // What the? 

  info_out.error ("In <sector> found child node: " + node->toString(),
               "that is not a <sector>, <element>, <branch>, nor <merger>.",
               sector_node->toStringTree());
  return;
  
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLLatticeExpander::connect_branch_and_merger(UAPNode* expand_root) {
  
  NodeMap branch_map, merger_map, to_map, from_map;
  StrList duplicates;
  
  // make a map of branch and merger nodes 

  map_sub_nodes (expand_root, "branch", "name", branch_map, duplicates);
  for (StrListCIter ia=duplicates.begin(); ia!=duplicates.end(); ia++) {  
    info_out.error ("Duplicate branch name: " + *ia);
  }
  
  map_sub_nodes (expand_root, "merger", "name", merger_map, duplicates);
  for (StrListCIter ia=duplicates.begin(); ia!=duplicates.end(); ia++) {  
    info_out.error ("Duplicate merger name: " + *ia);
  }
  
  // match every branch with a merger 

  for (NodeMapCIter ib = branch_map.begin(); ib != branch_map.end(); ib++) {
    UAPNode* branch = ib->second;
    string branch_name = ib->first;
    map_sub_nodes (branch, "to", "ref", to_map, duplicates);
    for (StrListCIter ia=duplicates.begin(); ia!=duplicates.end(); ia++) {  
      info_out.error ("Duplicate <to> subnodes in branch: " + branch->toString(),
                   "Duplicate <to> reference is: " + *ia);
    }
    
    // Loop over all <to> sub nodes of this <branch>

    for (NodeMapCIter it = to_map.begin(); it != to_map.end(); it++) {
      UAPNode* to = (*it).second;
      UAPAttribute* attrib_ref = to->getAttribute("ref");
      if (!attrib_ref) {
        info_out.error ("Subnode of this <branch>: " + branch->toString(),
                     "Does not have a \"ref\" attribute: " + to->toString());
        continue;
      }
      string merge_to = attrib_ref->getValue();
      if (merger_map.find(merge_to) == merger_map.end()) {
        info_out.error ("Subnode of this <branch>: " + branch->toString(),
                     "Has reference to unknown <merger> node: " + to->toString());
        continue;
      } 
      
      // For the corresponding <merger> node for this <to> find the 
      // corresponding <from> subnode.

      UAPNode* merger = merger_map[merge_to];
      map_sub_nodes (merger, "from", "ref", from_map, duplicates);
      for (StrListCIter ia=duplicates.begin(); ia!=duplicates.end(); ia++) {  
        info_out.error ("Duplicate <from> subnodes in merger: " + merger->toString(),
                     "Duplicate <from> reference is: " + *ia);
      }
      if (from_map.find(branch_name) == from_map.end()) {
        info_out.error ("No corresponding <from> subnode of <merger>: " + merger->toString(),
                 "To match <to> subnode: " + to->toString(),
                 "of <branch>: " + branch->toString());
        continue;
      } 
      UAPNode* from = from_map[branch_name];
      to->setConnect(from);
      from->setConnect(to);
    }
  } 
  
  // check that all mergers have a corresponding branch.
  for (NodeMapCIter im = merger_map.begin(); im != merger_map.end(); im++) {
    UAPNode* merger = (*im).second;
    string merger_name = (*im).first;
    map_sub_nodes (merger, "from", "ref", from_map, duplicates);
    
    // Loop over all <from> sub nodes of this <merger>
    for (NodeMapCIter it = from_map.begin(); it != from_map.end(); it++) {
      UAPNode* from = (*it).second;
      if (!from->getConnect()) {
        info_out.error ("Subnode <from>: " + from->toString(),
                 "Of <merger> node: " + merger->toString(),
                 "Does not have a corresponding <to> subnode of any <branch>.");
        continue;
      } 
    }
  }
  
  return info_out.everything_ok;
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLLatticeExpander::add_controls(UAPNode* aml_rep, UAPNode* expand_root) {

  // Setup the controller root node.

  NodeVec ele_list = expand_root->getSubNodesByName("element");

  // Transfer the controllers from aml_rep to the control_root.

  NodeVec controls = aml_rep->getSubNodesByName("controller");
  for (NodeVecCIter ic = controls.begin(); ic != controls.end(); ic++) {
    UAPNode* new_control = control_root->addChildCopy(*ic);
    ele_list.push_back(new_control);
  }

  // Create the master/slave links between the controllers and what they control.

  controls = control_root->getChildren();
  for (NodeVecCIter ic = controls.begin(); ic != controls.end(); ic++) {
    // Loop over all slave children.
    UAPNode* controller = *ic;
    string dflt_attrib = controller->getAttributeString("attribute");
    NodeVec s_list = controller->getChildren();

    for (NodeVecIter is = s_list.begin(); is != s_list.end(); is++) {
      UAPNode* slave_node = *is;
      if (slave_node->getName() != "slave") continue;

      string target_str = slave_node->getAttributeString("target");
      Twig twig(target_str, true);
      string attrib_name = twig.toNodeString(true);  
      if (attrib_name == "") attrib_name = dflt_attrib;
      string slave_name = twig.name;

      if (slave_name == "") {
        info_out.error ("No \"element\" attribute for slave of controller: " + 
                     slave_node->toString());
        return false;
      }

      // find all elements to be controlled
      for (NodeVecCIter ie = ele_list.begin(); ie != ele_list.end(); ie++) {
        UAPNode* slave_ele = *ie;
        if (slave_ele->getAttributeString("name") != slave_name) continue;
        slave_node->add(SLAVE, slave_ele);
        slave_ele->add(CONTROLLER, slave_node);
      } 
    }
  }

  return true;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLLatticeExpander::get_arg_map (UAPNode* main_sector, UAPNode* sub_sector, 
                    StrMap& arg_map) {
  
  // check that both sectors have an argument list 
  if (bool(main_sector->getAttribute("args")) != bool(sub_sector->getAttribute("args"))) {
    info_out.error (
        "Sector without an argument list references a sector that has one or vice versa.",
        "This sector: " + main_sector->toString(), 
        "References this sector: " + sub_sector->toString());
    return false;
  }
  
  // If no arguments then just retrun 
  if (!(main_sector->getAttribute("args"))) return true;
  
  // Get the argument lists. Both lists must be the same size 
  StrList actual_args, dummy_args;
  if (!AU.getSectorArgList (main_sector, actual_args)) return false;
  if (!AU.getSectorArgList (sub_sector, dummy_args)) return false;
  if (actual_args.size() != dummy_args.size()) {
    info_out.error ("Number of actual arguments does not match number of dummy arguments",
                 "This sector:       " + main_sector->toString(),
                 "Calls this sector: " + sub_sector->toString());
    return false;    
  }
  
  // Form the map 
  StrListCIter id = dummy_args.begin();
  for (StrListCIter ia = actual_args.begin(); ia != actual_args.end(); ia++) {
    arg_map[*id] = *ia;
    id++;
  }
  
  return true;
  
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::map_sub_nodes(UAPNode* root, const string& node_name, 
           const string& attrib_name, NodeMap& map, StrList& duplicates, bool clear) {
  
  if (clear) {
    map.clear();
    duplicates.clear();
  }
  
  NodeVec a_list = root->getSubNodesByName(node_name);
  for (NodeVecCIter ia=a_list.begin(); ia!=a_list.end(); ia++) {  
    if (!(*ia)->getAttribute(attrib_name)) continue;
    string name = (*ia)->getAttributeString(attrib_name);
    if (map.find(name) != map.end()) duplicates.push_back(name);
    map[name] = *ia;
  }

  return;
  
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::add_multipass_element (UAPNode* slave) {

   UAPNode* master;

  // If first time through then add a master element
  if (this_multi->n_pass == 1) {
    master = master_root->addChildCopy(slave);
    master->addAttribute("lord_rank", "MULTIPASS_LORD");
    if (this_multi->direction == 1) this_multi->masters.push_back(master);
    if (this_multi->direction == -1) this_multi->masters.insert(this_multi->masters.begin(), master);
  } else {
    if (this_multi->direction == 1) master = *(this_multi->iter)++;
    if (this_multi->direction == -1) master = *--(this_multi->iter);
  }

  // Add a |n suffix to the slave name
  UAPAttribute* name_attrib = slave->getAttribute("name");
  string name = name_attrib->getValue();
  bool ok;
  string str_i = BU::int_to_string (this_multi->n_pass, ok);
  name = name + "|" + str_i;
  name_attrib->setValue(name);

  // Adjust pointers between master and slave.
  slave->add(MASTER, master);
  slave->addAttribute("slave_rank", "MULTIPASS_SLAVE");
  master->add(SLAVE, slave);

  return;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::convert_to_actual (UAPNode* root) {

  // Add "design" + "err" attributes to get a "actual".

  bool ok;

  NodeVec children = root->getChildren();
  for (NodeVecIter ic = children.begin(); ic != children.end(); ic++) {

    UAPNode* child = *ic;
    convert_to_actual (child);
    UAPAttribute* design = child->getAttribute("design");
    UAPAttribute* err    = child->getAttribute("err");
    if (!design && !err) continue;

    double d = 0;
    if (design) {
      d = BU::string_to_double(design->getValue(), ok);
      if (!ok) {
        info_out.error ("Bad design number for node: " + child->toString());
        continue;
      }
    }

    double e = 0;
    if (err) {
      e = BU::string_to_double(err->getValue(), ok);
      if (!ok) {
        info_out.error ("Bad err number for node: " + child->toString());
        continue;
      }
    }

    child->addAttribute("actual", BU::double_to_string(d+e, ok));

  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::calc_s_positions (UAPNode* tracking_root) {

  NodeVec eles = tracking_root->getChildren();
  bool ok;

  // Get initial starting s-position.

  UAPNode* ele0 = *eles.begin();
  double s = 0;
  if (UAPNode* s_child = ele0->getChildByName("s")) 
    s = BU::string_to_double(s_child->getAttributeString("actual"), ok);
  else
    ele0->addChild("s")->addAttribute("actual", "0");

  // Loop over all nodes and add the element length to s.

  for (NodeVecIter ie = ++eles.begin(); ie != eles.end(); ie++) {
    UAPNode* ele = *ie;
    double l = 0;
    if (UAPNode* l_child = ele->getChildByName("length"))
      l = BU::string_to_double(l_child->getAttributeString("actual"), ok);
    s = s + l;
    string s_str;
    if (UAPNode* s_node = ele->getChildByName("s"))
      s_node->addAttribute("actual", BU::double_to_string (s, ok));
    else
      ele->addChild("s")->addAttribute("actual", BU::double_to_string (s, ok));
  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLLatticeExpander::apply_sets (string set_str, string value_str, UAPNode* aml_rep) {

  // Find all <set>s and transfer the value to the appropriate attribute.

  tree_transverser (aml_rep);  // Init
  while (true) {
    UAPNode* set_node = tree_transverser();

    if (!set_node) return;
    if (set_node->getName() != set_str) continue;

    string full_attrib = set_node->getAttributeString("attribute");
    Twig twig;
    if (!twig.fromString(full_attrib)) {
      info_out.error ("Bad attribute: " + full_attrib, "Of " + set_node->toString());
      continue;
    }

    // Find all matches and set.

    if (!BU::found(all_map, twig.name)) {
      info_out.error ("Node not found: " + twig.name, "For " + set_node->toString());
      continue;
    }
    UAPNode* named_node = all_map[twig.name];

    if (twig.target_attribute == "") twig.target_attribute = "design";

    UAPNode* attrib_node = twig.getLocalSubNode(named_node, true);
    if (!attrib_node) {
      info_out.error ("Invalid attribute name: " + full_attrib,
                   "For " + set_node->toString());
      continue;
    }

    string value = set_node->getAttributeString(value_str);
    if (value == "") {
      info_out.error ("Set: " + set_node->toString(),
                   "Does not have a \"" + value_str + "\" attribute");
      return;
    }
    attrib_node->addAttribute(twig.target_attribute, value);

  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------
//+
// set_str will be either "post_set" or "post_string_set".
// For each node with name set_str in the aml_rep do:
//   1) Search the target_root tree and find all "target" nodes pointed to.
//   2) For each target node set the appropriate attribute.
//-

void AMLLatticeExpander::apply_post_sets (string set_str, string value_str,
                                       UAPNode* aml_rep, UAPNode* target_root) {

  // Make a list of named elements.

  map<string, NodeVec> named_node_map;
  NodeVec named_node_list;

  tree_transverser(target_root);
  while(true) {
    UAPNode* node = tree_transverser();
    if (!node) break;
    string name = node->getAttributeString("name");
    if (name == "") continue;
    named_node_list.push_back(node);
    if (BU::found(named_node_map, name)) {
      NodeVec node_list = named_node_map[name];
      node_list.push_back(node);
      named_node_map.erase(name);
      named_node_map[name] = node_list; 
    } else {
      NodeVec node_list;
      node_list.push_back(node);
      named_node_map[name] = node_list;
    }
  }

  // Find all sets and transfer the value to the appropriate attribute.

  tree_transverser (aml_rep);  // Init
  while (true) {
    UAPNode* set_node = tree_transverser();

    if (!set_node) return;
    if (set_node->getName() != set_str) continue;

    // Transfer the attribute information to a Twig structure.

    string full_attrib = set_node->getAttributeString("attribute");
    Twig twig;
    if (!twig.fromString(full_attrib)) {
      info_out.error ("Bad attribute: " + full_attrib, "Of " + set_node->toString());
      continue;
    }

    if (twig.target_attribute == "") twig.target_attribute = "design";

    // Search for a matching element.

    bool found = false;
    NodeVec node_list; 

    // Wild cards could match to anything so use the entire list.
    if (twig.name.find("*") != string::npos || twig.name.find("?") != string::npos) 
      node_list = named_node_list;
    else
      node_list = named_node_map[twig.name];

    for (NodeVecIter in = node_list.begin(); in != node_list.end(); in++) {
      UAPNode* named_node = *in;

      if (!twig.matchNameAndPrefix(named_node)) continue;

      UAPNode* attrib_node = twig.getLocalSubNode(named_node, true);
      if (!attrib_node) {
        info_out.error ("Invalid attribute name: " + full_attrib,
                     "For " + set_node->toString());
        continue;
      }

      string value = set_node->getAttributeString(value_str);
      if (value == "") {
        info_out.error ("<" + set_str + "> does not have a \"" + value_str + "\" attribute",
                     set_node->toString());
        return;
      }
      attrib_node->addAttribute(twig.target_attribute, value);
      found = true;
    }

    if (!found) info_out.error ("No node found to set for " + set_node->toString());

  }

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

UAPNode* AMLLatticeExpander::tree_transverser (UAPNode* root) {

  // If there is a root then just initialize things.

  if (root) {
    iter_list.clear();
    parents.clear();
    parents.insert(parents.begin(), root);
    return root;
  }

  // If there are children of the current node start iterating on them.

  UAPNode* current_node = parents.front();
  NodeVec& children = current_node->getChildren();
  if (children.size() > 0) {
    current_node = children.front();
    parents.insert(parents.begin(), current_node);
    iter_list.push_front(children.begin());
    return current_node;
  }

  // Here if there are no children.
  // Look for the next sibling.

  while (true) {
    if (iter_list.size() == 0) return NULL;  // No more nodes in the tree.
    UAPNode* current_node = parents.front();
    NodeVec& children = current_node->getParent()->getChildren();
    NodeVecIter& iter = iter_list.front();
    iter++;
    // If at the end then go up one level
    if (iter == children.end()) {
      parents.erase(parents.begin());
      iter_list.pop_front();
      continue;
    // else return the next sibling
    } else {
      current_node = *iter;
      parents.front() = current_node;
      return current_node;
    }
  }

}
