#include "AML/AMLUtilities.hpp"
#include "UAP/UAPUtilities.hpp"
#include <cmath>

using namespace std;
namespace BU = BasicUtilities;

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLUtilities::inAMLNameSpace (UAPNode* node) {
  return inAMLNameSpace (node->getXMLURI());
}

bool AMLUtilities::inAMLNameSpace (const string& name) {
  if (name == "" || name == "http://lepp.cornell.edu/aml" || 
      name.substr(0, 29) == "{http://lepp.cornell.edu/aml}") return true;
  return false;
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

AMLUtilities::AMLUtilities() {
  init_valid_attributes();
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLUtilities::getSectorArgList (UAPNode* sector, StrList& arg_list) {
  
  arg_list.clear();

  string args = sector->getAttributeString("args");
  if (args == "") return true;

  string arg;
  size_t ix;
  for (ix=1; ix != string::npos;) {
    if ((ix = args.find(",")) != string::npos) {
      arg = args.substr(0, ix);
      args.erase(0, ix+1);
    } else {
      arg = args;
    }
    while (arg[0] == ' ') arg.erase(0, 1);
    while (arg[arg.length()-1] == ' ') arg.erase(arg.length()-1, 1);
    if (arg.find(" ") != string::npos) {
      info_out.error ("SECTOR ARGUMENT HAS BLANK SPACE", sector->toString());
      return false;
    }
    arg_list.push_back(arg);
  }
  return true;
  
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLUtilities::controllerBookkeeper (UAPNode* expand_root) {

  // Loop over all controllers.

  UAPUtilities utilities(expand_root);

  NodeVec controllers = expand_root->getSubNodesByName("controller");
  for (NodeVecIter ic = controllers.begin(); ic != controllers.end(); ic++) {
    UAPNode* controller = *ic;
    string dflt_attribute = controller->getAttributeString("default_attribute");
    string dflt_expression = controller->getAttributeString("expression");
    // Loop over all controller children

    NodeVec c_children = controller->getChildren();
    for (NodeVecIter icc = c_children.begin(); icc != c_children.end(); icc++) {
      UAPNode* c_child = *icc;

      // Check that this is a slave

      if (!inAMLNameSpace(c_child)) continue;
      if (c_child->getName() != "slave") {
        info_out.error ("Child: " + c_child->toString(),
                     "Is not a <slave> of controller: ", 
                     controller->toStringTree());
        continue;
      }

      // Evaluate the expression

      string exp = c_child->getAttributeString("expression");
      if (exp == "") exp == dflt_expression;
      if (exp == "") {
        info_out.error ("No expression for slave: " + c_child->toString(),
                        "Of controller: ", controller->toString());
        continue;
      }
      
      double value = utilities.evaluate(exp);

      // Get the attribute controlled.

      string attrib = dflt_attribute;
      string target = c_child->getAttributeString("target");
      if (target.find("[") != string::npos) {
        attrib = target.substr(target.find("["));
        attrib.erase(attrib.size()-1);
      }

      if (target == "") {
        info_out.error ("NO TARGET ATTRIBUTE FOR SLAVE: " + c_child->toStringTree(),
                        "OF CONTROLLER: " + controller->toStringTree());
        continue;
      }

      // Loop over the list of slave elements contained in each controller child.

      NodeVec eles = c_child->getList(SLAVE);
      for (NodeVecIter is = eles.begin(); is != eles.end(); is++) {
        UAPNode* ele = *is;

        // Find the attribute controlled

        UAPNode* attrib_node = Twig::getLocalSubNode(ele, attrib, true);
        if (!attrib_node) {
          info_out.error ("Reference to invalid attribute in controller: " + attrib,
                       "In controller: " + controller->toStringTree());
          continue;
        }

        bool ok;
        attrib_node->addAttribute("actual", BU::double_to_string(value, ok));

      }

    }

  }

  // Loop over all girders.

  return;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

bool AMLUtilities::splitElement (UAPNode* machine_root, double s_split, 
                                                NodeVecIter& iter, double tol) {

  bool ok;

  UAPNode* tracking_root = machine_root->getChildByName("tracking_lattice");
  UAPNode* master_root = machine_root->getChildByName("master_list");
  NodeVec& lattice = tracking_root->getChildren();
  iter = lattice.end();

  // Check for s_split out of bounds

  if (s_split < getAMLAttributeNumericValue(lattice.front(), "s@actual", ok) - tol) {
    info_out.error ("Position of split not within the lattice: " + 
                                                  BU::double_to_string(s_split, ok));
    return false;
  }

  if (s_split > getAMLAttributeNumericValue(lattice.back(), "s@actual", ok) + tol) {
    info_out.error ("Position of split not within the lattice: " + 
                                                 BU::double_to_string(s_split, ok));
    return false;
  }

  // Find where to split. 
  // If the spot to split is within tol of an element boundary then do not split.

  NodeVecIter in;
  double s1;
  for (in = lattice.begin(); in != lattice.end(); in++) {
    s1 = getAMLAttributeNumericValue(*in, "s@actual", ok);
    if (!ok) {
      iter = lattice.begin();
      return false;
    }
    if (fabs(s1 - s_split) < tol) {
      iter = ++in;
      return false;
    }
    if (s1+tol > s_split) break;
  }

  // Split element 

  UAPNode* ele = *in;

  double len = getAMLAttributeNumericValue(ele, "length@actual", ok);
  double s0 = s1 - len;

  // If the element to be split is not a super_slave then create a 
  //   super_lord to control the split haves.

  string len1_str = BU::double_to_string(s_split - s0, ok);
  string s1_str = BU::double_to_string(s_split, ok);
  string len2_str = BU::double_to_string(s1 - s_split, ok);
  string s2_str = BU::double_to_string(s1, ok);
  string ele_name = ele->getAttributeString("name");

  UAPNode* slave1;
  UAPNode* slave2;

  if (ele->getAttributeString("slave_rank") != "SUPER_SLAVE") {
    UAPNode* super_ele = master_root->addChildCopy(ele);
    super_ele->addAttribute("lord_rank", "SUPER_LORD");
    transferLordSlaveLinks(ele, super_ele);

    slave1 = tracking_root->addChild("element", ele);
    slave1->add(MASTER, super_ele);
    super_ele->add(SLAVE, slave1);

    slave2 = tracking_root->addChild("element", ele);
    slave2->add(MASTER, super_ele);
    super_ele->add(SLAVE, slave2);

    form_super_slave_names (super_ele);

    slave1->addAttribute("slave_rank", "SUPER_SLAVE");
    slave1->addChild("length")->addAttribute("actual", len1_str);
    slave1->addChild("s")->addAttribute("actual", s1_str);

    slave2->addAttribute("slave_rank", "SUPER_SLAVE");
    slave2->addChild("length")->addAttribute("actual", len2_str);
    slave2->addChild("s")->addAttribute("actual", s2_str);

    iter = --in;
    ele->deleteNode();

  // Here if the element split is already a super_slave.

  } else {
    slave1 = tracking_root->addChildCopy(ele, ele);
    slave2 = ele;

    slave1->addAttribute("name", ele_name + "|1");
    UAPNode* len_node = slave1->getChildByName("length");
    len_node->getAttribute("actual")->setValue(len1_str);
    slave1->getChildByName("s")->getAttribute("actual")->setValue(s1_str);

    slave2->addAttribute("name", ele_name + "|2");
    len_node = slave2->getChildByName("length");
    len_node->getAttribute("actual")->setValue(len2_str);
    len_node->removeAttribute("design");
    len_node->removeAttribute("err");
    slave2->getChildByName("s")->getAttribute("actual")->setValue(s2_str);

    // For each super_lord add a slave link to slave1.
    // Note: There is already a slave link to slave2 (= ele).

    NodeVec m_list = slave2->getList(MASTER);
    for (NodeVecIter im = m_list.begin(); im != m_list.end(); im++) { 
      UAPNode* master = *im;
      master->add(SLAVE, slave1, slave2);
    }

    iter = in;
    form_super_slave_names (slave1);
  }

  // Super slaves do not have a design or err length values.

  UAPNode* len_node = slave1->getChildByName("length");
  len_node->removeAttribute("design");
  len_node->removeAttribute("err");

  len_node = slave2->getChildByName("length");
  len_node->removeAttribute("design");
  len_node->removeAttribute("err");


}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLUtilities::form_super_slave_names (UAPNode* ele) {

  // If ele is a slave then call this routine for each of its lords.

  if (ele->getAttributeString("slave_rank") == "SUPER_SLAVE") {
    NodeVec lords = ele->getList(MASTER);
    for (NodeVecIter ie = lords.begin(); ie != lords.end(); ie++) {
      form_super_slave_names(*ie);
    }
    return;
  }

  // If this is not a super lord then there is nothing to do.

  if (ele->getAttributeString("lord_rank") != "SUPER_LORD") return;

  // The names of the slaves are a concatination of the lord names.

  typedef map<string, int>            IntMap;
  typedef map<string, int>::iterator  IntMapIter;

  IntMap slave_map;

  NodeVec slaves = ele->getList(SLAVE);
  for (NodeVecIter is = slaves.begin(); is != slaves.end(); is++) {
    UAPNode* slave = *is;
    NodeVec lords = slave->getList(MASTER);
    string slave_name;
    for (NodeVecIter im = lords.begin(); im != lords.end(); im++) { 
      if (im == lords.begin() || im != --lords.end()) 
        slave_name += (*im)->getAttributeString("name") + "|";
      else 
        slave_name += (*im)->getAttributeString("name");
    }
    slave->addAttribute("name", slave_name);
    if (BU::found(slave_map, slave_name)) 
      ++(slave_map[slave_name]);
    else
      slave_map[slave_name] = 0;

  }

  // Add a number to names that are not unique

  for (IntMapIter ia = slave_map.begin(); ia != slave_map.end(); ia++) {
    if (ia->second == 0) continue;
    ia->second = 1;
  }

  bool ok;

  for (NodeVecIter is = slaves.begin(); is != slaves.end(); is++) {
    UAPNode* slave = *is;
    string slave_name = slave->getAttributeString("name");
    if (slave_map[slave_name] == 0) continue;
    string this_name = slave_name;
    if (this_name[this_name.size()-1] != '|') this_name += "|";
    this_name += BU::int_to_string(slave_map[slave_name], ok);
    slave_map[slave_name]++;
    slave->addAttribute("name", this_name);
  }

  return;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLUtilities::transferLordSlaveLinks (UAPNode* old_node, UAPNode* new_node) {

  // Look at the old_node masters and change their slave pointer to point to the new_node

  NodeVec m_list = old_node->getList(MASTER);
  for (NodeVecIter im = m_list.begin(); im != m_list.end(); im++) { 
    UAPNode* master = *im;
    NodeVec& s_list = master->getList(SLAVE);
    for (NodeVecIter is = s_list.begin(); is != s_list.end(); is++) {
      UAPNode* slave = *is;
      if (slave == old_node) {
        *is = new_node;
      }        
    }
  }

  // Look at the old_node controllers and change their slave pointer to point to the new_node

  NodeVec c_list = old_node->getList(CONTROLLER);
  for (NodeVecIter ic = c_list.begin(); ic != c_list.end(); ic++) { 
    UAPNode* control = *ic;
    NodeVec& s_list = control->getList(SLAVE);
    for (NodeVecIter is = s_list.begin(); is != s_list.end(); is++) {
      UAPNode* slave = *is;
      if (slave == old_node) {
        *is = new_node;
      }        
    }
  }

  // Look at the old_node slaves and change teir masters and controllers to point to the new_node

  NodeVec s_list = old_node->getList(SLAVE);
  for (NodeVecIter is = s_list.begin(); is != s_list.end(); is++) { 
    UAPNode* slave = *is;

    NodeVec& m_list = slave->getList(MASTER);
    for (NodeVecIter im = m_list.begin(); im != m_list.end(); im++) {
      UAPNode* master = *im;
      if (master == old_node) {
        *im = new_node;
      }        
    }

    NodeVec& c_list = slave->getList(CONTROLLER);
    for (NodeVecIter ic = c_list.begin(); ic != c_list.end(); ic++) {
      UAPNode* control = *ic;
      if (control == old_node) {
        *ic = new_node;
      }        
    }

  }

  return;

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

double AMLUtilities::getAMLAttributeNumericValue (UAPNode* root, 
                                                        string attrib_name, bool& ok) {

  // If the attribute does not exist then this is ok an just return 0.

  string value_str = getAMLAttributeString(root, attrib_name, ok);
  if (!ok) {
    ok = true;
    return 0;
  }

  // Note: value_str = "" will result in ok = false.

  return BU::string_to_double(value_str, ok);
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

string AMLUtilities::getAMLAttributeString (UAPNode* root, 
                                                    string attrib_name, bool& ok) {

  ok = false;

  // attrib_name encodes both the node and attribute information
  // Eg: attrib_name = "quadrupole:k(n=1)@actual".
  // Split off the "@nnn" part where "nnn" is typically "design" (default), "actual", etc.

  Twig twig;
  if (!twig.fromString(attrib_name)) return "";

  UAPNode* attrib_node = twig.getSubNode(root);
  if (!attrib_node) return "";

  // See if the node has the correct attribute

  UAPAttribute* attrib = attrib_node->getAttribute(twig.target_attribute);
  if (!attrib) return "";
  ok = true;
  return attrib->getValue();

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------


bool AMLUtilities::validAttribute (const string& attribute) {
  return BU::found(valid_attributes, attribute);
}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLUtilities::init_valid_attributes () {

  wild_attributes.clear();
  valid_attributes.clear();

  add_valid_attribute ("s");
  add_valid_attribute ("length");
  add_valid_attribute ("quadrupole:k");
  add_valid_attribute ("sextupole:k");
  add_valid_attribute ("octupole:k");
  add_valid_attribute ("solenoid:ksol");

  add_valid_attribute ("orientation*");
  add_valid_attribute ("quadrupole:orientation*");
  add_valid_attribute ("sextupole:orientation*");
  add_valid_attribute ("octupole:orientation*");
  add_valid_attribute ("solenoid:orientation*");
  add_valid_attribute ("rf_cavity:orientation*");
  add_valid_attribute ("multipole:orientation*");
  add_valid_attribute ("thick_multipole:orientation*");
  add_valid_attribute ("beambeam:orientation*");
  add_valid_attribute ("wiggler:orientation*");
  add_valid_attribute ("electric_kicker:orientation*");
  add_valid_attribute ("kicker:orientation*");
  add_valid_attribute ("bend:orientation*");

  add_valid_attribute ("*orientation:tilt");
  add_valid_attribute ("*orientation:x_offset");
  add_valid_attribute ("*orientation:y_offset");
  add_valid_attribute ("*orientation:s_offset");
  add_valid_attribute ("*orientation:x_pitch");
  add_valid_attribute ("*orientation:y_pitch");
  add_valid_attribute ("*orientation:roll");

  for (int i = 0; i < 21; i++) {
    ostringstream oss;
    oss << i;
    add_valid_attribute ("multipole:kl(n=" + oss.str() + ")");
    add_valid_attribute ("multipole:ksl(n=" + oss.str() + ")");
    add_valid_attribute ("multipole:kl_u(n=" + oss.str() + ")");
    add_valid_attribute ("multipole:ksl_u(n=" + oss.str() + ")");
    add_valid_attribute ("multipole:tilt(n=" + oss.str() + ")");
    add_valid_attribute ("scaled_multipole:k_coef(n=" + oss.str() + ")");
    add_valid_attribute ("scaled_multipole:ks_coef(n=" + oss.str() + ")");
    add_valid_attribute ("scaled_multipole:tilt(n=" + oss.str() + ")");
  }

  add_valid_attribute ("aperture:xy_limit");
  add_valid_attribute ("aperture:x_limit");
  add_valid_attribute ("aperture:y_limit");

  add_valid_attribute ("methods:tracking_method:name");
  add_valid_attribute ("methods:map_creation_method:name");
  add_valid_attribute ("methods:symplectify:name");
  add_valid_attribute ("methods:itegrator_order:name");
  add_valid_attribute ("methods:num_steps");
  add_valid_attribute ("methods:ds_step");
  add_valid_attribute ("methods:relative_tollerance");
  add_valid_attribute ("methods:absolute_tollerance");

  add_valid_attribute ("wiggler:polarity");

  add_valid_attribute ("rf_cavity:harmonic");
  add_valid_attribute ("rf_cavity:voltage");
  add_valid_attribute ("rf_cavity:phase0");
  add_valid_attribute ("rf_cavity:rf_freq");
  add_valid_attribute ("rf_cavity:e_loss");

  add_valid_attribute ("electric_kicker:x_kick");
  add_valid_attribute ("electric_kicker:y_kick");
  add_valid_attribute ("electric_kicker:x_kick_u");
  add_valid_attribute ("electric_kicker:y_kick_u");
  add_valid_attribute ("electric_kicker:gap");

  add_valid_attribute ("bend:angle");
  add_valid_attribute ("bend:g");
  add_valid_attribute ("bend:rho");
  add_valid_attribute ("bend:e1");
  add_valid_attribute ("bend:e2");
  add_valid_attribute ("bend:h1");
  add_valid_attribute ("bend:h2");
  add_valid_attribute ("bend:f_int1");
  add_valid_attribute ("bend:f_int2");
  add_valid_attribute ("bend:h_gap1");
  add_valid_attribute ("bend:h_gap2");

  add_valid_attribute ("kicker:kick");
  add_valid_attribute ("kicker:x_kick");
  add_valid_attribute ("kicker:y_kick");
  add_valid_attribute ("kicker:bl_x_kick");
  add_valid_attribute ("kicker:bl_y_kick");

  add_valid_attribute ("beambeam:sig_x");
  add_valid_attribute ("beambeam:sig_y");
  add_valid_attribute ("beambeam:charge");

}

// --------------------------------------------------------------------------------
// --------------------------------------------------------------------------------

void AMLUtilities::add_valid_attribute (string attrib_str) {

  // If string does not have a wild card "*" then just put it on the list

  size_t i = attrib_str.find("*");
  if (i == string::npos) {
    valid_attributes.push_back(attrib_str);
    return;
  }

  // If the wildcard is at the end then save the attribute for later use.

  if (i == attrib_str.size()-1) {
    string sub_str = attrib_str.substr(0,attrib_str.size()-1);
    wild_attributes.push_back(sub_str);
    return;
  }

  // If the wildcard is at the beginning then match it against the wild_attributes

  if (i == 0) {
    attrib_str = attrib_str.substr(1);  // Strip off "*"
    size_t ixc = attrib_str.find(":");
    string match_str = attrib_str.substr(0,ixc);
    string add_str = attrib_str.substr(ixc);

    for (StrListIter iw = wild_attributes.begin(); iw != wild_attributes.end(); iw++) {
      string wild = *iw;
      size_t j = wild.find_last_of(":");
      ixc = 0;
      if (j != string::npos) ixc = j+1;
      if (wild.substr(ixc) == match_str) valid_attributes.push_back(wild + add_str); 
    }

    return;
  }

}
