/*
 * UAP Reader
 * Universal Accelerator Parser
 * Copyright (C) 2006 Daniel Bates, David Sagan, Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov)
 * David Sagan (dcs16@cornell.edu)
 * Andy Wolski (a.wolski@dl.ac.uk)
 */


#ifndef INC_AMLReader_hpp_
#define INC_AMLReader_hpp_ 1

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "UAP/UAPUtilities.hpp"
#include "UAP/BasicUtilities.hpp"
#include "AML/SAX2Wrapper.hpp"

/** <code>AMLReader</code> is used to construct the appropriate 
* UAP tree from an AML file.
* @author David Sagan
* @ingroup AML
*/

class AMLReader{
public:

  /** Creates an AML reader.
  */
  AMLReader();

  /** Destructor. 
  */
  ~AMLReader();
  
  /** Reads in an AML file (or files if there are include statements)
  * and constructs the appropriate UAP tree.
  * The constructed UAP tree has the root &lt;UAPRoot&gt; which
  * in turn has the child node &lt;AML_representation&gt;.
  * The sub-tree of &lt;AML_representation&gt; contains the 
  * information from the input file.
  * @param file_name     The AML file to read in.
  * @return              The &lt;UAPRoot&gt; node
  */
  UAPNode* AMLFileToAMLRep (const std::string& file_name);

  /** Creates a AML file (or files if there are include statements)
  * from an AML_representation tree.
  * @param root_node   May be a &lt;AML_representation&gt; node or a &lt;UAP_root&gt; node.
  * @param file_name   The root AML file to create. If not present or "" then
  *                        the original file name will be used.
  * @param one_file    If true then concatinate everything into one file. 
  *                        Default is false.
  * @return            &lt;AML_representation&gt; node.
  */
  UAPNode* AMLRepToAMLFile (UAPNode* root_node, 
                const std::string& file_name = "", bool one_file = false);

private:

  PrintInfoStruct info_out;
  bool read_file (UAPNode* input_node, std::string file_name, FileStackList file_stack);
  bool aml_rep_to_aml_file (UAPNode* aml_rep, bool one_file, 
      std::ofstream* aml_output, FileStackList file_stack, int indent = 0);

};

#endif
