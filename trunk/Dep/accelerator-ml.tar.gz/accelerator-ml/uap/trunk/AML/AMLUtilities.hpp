/*
 * AMLUtilities
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   Daniel Bates (dbates@lbl.gov)
 *   David Sagan (dcs16@cornell.edu)
 *   Andy Wolski (a.wolski@dl.ac.uk)
 */

#ifndef AMLUtilities_hpp
#define AMLUtilities_hpp 1


#include "UAP/UAPNode.hpp"
#include "AML/Twig.hpp"

class AMLUtilities {

public:

  AMLUtilities();

  /** Checks the string to see if it is blank ("") or is "http://lepp.conell.edu/aml" or
  * begins with "{http://lepp.conell.edu/aml}"
  * @param name       Name to check.
  * @return           True is part of the AML namespace.
  */
  static bool inAMLNameSpace (const std::string& name);

  /** Checks the URI for a node and returns whether a node is part of the AML namespace.
  * True if the URI is blank ("") or is "http://lepp.conell.edu/aml".
  * @param node       Node to check.
  * @return           True is part of the AML namespace.
  */
  static bool inAMLNameSpace (UAPNode* node);

  /** Does the bookkeeping for all controllers.
  * This is the routine that needs to be called after controller values are changed.
  * This routine transfers the controller values to the controlled element attributes.
  * @expand_root      Root of the expanded lattice tree.
  */
  void controllerBookkeeper (UAPNode* expand_root);

  /** Parses the argument list of a sector.
  * @param sector     Sector node for parsing.
  * @param arg_list   Returned list of arguments.
  * @return           True if everything OK. False otherwise.
  */
  bool getSectorArgList (UAPNode* sector, StrList& arg_list);

  /** Returns true if attribute is recognized as valid. false otherwise.
  * @param attribute      Attribute name.
  * @return               true if recognized.
  */
  bool validAttribute (const std::string& attribute);

  /** Splits the expanded lattice at the indicated position.
  * @param machine_root     The &lt;machine&gt; node. for the lattice.
  * @param s_split          The place to split the lattice.
  * @param iter             An iterator to the element just after the split.
  *                           If there is an error then iter = tracking_root.children.begin().
  * @param tol              Tollerance such that if s_split is within tol of an element 
  *                           boundary then no split is done. Default is 1e-6.
  * @return                 True if there was a split false otherwise.
  */
  bool splitElement (UAPNode* machine_root, double s_split, 
                                             NodeVecIter& iter, double tol = 1e-6);

  /** Adjusts the links between lords and slaves so that any links pointing to 
  * <code>old_node</code> will instead point to <code>new_node</code>.
  * @param old_node     The node with existing lord/slave links.
  * @param new_node     The node to which lord/slave links will be directed.
  */
  void transferLordSlaveLinks (UAPNode* old_node, UAPNode* new_node);

  /** Returns the numerical value of an AML attribute.
  * @param  root          Root name. This corresponds to a node of the form
  *                         &lt;xxx name = "root"&gt;
  * @param attrib_name    Name of the AML attribute. Eg: "length%value".
  * @param ok             True if there are no errors. False otherwise.
  *                         It is *not* an error if the attribute does not exist.
  *                         It is an error is the attribute value is "".
  * @return               The value of the attribute. 
  *                         If the attribute does not exist then 0 is returned.
  *                         If there is an error then 0 is returned.
  */
  double getAMLAttributeNumericValue (UAPNode* root, std::string attrib_name, bool& ok);

  /** Returns the string value of an AML attribute.
  * Note: This routine is not currently used and is being cosidered for deletion.
  * @param  root          Root name. This corresponds to a node of the form
  *                         &lt;xxx name = "root"&gt;
  * @param attrib_name    Name of the attribute. Eg: "length%value".
  * @param ok             True if the attribute exists. False otherwise.
  * @return               String value of the parameter. 
  *                         If the attribute is not found then "" is returned.
  */
  std::string getAMLAttributeString (UAPNode* root, std::string attrib_name, bool& ok);
 
  /** Assigns appropriate names to super_slave elements
  * @param ele      Either a super_slave or a super_lord element.
  * @return         Appropriate names are assigned.
  */
  void form_super_slave_names (UAPNode* ele);

private:

  PrintInfoStruct info_out;  
  StrList valid_attributes;
  StrList wild_attributes;

  void init_valid_attributes ();
  void add_valid_attribute (std::string attrib_str);

};

#endif
