/*
 * AML Reader
 * Universal Accelerator Parser
 * Copyright (C) 2006 Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   Daniel Bates <dbates@lbl.gov>
 *   David Sagan <dcs16@cornell.edu>
 */

#include "AMLReader.hpp"

using namespace BasicUtilities;
using namespace std;

AMLReader::AMLReader() {}

AMLReader::~AMLReader() {}


UAPNode* AMLReader::AMLFileToAMLRep (const string& file_name) {

  // Create the root node
  UAPNode* root = new UAPNode("UAP_root");

  // Add the input and file nodes */
  UAPNode* aml_rep = root->addChild ("AML_representation");
  aml_rep->addAttribute ("source_file_language", "AML");
  aml_rep->addAttribute ("filename", file_name);

  // Read file
  FileStackList file_stack;

  if (!read_file (aml_rep, file_name, file_stack)) return NULL;

  return root;

}

//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
// Method to read in a file 

bool AMLReader::read_file (UAPNode* input_node, string file_name, FileStackList file_stack) {

  info_out.ix_line = -1;
  info_out.parsing_status = "Opening a lattice file";

  // put the name on the stack

  file_stack.addFile(file_name);
  string this_file = file_stack.file_list.back().full_name;

  // Check that the file exists

  ifstream myfile;
  myfile.open(this_file.c_str());
  if (!myfile.is_open()) {
    info_out.error ("File not found: " + file_name);
    return false;
  }
  myfile.close();

  // Parse the AML file to get the UAP tree

  SAX2Wrapper parser;
  if (!parser.XMLFileToUAPRep(this_file, input_node)) return false;

  // Look for included files

  NodeVec inc_list = input_node->getSubNodesByName ("{http://www.w3.org/2001/XInclude}include");
  for (NodeVecIter it=inc_list.begin(); it!=inc_list.end(); ++it) {
    UAPNode* include_node = *it;
    string include_file = include_node->getAttributeString("href");

    cout << "Including: " + include_file << endl;
    if (!read_file (include_node, include_file, file_stack)) return false;

    // Remove <null_root> child if present.

    UAPNode* null_node = include_node->getChildByName("null_root");
    if (null_node && include_node->getChildren().size() == 1) {
      NodeVec children = null_node->getChildren();
      for (NodeVecIter ic = children.begin(); ic != children.end(); ic++) 
        include_node->addChildCopy(*ic);
      null_node->deleteNode();
    }

  }

  return true;

}

//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------

UAPNode* AMLReader::AMLRepToAMLFile (UAPNode* aml_root, 
                    const string& file_name, bool one_file) {

  info_out.ix_line = -1;
  info_out.parsing_status = "Creating an AML lattice file";

  UAPNode* aml_rep = aml_root;

  if (aml_rep->getName() == "UAP_root") 
                  aml_rep = aml_rep->getChildByName("AML_representation");

  if (!aml_rep || (aml_rep->getName() != "AML_representation")) {
    info_out.error ("NODE argument is not <AML_representation> or its parent");
    return NULL;
  }

  UAPNode* lab = aml_rep->getChildByName("laboratory");

  if (!lab || lab->getName() != "laboratory") {
    info_out.error ("Node argument is not <laboratory> or its parent");
    return NULL;
  }


  ofstream* aml_out = NULL;
  string this_file = file_name;
  if (this_file == "") this_file = aml_rep->getAttributeString("filename");
  if (this_file == "") {
    info_out.error ("No file name given for creating an AML file.");
    return NULL;
  }
  aml_out = new ofstream(this_file.c_str());
  if (!aml_out->is_open()) {
    info_out.error ("Cannot open file: " + this_file);
    return NULL;
  }

  FileStackList file_stack;
  file_stack.addFile(this_file);
  aml_rep_to_aml_file (lab, one_file, aml_out, file_stack);

  if (aml_out) {
    if (aml_out->is_open()) aml_out->close();
    delete aml_out;
  }

  return aml_rep;

}

//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------

bool AMLReader::aml_rep_to_aml_file (UAPNode* aml_rep, bool one_file, 
                  ofstream* aml_output, FileStackList file_stack, int indent) {

  bool ok = true;

  // Create a new file stream if needed

  ofstream* aml_out;
  NodeVec children = aml_rep->getChildren();
  string node_name = aml_rep->getQName();

  // Write node name

  *aml_output << string(indent, ' ') << "<" << node_name;

  // Write attributes

  AttributeVec attributes = aml_rep->getAttributes();
  for (AttributeVecCIter ia = attributes.begin(); ia != attributes.end(); ia++) {
    *aml_output << " " << ia->getName() << " = \"" << to_xml_string(ia->getValue()) << "\"";
  }

  // If no children then end the node

  bool generate_new_file = 
          (aml_rep->getUniversalName() == "{http://www.w3.org/2001/XInclude}include" && !one_file);

  if (children.size() == 0 || generate_new_file) {
    *aml_output << " />" << endl;
  } else {
    *aml_output << ">" << endl;   // Complete the opening tag
  }

  // If an <{http://www.w3.org/2001/XInclude}include> node then open a new file if needed.
  // A new file will a <null_root> root element unless there is exactly one child.

  int child_indent = indent + 2;  // Indentation for children of current node.
  bool null_root = false;
  aml_out = aml_output;

  if (generate_new_file) {
    string inc_name = aml_rep->getAttributeString("href");
    if (inc_name == "") {
      info_out.error ("No file name given for creating an AML file.");
      return false;
    }
    file_stack.addFile(inc_name);
    string f_name = file_stack.file_list.back().full_name;
    aml_out = new ofstream(f_name.c_str());
    if (!aml_out->is_open()) {
      info_out.error ("Cannot open file: " + f_name);
      return false;
    }
    if (children.size() > 1) {
      *aml_out << "<null_root>" << endl;
      null_root = true;
    }
    child_indent = 2;  // Reset for a new file
  }

  // Loop over the children

  for (NodeVecCIter it = children.begin(); it != children.end(); it++) {
    if (!aml_rep_to_aml_file (*it, one_file, aml_out, file_stack, child_indent)) ok = false;
  }

  // Write the end tag

  if ((aml_rep->getUniversalName() != "{http://www.w3.org/2001/XInclude}include" || one_file) &&
         children.size() > 0) *aml_out << string(indent, ' ') << "</" << node_name << ">" << endl; 

  if (null_root) *aml_out << "</null_root>" << endl;

  // Close the file if needed.

  if (node_name == "{http://www.w3.org/2001/XInclude}include" && !one_file) {
    aml_out->close();
    delete aml_out;
  }

  return ok;

}
