#include <xercesc/sax2/SAX2XMLReader.hpp>
#include <xercesc/sax2/XMLReaderFactory.hpp>
#include <xercesc/sax2/DefaultHandler.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/parsers/SAX2XMLReaderImpl.hpp>

#if defined(XERCES_NEW_IOSTREAMS)
#include <iostream>
#else
#include <iostream.h>
#endif

#include <AML/SAX2Wrapper.hpp>

XERCES_CPP_NAMESPACE_USE

using namespace std;
namespace BU = BasicUtilities;

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

bool SAX2Wrapper::XMLFileToUAPRep (const string& xml_file, UAPNode* root, bool convert) {

  parse_OK = true;
  this_root = root;
  current = root;
  finished = false;
  convert_entities = convert;

  try {
    XMLPlatformUtils::Initialize();
  }
  catch (const XMLException& toCatch) {
    char* message = XMLString::transcode(toCatch.getMessage());
    cout << "Error during initialization! :\n";
    cout << "Exception message is: \n" 
         << message << "\n";
    XMLString::release(&message);
    return false;
  }

  SAX2XMLReader* parser = XMLReaderFactory::createXMLReader();

  parser->setFeature(XMLUni::fgSAX2CoreValidation, false);  
  parser->setFeature(XMLUni::fgSAX2CoreNameSpaces, true);   
  parser->setFeature(XMLUni::fgXercesContinueAfterFatalError, true);
  parser->setFeature(XMLUni::fgSAX2CoreNameSpacePrefixes, true);

  // parser->setFeature(XMLUni::fgXercesDynamic, true);
  // parser->setFeature(XMLUni::fgSAX2CoreValidation, false);
  // parser->setFeature(XMLUni::fgSAX2CoreValidation, true);
  // parser->setFeature(XMLUni::fgXercesDynamic, false);
  // parser->setFeature(XMLUni::fgXercesSchema, doSchema);
  // parser->setFeature(XMLUni::fgXercesSchemaFullChecking, schemaFullChecking);

  parser->setContentHandler(this);
  parser->setErrorHandler(this);

  try{
    parser->parse(xml_file.c_str());
  } catch (RuntimeException& except) {
    cout << "RuntimeException!" << endl;
    parse_OK = false;
  } catch (...) {
    cout << "Parse Exception!" << endl;
  }

  delete parser;

  root = this_root;
  return parse_OK;

}

// ---------------------------------------------------------------------------
//  SAX2Wrapper: Overrides of the SAX ErrorHandler interface
// ---------------------------------------------------------------------------

void SAX2Wrapper::error(const SAXParseException& e) {
  error_out ("Error", e);
  return;
}

void SAX2Wrapper::fatalError(const SAXParseException& e) {
  error_out ("Fatal error", e);
  return;
}

void SAX2Wrapper::warning(const SAXParseException& e) {
  error_out ("Warning", e);
  return;
}

void SAX2Wrapper::error_out (const string& err_type, const SAXParseException& e) {
  if (finished)
    std::cout << err_type << ": " << "Extra stuff after end of root node" << std::endl;
  else
    std::cout << err_type << ": " << StrX(e.getMessage()) << std::endl;

  std::cout << "  In file: " << StrX(e.getSystemId()) << std::endl
       << "  Line: " << e.getLineNumber() << " Column: " << e.getColumnNumber() << std::endl;
  parse_OK = false;
}

// ---------------------------------------------------------------------------
//  SAX2Wrapper: Overrides of the SAX DocumentHandler interface
// ---------------------------------------------------------------------------

void SAX2Wrapper::characters(const XMLCh* const chars,
                           const unsigned int length) {

  // trim leading and trailing spaces and add to tree.
 
  string text = BU::trim(StrX(chars));
  if (text == "") return;
  current->addChild(text, TEXT_NODE);
}


void SAX2Wrapper::endDocument() {
  // std::cout << "endDocument called" << std::endl; 
}


void SAX2Wrapper::endElement(const XMLCh* const uri,
                           const XMLCh* const localname,
                           const XMLCh* const qname) {

  current = current->getParent();
  if (current == this_root) finished = true;

}


void SAX2Wrapper::ignorableWhitespace( const XMLCh* const chars,
                                     const unsigned int length) {
  std::cout << "ignorableWhite: " << StrX(chars) << std::endl;
}

void SAX2Wrapper::processingInstruction(const XMLCh* const target,
                                      const XMLCh* const data) {
  std::cout << "processingInstruction: " << StrX(data) << std::endl;
}


void SAX2Wrapper::startDocument() {
  // std::cout << "startDocument called" << std::endl; 
}


void SAX2Wrapper::startElement(const XMLCh* const uri,
                             const XMLCh* const localname,
                             const XMLCh* const qname,
                             const Attributes&  attributes) {


  // Set UAPNode name

  string loc_name = StrX(localname);

  if (!this_root) {
    this_root = new UAPNode(loc_name);
    current = this_root;
  } else {
    current = current->addChild(loc_name);
  }

  // Set URI

  current->setXMLURI(StrX(uri));

  // If there is an associated prefix then strip this off

  string q_name = StrX(qname);
  int ix = q_name.find_last_of(":");
  if (ix != string::npos) {
    current->setXMLPrefix(q_name.substr(0, ix));
    q_name.erase(0, ix+1);
    current->setName(q_name);
  }

  // Transfer attribute information

  unsigned int len = attributes.getLength();
  for (unsigned int index = 0; index < len; index++) {
    string value =  StrX(attributes.getValue(index));
    if (convert_entities) BU::from_xml_string (value);
    current->addAttribute(StrX(attributes.getQName(index)), value);
  }

}

//------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------

string SAX2Wrapper::StrX(const XMLCh* const toTranscode) {
  char* chars = XMLString::transcode(toTranscode);
  string line = chars;
  XMLString::release(&chars);
  return line;
}
