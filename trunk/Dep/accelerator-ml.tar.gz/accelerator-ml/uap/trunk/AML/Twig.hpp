/*
 * Twig
 * Universal Accelerator Parser
 * Copyright (C) 2007 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 */

#ifndef Twig_hpp
#define Twig_hpp 1

#include <iostream>
#include <string>
#include <map>
#include <list>
#include <cassert>

#include "UAP/UAPNode.hpp"

//-----------------------------------------------------------------------
//-----------------------------------------------------------------------

/** Structure for holding xml attribute information.
*/

struct AttributeID {

  AttributeID ();
  AttributeID (std::string name, std::string value);

  std::string name;
  std::string value;
};

//-----------------------------------------------------------------------
//-----------------------------------------------------------------------

typedef std::vector<AttributeID>                     AttributeIDVec;
typedef std::vector<AttributeID>::iterator           AttributeIDVecIter;
typedef std::vector<AttributeID>::const_iterator     AttributeIDVecCIter;

//-----------------------------------------------------------------------
//-----------------------------------------------------------------------
/** Structure for holding the information on one subnode.
*/

class NodeID {

public:

  /** Adds an attribute to the NodeID.
  * @param name     Attribute name.
  * @param value    Attribute value.
  */
  void addAttribute(std::string name, std::string value);

  /** Gets the child UAPNode given the parent node and the NodeID.
  * @param parent     Pointer to the Parent node.
  * @param create     Create the child if not present?
  * @return           Pointer to the child node. NULL if there is no child.
  */
  UAPNode* getChild(UAPNode* parent, bool create = false);

  /** Translates the NodeID to the equivalent string.
  * @return                       Output string.
  */
  std::string toString () const;

  bool operator== (const NodeID& n) const;
  bool operator== (UAPNode* u);

  // Data

  std::string  name;   // NOTE: Right now name is input name
  std::string  xml_local_name;
  std::string  xml_prefix;
  std::string  xml_uri;
  AttributeIDVec attribute;
};

//-----------------------------------------------------------------------
//-----------------------------------------------------------------------

typedef std::vector<NodeID>                     NodeIDVec;
typedef std::vector<NodeID>::iterator           NodeIDVecIter;
typedef std::vector<NodeID>::reverse_iterator   NodeIDVecRIter;
typedef std::vector<NodeID>::const_iterator     NodeIDVecCIter;

bool operator== (const NodeIDVec& x, const NodeIDVec& y);

//-----------------------------------------------------------------------
//-----------------------------------------------------------------------

/** The Twig class is used for pattern matching to sections in a UAPNode tree.
* Example:
* A string (in what is called "bracket" notation):
*   "p1.p2.q[quadrupole:k(a=1,b)@err]"
* When translated into a Twig the string looks like:
*   .target_attribute = "err"
*   .name = "q"
*   .prefix[0] = "p1"
*   .prefix[1] = "p2"
*   .has_brackets = true
*   .node_vec[0]
*     .name = "quadrupole"
*   .node_vec[1]
*     .name = "k"
*     .attrib[0]
*       .name = "a"
*       .value = "1"
*     .attrib[1]
*       .name = "b"
*       .value = ""
* And, for example, this Twig will match to the following portion of a UAPNode tree:
*   <xxx name = "q">
*     |- <quadrupole ttt = "yyy">
*          |- <k a = "1" b = "zzz">
*
* In this example the <k> node is called the "base" node of the twig, and
* the <xxx> node is called the "head" node.
* <pre>
*   Input      Prefix            name   node_vec
*   ---------- ---------------   ----   ---------
*  "A...B.Z[]" ["A", ".", "B"]   "Z"    None
*  "A...Z[]"   ["A", "."]        "Z"    None
*  ".Z[]"      [""]              "Z"    None
*  "Z[]"       []                "Z"    None
*  "X:Y:Z"     []                ""     ["X", "Y", "Z"]
*</pre>
*
* The above string is equivalent to the string (in "bracketless" notation):
*   "*(name = q,prefix = p1.p2):quadrupole:k(a=1,b)%err"
* When translated into a Twig this string looks like
*   .target_attribute = "err"
*   .has_brackets = false
*   .node_vec[0]
*     .name = "*"
*     .attrib[0]
*       .name = "name"
*       .value = "q"
*     .attrib[1]
*       .name = "prefix"
*       .value = "p1.p2"
*   .node_vec[1]
*     .name = "quadrupole"
*   .node_vec[2]
*     .name = "k"
*     .attrib[0]
*       .name = "a"
*       .value = "1"
*     .attrib[1]
*       .name = "b"
*       .value = ""
*
* Note that something in "bracket" notation can always be converted into "bracketless" 
* but the reverse is not always possible.
*
* Note: The difference between Twig("a[]", true) and Twig("a", true) is that the first
* Twig has .has_brackets = true and the second has .has_brackets = false.
*
* Note: When a component is potentially confusing (has internal ".", ":", etc.), quotation
* Marks can be used. Example:
*     q[quadrupole:(k(a="1.3")]
*     beam:'{http://cern.ch/madx}madx':energy
*/

class Twig {

public:

  /** Creates a new Twig.
  */
  Twig ();

  /** Creates a new Twig from an old one.
  * See the fromString method for more details.
  */
  Twig (std::string twig_str, bool has_ele_name = false);

  /** Parses a string and converts it into a Twig.
  * The parsing will handle strings that are or are not in bracket notation.
  * For example: 
  *   twig_str = "q1[quadrupole:k(n=1)@err]" 
  * If the string does not have brackets "[...]", or ":", etc. like:
  *   twig_str = "q"
  * Then it is ambiguous whether "q" is an element name or an attribute name.
  *  
  * @param twig_str       Input string.
  * @param has_ele_name   If True then an ambiguous name is interpreted as an element name.
  * @return               True if there are no syntax problems. False otherwise.
  */
  bool fromString (std::string trig_str, bool has_ele_name = false);

  /** Translates from a Twig to the equivalent string.
  * @return         Output string.
  */
  std::string toString ();

  /** Translates the node part of a Twig to the equivalent string.
  * @param include_target_attrib  If true then append "@target_attribute"
  * @return                       Output string.
  */
  std::string toNodeString (bool include_target_attrib = false);

  /** Finds a subnode that matches a Twig.
  * The root node is assumed to match .name and
  * the root's children are searched for a match to .node_vec[0].
  * When a match to .node_vec[0] is found, the children of the matching node
  * are searched for a match to .node_vec[1], etc. 
  * This method assumes that there are no multiple matches to .node_vec[i].
  * @param root     root node for searching.
  * @param create   If true then create subnode if not found.
  * @return         Pointer to the subnode. NULL if not found nor created.
  */
  UAPNode* getLocalSubNode (UAPNode* root, bool create = false);

  /** Finds a subnode that matches a Twig.
  * The root node is assumed to match .name and
  * the root's children are searched for a match to .node_vec[0].
  * When a match to .node_vec[0] is found, the children of the matching node
  * are searched for a match to .node_vec[1], etc.
  * @param root       Root node for searching.
  * @param twig_str   String equivalent of a string. 
  * @param create     If true then create subnode if not found.
  * @return           Pointer to the subnode. NULL if not found nor created.
  */
  static UAPNode* getLocalSubNode (UAPNode* root, std::string twig_str, bool create = false);

  /** Finds a subnode that matches a Twig.
  * @param root     root node for searching.
  * @return         Pointer to the subnode. NULL if not found nor created.
  */
  UAPNode* getSubNode (UAPNode* root);

  /** Finds all subnodes that matches a Twig.
  * @param root       root node for searching.
  * @param twig_str   String equivalent of a string. 
  * @return           Vec of subnodes.
  */
  static NodeVec getSubNodes (UAPNode* root, std::string twig_str);

  /** Finds all subnodes that matches a Twig.
  * @param root       root node for searching.
  * @return           Vec of subnodes.
  */
  NodeVec getSubNodes (UAPNode* root);

  /** Match name and prefix from a Twig to the name and prefix attributes in
  * a UAPNode. That is, the node is of the form: <xxx name = "..." prefix = "..." />.
  * Note: The twig name and prefix may contain "*" and "%" wild card characters.
  *  @param named_node    Node with a name attribute and possibly a prefix attribute.
  *  @return              True if there is a match. Note: If the node does not have
  *                         a name attribute or the Twig name is "" then False is returned.
  */
  bool matchNameAndPrefix (UAPNode* named_node);

  /** Test to see if two Twigs are identical.
  *  @return       True if the Twigs are identical
  */
  bool operator== (Twig t);

public:

  // Data

  std::string name;
  StrList prefix;
  NodeIDVec nodeid_vec;
  std::string target_attribute;
  bool has_brackets;

private:

  StrList break_line_into_words(std::string line, bool& ok);
  static UAPNode* get_sub_node (UAPNode* root, NodeID node0, NodeIDVec id_vec);
  static void get_sub_nodes (UAPNode* root, NodeID node0, 
                                             NodeIDVec id_vec, NodeVec& node_vec);
  static void get_local_sub_nodes (UAPNode* root, NodeIDVec id_vec, NodeVec& node_vec);
  bool matchName (std::string twig_name, std::string node_name);
  bool matchPrefix (StrList& twig_prefix, StrListCIter twig_iter,
                    StrList& node_prefix, StrListCIter node_iter);

  void nodeid_vec_push_back (NodeID& node, const std::string& twig_str);

};

#endif
