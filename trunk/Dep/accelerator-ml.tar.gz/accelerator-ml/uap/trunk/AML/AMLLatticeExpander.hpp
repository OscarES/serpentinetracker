/*
 * UAP Lattice Expander
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   Daniel Bates <dbates@lbl.gov>
 *   David Sagan <dcs16@cornell.edu>
 */

#ifndef AMLLatticeExpander_hpp
#define AMLLatticeExpander_hpp 1

#include "AML/AMLUtilities.hpp"
#include "UAP/UAPNode.hpp"
#include "UAP/UAPUtilities.hpp"

/** This class handles lattice expansion and expression evaluation.
* <p>
* @author David Sagan
* @ingroup UAP
*/
class AMLLatticeExpander {

public:

  AMLLatticeExpander();

  ~AMLLatticeExpander();

  /** Does lattice expansion for all machines.
  * <p>
  * This method will look for a subnode &lt;AML_representation&gt; of UAPRoot
  * to find the lattice data.
  * A subnode &ltexpanded_lattice&gt; of UAPRoot will be constructed with the
  * expanded lattice. If &lt;expanded_lattice&gt; already exists it will be overwritten.
  * @param UAPRoot    The root node. 
  * @return           &ltexpanded_lattice&gt; node. NULL if there was a problem.
  */
  UAPNode* AMLExpandLattice(UAPNode* UAPRoot);

  /** Routine to move inheratance information from the inheritee lattice element to 
  * the inheritor lattice element (elements with the "inherit" attribute).
  * @param root    The root node for the elements.
  * @return        True if everything is OK. False otherwise.
  */
  static bool InheritBookkeeper (UAPNode* root);

private:

  UAPNode* scratch_root; // Place for scratch trees.
  UAPNode* master_root;   // <master_list> node
  UAPNode* control_root;  // <control_list> node
  UAPNode* global_root;   // <global> node
  NodeMap sector_map;     // map sector names to sector nodes
  NodeMap element_map;    // map element names to element nodes
  NodeMap girder_map;     // map girder names to girder nodes
  NodeMap controller_map; // map controller names to controller nodes
  NodeMap all_map;        // map of all named elements
  NodeVec girder_list;   // list of girders supporting the current element.

  std::map<std::string, NodeVecCIter> map_list_iter;
  std::map<std::string, NodeVec> map_list_children;

  StrList sector_call_list;

  PrintInfoStruct info_out;
  AMLUtilities AU;

  struct multipass_struct {
    int n_pass;
    NodeVec masters;
    NodeVecCIter iter;
    int direction;
  };

  typedef std::map<std::string, multipass_struct*> MultiMap;
  MultiMap multi_map;
  multipass_struct* this_multi;

  NodeVec                 parents;
  std::list<NodeVecIter>  iter_list;

  /* methods */

  void make_named_lists(UAPNode* root);
  bool expand_machines (UAPNode* aml_rep, UAPNode* expand_root);
  bool connect_branch_and_merger (UAPNode* expand_root);
  bool add_controls (UAPNode* aml_rep, UAPNode* expand_root);

  void expand_this_machine (UAPNode* machine_in, UAPNode* aml_rep, UAPNode* expand_root);
  void transfer_node_info_to_machine (std::string who, UAPNode* aml_rep, 
                                             UAPNode* machine_in, UAPNode* machine);

  void transfer_info_to_new_node (UAPNode* old_node, UAPNode* new_node);
  void expand_this_sector_or_list (UAPNode* lat_root, UAPNode* sector_in, 
                    int direction, bool multipass, bool expanding_a_list, std::string tag); 
 
  void add_this_element_or_sector (UAPNode* lat_root, UAPNode* node, StrMap& arg_map,
                int direction, bool multipass, bool expanding_a_list, std::string tag);

  bool get_arg_map (UAPNode* main_sector, UAPNode* sub_sector, StrMap& arg_map);

  void add_multipass_element (UAPNode* element);
  void calc_s_positions (UAPNode* tracking_root);
  void convert_to_actual (UAPNode* tracking_root);

  void superimpose_sector_given_ref (UAPNode* super_sect_in, 
                                                UAPNode* ref_ele, std::string ref_origin = "");
  void superimpose_sector_given_s (UAPNode* super_sect_in, double s_entrance,
                                                  UAPNode* machine_root, std::string tag = "");
  void superimpose_element (UAPNode* super_ele, UAPNode* tracking_lattice);
  UAPNode* superimpose_element_given_ref (UAPNode* super_ele, UAPNode* ref_ele);
  UAPNode* superimpose_element_given_s (UAPNode* ele_in, double s_ref, 
                                                       UAPNode* machine_root);

  NodeVec get_named_elements (const std::string& ref_name, UAPNode* root);

  void apply_sets (std::string set_str, std::string value_str, UAPNode* aml_rep);
  void apply_post_sets (std::string set_str, std::string value_str, 
                                          UAPNode* aml_rep, UAPNode* target_root);

  UAPNode* tree_transverser (UAPNode* root = NULL);

  /** Returns a map of sub-nodes with a given name and a given attribute name.
  * All sub-nodes (children and sub-children) are searched.
  * The map key is the the value string of the attribute
  * the map value is a pointer to the node.
  * @param _name        The name of the node.
  * @param _attribute   The name of the attribute.
  * @param duplicates   A list of duplicates attribute values found (hopefully none).
  *                     This list is useful in generating error messages.
  * @return             A map of the nodes.
  * @see UAPNode
  * @see string
  */
  void map_sub_nodes(UAPNode* root, const std::string& _name, const std::string& _attribute, 
                                   NodeMap& map, StrList& duplicates, bool clear = true); 

  static void inherit_from (UAPNode* parent_ref);
  static void inherit_pusher (UAPNode* from_child, UAPNode* to_node);

};

#endif
