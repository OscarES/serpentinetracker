#include "antlr/CommonHiddenStreamToken.hpp"

ANTLR_BEGIN_NAMESPACE(antlr)

CommonHiddenStreamToken::CommonHiddenStreamToken()
: CommonToken()
{
}

CommonHiddenStreamToken::CommonHiddenStreamToken(int t, const ANTLR_USE_NAMESPACE(std)string& txt)
: CommonToken(t,txt)
{
}

CommonHiddenStreamToken::CommonHiddenStreamToken(const ANTLR_USE_NAMESPACE(std)string& s)
: CommonToken(s)
{
}

RefToken CommonHiddenStreamToken::getHiddenAfter()
{
  return hiddenAfter;
}

RefToken CommonHiddenStreamToken::getHiddenBefore()
{
  return hiddenBefore;
}

RefToken CommonHiddenStreamToken::factory()
{
  return RefToken(new CommonHiddenStreamToken);
}

void CommonHiddenStreamToken::setHiddenAfter(RefToken t)
{
  hiddenAfter = t;
}

void CommonHiddenStreamToken::setHiddenBefore(RefToken t)
{
  hiddenBefore = t;
}

ANTLR_END_NAMESPACE

