/*
 * UAP Exception
 * Universal Accelerator Parser
 * Copyright (C) 2005, 2006 Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov)
 * David Sagan (dcs16@cornell.edu)
 */

#include "UAP/UAPException.hpp"
#include "UAP/UAPNode.hpp"

using namespace std;

UAPException::UAPException(const string& _message) : message(_message), cause(NULL) {}

UAPException::UAPException(const string& _message, const UAPException& _cause) 
: message(_message), cause(new UAPException(_cause)) {}

UAPException::~UAPException() throw() {}

string UAPException::getMessage() const
{
    return message;
}

UAPException* UAPException::getCause() const
{
    return cause;
}

void UAPException::printStackTrace(std::ostream& _file)
{
    std::ostream* file = &_file;
    (*file) << message << std::endl;
    if (cause)
        cause->printStackTrace(_file);
}

string UAPException::toString() const
{
    return "Exception: " + message;
}

std::ostream& operator << (std::ostream& os, const UAPException& except)
{
    os << except.toString() << std::endl;
    return os;
}

std::ostream& operator << (std::ostream& os, const UAPException* except)
{
    os << except->toString() << std::endl;
    return os;
}

UAPIOException::UAPIOException(const string& _message, const string& _file, 
                               int _line) 
: UAPException(_message), file(_file), line(_line) {}

UAPIOException::UAPIOException(const string& _message, const string& _file, 
                               int _line, const UAPException& _cause) 
: UAPException(_message, _cause), file(_file), line(_line) {}

UAPIOException::~UAPIOException() throw() {}

string UAPIOException::getFile() const
{
    return file;
}

int UAPIOException::getLineNumber() const
{
    return line;
}

string UAPIOException::toString() const
{
    std::ostringstream result;
    result << "IOException: Occurred on line "<<line<<" in file \""<<file<<"\"; "<<getMessage();
    return result.str();
}

UAPNodeException::UAPNodeException(const string& _message, UAPNode* _node) 
: UAPException(_message), node(_node) {}

UAPNodeException::UAPNodeException(const string& _message, UAPNode* _node, const UAPException& _cause) 
: UAPException(_message, _cause), node(_node) {}

UAPNodeException::~UAPNodeException() throw() {}

UAPNode* UAPNodeException::getNode() 
{
    return node;
}

string UAPNodeException::toString() const
{
    std::ostringstream result;
    result << "Exception: " << getMessage();
    if (!node)
        result << "\tOccured at node: " << node;
    return result.str();
}

UAPParserException::UAPParserException(const string& _message) 
: UAPException(_message) {}

UAPParserException::UAPParserException(const string& _message, const UAPException& _cause) 
: UAPException(_message, _cause) {}

UAPParserException::~UAPParserException() throw() {}

UAPNotRecognizedException::UAPNotRecognizedException(const string& _message) 
: UAPParserException(_message) {}

UAPNotRecognizedException::UAPNotRecognizedException(const string& _message, const UAPException& _cause) 
: UAPParserException(_message, _cause) {}

UAPNotRecognizedException::~UAPNotRecognizedException() throw() {}

UAPBeamlineExpansionFailedException::UAPBeamlineExpansionFailedException(const string& _message) 
: UAPException(_message) {}

UAPBeamlineExpansionFailedException::UAPBeamlineExpansionFailedException(const string& _message, 
                                                                         const UAPException& _cause) 
: UAPException(_message, _cause) {}

UAPBeamlineExpansionFailedException::~UAPBeamlineExpansionFailedException() throw() {}

UAPInvalidExpressionException::UAPInvalidExpressionException(const string& _message) 
: UAPParserException(_message) {}

UAPInvalidExpressionException::UAPInvalidExpressionException(const string& _message, const UAPException& _cause) 
: UAPParserException(_message, _cause) {}

UAPInvalidExpressionException::~UAPInvalidExpressionException() throw() {}

UAPParameterNotFoundException::UAPParameterNotFoundException(const string& _message) 
: UAPException(_message) {}

UAPParameterNotFoundException::UAPParameterNotFoundException(const string& _message, 
                                                             const UAPException& _cause) 
: UAPException(_message, _cause) {}

UAPParameterNotFoundException::~UAPParameterNotFoundException() throw() {}

UAPNotSupportedException::UAPNotSupportedException(const string& _message) 
: UAPException(_message) {}

UAPNotSupportedException::UAPNotSupportedException(const string& _message, const UAPException& _cause) 
: UAPException(_message, _cause) {}

UAPNotSupportedException::~UAPNotSupportedException() throw() {}

UAPFileCouldNotBeOpened::UAPFileCouldNotBeOpened(const string& _message, 
                                                 const string& _file, int _line) 
: UAPIOException(_message, _file, _line) {}

UAPFileCouldNotBeOpened::UAPFileCouldNotBeOpened(const string& _message, 
                                                 const string& _file, int _line, 
                                                 const UAPException& _cause) 
: UAPIOException(_message, _file, _line, _cause) {}

UAPFileCouldNotBeOpened::~UAPFileCouldNotBeOpened() throw() {}

UAPAttributeNotFound::UAPAttributeNotFound(const string& _message, UAPNode* _node) 
: UAPNodeException(_message, _node) {}

UAPAttributeNotFound::UAPAttributeNotFound(const string& _message, UAPNode* _node, 
                                           const UAPException& _cause) 
: UAPNodeException(_message, _node, _cause) {}

UAPAttributeNotFound::~UAPAttributeNotFound() throw() {}

UAPAttributeConfusion::UAPAttributeConfusion(const string& _message, UAPNode* _node) 
: UAPNodeException(_message, _node) {}

UAPAttributeConfusion::UAPAttributeConfusion(const string& _message, UAPNode* _node, 
                                             const UAPException& _cause) 
: UAPNodeException(_message, _node, _cause) {}

UAPAttributeConfusion::~UAPAttributeConfusion() throw() {}

UAPBadAttributeValue::UAPBadAttributeValue(const string& _message, UAPNode* _node) 
: UAPNodeException(_message, _node) {}

UAPBadAttributeValue::UAPBadAttributeValue(const string& _message, UAPNode* _node, 
                                           const UAPException& _cause) 
: UAPNodeException(_message, _node, _cause) {}

UAPBadAttributeValue::~UAPBadAttributeValue() throw() {}

UAPNodeNotFound::UAPNodeNotFound(const string& _message, UAPNode* _node) 
: UAPNodeException(_message, _node) {}

UAPNodeNotFound::UAPNodeNotFound(const string& _message, UAPNode* _node, 
                                 const UAPException& _cause) 
: UAPNodeException(_message, _node, _cause) {}

UAPNodeNotFound::~UAPNodeNotFound() throw() {}
