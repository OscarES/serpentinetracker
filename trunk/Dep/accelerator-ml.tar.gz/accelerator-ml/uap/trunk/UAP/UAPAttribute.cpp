/*
 * UAP Attribute
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates, Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov), Andy Wolski (awolski@lbl.gov)
 */

#include "UAPAttribute.hpp"

namespace BU = BasicUtilities;
using namespace std;

UAPAttribute::UAPAttribute(const string& _name, const string& _value)
  : name(_name),value(_value) {}

void UAPAttribute::setName(const string& _name)
{
  name = _name;
}

void UAPAttribute::setValue(const string& _value)
{
  value = _value;
}

string UAPAttribute::getName() const
{
  return name;
}

string UAPAttribute::getValue() const
{
  return value;
}

string UAPAttribute::toString() const
{
  return (name+" = \""+value+"\"");
}

bool UAPAttribute::getInt(int& num) {
  bool ok;
  num = BU::string_to_int(value, ok);
  return ok;
} 

bool UAPAttribute::getDouble(double& num) {
  bool ok;
  num = BU::string_to_double(value, ok);
  return ok;
} 

bool UAPAttribute::getBool(bool& num) {
  bool ok;
  num = BU::string_to_bool(value, ok);
  return ok;
} 

std::ostream& operator << (std::ostream& os, const UAPAttribute& attr)
{
  os<<attr.toString();
  return os;
}

std::ostream& operator << (std::ostream& os, const UAPAttribute* attr)
{
  os<<attr->toString();
  return os;
}
