#ifndef INC_ExpressionTreeWalker_hpp_
#define INC_ExpressionTreeWalker_hpp_

#include "antlr/config.hpp"
#include "ExpressionParserTokenTypes.hpp"
/* $ANTLR 2.7.0: "Expression.g" -> "ExpressionTreeWalker.hpp"$ */
#include "antlr/TreeParser.hpp"


/*
 * Expression Parser
 * Universal Accelerator Parser
 * Copyright (C) 2005, 2006, 2007 Andy Wolski, Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov)
 * Andy Wolski  (a.wolski@dl.ac.uk)
 */
 #include <string>
 #include <map>
 #include <list>
 #include "UAPNode.hpp"

/** An evaluator for arithmetic expressions. (You can use this standalone, but you should really
* only use this class with the Universal Accelerator Parser library). Reads a 
* {@link antlr::TokenStream TokenStream} and invokes the appropriate methods in this class.
* <p>
* Once you instantiate the tree walker, you must call the methods {@link #setContext} 
* (with or without an argument), and {@link #setUtilities} with an instance of {@link UAPUtilities}.
* <p>
* The {@link #evaluate} method evaluates an expression.
* @see antlr::TokenStream
* @ingroup ExpressionParsing
*/
class ExpressionTreeWalker : public ANTLR_USE_NAMESPACE(antlr)TreeParser, public ExpressionParserTokenTypes
 {

  private:
  
  /** The utilities class to use to resolve parameters. */
  class UAPUtilities* utilities;
  
  /** The context to use when resolving the attributes of an element. */
  class UAPNode* context;
  
    /** The map of mathematical constants. */
    std::map<std::string, double> mathConstants;
    
  public:
  
  /** Sets the <code>UAPUtilities</code> object to use to resolve parameters.
  * @param _utilities the <code>UAPUtilities</code> object
  * @see UAPUtilities
  */
  void setUtilities(class UAPUtilities* _utilities){
    utilities = _utilities;
  }
  
  /** Sets the <code>UAPNode</code> object to use to resolve attributes of an element.
  * @param _context the <code>UAPNode</code> object
  * @see UAPNode
  */
  void setContext(class UAPNode* _context = NULL){
    context = _context;
  }
    
    /** Sets the map of mathematical constants to use during evaluation.
  * @param _mathConstants the map of <string, double> pairs of mathematical constants.
  */
  void setMathConstants(const std::map<std::string, double>& _mathConstants){
    mathConstants = _mathConstants;
  }
  
  public:
	ExpressionTreeWalker();
	public: double  evaluate(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
	public: double  evaluate_function(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
	public: void mathFunction(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
	public: std::string  subs_params(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
	public: void twConst(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
	public: std::string  amlPath(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
	public: void amlAttrValue(ANTLR_USE_NAMESPACE(antlr)RefAST _t);
private:
	static const char* _tokenNames[];
	
	static const unsigned long _tokenSet_0_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_0;
	static const unsigned long _tokenSet_1_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_1;
};

#endif /*INC_ExpressionTreeWalker_hpp_*/
