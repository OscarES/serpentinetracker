/*
 * UAP Utilities
 * Universal Accelerator Parser
 * Copyright (C) 2005, 2006 Andy Wolski, Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Andy Wolski (a.wolski@dl.ac.uk), Daniel Bates (dbates@lbl.gov), David Sagan (dcs16@cornell.edu)
 */

#ifndef UAPUtilities_hpp
#define UAPUtilities_hpp 1

#include <cmath>
#include <list>
#include <map>
#include <string>
#include "UAPException.hpp"

class UAPNode;
class UAPAttribute;

// These macro definitions are referenced by the methods gasdev and ran1.
#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

/** A collection of utility methods for dealing with various UAP model activities.
* @author Andy Wolski, Daniel Bates, David Sagan
* @ingroup CoreServices
*/
class UAPUtilities
{
public:

  /** Creates a new collection of utilities for use with the specified UAPNode.
  * @param _UAPRootNode the root node of the UAP model
  * @see UAPNode
  */
  UAPUtilities(UAPNode* _UAPRootNode);

  /** Destructor. */
  ~UAPUtilities();

  /** Sets the root UAP node to use for this class.
  * @param _UAPRootNode the node
  * @see UAPNode
  */
  void setUAPRootNode(UAPNode* _UAPRootNode);

  /** Returns the root UAP node used by this class.
  * @return the root node.
  * @see UAPNode
  */
  UAPNode* getUAPRootNode();

  /** Evaluates arithmetic expressions.
  * <p>
  * This method reduces all arithmetic expressions to a constant starting from the root node.
  * @return see {@link #evaluate(UAPNode)}
  */
  int evaluate();
  
  /** Evaluates arithmetic expressions starting from the specified node.
  * <p>
  * This method reduces all arithmetic expressions to a constant.
  * @param node       The node to evaluate
    * @param context  The <code>UAPNode</code> object to use to resolve element attribute names (default: <code>NULL</code>)
  * @return <code>-1</code>.
  */
  int evaluate(UAPNode* node, UAPNode* context = 0);
  
  /** Returns the evaluted value of the specified attribute. 
  * @param attrb    The attribute to evaluate
  * @param context  The <code>UAPNode</code> object to use to resolve element attribute names (default: <code>NULL</code>)
  * @return         The evaluted value of the attribute.
  * @exception      UAPParserException if evaluation failed
  */
  double evaluate(const std::string attrib, UAPNode* context = NULL) throw(UAPParserException);
  
  double evaluate(UAPAttribute&, UAPNode* context = NULL) throw(UAPParserException);

  /** Returns the value for the specified parameter or controller element.
  * <p>
  * This method stores the value of the specified parameter in the
  * variable specified by the argument param_value.
  * @param node         The root node for the search for a parameter with name = param_name.
  * @param param_name   The parameter name.
  * @param param_value  The variable to store the value.
  * @see UAPNode
  */
  int getParameterValue(UAPNode* node, std::string& param_name, std::string& param_value);
  
  /** Appends the specified constant to the list of constants.
  * <p>
  * If the argument allow_overwrite is <code>true</code> any existing value for the constant will 
  * be overwritten with specified value.
  * @param name             The name of the constant
  * @param value            The value of the constant
  * @param allow_overwrite  <code>true</code> to overwrite the value of the constant if it exists;
  *                           <code>false</code> otherwise (default: false).
  */
  void addConstant(const std::string& name, double value, bool allow_overwrite = false);
  
  /** Removes the constant with the specified name from the list of constants.
  * @param name the name of the constant
  * @return <code>-1</code> if constant was removed;
  *         <code>0</code> if the constant does not exist.
  */
  int removeConstant(const std::string& name);
    
  /** Parses the specified expression and returns a list of identifiers in the expression.
  * @param expr the expression to parse
  * @return a list of identifier in the expression.
  * @exception UAPParserException if the expression is malformed or invalid
  */
  std::list<std::string> parseIdentifiers(const std::string& expr) throw(UAPParserException);
    
  /** Returns the next pseudorandom, Gaussian distributed, number with 
  * mean 0.0 and variance 1.0.
  * @return the next pseudorandom number.
  */
  double nextGaussian();
  
  /** Returns the next pseudorandom number between 0.0 and 1.0.
  * @return the next pseudorandom number.
  */
  double nextDouble();
  
private:

  /** The root node of the UAP model. */
  UAPNode* UAPRootNode;
  
  /** The random number generator seed. */
  long seed;
    
  /** The map of mathematical constants. */
  std::map<std::string, double> constants;
  
  /** Returns a normally distributed deviate with zero mean and unit variance.
  * See <i>Numerical Receipes In C: The Art Of Scientific Computing</i> page 289.
  * @param idum seed
  * @return a normally distributed deviate with zero mean and unit variance.
  */
  float gasdev(long* idum);
  
  /** Returns a uniform random deviate between 0.0 and 1.0 (exclusive of the endpoint values).
  * See <i>Numerical Receipes In C: The Art Of Scientific Computing</i> page 280.
  * @param idum seed
  * @return a uniform random deviate between 0.0 and 1.0 (exclusive of the endpoint values).
  */
  float ran1(long* idum);

};

#endif
