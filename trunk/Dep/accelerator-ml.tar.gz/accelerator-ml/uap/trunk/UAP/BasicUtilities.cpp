/*
 * UAP Utilities
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan, Andy Wolski, Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 *   Andy Wolski (a.wolski@dl.ac.uk)
 *   Daniel Bates (dbates@lbl.gov)
 */

#include <iostream>
#include <algorithm>
#include <sstream>

#include "UAP/BasicUtilities.hpp"

namespace BU = BasicUtilities;
using namespace std;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string PrintInfoStruct::parsing_status;
string PrintInfoStruct::file_name; 
string PrintInfoStruct::statement;
int PrintInfoStruct::ix_line;
bool PrintInfoStruct::everything_ok;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

StrList& operator<< (StrList& s_list, const string& str) {
  s_list.push_back(str);
  return s_list;
}

StrList& operator<< (StrList& list_out, StrList list_in) {
  list_out.merge(list_in);
  return list_out;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

StrVec& operator<< (StrVec& s_vector, const string& str) {
  s_vector.push_back(str);
  return s_vector;
}

StrVec& operator<< (StrVec& vector_out, StrVec vector_in) {
  vector_out.insert(vector_out.end(), vector_in.begin(), vector_in.end());
  return vector_out;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

std::string BU::element_val(StrList& s_list, int index) {
  if (index > s_list.size()-1) return "";
  StrListIter is = s_list.begin();
  for (int i = 0; i < index; i++)
    is++;
  return *is;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::trim(string str) {


  const string delims = " \t\r\n";

  size_t ix = str.find_first_not_of(delims);
  if (ix == string::npos) return "";

  str.erase(0, ix);
  ix = str.find_last_not_of(delims);
  str.erase(ix+1);

  return str;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BU::split_file_name (string file_name_in, string& dir, string& base, bool& is_relative) {

  split_file_name (file_name_in, dir, base);

  if (dir == "") {
    is_relative = true;
    return;
  }

  char dir0 = dir[0];

  if (dir0 == '/' || dir0 == '\\' || dir0 == '~') {
    is_relative = false;
  } else if (dir0 == '.') {
    is_relative = true;
  } else if (isalpha(dir0) || isdigit(dir0)) {
    is_relative = true;
  } else {
    is_relative = false;
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BU::split_file_name (string file_name_in, string& dir, string& base) {

  // Look for the end of the dir part of the file_name

  int ix_dir = -1;

  int i = file_name_in.rfind("]");
  if (i != string::npos && i > ix_dir) ix_dir = i;

  i = file_name_in.rfind(":");
  if (i != string::npos && i > ix_dir) ix_dir = i;
  
  i = file_name_in.rfind("/");
  if (i != string::npos && i > ix_dir) ix_dir = i;
  
  i = file_name_in.rfind("\\");
  if (i != string::npos && i > ix_dir) ix_dir = i;
  
  if (ix_dir == -1) {
    base = file_name_in;
    dir = "";
    return;  
  }

  dir = file_name_in.substr(0, ix_dir+1);
  base = file_name_in.substr(ix_dir+1);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

int BU::string_to_int (const string& str, bool& ok) { 
  ok = false;
  if (str == "") return 0;
  istringstream iss(str);
  int value;
  ok = !(iss >> dec >> value).fail();
  return value;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

int BU::string_to_int (const string& str) { 
  if (str == "") throw;
  istringstream iss(str);
  int value;
  if ((iss >> dec >> value).fail()) throw;
  return value;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BU::is_int (const string& str) { 
  if (str.length() == 0) return false;
  for(unsigned int i=0; i < str.length(); i++) {
    if (i == 0  && (str[i] == '-' || str[i] == '+')) {
      if (str.length() == 1) return false;
      continue;
    }
    if (!isdigit(str[i])) return false;
  }
 return true; 
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

double BU::string_to_double (const string& str, bool& ok) { 
  ok = false;
  if (str == "") return 0;
  istringstream iss(str);
  double value;
  ok = !(iss >> dec >> value).fail();
  return value;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

double BU::string_to_double (const string& str) { 
  if (str == "") throw;
  istringstream iss(str);
  double value;
  if ((iss >> dec >> value).fail()) throw;
  return value;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BU::is_double (const string& str) { 

  if (str.length() == 0) return false;

  double d;
  istringstream i(str);

  if (i >> d) 
    return true;
  else
    return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BU::string_to_bool (const string& str, bool& ok) { 
  ok = false;
  if (str == "") return false;
  istringstream iss(str);
  bool value;
  ok =  !(iss >> boolalpha >> value).fail();
  return value;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BU::string_to_bool (const string& str) { 
  if (str == "") throw;
  istringstream iss(str);
  bool value;
  if ((iss >> boolalpha >> value).fail()) throw;
  return value;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::bool_to_string (bool this_bool) { 
  if (this_bool) return "TRUE";
  return "FALSE";
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BU::is_bool (const string& str) { 

  if (str.length() == 0) return false;

  bool b;
  istringstream i(str);

  if (i >> b) 
    return true;
  else
    return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::int_to_string (const int i, bool& ok) {
  ostringstream oss;
  string str;
  if (!(oss << i)) {
    ok = false;
    return "";
  }
  ok = true;
  return oss.str();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::int_to_string (const int i) {
  ostringstream oss;
  string str;
  if (!(oss << i)) throw;
  return oss.str();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::double_to_string (const double r, bool& ok) {
  ostringstream oss;
  if (!(oss << r)) {
    ok = false;
    return "";
  }
  ok = true;
  return oss.str();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::double_to_string (const double r) {
  ostringstream oss;
  if (!(oss << r)) throw;
  return oss.str();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::str_to_lower(const string& str_in) {
  string str_out = str_in;
  for(unsigned int i=0; i < str_in.length(); i++) {
    str_out[i] = tolower(str_in[i]);
  }
 return str_out; 
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::add_parens_if_needed (const string& expression) {

  // Rule: We need to add parantheses if there is a "+" or "-" sign outside
  // of any parentheses. For example: An expression like "(a/b) + c" needs 
  // parentheses but the expression "a * (b + c)" does not.

  int np = 0;

  for (int i = 0; i < expression.size(); i++) {
    char ch = expression[i];
    if (ch == '(') np++;
    if (ch == ')') np--;
    if (np != 0) continue;
    if (ch == '+' || ch == '-')
      return "(" + expression + ")";
  }

  return expression;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::str_to_upper(const string& str_in) {
  string str_out = str_in;
  for(unsigned int i=0; i < str_in.length(); i++) {
    str_out[i] = toupper(str_in[i]);
  }
 return str_out; 
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::to_xml_string (string str_in) {

  int i = -1;

  while ((i = str_in.find("&", i+1)) != string::npos)
    str_in.replace(i, 1, "&amp;");
    
  while ((i = str_in.find("<")) != string::npos)
    str_in.replace(i, 1, "&lt;");
    
  while ((i = str_in.find(">")) != string::npos)
    str_in.replace(i, 1, "&gt;");
    
  while ((i = str_in.find("\"")) != string::npos)
    str_in.replace(i, 1, "&quote;");
    
  return str_in;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::from_xml_string (string str_in) {

  size_t i;

  while ((i = str_in.find("&amp;")) != string::npos)
    str_in.replace(i, 5, "&");
    
  while ((i = str_in.find("&lt;")) != string::npos)
    str_in.replace(i, 4, "<");
    
  while ((i = str_in.find("&gt;")) != string::npos)
    str_in.replace(i, 4, ">");
    
  while ((i = str_in.find("&quote;")) != string::npos)
    str_in.replace(i, 7, "\"");
    
  while ((i = str_in.find("&rsquo;")) != string::npos)
    str_in.replace(i, 7, "'");
    
  return str_in;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BU::found(StrList& s_list, const string& item) {
  return (find(s_list.begin(), s_list.end(), item) != s_list.end());
}

bool BU::found(StrVec& s_vector, const string& item) {
  return (find(s_vector.begin(), s_vector.end(), item) != s_vector.end());
}

bool BU::found(string& str, const string& item) {
  return (str.find(item) != string::npos);
}

bool BU::found_value(StrMap& string_map, const string& item) {
  for (StrMapCIter im = string_map.begin(); im != string_map.end(); im++) {
    if (im->second == item) return true;
  }
  return false;
}

StrListIter BU::find(StrList& s_list, const string& item) {
  return find(s_list.begin(), s_list.end(), item);
}

StrListIter BU::rfind(StrList& s_list, const string& item) {
  StrListIter is_item = s_list.end();
  for (StrListIter is = s_list.begin(); is != s_list.end(); is++)
    if (*is == item) is_item = is;
  return is_item;
}

StrList BU::list_copy(StrListIter begin, StrListIter end) {
  StrList str_list;
  for (StrListIter is = begin; is != end; is++) 
    str_list.push_back(*is);
  return str_list;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BU::str_pop (StrList& str_list) {

  string front = str_list.front();
  str_list.pop_front();
  return front;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BU::get_taylor_exponents (const string& exp_str, IntVec& exp_vec) {

  if (exp_vec.size() != 6) exp_vec.resize(6);

  bool ok;
  int i = 0;

  for (size_t j = 0; j < exp_str.size(); j++) {
    if (exp_str.substr(j,1) == " ") continue;
    size_t j2 = exp_str.find(" ", j);
    if (j2 == string::npos) j2 = exp_str.size();
    if (i == 6) return false;
    exp_vec[i] = string_to_int(exp_str.substr(j, j2-j), ok);
    if (exp_vec[i++] < 0) return false;  // Negative value not acceptable.
    if (!ok) return false;
    j = j2;
    if (j == exp_str.size()) break;
  }

  if (i < 6) return false;
  return true;

}

//--------------------------------------------------------------------------------------------

bool BU::splitXMLName (const string& _name, string& uri, string& prefix, string& loc_name) {
  bool prefix_found;
  return splitXMLName(_name, uri, prefix, loc_name, prefix_found);
}

//--------------------------------------------------------------------------------------------

bool BU::splitXMLName (const string& _name, string& uri, string& prefix, 
                                             string& loc_name, bool& prefix_found) {

  uri = "";
  prefix = "";
  loc_name = _name;
  prefix_found = false;

  if (_name.size() == 0) return true;

  // A "{...}" gives the uri

  if (_name[0] == '{') {
    size_t ix = _name.find("}");
    if (ix == string::npos) return false;
    uri = _name.substr(1, ix-1);
    if (uri == "") {
      cout << "UAPNode::splitXMLName: Blank URIs not allowed: " << _name << endl;
      throw;  
    }
    loc_name = _name.substr(ix+1);
  }

  // A ":", if present, means there is a prefix.

  size_t ix = loc_name.find(":");
  if (ix != string::npos) {
    prefix = loc_name.substr(0, ix);
    loc_name = loc_name.substr(ix+1);
    prefix_found = true;
  } else {
    prefix_found = false;
  }

  return true;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void PrintInfoStruct::error (string line1, string line2, string line3) {
  cout << endl;
  cout << "ERROR: " << line1 << endl;
  print (line2, line3);
  everything_ok = false;
  return;
}

void PrintInfoStruct::warning (string line1, string line2, string line3) {
  cout << endl;
  cout << "Warning: " << line1 << endl;
  print (line2, line3);
  return;
}

void PrintInfoStruct::print (string& line2, string& line3) {

  // If line2 or line3 is made up of multiple lines then indent
  // everything 7 spaces.

  string space_str = string(5, ' ');

  if (line2 != "") {
    line2 += space_str;
    while (true) {
      size_t ix = line2.find("\n");
      if (ix == string::npos) {
        cout << space_str << line2 << endl;
        break;
      } else {
        cout << space_str << line2.substr(0,ix+1);
        line2.erase(0,ix+1);
      }
    }
  }

  if (line3 != "") {
    line3 += space_str;
    while (true) {
      size_t ix = line3.find("\n");
      if (ix == string::npos) {
        cout << space_str << line3 << endl;
        break;
      } else {
        cout << space_str << line3.substr(0,ix+1);
        line3.erase(0,ix+1);
      }
    }
  }

  cout << space_str << "While: " << parsing_status << endl;
  if (file_name != "") cout << "  IN FILE: " << file_name << endl;
  if (ix_line > 0)     cout << "  AT OR BEFORE LINE: " << ix_line << endl;
  if (statement != "") {
    cout << "  IN STATEMENT: " << BU::trim(statement) << endl;
  }
  everything_ok = false;
  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool FileStackElement::splitName (const string& file_name_in) {

  this_name = file_name_in;
  bool is_relative;
  BU::split_file_name (file_name_in, this_dir, this_file_no_dir, is_relative);
  return is_relative;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void FileStackList::addFile (const string& file_name) {

  FileStackElement this_file;
  bool relative_path = this_file.splitName(file_name);

  if (!relative_path || file_list.size() == 0) {
    this_file.full_dir = this_file.this_dir;
    this_file.full_name = this_file.this_name;
  } else {
    FileStackElement prev_file = file_list.back();
    this_file.full_dir = prev_file.full_dir + this_file.this_dir;
    this_file.full_name = prev_file.full_dir + this_file.this_name;    
  }

  file_list.push_back(this_file);
  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

StreamStruct::StreamStruct(string file_name) {
  ix_line = 0;
  continuation_char = "";
  n_indent = 8;
  max_len = 98;
  if (file_name == "") out_file = NULL;
  else out_file = new ofstream(file_name.c_str());
}

void StreamStruct::close_file() {
  if (!out_file) return;
  if (out_file->is_open()) {
    out_file->close();
    delete out_file;
  }
}

void StreamStruct::open_file(const string& file_name) {
  out_file = new ofstream(file_name.c_str());
}

bool StreamStruct::is_open() {
  if (out_file) return out_file->is_open();
  return false;
}

StreamStruct& StreamStruct::operator<< (const string& str) {

  if (str == "") return *this;

  int len = ix_line + str.length();
  if (len < max_len) {
    *out_file << str;
    ix_line = len;
  } else {
    if (ix_line != 0) {
      *out_file << " " << continuation_char << endl;
      *out_file << string(n_indent, ' ');
      ix_line = n_indent;
    }
    *out_file << str;
    ix_line += str.length();
  }
  return *this;
}

StreamStruct& StreamStruct::operator<< (const int i) {
  bool ok;
  return (*this << BU::int_to_string(i, ok));
}

StreamStruct& StreamStruct::operator<< (EndStruct& s) {
  *out_file << endl;
  ix_line = 0;
  return *this;
}

StreamStruct& StreamStruct::operator= (StreamStruct& s) {
  out_file          = s.out_file; 
  continuation_char = s.continuation_char;
  n_indent          = s.n_indent;
  return *this;
}

