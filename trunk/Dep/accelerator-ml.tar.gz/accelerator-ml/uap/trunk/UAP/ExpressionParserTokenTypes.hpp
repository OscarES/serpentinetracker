#ifndef INC_ExpressionParserTokenTypes_hpp_
#define INC_ExpressionParserTokenTypes_hpp_

/* $ANTLR 2.7.0: "Expression.g" -> "ExpressionParserTokenTypes.hpp"$ */
struct ExpressionParserTokenTypes {
	enum {
		EOF_ = 1,
		NULL_TREE_LOOKAHEAD = 3,
		SEMI = 4,
		PLUS = 5,
		MINUS = 6,
		MULT = 7,
		DIV = 8,
		MOD = 9,
		POW = 10,
		LPAREN = 11,
		COMMA = 12,
		RPAREN = 13,
		IDENT = 14,
		LBRACKET = 15,
		COLON = 16,
		RBRACKET = 17,
		AT = 18,
		// "." = 19
		EQUAL = 20,
		NUM_DOUBLE = 21,
		NUM_FLOAT = 22,
		STRING_LITERAL_S = 23,
		STRING_LITERAL_D = 24,
		LITERAL_sqrt = 25,
		LITERAL_log = 26,
		LITERAL_exp = 27,
		LITERAL_sin = 28,
		LITERAL_cos = 29,
		LITERAL_tan = 30,
		LITERAL_asin = 31,
		LITERAL_acos = 32,
		LITERAL_atan = 33,
		LITERAL_atan2 = 34,
		LITERAL_abs = 35,
		LITERAL_max = 36,
		LITERAL_min = 37,
		LITERAL_ran = 38,
		LITERAL_ran_gauss = 39,
		LITERAL_randf = 40,
		LITERAL_gauss = 41,
		LITERAL_tgauss = 42,
		// "user0" = 43
		// "user1" = 44
		// "user2" = 45
		FUNC = 46,
		AMLPATH = 47,
		AMLPATHNODE = 48,
		AMLPATHATTREXPR = 49,
		AMLPATHELEMENT = 50,
		AMLPATHTAGLIST = 51,
		AMLPATHATTRIB = 52,
		WS_ = 53,
		ESC = 54,
	};
};
#endif /*INC_ExpressionParserTokenTypes_hpp_*/
