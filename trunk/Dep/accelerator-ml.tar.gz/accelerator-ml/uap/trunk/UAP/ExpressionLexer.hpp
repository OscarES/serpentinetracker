#ifndef INC_ExpressionLexer_hpp_
#define INC_ExpressionLexer_hpp_

#include "antlr/config.hpp"
/* $ANTLR 2.7.0: "Expression.g" -> "ExpressionLexer.hpp"$ */
#include "antlr/CommonToken.hpp"
#include "antlr/InputBuffer.hpp"
#include "antlr/BitSet.hpp"
#include "ExpressionParserTokenTypes.hpp"
#include "antlr/CharScanner.hpp"

/*
 * Expression Parser
 * Universal Accelerator Parser
 * Copyright (C) 2005, 2006, 2007 Andy Wolski, Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov)
 * Andy Wolski  (a.wolski@dl.ac.uk)
 */
 #include <string>
 #include <map>
 #include <list>
 #include "UAPNode.hpp"

/** A lexer for arithmetic expressions. (You can use this standalone, but you should really
* only use this class with the Universal Accelerator Parser library). Reads a 
* {@link antlr::TokenStream TokenStream} and invokes the appropriate methods in this class.
* @see antlr::TokenStream
* @ingroup ExpressionParsing
*/
class ExpressionLexer : public ANTLR_USE_NAMESPACE(antlr)CharScanner, public ExpressionParserTokenTypes
 {
private:
	void initLiterals();
public:
	bool getCaseSensitiveLiterals() const;
public:
	ExpressionLexer(ANTLR_USE_NAMESPACE(std)istream& in);
	ExpressionLexer(ANTLR_USE_NAMESPACE(antlr)InputBuffer& ib);
	ExpressionLexer(const ANTLR_USE_NAMESPACE(antlr)LexerSharedInputState& state);
	ANTLR_USE_NAMESPACE(antlr)RefToken nextToken();
	public: void mWS_(bool _createToken);
	public: void mLPAREN(bool _createToken);
	public: void mRPAREN(bool _createToken);
	public: void mLBRACKET(bool _createToken);
	public: void mRBRACKET(bool _createToken);
	public: void mPLUS(bool _createToken);
	public: void mMINUS(bool _createToken);
	public: void mMULT(bool _createToken);
	public: void mDIV(bool _createToken);
	public: void mMOD(bool _createToken);
	public: void mPOW(bool _createToken);
	public: void mCOMMA(bool _createToken);
	public: void mCOLON(bool _createToken);
	public: void mEQUAL(bool _createToken);
	public: void mAT(bool _createToken);
	public: void mSEMI(bool _createToken);
	public: void mIDENT(bool _createToken);
	public: void mNUM_FLOAT(bool _createToken);
	public: void mNUM_DOUBLE(bool _createToken);
	public: void mSTRING_LITERAL_S(bool _createToken);
	protected: void mESC(bool _createToken);
	public: void mSTRING_LITERAL_D(bool _createToken);
private:
	
	static const unsigned long _tokenSet_0_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_0;
	static const unsigned long _tokenSet_1_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_1;
};

#endif /*INC_ExpressionLexer_hpp_*/
