/*
 * UAP Exception
 * Universal Accelerator Parser
 * Copyright (C) 2005, 2006 Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov)
 * David Sagan (dcs16@cornell.edu)
 */

#ifndef UAPException_hpp
#define UAPException_hpp 1

#include <iostream>
#include <sstream>
#include <string>
#include <exception>

class UAPNode;

/** This class and its subclasses indicates conditions that a 
* reasonable application might want to catch.
* @see std::exception
* @ingroup CoreUAP
* @{
*/
class UAPException : public std::exception {
    
public:
    
    /** Constructs a new exception with the specified detail message.
    * @param _message the detail message (default: "Unspecified exception")
    */
    UAPException(const std::string& _message = "Unspecified exception");
    
    /** Constructs a new exception with the specified detail message.
    * @param _message the detail message
    * @param _cause the cause
    */
    UAPException(const std::string& _message, const UAPException& _cause);
    
    /** Destructor. */
    virtual ~UAPException() throw();
    
    /** Returns the detail message string of this exception.
    * @return the detail message string of this exception.
    */
    std::string getMessage() const;
    
    /** Returns the cause of this exception or <code>null</code> if the cause is nonexistent or unknown.
    * @return the cause of this exception or <code>null</code> if the cause is nonexistent or unknown.
    * @see UAPException
    */
    UAPException* getCause() const;
    
    /** Prints this exception and its backtrace to the specified file.
    * @param _file the file to use for output (default: standard error stream)
    * @see std::ostream
    */
    void printStackTrace(std::ostream& _file = std::cerr);
    
    /** Returns a string object with a short 
    * description of this exception.
    * @return a short description of this exception.
    * @see #getMessage
    */
    virtual std::string toString() const;
    
    /** Overrides the default output stream operator. 
    * @see #toString
    */
    friend std::ostream& operator << (std::ostream& os, const UAPException& except);
    friend std::ostream& operator << (std::ostream& os, const UAPException* except);
    
private:
    
    /** The detail message of this exception. */
    std::string message;
    
    /** The cause of this exception. */
    UAPException* cause;

};

/** Signals that an I/O exception of some sort has occurred.
* <p>
* This class is the general class of exceptions produced by failed or interrupted I/O operations.
* @see UAPException
*/
class UAPIOException : public UAPException {
    
public:
    
    /** Constructs an <code>UAPIOException</code> with the specified detail message,
    * the name of the file and the line number.
    * @param _message the detail message (default: "Unspecified exception")
    * @param _file the file (default: "Unspecified file name")
    * @param _line the line number (default: 0)
    */
    UAPIOException(const std::string& _message = "Unspecified exception", 
                   const std::string& _file = "Unspecified file name", 
                   int _line = 0);
    
    /** Constructs an <code>UAPIOException</code> with the specified detail message,
    * the name of the file and the line number.
    * @param _message the detail message
    * @param _file the file
    * @param _line the line number
    * @param _cause the cause
    */
    UAPIOException(const std::string& _message, 
                   const std::string& _file, 
                   int _line, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPIOException() throw();
    
    /** Returns the name of the file where this exception occurred.
    * @return the name of the file where this exception occurred.
    */
    std::string getFile() const;
    
    /** Returns the line number in the file where this exception occurred.
    * @return the line number in the file where this exception occurred.
    */
    int getLineNumber() const;
    
    /** Overrides the default toString operator. 
    * @see #UAPException::toString
    */
    std::string toString() const;
    
private:
        
    /** The name of the file where this exception occurred. */
    std::string file;
    
    /** The line number where this exception occurred. */
    int line;
};

/** Signals that a node exception of some sort occurred.
* @see UAPException
*/
class UAPNodeException : public UAPException {
    
public:
    
    /** Constructs an <code>UAPNodeException</code> with the specified detail message,
    * and the <code>UAPNode</code> object.
    * @param _message the detail message (default: "Unspecified exception")
    * @param _node the <code>UAPNode</code> (default: <code>NULL</code>)
    * @see UAPNode
    */
    UAPNodeException(const std::string& _message = "Unspecified exception", UAPNode* _node = NULL);
    
    /** Constructs an <code>UAPNodeException</code> with the specified detail message,
    * and the <code>UAPNode</code> object.
    * @param _message the detail message
    * @param _node the <code>UAPNode</code>
    * @param _cause the cause
    * @see UAPNode
    */
    UAPNodeException(const std::string& _message, UAPNode* _node, const UAPException& _cause);

    /** Destructor. */
    ~UAPNodeException() throw();
    
    /** Returns the <code>UAPNode</code> where this exception occurred.
    * @return <code>NULL</code> or the <code>UAPNode</code> where this exception occurred.
    * @see UAPNode
    */
    UAPNode* getNode();
    
    /** Overrides the default toString operator. 
    * @see #UAPException::toString
    */
    std::string toString() const;
    
private:
    
    /** The node where this exception occured. */
    UAPNode* node;
    
};

/** Encapsulates a general parser error or warning.
* @see UAPException
*/
class UAPParserException : public UAPException {
    
public:
    
    /** @see UAPException */
    UAPParserException(const std::string& _message = "Unspecified exception");
    
    /** @see UAPException */
    UAPParserException(const std::string& _message, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPParserException() throw();

};

/** Signals an unrecognized identifier.
* <p>
* A parser may throw this exception when it finds an unrecognized identifier.
* @see UAPParserException
*/
class UAPNotRecognizedException : public UAPParserException {

public:
    
    /** @see UAPParserException */
    UAPNotRecognizedException(const std::string& _message = "Unspecified exception");
    
    /** @see UAPParserException */
    UAPNotRecognizedException(const std::string& _message, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPNotRecognizedException() throw();

};

/** Signals that a beamline expansion operation failed.
* @version 1.0, 08/02/05
* @see UAPException
*/
class UAPBeamlineExpansionFailedException : public UAPException {
    
public:
    
    /** @see UAPException */
    UAPBeamlineExpansionFailedException(const std::string& _message = "Unspecified exception");
    
    /** @see UAPException */
    UAPBeamlineExpansionFailedException(const std::string& _message, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPBeamlineExpansionFailedException() throw();

};

/** Signals that a invalid expression was encountered.
* <p>
* This exception may be thrown upon evaluation of a malformed arithmetic
* expression or other syntactical errors.
* @see UAPParserException
*/
class UAPInvalidExpressionException : public UAPParserException {
    
public:

    /** @see UAPException */
    UAPInvalidExpressionException(const std::string& _message = "Unspecified exception");
    
    /** @see UAPException */
    UAPInvalidExpressionException(const std::string& _message, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPInvalidExpressionException() throw();

};

/** Signals that a parameter was not found.
* @see UAPException
*/
class UAPParameterNotFoundException : public UAPException {

public:

    /** @see UAPException */
    UAPParameterNotFoundException(const std::string& _message = "Unspecified exception");
    
    /** @see UAPException */
    UAPParameterNotFoundException(const std::string& _message, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPParameterNotFoundException() throw();

};

/** Thrown to indicate that a particular feature is not implemented.
* @see UAPException
*/
class UAPNotSupportedException: public UAPException {

public:
    
    /** @see UAPException */
    UAPNotSupportedException(const std::string& _message = "Unspecified exception");
    
    /** @see UAPException */
    UAPNotSupportedException(const std::string& _message, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPNotSupportedException() throw();
    
};

/** Thrown to indicate that a file could not be opened.
* @see UAPIOException
*/
class UAPFileCouldNotBeOpened: public UAPIOException {
    
public:
    
    /** @see UAPIOException */
    UAPFileCouldNotBeOpened(const std::string& _message = "Unspecified exception", 
                            const std::string& _file = "Unspecified file name", 
                            int _line = 0);
    
    /** @see UAPIOException */
    UAPFileCouldNotBeOpened(const std::string& _message, 
                            const std::string& _file, int _line, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPFileCouldNotBeOpened() throw();
    
};

/** Thrown to indicate that an expected attribute was not present.
* @see UAPNodeException
*/
class UAPAttributeNotFound: public UAPNodeException {

public:

    /** @see UAPNodeException */
    UAPAttributeNotFound(const std::string& _message = "Unspecified exception", UAPNode* _node = NULL);
    
    /** @see UAPNodeException */
    UAPAttributeNotFound(const std::string& _message, UAPNode* _node, const UAPException& _cause);    
    
    /** Destructor. */
    ~UAPAttributeNotFound() throw();

};

/** Thrown to indicate that there were conflicting attributes present.
* @see UAPNodeException
*/
class UAPAttributeConfusion: public UAPNodeException {

public:
    
    /** @see UAPNodeException */
    UAPAttributeConfusion(const std::string& _message = "Unspecified exception", UAPNode* _node = NULL);
    
    /** @see UAPNodeException */
    UAPAttributeConfusion(const std::string& _message, UAPNode* _node, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPAttributeConfusion() throw();

};

/** Thrown to indicate that the attribute value is bad in some way.
* @see UAPNodeException
*/
class UAPBadAttributeValue: public UAPNodeException {
    
public:
    
    /** @see UAPNodeException */
    UAPBadAttributeValue(const std::string& _message = "Unspecified exception", UAPNode* _node = NULL);
    
    /** @see UAPNodeException */
    UAPBadAttributeValue(const std::string& _message, UAPNode* _node, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPBadAttributeValue() throw();

};

/** Thrown to indicate that an expected node was not present.
* @see UAPNodeException
*/
class UAPNodeNotFound: public UAPNodeException {

public:

    /** @see UAPNodeException */
    UAPNodeNotFound(const std::string& _message = "Unspecified exception", UAPNode* _node = NULL);
    
    /** @see UAPNodeException */
    UAPNodeNotFound(const std::string& _message, UAPNode* _node, const UAPException& _cause);
    
    /** Destructor. */
    ~UAPNodeNotFound() throw();

};


/** @} */
#endif
