/* $ANTLR 2.7.0: "Expression.g" -> "ExpressionParser.cpp"$ */
#include "ExpressionParser.hpp"
#include "antlr/NoViableAltException.hpp"
#include "antlr/SemanticException.hpp"

  #include <list>
  #include "antlr/MismatchedTokenException.hpp"
  #include "UAP/UAPException.hpp"
  #define EXP_DEFAULT_CATCH ANTLR_USE_NAMESPACE(antlr)Token* nextToken = NULL; \
            try { \
              nextToken = LT(2); \
            } catch (...) { \
              throw UAPParserException("error: parse error at end of input"); \
            } \
            throw UAPParserException("error: parse error before '"+(nextToken)->getText()+"' token"); \

ExpressionParser::ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,k)
{
	setTokenNames(_tokenNames);
}

ExpressionParser::ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(tokenBuf,2)
{
	setTokenNames(_tokenNames);
}

ExpressionParser::ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer, int k)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,k)
{
	setTokenNames(_tokenNames);
}

ExpressionParser::ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(lexer,2)
{
	setTokenNames(_tokenNames);
}

ExpressionParser::ExpressionParser(const ANTLR_USE_NAMESPACE(antlr)ParserSharedInputState& state)
: ANTLR_USE_NAMESPACE(antlr)LLkParser(state,2)
{
	setTokenNames(_tokenNames);
}

/** Parses an expression. */
int  ExpressionParser::expr() {
	int n;
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST expr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	n = 0; nident = &n;
	
	try {      // for error handling
		aExpr();
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp51_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp51_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		match(SEMI);
		}
		expr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)ANTLRException& ex) {
		
		ANTLR_USE_NAMESPACE(antlr)Token* nextToken = NULL;
		try {
		nextToken = LT(2);
		} catch (...) {
		throw UAPParserException("error: syntax error at end of input");
		}
		throw UAPParserException("error: parse error before '"+(nextToken)->getText()+"' token");
		
	}
	returnAST = expr_AST;
	return n;
}

/** Recognizes the synxtax for arithmetic addition and subtraction. */
void ExpressionParser::aExpr() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST aExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	prodExpr();
	astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
	{
	for (;;) {
		if ((LA(1)==PLUS||LA(1)==MINUS)) {
			{
			switch ( LA(1)) {
			case PLUS:
			{
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp52_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
				tmp52_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
				astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp52_AST));
				match(PLUS);
				break;
			}
			case MINUS:
			{
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp53_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
				tmp53_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
				astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp53_AST));
				match(MINUS);
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
			}
			}
			}
			prodExpr();
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		}
		else {
			goto _loop6;
		}
		
	}
	_loop6:;
	}
	aExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	returnAST = aExpr_AST;
}

/** Recognizes the syntax for arithmetic multiplication, division, and modular arithmetic (not supported). */
void ExpressionParser::prodExpr() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST prodExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	powExpr();
	astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
	{
	for (;;) {
		if (((LA(1) >= MULT && LA(1) <= MOD))) {
			{
			switch ( LA(1)) {
			case MULT:
			{
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp54_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
				tmp54_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
				astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp54_AST));
				match(MULT);
				break;
			}
			case DIV:
			{
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp55_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
				tmp55_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
				astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp55_AST));
				match(DIV);
				break;
			}
			case MOD:
			{
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp56_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
				tmp56_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
				astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp56_AST));
				match(MOD);
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
			}
			}
			}
			powExpr();
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		}
		else {
			goto _loop10;
		}
		
	}
	_loop10:;
	}
	prodExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	returnAST = prodExpr_AST;
}

/** Recognizes the syntax for arithmetic exponentiation. */
void ExpressionParser::powExpr() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST powExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	tExpr();
	astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
	{
	switch ( LA(1)) {
	case POW:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp57_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp57_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp57_AST));
		match(POW);
		tExpr();
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		break;
	}
	case SEMI:
	case PLUS:
	case MINUS:
	case MULT:
	case DIV:
	case MOD:
	case COMMA:
	case RPAREN:
	{
		break;
	}
	default:
	{
		throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
	}
	}
	}
	powExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	returnAST = powExpr_AST;
}

/** Recognizes the syntax for arithmetic plus/minus functions or atomic elements.
  * @see #atom
  */
void ExpressionParser::tExpr() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST tExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	{
	switch ( LA(1)) {
	case PLUS:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp58_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp58_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp58_AST));
		match(PLUS);
		break;
	}
	case MINUS:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp59_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp59_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp59_AST));
		match(MINUS);
		break;
	}
	case LPAREN:
	case IDENT:
	case LBRACKET:
	case NUM_DOUBLE:
	case NUM_FLOAT:
	case LITERAL_sqrt:
	case LITERAL_log:
	case LITERAL_exp:
	case LITERAL_sin:
	case LITERAL_cos:
	case LITERAL_tan:
	case LITERAL_asin:
	case LITERAL_acos:
	case LITERAL_atan:
	case LITERAL_atan2:
	case LITERAL_abs:
	case LITERAL_max:
	case LITERAL_min:
	case LITERAL_ran:
	case LITERAL_ran_gauss:
	case LITERAL_randf:
	case LITERAL_gauss:
	case LITERAL_tgauss:
	case 43:
	case 44:
	case 45:
	{
		break;
	}
	default:
	{
		throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
	}
	}
	}
	{
	switch ( LA(1)) {
	case LITERAL_sqrt:
	case LITERAL_log:
	case LITERAL_exp:
	case LITERAL_sin:
	case LITERAL_cos:
	case LITERAL_tan:
	case LITERAL_asin:
	case LITERAL_acos:
	case LITERAL_atan:
	case LITERAL_atan2:
	case LITERAL_abs:
	case LITERAL_max:
	case LITERAL_min:
	case LITERAL_ran:
	case LITERAL_ran_gauss:
	case LITERAL_randf:
	case LITERAL_gauss:
	case LITERAL_tgauss:
	case 43:
	case 44:
	case 45:
	{
		tFunc();
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		break;
	}
	case LPAREN:
	case IDENT:
	case LBRACKET:
	case NUM_DOUBLE:
	case NUM_FLOAT:
	{
		atom();
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		break;
	}
	default:
	{
		throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
	}
	}
	}
	tExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	returnAST = tExpr_AST;
}

/** Recognizes the syntax for arithmetic functions. */
void ExpressionParser::tFunc() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST tFunc_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	mathFunction();
	astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
	ANTLR_USE_NAMESPACE(antlr)RefAST tmp60_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	tmp60_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
	match(LPAREN);
	{
	switch ( LA(1)) {
	case PLUS:
	case MINUS:
	case LPAREN:
	case IDENT:
	case LBRACKET:
	case NUM_DOUBLE:
	case NUM_FLOAT:
	case LITERAL_sqrt:
	case LITERAL_log:
	case LITERAL_exp:
	case LITERAL_sin:
	case LITERAL_cos:
	case LITERAL_tan:
	case LITERAL_asin:
	case LITERAL_acos:
	case LITERAL_atan:
	case LITERAL_atan2:
	case LITERAL_abs:
	case LITERAL_max:
	case LITERAL_min:
	case LITERAL_ran:
	case LITERAL_ran_gauss:
	case LITERAL_randf:
	case LITERAL_gauss:
	case LITERAL_tgauss:
	case 43:
	case 44:
	case 45:
	{
		aExpr();
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		{
		for (;;) {
			if ((LA(1)==COMMA)) {
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp61_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
				tmp61_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
				match(COMMA);
				aExpr();
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			}
			else {
				goto _loop19;
			}
			
		}
		_loop19:;
		}
		break;
	}
	case RPAREN:
	{
		break;
	}
	default:
	{
		throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
	}
	}
	}
	ANTLR_USE_NAMESPACE(antlr)RefAST tmp62_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	tmp62_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
	match(RPAREN);
	tFunc_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	tFunc_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(FUNC,"FUNC")))->add(tFunc_AST)));
	currentAST.root = tFunc_AST;
	currentAST.child = tFunc_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&tFunc_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
		tFunc_AST->getFirstChild() : tFunc_AST;
	currentAST.advanceChildToEnd();
	tFunc_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	returnAST = tFunc_AST;
}

/** Recognizes an atomic element, such as a double-precision or floating-point number. */
void ExpressionParser::atom() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST atom_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  iName = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST iName_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	try {      // for error handling
		switch ( LA(1)) {
		case NUM_DOUBLE:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp63_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp63_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp63_AST));
			match(NUM_DOUBLE);
			atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
			break;
		}
		case NUM_FLOAT:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp64_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp64_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp64_AST));
			match(NUM_FLOAT);
			atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
			break;
		}
		case IDENT:
		case LBRACKET:
		{
			{
			if ((LA(1)==IDENT||LA(1)==LBRACKET) && (_tokenSet_0.member(LA(2)))) {
				amlPath();
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			}
			else if ((LA(1)==IDENT) && (_tokenSet_1.member(LA(2)))) {
				iName = LT(1);
				iName_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(iName));
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(iName_AST));
				match(IDENT);
				idents.push_back(iName->getText());
			}
			else {
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
			}
			
			}
			(*nident)++;
			atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
			break;
		}
		case LPAREN:
		{
			{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp65_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp65_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			astFactory.makeASTRoot(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp65_AST));
			match(LPAREN);
			}
			aExpr();
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp66_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp66_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			match(RPAREN);
			atom_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)ANTLRException& ex) {
		
		EXP_DEFAULT_CATCH
		
	}
	returnAST = atom_AST;
}

/** Recognizes various mathematical functions. */
void ExpressionParser::mathFunction() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	switch ( LA(1)) {
	case LITERAL_sqrt:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp67_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp67_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp67_AST));
		match(LITERAL_sqrt);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_log:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp68_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp68_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp68_AST));
		match(LITERAL_log);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_exp:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp69_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp69_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp69_AST));
		match(LITERAL_exp);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_sin:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp70_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp70_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp70_AST));
		match(LITERAL_sin);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_cos:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp71_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp71_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp71_AST));
		match(LITERAL_cos);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_tan:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp72_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp72_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp72_AST));
		match(LITERAL_tan);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_asin:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp73_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp73_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp73_AST));
		match(LITERAL_asin);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_acos:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp74_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp74_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp74_AST));
		match(LITERAL_acos);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_atan:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp75_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp75_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp75_AST));
		match(LITERAL_atan);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_atan2:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp76_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp76_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp76_AST));
		match(LITERAL_atan2);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_abs:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp77_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp77_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp77_AST));
		match(LITERAL_abs);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_max:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp78_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp78_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp78_AST));
		match(LITERAL_max);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_min:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp79_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp79_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp79_AST));
		match(LITERAL_min);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_ran:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp80_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp80_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp80_AST));
		match(LITERAL_ran);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_ran_gauss:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp81_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp81_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp81_AST));
		match(LITERAL_ran_gauss);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_randf:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp82_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp82_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp82_AST));
		match(LITERAL_randf);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_gauss:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp83_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp83_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp83_AST));
		match(LITERAL_gauss);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case LITERAL_tgauss:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp84_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp84_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp84_AST));
		match(LITERAL_tgauss);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case 43:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp85_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp85_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp85_AST));
		match(43);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case 44:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp86_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp86_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp86_AST));
		match(44);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	case 45:
	{
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp87_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp87_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp87_AST));
		match(45);
		mathFunction_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		break;
	}
	default:
	{
		throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
	}
	}
	returnAST = mathFunction_AST;
}

/** Recognizes an AML path.
  * AML path is a language for addressing parts of an AML document. 
  * See "Attribute Names in Arithmetic Expressions" in the AML documention for more information.
  */
void ExpressionParser::amlPath() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST amlPath_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	try {      // for error handling
		amlPathElement();
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
		amlPath_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		amlPath_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(AMLPATH,"AMLPATH")))->add(amlPath_AST)));
		currentAST.root = amlPath_AST;
		currentAST.child = amlPath_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&amlPath_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
			amlPath_AST->getFirstChild() : amlPath_AST;
		currentAST.advanceChildToEnd();
		amlPath_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	}
	catch (UAPException& ex) {
		
		ANTLR_USE_NAMESPACE(antlr)Token* nextToken = NULL;
		try {
		nextToken = LT(2);
		} catch (...) {
		throw UAPParserException("error: parse error at end of input", ex);
		}
		throw UAPParserException("error: parse error before '"+(nextToken)->getText()+"' token", ex);
		
	}
	catch (ANTLR_USE_NAMESPACE(antlr)ANTLRException& ex) {
		
		EXP_DEFAULT_CATCH
		
	}
	returnAST = amlPath_AST;
}

/** Implements AML path 0.49 syntax.
  * Recognizes expressions of the form: 
  * <p>
  * <ul>
  * <li>name:attrib_name@component
  * <li>name[attrib_name@component]
  * </ul>
  * <p>
  * The former syntax can address any node in an AML document whereas the latter is shorthand for 
  * addressing only element, controller, and beam nodes.
  * <p>
  * Upon evaluation, if component was not specified then the component "design" will be chosen. 
  * Should neither the specified component nor component "design" be defined, then 0 is returned.
  * <p>
  * If name is not specified then the node being addressed must be specified with method 
  * {@link #ExpressionTreeWalker.setContext} before evaluating this expression.
  * Recognizes an element in an AML path.
  */
void ExpressionParser::amlPathElement() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST amlPathElement_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e1 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e1_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	try {      // for error handling
		{
		if ((LA(1)==IDENT||LA(1)==LBRACKET) && (LA(2)==IDENT||LA(2)==LBRACKET||LA(2)==AT)) {
			{
			switch ( LA(1)) {
			case IDENT:
			{
				try { // for error handling
					e1 = LT(1);
					e1_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e1));
					astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e1_AST));
					match(IDENT);
				}
				catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
					
					throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid element name");
					
				}
				break;
			}
			case LBRACKET:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
			}
			}
			}
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp88_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp88_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			match(LBRACKET);
			{
			switch ( LA(1)) {
			case AT:
			{
				amlPathAttrib();
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
				break;
			}
			case IDENT:
			{
				amlPathNode();
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
				{
				for (;;) {
					if ((LA(1)==COLON)) {
						ANTLR_USE_NAMESPACE(antlr)RefAST tmp89_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
						tmp89_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
						match(COLON);
						amlPathNode();
						astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
					}
					else {
						goto _loop26;
					}
					
				}
				_loop26:;
				}
				{
				switch ( LA(1)) {
				case AT:
				{
					amlPathAttrib();
					astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
					break;
				}
				case RBRACKET:
				{
					break;
				}
				default:
				{
					throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
			}
			}
			}
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp90_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp90_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			match(RBRACKET);
		}
		else if ((LA(1)==IDENT) && (LA(2)==COLON)) {
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp91_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp91_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp91_AST));
			match(IDENT);
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp92_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp92_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(tmp92_AST));
			match(COLON);
			amlPathNode();
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			{
			for (;;) {
				if ((LA(1)==COLON)) {
					ANTLR_USE_NAMESPACE(antlr)RefAST tmp93_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
					tmp93_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
					match(COLON);
					amlPathNode();
					astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
				}
				else {
					goto _loop29;
				}
				
			}
			_loop29:;
			}
			{
			switch ( LA(1)) {
			case AT:
			{
				amlPathAttrib();
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
				break;
			}
			case SEMI:
			case PLUS:
			case MINUS:
			case MULT:
			case DIV:
			case MOD:
			case POW:
			case COMMA:
			case RPAREN:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		else {
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		
		}
		amlPathElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		amlPathElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(AMLPATHELEMENT,"AMLPATHELEMENT")))->add(amlPathElement_AST)));
		currentAST.root = amlPathElement_AST;
		currentAST.child = amlPathElement_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&amlPathElement_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
			amlPathElement_AST->getFirstChild() : amlPathElement_AST;
		currentAST.advanceChildToEnd();
		amlPathElement_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)ANTLRException& ex) {
		
		EXP_DEFAULT_CATCH
		
	}
	returnAST = amlPathElement_AST;
}

/** Recognizes the syntax for the component part of an AML path.
  * An "@" sign must prefix the component.
  */
void ExpressionParser::amlPathAttrib() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST amlPathAttrib_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e1 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e1_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	ANTLR_USE_NAMESPACE(antlr)RefAST tmp94_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	tmp94_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
	match(AT);
	try { // for error handling
		e1 = LT(1);
		e1_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e1));
		astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e1_AST));
		match(IDENT);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
		
		throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid attribute name");
		
	}
	amlPathAttrib_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	amlPathAttrib_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(AMLPATHATTRIB,"AMLPATHATTRIB")))->add(amlPathAttrib_AST)));
	currentAST.root = amlPathAttrib_AST;
	currentAST.child = amlPathAttrib_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&amlPathAttrib_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
		amlPathAttrib_AST->getFirstChild() : amlPathAttrib_AST;
	currentAST.advanceChildToEnd();
	amlPathAttrib_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	returnAST = amlPathAttrib_AST;
}

/** Recognizes the syntax for the name part of an AML path. 
  * @see #amlPathElement
  */
void ExpressionParser::amlPathNode() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST amlPathNode_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e1 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e1_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	try {      // for error handling
		try { // for error handling
			e1 = LT(1);
			e1_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e1));
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e1_AST));
			match(IDENT);
		}
		catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
			
			throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid node name");
			
		}
		{
		switch ( LA(1)) {
		case LPAREN:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp95_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp95_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			match(LPAREN);
			amlPathAttrExpr();
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
			{
			for (;;) {
				if ((LA(1)==COMMA)) {
					ANTLR_USE_NAMESPACE(antlr)RefAST tmp96_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
					tmp96_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
					match(COMMA);
					amlPathAttrExpr();
					astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST));
				}
				else {
					goto _loop38;
				}
				
			}
			_loop38:;
			}
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp97_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp97_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			match(RPAREN);
			break;
		}
		case SEMI:
		case PLUS:
		case MINUS:
		case MULT:
		case DIV:
		case MOD:
		case POW:
		case COMMA:
		case RPAREN:
		case COLON:
		case RBRACKET:
		case AT:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
		amlPathNode_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		amlPathNode_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(AMLPATHNODE,"AMLPATHNODE")))->add(amlPathNode_AST)));
		currentAST.root = amlPathNode_AST;
		currentAST.child = amlPathNode_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&amlPathNode_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
			amlPathNode_AST->getFirstChild() : amlPathNode_AST;
		currentAST.advanceChildToEnd();
		amlPathNode_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)ANTLRException& ex) {
		
		EXP_DEFAULT_CATCH
		
	}
	returnAST = amlPathNode_AST;
}

/** Recognizes the syntax for the list of tags part of an AML path. */
void ExpressionParser::amlPathTagList() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST amlPathTagList_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e1 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e1_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	try {      // for error handling
		{
		for (;;) {
			if ((LA(1)==IDENT)) {
				try { // for error handling
					e1 = LT(1);
					e1_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e1));
					astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e1_AST));
					match(IDENT);
				}
				catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
					
					throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid tag name");
					
				}
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp98_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
				tmp98_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
				match(19);
			}
			else {
				goto _loop34;
			}
			
		}
		_loop34:;
		}
		amlPathTagList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		amlPathTagList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(AMLPATHTAGLIST,"AMLPATHTAGLIST")))->add(amlPathTagList_AST)));
		currentAST.root = amlPathTagList_AST;
		currentAST.child = amlPathTagList_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&amlPathTagList_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
			amlPathTagList_AST->getFirstChild() : amlPathTagList_AST;
		currentAST.advanceChildToEnd();
		amlPathTagList_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)ANTLRException& ex) {
		
		EXP_DEFAULT_CATCH
		
	}
	returnAST = amlPathTagList_AST;
}

/** Recognizes the AML path syntax for matching attribute-value pairs. */
void ExpressionParser::amlPathAttrExpr() {
	
	returnAST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)ASTPair currentAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST amlPathAttrExpr_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e1 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e1_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e2 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e2_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e3 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e3_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e4 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e4_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e5 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e5_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefToken  e6 = ANTLR_USE_NAMESPACE(antlr)nullToken;
	ANTLR_USE_NAMESPACE(antlr)RefAST e6_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	try {      // for error handling
		{
		switch ( LA(1)) {
		case AT:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp99_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
			tmp99_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
			match(AT);
			break;
		}
		case IDENT:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
		try { // for error handling
			e1 = LT(1);
			e1_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e1));
			astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e1_AST));
			match(IDENT);
		}
		catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
			
			throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid attribute name");
			
		}
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp100_AST = ANTLR_USE_NAMESPACE(antlr)nullAST;
		tmp100_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(LT(1)));
		match(EQUAL);
		{
		switch ( LA(1)) {
		case NUM_DOUBLE:
		{
			try { // for error handling
				e2 = LT(1);
				e2_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e2));
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e2_AST));
				match(NUM_DOUBLE);
			}
			catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
				
				throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid attribute value");
				
			}
			break;
		}
		case NUM_FLOAT:
		{
			try { // for error handling
				e3 = LT(1);
				e3_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e3));
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e3_AST));
				match(NUM_FLOAT);
			}
			catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
				
				throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid attribute value");
				
			}
			break;
		}
		case IDENT:
		{
			try { // for error handling
				e4 = LT(1);
				e4_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e4));
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e4_AST));
				match(IDENT);
			}
			catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
				
				throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid attribute value");
				
			}
			break;
		}
		case STRING_LITERAL_S:
		{
			try { // for error handling
				e5 = LT(1);
				e5_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e5));
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e5_AST));
				match(STRING_LITERAL_S);
			}
			catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
				
				throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid attribute value");
				
			}
			break;
		}
		case STRING_LITERAL_D:
		{
			try { // for error handling
				e6 = LT(1);
				e6_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(e6));
				astFactory.addASTChild(currentAST, ANTLR_USE_NAMESPACE(antlr)RefAST(e6_AST));
				match(STRING_LITERAL_D);
			}
			catch (ANTLR_USE_NAMESPACE(antlr)MismatchedTokenException& ex) {
				
				throw UAPParserException("error: '"+(ex.token)->getText()+"' is not a valid attribute value");
				
			}
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(LT(1), getFilename());
		}
		}
		}
		amlPathAttrExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
		amlPathAttrExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.make( (new ANTLR_USE_NAMESPACE(antlr)ASTArray(2))->add(ANTLR_USE_NAMESPACE(antlr)RefAST(astFactory.create(AMLPATHATTREXPR,"AMLPATHATTREXPR")))->add(amlPathAttrExpr_AST)));
		currentAST.root = amlPathAttrExpr_AST;
		currentAST.child = amlPathAttrExpr_AST!=ANTLR_USE_NAMESPACE(antlr)nullAST &&amlPathAttrExpr_AST->getFirstChild()!=ANTLR_USE_NAMESPACE(antlr)nullAST ?
			amlPathAttrExpr_AST->getFirstChild() : amlPathAttrExpr_AST;
		currentAST.advanceChildToEnd();
		amlPathAttrExpr_AST = ANTLR_USE_NAMESPACE(antlr)RefAST(currentAST.root);
	}
	catch (ANTLR_USE_NAMESPACE(antlr)ANTLRException& ex) {
		
		EXP_DEFAULT_CATCH
		
	}
	returnAST = amlPathAttrExpr_AST;
}

const char* ExpressionParser::_tokenNames[] = {
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	"SEMI",
	"PLUS",
	"MINUS",
	"MULT",
	"DIV",
	"MOD",
	"POW",
	"LPAREN",
	"COMMA",
	"RPAREN",
	"a label",
	"LBRACKET",
	"COLON",
	"RBRACKET",
	"AT",
	"\".\"",
	"EQUAL",
	"NUM_DOUBLE",
	"NUM_FLOAT",
	"STRING_LITERAL_S",
	"STRING_LITERAL_D",
	"\"sqrt\"",
	"\"log\"",
	"\"exp\"",
	"\"sin\"",
	"\"cos\"",
	"\"tan\"",
	"\"asin\"",
	"\"acos\"",
	"\"atan\"",
	"\"atan2\"",
	"\"abs\"",
	"\"max\"",
	"\"min\"",
	"\"ran\"",
	"\"ran_gauss\"",
	"\"randf\"",
	"\"gauss\"",
	"\"tgauss\"",
	"\"user0\"",
	"\"user1\"",
	"\"user2\"",
	"FUNC",
	"AMLPATH",
	"AMLPATHNODE",
	"AMLPATHATTREXPR",
	"AMLPATHELEMENT",
	"AMLPATHTAGLIST",
	"AMLPATHATTRIB",
	"WS_",
	"ESC",
	0
};

const unsigned long ExpressionParser::_tokenSet_0_data_[] = { 376832UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet ExpressionParser::_tokenSet_0(_tokenSet_0_data_,4);
const unsigned long ExpressionParser::_tokenSet_1_data_[] = { 14320UL, 0UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet ExpressionParser::_tokenSet_1(_tokenSet_1_data_,4);


