#ifndef INC_ExpressionParser_hpp_
#define INC_ExpressionParser_hpp_

#include "antlr/config.hpp"
/* $ANTLR 2.7.0: "Expression.g" -> "ExpressionParser.hpp"$ */
#include "antlr/TokenStream.hpp"
#include "antlr/TokenBuffer.hpp"
#include "ExpressionParserTokenTypes.hpp"
#include "antlr/LLkParser.hpp"


/*
 * Expression Parser
 * Universal Accelerator Parser
 * Copyright (C) 2005, 2006, 2007 Andy Wolski, Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov)
 * Andy Wolski  (a.wolski@dl.ac.uk)
 */
 #include <string>
 #include <map>
 #include <list>
 #include "UAPNode.hpp"

/** A parser for arithmetic expressions. (You can use this standalone, but you should really
* only use this class with the Universal Accelerator Parser library). Reads a 
* {@link antlr::TokenStream TokenStream} and invokes the appropriate methods in this class.
* <p>
* When you instantiate the parser you must specify the lexer.
* <p>
* <code>ExpressionParser parser(lexer); </code>
* <p>
* To parse an expression use <code>parser.expr()</code>.
* <p>
* The end of line character is ';'.
* @see antlr::TokenStream
* @ingroup ExpressionParsing
*/
class ExpressionParser : public ANTLR_USE_NAMESPACE(antlr)LLkParser, public ExpressionParserTokenTypes
 {

  int* nident;
  std::list<std::string> idents;
  
  public:
  
    /** Returns the list of identifiers in this expression.
    * @return the list of identifiers in this expression.
    */
    std::list<std::string>& getIdentifiers()
    {
      return idents;
    }
protected:
	ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf, int k);
public:
	ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenBuffer& tokenBuf);
protected:
	ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer, int k);
public:
	ExpressionParser(ANTLR_USE_NAMESPACE(antlr)TokenStream& lexer);
	ExpressionParser(const ANTLR_USE_NAMESPACE(antlr)ParserSharedInputState& state);
	public: int  expr();
	public: void aExpr();
	public: void prodExpr();
	public: void powExpr();
	public: void tExpr();
	public: void tFunc();
	public: void atom();
	public: void mathFunction();
	public: void amlPath();
	public: void amlPathElement();
	public: void amlPathAttrib();
	public: void amlPathNode();
	public: void amlPathTagList();
	public: void amlPathAttrExpr();
private:
	static const char* _tokenNames[];
	
	static const unsigned long _tokenSet_0_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_0;
	static const unsigned long _tokenSet_1_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_1;
};

#endif /*INC_ExpressionParser_hpp_*/
