/*
 * UAP Model Builder
 * Universal Accelerator Parser
 * Copyright (C) 2005 Andy Wolski, Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   Andy Wolski <a.wolski@dl.ac.uk>
 *   Daniel Bates <dbates@lbl.gov>
 *   David Sagan <dcs16@cornell.edu>
 */

#ifndef UAPBuilder_hpp
#define UAPBuilder_hpp 1

#include <string>
#include <algorithm>

#include "UAP/UAPNode.hpp"
#include "UAP/UAPException.hpp"

#define ALLOW_REPEATS true

/** Defines the API to construct a UAP model from an input document. 
* Using this class, an application programmer can obtain a {@link UAPNode UAP model}.
* <p>
* Once a {@link UAPNode UAP model} is obtained, it can be translated 
* into a variety of formats.
* @author Andy Wolski, Daniel Bates
* @version 1.6, 03/23/06
* @ingroup UAP
*/
class UAPBuilder {

public:

  /** Creates a UAPBuilder and initializes it with the specified 
  * {@link DialectTranslator dialect translator} and {@link UAPNode node}
  * @param DialectTranslator the dialect translator
  * @param UAPNode the root node
  * @see UAPNode
  */
  UAPBuilder(UAPNode* node);

  /** Destructor. */
  ~UAPBuilder();

  /** Adds a child Node to this model.
  * <p>
  * This methods calls the {@link #UAPNode::addChild UAPNode.addChild} method
  * with the specified type and name arguments.
  * @param type the type of the child
  * @param name the name of the child
  * @see #UAPNode::addChild
  * @see string
  */
  void addChild(enum UAPNode_type type, std::string name);

  /** Adds an attribute to this model.
  * <p>
  * This methods calls the {@link #UAPNode::addAttribute UAPNode.addAttribute} method
  * with the specified name, value and allow_repeats arguments.
  * @param name the name of the attribute
  * @param value the value of the attribute
  * @param allow_repeats <code>true</code> to allow duplicate attributes;
  *             <code>false</code> if attributes must be unique. (default: false)
  * @see #UAPNode::addAttribute
  * @see string
  * @see bool
  */
  void addAttribute(std::string name, std::string value, bool allow_repeats=false);

  /** Switch focus to the parent of the current node. */
  void moveToParent();

 /** Returns the current node.
 */
 UAPNode* getCurrentNode();

  /** Returns a list of all the <code>UAPNode</code>(s) with a given tag name in
  * the order in which they are encountered in a preorder traversal of this UAP model.
  * @param tagName the name of the Nodes
  * @return a list of <code>UAPNode</code>s.
  * @see UAPNode
  */
  NodeVec getSubNodesByTagName(const std::string& tagName);
  
  /** Returns the first child node of the current node with the specified name.
  * Only the first level sub-nodes (the children) are searched.
  * @param _name The name of the node.
  * @return A child node which has the specified name.
  *      <code>NULL</code> if no node has the specified name.
  * @see getSubNodeByName
  * @see getSubNodesByName
  * @see UAPNode
  * @see string
  */
  UAPNode* getChildByName(const std::string& _name); 

  /** Returns the first child node of the specified node with the specified name. 
  * Only the first level sub-nodes (the children) are searched.
  * The search begins at the node <code>beginPosition</code>.
  * <p>
  * @param beginPosition the UAP node
  * @param _name The name of the node
  * @return A child node which has the specified name.
  *      <code>NULL</code> if no node has the specified name.
  * @see getSubNodeByName
  * @see getSubNodesByName
  * @see UAPNode
  * @see string
  */
  UAPNode* getChildByName(UAPNode* beginPosition, const std::string& _name);

  /** Returns a list of children of the current node with the specified name.
  * Only the first level sub-nodes (the children) are searched.
  * @param _name the name of the node.
  * @return A list of child nodes.
  * @see getSubNodeByName
  * @see getSubNodesByName
  * @see UAPNode
  * @see string
  */
  NodeVec getChildrenByName(const std::string& _name); 

  /** Returns a list of children of the specified node with the specified name. 
  * Only the first level sub-nodes (the children) are searched.
  * <p>
  * @param beginPosition the parent of the children.
  * @param _name The name to match to.
  * @return A list of child nodes.
  * @see getSubNodeByName
  * @see getSubNodesByName
  * @see UAPNode
  * @see string
  */
  NodeVec getChildrenByName(UAPNode* beginPosition, const std::string& _name);

  /** Returns the first sub-node node of the current node with the specified name.
  * All sub-nodes (children and sub-children) are searched.
  * @param _name The name of the node.
  * @return The node to which the name is mapped in this UAP model;
  *      <code>NULL</code> if the name is not mapped to any node in this UAP model.
  * @see getChildByName
  * @see getChildrenByName
  * @see UAPNode
  * @see string
  */
  UAPNode* getSubNodeByName(const std::string& _name); 

  /** Returns the first sub-node node of the specified node with the specified name. 
  * All sub-nodes (children and sub-children) are searched.
  * The search begins at the node <code>beginPosition</code>.
  * <p>
  * @param beginPosition the UAP node
  * @param _name the name of the node
  * @return the node to which the name is mapped in this UAP model;
  *      <code>NULL</code> if the name is not mapped to any node in this UAP model.
  * @see getChildByName
  * @see getChildrenByName
  * @see UAPNode
  * @see string
  */
  UAPNode* getSubNodeByName(UAPNode* beginPosition, const std::string& _name);

  /** Returns a list of sub-noderen of the current node with the specified name.
  * All sub-nodes (children and sub-children) are searched.
  * @param _name the name of the node.
  * @return A list of nodes.
  * @see getChildByName
  * @see getChildrenByName
  * @see UAPNode
  * @see string
  */
  NodeVec getSubNodesByName(const std::string& _name); 

  /** Returns a list of children of the specified node with the specified name. 
  * All sub-nodes (children and sub-children) are searched.
  * <p>
  * @param beginPosition the parent of the children.
  * @param _name the name to match to.
  * @return A list of nodes.
  * @see getChildByName
  * @see getChildrenByName
  * @see UAPNode
  * @see string
  */
  NodeVec getSubNodesByName(UAPNode* beginPosition, const std::string& _name);

private:

  /** The root node of this model. */
  UAPNode* root;

  /** The current node. */
  UAPNode* currentNode;

};

#endif
