/* $ANTLR 2.7.0: "Expression.g" -> "ExpressionTreeWalker.cpp"$ */
#include "ExpressionTreeWalker.hpp"
#include "antlr/Token.hpp"
#include "antlr/AST.hpp"
#include "antlr/NoViableAltException.hpp"
#include "antlr/MismatchedTokenException.hpp"
#include "antlr/SemanticException.hpp"
#include "antlr/BitSet.hpp"

  #include <sstream>
  #include <cmath>
  #include <cstdlib>
  #include <cassert>
  #include <algorithm>
  #include <queue>
  #include "UAP/UAPUtilities.hpp"

ExpressionTreeWalker::ExpressionTreeWalker() {
	setTokenNames(_tokenNames);
}

/** Evaluates an expression to a double-precision constant. */
double  ExpressionTreeWalker::evaluate(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
	double r;
	
	ANTLR_USE_NAMESPACE(antlr)RefAST evaluate_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
	ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST m = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	double a=0;
	double b=0;
	r=0;
	bool unitary_minus = true;
	bool unitary_plus = true;
	
	
	try {      // for error handling
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case PLUS:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t97 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp1_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,PLUS);
			_t = _t->getFirstChild();
			a=evaluate(_t);
			_t = _retTree;
			{
			if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
			switch ( _t->getType()) {
			case PLUS:
			case MINUS:
			case MULT:
			case DIV:
			case POW:
			case LPAREN:
			case NUM_DOUBLE:
			case NUM_FLOAT:
			case FUNC:
			{
				b=evaluate(_t);
				_t = _retTree;
				unitary_plus = false;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
			}
			}
			}
			r = unitary_plus ? a : a+b;
			_t = __t97;
			_t = _t->getNextSibling();
			break;
		}
		case MINUS:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t99 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp2_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,MINUS);
			_t = _t->getFirstChild();
			a=evaluate(_t);
			_t = _retTree;
			{
			if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
			switch ( _t->getType()) {
			case PLUS:
			case MINUS:
			case MULT:
			case DIV:
			case POW:
			case LPAREN:
			case NUM_DOUBLE:
			case NUM_FLOAT:
			case FUNC:
			{
				b=evaluate(_t);
				_t = _retTree;
				unitary_minus = false;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
			}
			}
			}
			r = unitary_minus ? -a : a-b;
			_t = __t99;
			_t = _t->getNextSibling();
			break;
		}
		case MULT:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t101 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp3_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,MULT);
			_t = _t->getFirstChild();
			a=evaluate(_t);
			_t = _retTree;
			b=evaluate(_t);
			_t = _retTree;
			r = a*b;
			_t = __t101;
			_t = _t->getNextSibling();
			break;
		}
		case DIV:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t102 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp4_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,DIV);
			_t = _t->getFirstChild();
			a=evaluate(_t);
			_t = _retTree;
			b=evaluate(_t);
			_t = _retTree;
			if (b == 0) { 
			throw UAPInvalidExpressionException("error: divide by zero");
			}
			r = a/b;
			
			_t = __t102;
			_t = _t->getNextSibling();
			break;
		}
		case POW:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t103 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp5_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,POW);
			_t = _t->getFirstChild();
			a=evaluate(_t);
			_t = _retTree;
			b=evaluate(_t);
			_t = _retTree;
			r = pow(a,b);
			_t = __t103;
			_t = _t->getNextSibling();
			break;
		}
		case LPAREN:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t104 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp6_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LPAREN);
			_t = _t->getFirstChild();
			r=evaluate(_t);
			_t = _retTree;
			_t = __t104;
			_t = _t->getNextSibling();
			break;
		}
		case FUNC:
		{
			r=evaluate_function(_t);
			_t = _retTree;
			break;
		}
		case NUM_DOUBLE:
		{
			n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,NUM_DOUBLE);
			_t = _t->getNextSibling();
			r = atof(n->getText().c_str());
			break;
		}
		case NUM_FLOAT:
		{
			m = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,NUM_FLOAT);
			_t = _t->getNextSibling();
			r = atof(m->getText().c_str());
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
	}
	_retTree = _t;
	return r;
}

/** Evaluates a function call to a double-precision constant. */
double  ExpressionTreeWalker::evaluate_function(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
	double r;
	
	ANTLR_USE_NAMESPACE(antlr)RefAST evaluate_function_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
	ANTLR_USE_NAMESPACE(antlr)RefAST f = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	double e=0;
	double a=0;
	double b=0;
	r=0;
	std::queue<double> args;
	
	
	try {      // for error handling
		ANTLR_USE_NAMESPACE(antlr)RefAST __t106 = _t;
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp7_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
		match(_t,FUNC);
		_t = _t->getFirstChild();
		f = _t==ASTNULL ? ANTLR_USE_NAMESPACE(antlr)nullAST : ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
		mathFunction(_t);
		_t = _retTree;
		{
		for (;;) {
			if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
			if ((_tokenSet_0.member(_t->getType()))) {
				e=evaluate(_t);
				_t = _retTree;
				args.push(e);
			}
			else {
				goto _loop108;
			}
			
		}
		_loop108:;
		}
		_t = __t106;
		_t = _t->getNextSibling();
		
		switch(f->getType()){
		case LITERAL_sqrt:
		r = sqrt(args.front());
		break;
		case LITERAL_log:
		r = log(args.front());
		break;
		case LITERAL_exp:
		r = exp(args.front());
		break;
		case LITERAL_sin:
		r = sin(args.front());
		break;
		case LITERAL_cos:
		r = cos(args.front());
		break;
		case LITERAL_tan:
		r = tan(args.front());
		break;
		case LITERAL_asin:
		r = asin(args.front());
		break;
		case LITERAL_acos:
		r = acos(args.front());
		break;
		case LITERAL_atan:
		r = atan(args.front());
		break;
		case LITERAL_abs:
		r = abs(static_cast<int>(args.front()));
		break;
		case LITERAL_ran:
		r = utilities->nextDouble();
		break;
		case LITERAL_ran_gauss:
		r = utilities->nextGaussian();
		break;
		case LITERAL_atan2:
		if (args.size() == 2){
		a = args.front();
		args.pop();
		b = args.front();
		r = atan2(a,b);
		}
		break;
		case LITERAL_min:
		if (args.size() == 2){
		a = args.front();
		args.pop();
		b = args.front();
		r = (b < a)? b : a;
		}
		break;
		case LITERAL_max:
		if (args.size() == 2){
		a = args.front();
		args.pop();
		b = args.front();
		r = (b > a)? b : a;
		}
		break;
		default:
		break;
		}
		
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
	}
	_retTree = _t;
	return r;
}

void ExpressionTreeWalker::mathFunction(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
	
	ANTLR_USE_NAMESPACE(antlr)RefAST mathFunction_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
	
	try {      // for error handling
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case LITERAL_sqrt:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp8_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_sqrt);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_log:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp9_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_log);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_exp:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp10_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_exp);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_sin:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp11_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_sin);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_cos:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp12_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_cos);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_tan:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp13_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_tan);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_asin:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp14_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_asin);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_acos:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp15_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_acos);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_atan:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp16_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_atan);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_atan2:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp17_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_atan2);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_abs:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp18_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_abs);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_max:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp19_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_max);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_min:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp20_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_min);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_ran:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp21_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_ran);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_ran_gauss:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp22_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_ran_gauss);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_randf:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp23_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_randf);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_gauss:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp24_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_gauss);
			_t = _t->getNextSibling();
			break;
		}
		case LITERAL_tgauss:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp25_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LITERAL_tgauss);
			_t = _t->getNextSibling();
			break;
		}
		case 43:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp26_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,43);
			_t = _t->getNextSibling();
			break;
		}
		case 44:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp27_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,44);
			_t = _t->getNextSibling();
			break;
		}
		case 45:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp28_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,45);
			_t = _t->getNextSibling();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
	}
	_retTree = _t;
}

/** Substitutes the corresponding values for any named parameters and/or AML paths in the expression. */
std::string  ExpressionTreeWalker::subs_params(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
	std::string v;
	
	ANTLR_USE_NAMESPACE(antlr)RefAST subs_params_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
	ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST f = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	v = "";
	std::string v1 = "";
	std::string v2 = "";
	std::queue<std::string> args;
	
	
	try {      // for error handling
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case IDENT:
		case NUM_DOUBLE:
		case NUM_FLOAT:
		{
			n = _t==ASTNULL ? ANTLR_USE_NAMESPACE(antlr)nullAST : ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			twConst(_t);
			_t = _retTree;
			v = "(" + n->getText() + ")";
			break;
		}
		case AMLPATH:
		{
			v=amlPath(_t);
			_t = _retTree;
			break;
		}
		case PLUS:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t110 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp29_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,PLUS);
			_t = _t->getFirstChild();
			v1=subs_params(_t);
			_t = _retTree;
			{
			if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
			switch ( _t->getType()) {
			case PLUS:
			case MINUS:
			case MULT:
			case DIV:
			case POW:
			case LPAREN:
			case IDENT:
			case NUM_DOUBLE:
			case NUM_FLOAT:
			case FUNC:
			case AMLPATH:
			{
				v2=subs_params(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
			}
			}
			}
			v = (v2 == "")? v + v1 : v + v1 + "+" + v2;
			_t = __t110;
			_t = _t->getNextSibling();
			break;
		}
		case MINUS:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t112 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp30_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,MINUS);
			_t = _t->getFirstChild();
			v1=subs_params(_t);
			_t = _retTree;
			{
			if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
			switch ( _t->getType()) {
			case PLUS:
			case MINUS:
			case MULT:
			case DIV:
			case POW:
			case LPAREN:
			case IDENT:
			case NUM_DOUBLE:
			case NUM_FLOAT:
			case FUNC:
			case AMLPATH:
			{
				v2=subs_params(_t);
				_t = _retTree;
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
			}
			}
			}
			
			// Encloses v1 in parentheses if v1 is negative. Performs negation.
			if (v1.substr(0,1) == "-")
			v1 = "(" + v1 + ")";
			v = (v2 == "")? v + "-" + v1 : v + v1 + "-" + v2;
			
			_t = __t112;
			_t = _t->getNextSibling();
			break;
		}
		case MULT:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t114 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp31_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,MULT);
			_t = _t->getFirstChild();
			v1=subs_params(_t);
			_t = _retTree;
			v2=subs_params(_t);
			_t = _retTree;
			v = v + v1 + "*" + v2;
			_t = __t114;
			_t = _t->getNextSibling();
			break;
		}
		case DIV:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t115 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp32_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,DIV);
			_t = _t->getFirstChild();
			v1=subs_params(_t);
			_t = _retTree;
			v2=subs_params(_t);
			_t = _retTree;
			v = v + v1 + "/" + v2;
			_t = __t115;
			_t = _t->getNextSibling();
			break;
		}
		case POW:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t116 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp33_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,POW);
			_t = _t->getFirstChild();
			v1=subs_params(_t);
			_t = _retTree;
			v2=subs_params(_t);
			_t = _retTree;
			v = v + v1 + "^" + v2;
			_t = __t116;
			_t = _t->getNextSibling();
			break;
		}
		case LPAREN:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t117 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp34_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,LPAREN);
			_t = _t->getFirstChild();
			v1=subs_params(_t);
			_t = _retTree;
			v = v + "(" + v1 + ")";
			_t = __t117;
			_t = _t->getNextSibling();
			break;
		}
		case FUNC:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t118 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp35_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,FUNC);
			_t = _t->getFirstChild();
			f = _t==ASTNULL ? ANTLR_USE_NAMESPACE(antlr)nullAST : ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			mathFunction(_t);
			_t = _retTree;
			{
			for (;;) {
				if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
				if ((_tokenSet_1.member(_t->getType()))) {
					v1=subs_params(_t);
					_t = _retTree;
					args.push(v1);
				}
				else {
					goto _loop120;
				}
				
			}
			_loop120:;
			}
			_t = __t118;
			_t = _t->getNextSibling();
			
			v = v + f->getText() + "(";
			while(args.size() > 1){
			v = v + args.front() + ",";
			args.pop();
			}
			v = v + args.front() + ")";
			
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
	}
	_retTree = _t;
	return v;
}

/** Substitutes the corresponding value for any named parameter. */
void ExpressionTreeWalker::twConst(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
	
	ANTLR_USE_NAMESPACE(antlr)RefAST twConst_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
	ANTLR_USE_NAMESPACE(antlr)RefAST n = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	try {      // for error handling
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case NUM_DOUBLE:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp36_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,NUM_DOUBLE);
			_t = _t->getNextSibling();
			break;
		}
		case NUM_FLOAT:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp37_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,NUM_FLOAT);
			_t = _t->getNextSibling();
			break;
		}
		case IDENT:
		{
			n = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,IDENT);
			_t = _t->getNextSibling();
			
			// Substitute identifier
			std::string s;
			std::string nText = n->getText();
			int found_param = 0;
			std::map<std::string, double>::const_iterator it = mathConstants.find(nText);
			if (it != mathConstants.end()) {
			std::stringstream tmp;
			tmp << it->second;
			found_param = 1;
			s = tmp.str();
			} else
			found_param = utilities->getParameterValue(utilities->getUAPRootNode(),nText,s);
			
			if(!found_param)
			s = "#" + nText + "@";
			n->setText(s);
			
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
	}
	_retTree = _t;
}

/** Evaluates an AML path to an arithmetic expression that can be further evaluated. */
std::string  ExpressionTreeWalker::amlPath(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
	std::string r;
	
	ANTLR_USE_NAMESPACE(antlr)RefAST amlPath_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
	ANTLR_USE_NAMESPACE(antlr)RefAST tagName = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST firstNodeName = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST attrName = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST nodeName = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST aName = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST aValue = ANTLR_USE_NAMESPACE(antlr)nullAST;
	ANTLR_USE_NAMESPACE(antlr)RefAST attrName2 = ANTLR_USE_NAMESPACE(antlr)nullAST;
	
	r = "0";
	/* The current node in the UAP tree (initially: the root of the tree) */
	class UAPNode* currentNode = utilities->getUAPRootNode();
	/* The list of matched nodes. */
	NodeVec matchedNodes;
	/* The string representation of the tags of this path. */
	std::string tag = "";
	bool shouldUseContextNode = true;
	bool hasSpecifiedReturnAttrib = false;
	bool isAnonymousPath = false;
	/* Temporary list of nodes. */
	NodeVec _temp;
	
	
	try {      // for error handling
		ANTLR_USE_NAMESPACE(antlr)RefAST __t122 = _t;
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp38_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
		match(_t,AMLPATH);
		_t = _t->getFirstChild();
		{
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case AMLPATHTAGLIST:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t124 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp39_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,AMLPATHTAGLIST);
			_t = _t->getFirstChild();
			{
			for (;;) {
				if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
				if ((_t->getType()==IDENT)) {
					tagName = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
					match(_t,IDENT);
					_t = _t->getNextSibling();
					tag += tagName->getText();
				}
				else {
					goto _loop126;
				}
				
			}
			_loop126:;
			}
			_t = __t124;
			_t = _t->getNextSibling();
			break;
		}
		case AMLPATHELEMENT:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
		}
		ANTLR_USE_NAMESPACE(antlr)RefAST __t127 = _t;
		ANTLR_USE_NAMESPACE(antlr)RefAST tmp40_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
		match(_t,AMLPATHELEMENT);
		_t = _t->getFirstChild();
		{
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case IDENT:
		{
			firstNodeName = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,IDENT);
			_t = _t->getNextSibling();
			shouldUseContextNode = false;
			break;
		}
		case COLON:
		case AMLPATHNODE:
		case AMLPATHATTRIB:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
		}
		{
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case COLON:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp41_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,COLON);
			_t = _t->getNextSibling();
			isAnonymousPath = true;
			break;
		}
		case AMLPATHNODE:
		case AMLPATHATTRIB:
		{
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
		}
		
		if (shouldUseContextNode)
		/* Begin the search from the context node. */
		currentNode = context;
		else if (currentNode && isAnonymousPath)
		currentNode = currentNode->getChildByName(firstNodeName->getText());
		else if (currentNode) {
		/* Find the node whose name attribute value is firstNodeName->getText(). */
		bool hasFirstNode = false;
		matchedNodes = utilities->getUAPRootNode()->getSubNodesByName("constant");
		_temp = currentNode->getSubNodesByName("element");
		matchedNodes.insert(matchedNodes.end(), _temp.begin(), _temp.end());
		_temp = currentNode->getSubNodesByName("controller");
		matchedNodes.insert(matchedNodes.end(), _temp.begin(), _temp.end());
		_temp = currentNode->getSubNodesByName("beam");
		matchedNodes.insert(matchedNodes.end(), _temp.begin(), _temp.end());
		if (tag == "") {
		/* Match attribute name. */
		for (NodeVecCIter imm=matchedNodes.begin(); imm != matchedNodes.end(); ++imm)
		if ((*imm)->getAttributeString("name") == firstNodeName->getText()) {
		currentNode = *imm;
		hasFirstNode = true;
		break;
		}
		} else {
		/* Match attribute name and tag. */
		for (NodeVecCIter imn=matchedNodes.begin(); imn != matchedNodes.end(); ++imn)
		if ((*imn)->getAttributeString("name") == firstNodeName->getText()
		&& (*imn)->getAttributeString("tag") == tag) {
		currentNode = *imn;
		hasFirstNode = true;
		break;
		}
		}
		if (!hasFirstNode)
		currentNode = NULL;
		}
		if (!currentNode)
		throw UAPParserException("error: '"+firstNodeName->getText()+"' undeclared");
		
		{
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case AMLPATHATTRIB:
		{
			{
			ANTLR_USE_NAMESPACE(antlr)RefAST __t132 = _t;
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp42_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,AMLPATHATTRIB);
			_t = _t->getFirstChild();
			attrName = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,IDENT);
			_t = _t->getNextSibling();
			_t = __t132;
			_t = _t->getNextSibling();
			
			if (currentNode)
			/* Retrieve the value of the attribute with the specified name. */
			r = currentNode->getAttributeString(attrName->getText());
			if (r == "")
			/* If the attribute whose name is attrName->getText() is not defined. */
			r = "0";
			
			}
			break;
		}
		case AMLPATHNODE:
		{
			{
			{
			int _cnt139=0;
			for (;;) {
				if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
				if ((_t->getType()==AMLPATHNODE)) {
					ANTLR_USE_NAMESPACE(antlr)RefAST __t135 = _t;
					ANTLR_USE_NAMESPACE(antlr)RefAST tmp43_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
					match(_t,AMLPATHNODE);
					_t = _t->getFirstChild();
					nodeName = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
					match(_t,IDENT);
					_t = _t->getNextSibling();
					
					/* Find the list of nodes matchedNodes whose name is nodeName->getText(). */
					if (currentNode)
					matchedNodes = currentNode->getChildrenByName(nodeName->getText());
					
					
					{
					for (;;) {
						if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
						if ((_t->getType()==AMLPATHATTREXPR)) {
							ANTLR_USE_NAMESPACE(antlr)RefAST __t137 = _t;
							ANTLR_USE_NAMESPACE(antlr)RefAST tmp44_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
							match(_t,AMLPATHATTREXPR);
							_t = _t->getFirstChild();
							aName = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
							match(_t,IDENT);
							_t = _t->getNextSibling();
							aValue = _t==ASTNULL ? ANTLR_USE_NAMESPACE(antlr)nullAST : ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
							amlAttrValue(_t);
							_t = _retTree;
							_t = __t137;
							_t = _t->getNextSibling();
							
							/* Compute the subset of the list matchedNodes whose elements have 
							this attribute-value pair. */
							NodeVec temp;
							for (NodeVecCIter it=matchedNodes.begin(); it != matchedNodes.end(); ++it)
							if ((*it)->getAttributeString(aName->getText()) == aValue->getText())
							temp.push_back(*it);
							matchedNodes = temp;
							
						}
						else {
							goto _loop138;
						}
						
					}
					_loop138:;
					}
					
					/* Set the current node to the node that matched every attribute-value pair; 
					otherwise set to <code>NULL</code>. */
					currentNode = (matchedNodes.empty())? NULL: matchedNodes.front();
					
					_t = __t135;
					_t = _t->getNextSibling();
				}
				else {
					if ( _cnt139>=1 ) { goto _loop139; } else {throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);}
				}
				
				_cnt139++;
			}
			_loop139:;
			}
			{
			if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
			switch ( _t->getType()) {
			case AMLPATHATTRIB:
			{
				ANTLR_USE_NAMESPACE(antlr)RefAST __t141 = _t;
				ANTLR_USE_NAMESPACE(antlr)RefAST tmp45_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
				match(_t,AMLPATHATTRIB);
				_t = _t->getFirstChild();
				attrName2 = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
				match(_t,IDENT);
				_t = _t->getNextSibling();
				hasSpecifiedReturnAttrib = true;
				_t = __t141;
				_t = _t->getNextSibling();
				break;
			}
			case 3:
			{
				break;
			}
			default:
			{
				throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
			}
			}
			}
			
			if (currentNode && hasSpecifiedReturnAttrib)
			/* Retrieve the value of the attribute with the specified name. */
			r = "(" + currentNode->getAttributeString(attrName2->getText()) +")";
			else if (currentNode)
			/* Retrieve the value of the default attribute. */
			r = "(" + currentNode->getAttributeString("design") + ")";
			if (r == "")
			/* Either the attribute whose name is attrName2->getText() or 
			the default attribute is not defined. */
			r = "(0)";
			
			}
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
		}
		_t = __t127;
		_t = _t->getNextSibling();
		_t = __t122;
		_t = _t->getNextSibling();
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
	}
	_retTree = _t;
	return r;
}

void ExpressionTreeWalker::amlAttrValue(ANTLR_USE_NAMESPACE(antlr)RefAST _t) {
	
	ANTLR_USE_NAMESPACE(antlr)RefAST amlAttrValue_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
	
	try {      // for error handling
		if (_t==ANTLR_USE_NAMESPACE(antlr)nullAST) _t=ASTNULL;
		switch ( _t->getType()) {
		case NUM_DOUBLE:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp46_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,NUM_DOUBLE);
			_t = _t->getNextSibling();
			break;
		}
		case NUM_FLOAT:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp47_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,NUM_FLOAT);
			_t = _t->getNextSibling();
			break;
		}
		case IDENT:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp48_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,IDENT);
			_t = _t->getNextSibling();
			break;
		}
		case STRING_LITERAL_S:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp49_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,STRING_LITERAL_S);
			_t = _t->getNextSibling();
			break;
		}
		case STRING_LITERAL_D:
		{
			ANTLR_USE_NAMESPACE(antlr)RefAST tmp50_AST_in = ANTLR_USE_NAMESPACE(antlr)RefAST(_t);
			match(_t,STRING_LITERAL_D);
			_t = _t->getNextSibling();
			break;
		}
		default:
		{
			throw ANTLR_USE_NAMESPACE(antlr)NoViableAltException(_t);
		}
		}
	}
	catch (ANTLR_USE_NAMESPACE(antlr)RecognitionException& ex) {
		reportError(ex);
		if (_t!=ANTLR_USE_NAMESPACE(antlr)nullAST) {_t = _t->getNextSibling();}
	}
	_retTree = _t;
}

const char* ExpressionTreeWalker::_tokenNames[] = {
	"<0>",
	"EOF",
	"<2>",
	"NULL_TREE_LOOKAHEAD",
	"SEMI",
	"PLUS",
	"MINUS",
	"MULT",
	"DIV",
	"MOD",
	"POW",
	"LPAREN",
	"COMMA",
	"RPAREN",
	"a label",
	"LBRACKET",
	"COLON",
	"RBRACKET",
	"AT",
	"\".\"",
	"EQUAL",
	"NUM_DOUBLE",
	"NUM_FLOAT",
	"STRING_LITERAL_S",
	"STRING_LITERAL_D",
	"\"sqrt\"",
	"\"log\"",
	"\"exp\"",
	"\"sin\"",
	"\"cos\"",
	"\"tan\"",
	"\"asin\"",
	"\"acos\"",
	"\"atan\"",
	"\"atan2\"",
	"\"abs\"",
	"\"max\"",
	"\"min\"",
	"\"ran\"",
	"\"ran_gauss\"",
	"\"randf\"",
	"\"gauss\"",
	"\"tgauss\"",
	"\"user0\"",
	"\"user1\"",
	"\"user2\"",
	"FUNC",
	"AMLPATH",
	"AMLPATHNODE",
	"AMLPATHATTREXPR",
	"AMLPATHELEMENT",
	"AMLPATHTAGLIST",
	"AMLPATHATTRIB",
	"WS_",
	"ESC",
	0
};

const unsigned long ExpressionTreeWalker::_tokenSet_0_data_[] = { 6295008UL, 16384UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet ExpressionTreeWalker::_tokenSet_0(_tokenSet_0_data_,4);
const unsigned long ExpressionTreeWalker::_tokenSet_1_data_[] = { 6311392UL, 49152UL, 0UL, 0UL };
const ANTLR_USE_NAMESPACE(antlr)BitSet ExpressionTreeWalker::_tokenSet_1(_tokenSet_1_data_,4);


