/*
 * UAP Model Builder
 * Universal Accelerator Parser
 * Copyright (C) 2005 Andy Wolski, Daniel Bates, Daivd Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * David Sagan (dcs16@cornell.edu)
 * Andy Wolski (awolski@lbl.gov), 
 */

#include "UAPBuilder.hpp"
using namespace std;

UAPBuilder::UAPBuilder(UAPNode* node) :
          root(node), currentNode(node) {}

UAPBuilder::~UAPBuilder() {}

UAPNode* UAPBuilder::getCurrentNode() {
  return currentNode;
}

void UAPBuilder::addChild(enum UAPNode_type type, string name)
{
  currentNode = currentNode->addChild(name, type);
}

void UAPBuilder::moveToParent()
{
  currentNode = currentNode->getParent();
}

void UAPBuilder::addAttribute(string name, string value, bool allow_repeats)
{
  enum UAPNode_type type = currentNode->getType();
  currentNode->addAttribute(name, value, allow_repeats);
    
}

UAPNode* UAPBuilder::getChildByName(const string& _name)
{
  for (NodeVecIter it=root->getChildren().begin(); it!=root->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) return *it;
  }
  return NULL;
}

UAPNode* UAPBuilder::getChildByName(UAPNode* beginPosition, const string& _name)
{
  for (NodeVecIter it=beginPosition->getChildren().begin(); it!=beginPosition->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) return *it;
  }
  return NULL;
}

NodeVec UAPBuilder::getChildrenByName(const string& _name)
{
  NodeVec nList;
  for (NodeVecIter it=root->getChildren().begin(); it!=root->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) nList.push_back(*it);
  }
  return nList;
}

NodeVec UAPBuilder::getChildrenByName(UAPNode* beginPosition, const string& _name)
{
  NodeVec nList;
  for (NodeVecIter it=beginPosition->getChildren().begin(); it!=beginPosition->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) nList.push_back(*it);
  }
  return nList;
}

UAPNode* UAPBuilder::getSubNodeByName(const string& _name)
{
  UAPNode* node;
  for (NodeVecIter it=root->getChildren().begin(); it!=root->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) return *it;
    node = getSubNodeByName(*it, _name);
    if (node) return node;
  }
  return NULL;
}

UAPNode* UAPBuilder::getSubNodeByName(UAPNode* beginPosition, const string& _name)
{
  UAPNode* node;
  for (NodeVecIter it=beginPosition->getChildren().begin(); it!=beginPosition->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) return *it;
    node = getSubNodeByName(*it, _name);
    if (node) return node;
  }
  return NULL;
}

NodeVec UAPBuilder::getSubNodesByName(const string& _name)
{
  NodeVec nList;
  for (NodeVecIter it=root->getChildren().begin(); it!=root->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) nList.push_back(*it);
    (*it)->getSubNodesByName (_name, nList);
  }
  return nList;
}

NodeVec UAPBuilder::getSubNodesByName(UAPNode* beginPosition, const string& _name)
{
  NodeVec nList;
  for (NodeVecIter it=beginPosition->getChildren().begin(); it!=beginPosition->getChildren().end(); ++it) {
    if ((*it)->getName() == _name) nList.push_back(*it);
    (*it)->getSubNodesByName ( _name, nList);
  }
  return nList;
}


