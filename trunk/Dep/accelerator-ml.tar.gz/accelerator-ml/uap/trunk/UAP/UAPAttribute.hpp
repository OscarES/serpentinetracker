/*
 * UAP Attribute
 * Universal Accelerator Parser
 * Copyright (C) 2005 Daniel Bates, Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Daniel Bates (dbates@lbl.gov), Andy Wolski (awolski@lbl.gov)
 */

#ifndef UAPAttribute_hpp
#define UAPAttribute_hpp 1

#include <string>
#include "UAP/BasicUtilities.hpp"

/** <code>UAPAttribute</code> instances are used to construct a UAP model.
* <p>
* The <code>UAPAttribute</code> class provides a mutable wrapper for translation so that
* it is safe to use as an attribute.
* <p>
* Each UAP attribute describes:
* <ul>
*  <li>its name
*  <li>its value
* </ul>
* <p>
* The value of an attribute is a string.
* @author Daniel Bates, Andy Wolski
* @version 1.3, 07/18/05
* @ingroup CoreFoundation
*/
class UAPAttribute{
public:

  /** Creates a <code>UAPAttribute</code> with the specified name and value.
  * @param _name the name
  * @param _value the value
  * @see string
  */
  UAPAttribute(const std::string& _name, const std::string& _value);
  
  /** Sets the name of this attribute.
  * @param _name the name
  * @see string
  */
  void setName(const std::string& _name);

  /** Sets the value of this attribute.
  * @param _value the value
  * @see string
  */
  void setValue(const std::string& _value);

  /** Returns the name of this attribute.
  * @return the name of this attribute.
  * @see string
  */
  std::string getName() const;

  /** Returns the value of this attribute.
  * @return The value of this attribute.
  * @see string
  */
  std::string getValue() const;

  /** Returns the integer representation of the attribute value.
  * @arg    The integer number.
  * @return True if conversion OK. False otherwise.
  */
  bool getInt(int& num);

  /** Returns the real (double) representation of the attribute value.
  * @arg    The double number.
  * @return True if conversion OK. False otherwise.
  */
  bool getDouble(double& num);

  /** Returns the logical (bool) representation of the attribute value.
  * @arg    The lagical.
  * @return True if conversion OK. False otherwise.
  */
  bool getBool(bool& num);

  /** Returns a string object representing this attribute.
  * @return a string representation of this attribute.
  * @see string
  */
  std::string toString() const;

  /** Overrides the default output stream operator. 
  * @see #toString
  */
  friend std::ostream& operator << (std::ostream& os, const UAPAttribute& attr);
  friend std::ostream& operator << (std::ostream& os, const UAPAttribute* attr);
  
private:

  /** The name of this attribute. */
  std::string name;

  /** The value of this attribute. */
  std::string value;

};

#endif

