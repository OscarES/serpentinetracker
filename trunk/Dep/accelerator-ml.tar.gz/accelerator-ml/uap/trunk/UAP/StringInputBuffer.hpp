/*
 * String Input Buffer
 * Universal Accelerator Parser
 * Copyright (C) 2005 Andy Wolski, Daniel Bates
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 * Andy Wolski (awolski@lbl.gov), Daniel Bates (dbates@lbl.gov)
 */

#ifndef StringInputBuffer_hpp
#define StringInputBuffer_hpp 1

#include "antlr/InputBuffer.hpp"

ANTLR_USING_NAMESPACE(antlr)

/** This class allows an application to create an input stream in which the contents
* are supplied by the contents of a string.
* @author Andy Wolski, Daniel Bates
* @version 1.1
* @ingroup CoreUAP
*/
class StringInputBuffer : public InputBuffer
{
public:
  
  /** Creates an input stream from the specified string with its index
  * position equal to zero.
  * @param _istr the string
  * @see std::string
  */
  StringInputBuffer(std::string& _istr);

  /** Returns the next character in this stream.
  * @return next character in this stream.
  */
  int getChar();

private:

  /** The input string. */
  std::string& istr;

  /** The current index position of the stream. */
  int nchar;

};

#endif
