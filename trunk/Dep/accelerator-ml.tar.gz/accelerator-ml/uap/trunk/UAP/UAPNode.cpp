#include "UAPNode.hpp"

using namespace std;
namespace BU = BasicUtilities;

//--------------------------------------------------------------------------------------------

UAPNode::UAPNode(enum UAPNode_type _type, const string& _name) : 
      type(_type), parent(NULL), twin(NULL), connect(NULL), 
      children(), slaves(), masters(), controllers(), ix_child(-1) {

  if (!BU::splitXMLName (_name, xml_uri, xml_prefix, name)) {
    cout << "Bad name argument in UAPNode constructor: " << _name << endl;
    throw;
  }

}

//--------------------------------------------------------------------------------------------

UAPNode::UAPNode(const string& _name) :
      type(ELEMENT_NODE), parent(NULL), twin(NULL), connect(NULL), 
      children(), slaves(), masters(), controllers(), ix_child(-1) {

  if (!BU::splitXMLName (_name, xml_uri, xml_prefix, name)) {
    cout << "Bad name argument in UAPNode constructor: " << _name << endl;
    throw;
  }

}

//--------------------------------------------------------------------------------------------

UAPNode::UAPNode(const UAPNode& node){
  parent      = NULL;
  name        = node.name;
  xml_prefix  = node.xml_prefix;
  xml_uri     = node.xml_uri;
  type        = node.type;
  connect     = node.connect;
  twin        = node.twin;
  masters     = node.masters;
  slaves      = node.slaves;
  controllers = node.controllers;
  for (NodeVecCIter it = node.children.begin(); it != node.children.end(); ++it)
    addChildCopy(*it);
  for (AttributeVecCIter itt = node.attributes.begin(); itt != node.attributes.end(); ++itt)
    addAttribute(itt->getName(), itt->getValue(), true);
}

//--------------------------------------------------------------------------------------------

void UAPNode::getPath(IntArray& path) const {
  this->getPath2(path, 0);
}

//--------------------------------------------------------------------------------------------

void UAPNode::getPath2(IntArray& path, int n) const {

  if (parent)
    parent->getPath2(path, n+1);
  else
    path.resize(n+1);

  path[path.size()-n-1] = ix_child;

}

//--------------------------------------------------------------------------------------------

string UAPNode::getName() const{
  return name;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setName(const string& _name) {
  name = _name;
}

//--------------------------------------------------------------------------------------------

enum UAPNode_type UAPNode::getType() const{
  return type;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setType(enum UAPNode_type _type) {
  type = _type;
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::getParent() const{
  return parent;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setParent(UAPNode* _parent) {
  parent = _parent;
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::getTwin() const{
  return twin;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setTwin(UAPNode* _twin) {
  twin = _twin;
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::getConnect() const{
  return connect;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setConnect(UAPNode* _connect) {
  connect = _connect;
}

//--------------------------------------------------------------------------------------------

NodeVec& UAPNode::getChildren() {
  return children;
}

//--------------------------------------------------------------------------------------------

NodeVecIter UAPNode::getChildIter (const UAPNode* child) {
  for (NodeVecIter it=children.begin(); it!=children.end(); ++it)
    if (*it == child) return it;
  return children.end();
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::detachNode() {

  if (!parent) return this; // Nothing to be done

  // Remove node from parent's children list.

  NodeVecIter it = parent->getChildIter(this);
  parent->children.erase(it);

  // Now renumber the parent's children's childIndexNumber

  int ix_child = 0;
  for (NodeVecIter it = parent->children.begin(); it != parent->children.end(); it++)
    (*it)->ix_child = ix_child++;

  // Unlink from the parent and return.

  this->setParent(NULL);
  return this;

}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::addChild(const string& _name, UAPNode* old_child, enum UAPNode_type _type) {

  UAPNode* new_node = new UAPNode(_type, _name);
  if (!addChild(new_node, old_child)) {
    cout << "UAPNode::addChild: old_child not found for: " << old_child->toString() << endl;
    cout << "    For parent: " << this->toString() << endl;
    return NULL;
  }

  // Possibly we will need to set the xml_prefix and xml_uri info to be consistant with the local
  // elders.

  bool prefix_found;
  string uri, prefix, loc_name;
  BU::splitXMLName(_name, uri, prefix, loc_name, prefix_found);

  // A local-name has a blank xml_prefix.
  // A local-name or qualified-name inherits the xml_uri from the nearest elder that has 
  // a matching xml_prefix.
  // If no matching elder is found: 
  //   This is an error with a qualified-name.
  //   The xml_uri remains blank with a local-name.

  if (uri == "") {  // Must be local or qualified
    UAPNode* elder = this;
    while (true) {

      if (!elder) {
        if (!prefix_found) return new_node;  // !prefix_found <--> local-name
        cout << "UAPNode::addChild: No elder found with matching XML prefix for: " 
             << new_node->toString() << endl;
        return NULL;
      }

      if (elder->xml_prefix == prefix) {   
        new_node->xml_uri = elder->xml_uri;
        return new_node;
      }

      elder = elder->parent;

    }
  }

  // With a universal-name the xml_prefix is obtained from the nearest elder
  // with the same xml_uri.

  if (uri != "" && !prefix_found) {
    UAPNode* elder = this;
    while (true) {

      if (!elder) {
        cout << "UAPNode::addChild: No elder found with matching XML URI for: " 
             << new_node->toString() << endl;
        return NULL;
      }

      if (elder->xml_uri == uri) {
        new_node->xml_prefix = elder->xml_prefix;
        return new_node;
      }

      elder = elder->parent;

    }

  }

  // Must be a full-name. Nothing to be done here.

  return new_node;

}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::addChild(const string& _name, enum UAPNode_type _type, UAPNode* old_child) {
  return addChild(_name, old_child, _type);
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::addChildCopy(const UAPNode* node, const UAPNode* old_child) {
  assert(node);
  UAPNode* new_node = new UAPNode(*node);
  addChild(new_node, old_child);
  return new_node;
}

//--------------------------------------------------------------------------------------------
UAPNode* UAPNode::addChild(UAPNode* node, const UAPNode* old_child) {

  node->setParent(this);

  if (!old_child) {
    children.push_back(node);
    node->ix_child = children.size() - 1;

  } else {
    NodeVecIter iter = this->getChildIter(old_child);
    children.insert(iter, node);
    int ix_c = 0;
    for(iter = children.begin(); iter != children.end(); iter++) {
      (*iter)->ix_child = ix_c++;
    }
  }

  return node;
}

//--------------------------------------------------------------------------------------------

bool UAPNode::hasAttributes() const{
  return attributes.empty();
}

//--------------------------------------------------------------------------------------------

AttributeVec& UAPNode::getAttributes() {
  return attributes;
}

//--------------------------------------------------------------------------------------------

UAPAttribute* UAPNode::getAttribute(const string& _name){
  for (AttributeVecIter it=attributes.begin(); it!=attributes.end(); it++)
    if (it->getName() == _name)
      return &(*it);
  
  return NULL;
}

//--------------------------------------------------------------------------------------------

string UAPNode::getAttributeString(const string& _name) {
  for (AttributeVecIter it=attributes.begin(); it!=attributes.end(); ++it)
        if (it->getName() == _name) return it->getValue();
  
  return "";
}

//--------------------------------------------------------------------------------------------

bool UAPNode::removeAttribute(const string& _name) {
  for (AttributeVecIter it=attributes.begin(); it!=attributes.end(); ++it) {
    if (it->getName() == _name) {
      attributes.erase(it);
      return true;
    }
  }
  return false;
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::addAttribute(const string& _name, const string& _value, bool allow_repeats) {

  if (!allow_repeats) {
    for (AttributeVecIter it=attributes.begin(); it!=attributes.end(); ++it) {
      if (it->getName() == _name) {
        it->setValue(_value);
        return this;
      }
    }
  }

  UAPAttribute new_attribute(_name, _value);
  attributes.push_back(new_attribute);
  return this;

}

//--------------------------------------------------------------------------------------------

NodeVec UAPNode::getChildrenByName(const string& _name) {
  string uri, prefix, loc_name;
  BU::splitXMLName(_name, uri, prefix, loc_name);

  NodeVec result;
  for (NodeVecIter it=children.begin(); it!=children.end(); ++it) {
    UAPNode* node = *it;
    if (prefix != "" && uri == "") { // If a qname
      if (node->name == loc_name && node->xml_prefix == prefix) result.push_back(node);
    } else {
      if (node->name == loc_name && node->xml_uri == uri) result.push_back(node);
    }
  }

  return result;
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::getChildByName (const string& _name, bool create) {

  if (!this) return NULL;

  string uri, prefix, loc_name;
  BU::splitXMLName(_name, uri, prefix, loc_name);

  for (NodeVecIter it=children.begin(); it!=children.end(); ++it) {
    UAPNode* node = *it;
    if (node->name == loc_name && node->xml_uri == uri) 
      return (*it);
  }

  if (create) {
    UAPNode* child = this->addChild(loc_name);
    child->setXMLURI(uri);
    return child;
  }

  return NULL;
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::add (UAPNode_list list_name, UAPNode* new_ele, UAPNode* old_ele) {
  NodeVec& this_list = getList(list_name);
  if (!old_ele) {
    this_list.push_back(new_ele);
    return new_ele;
  }
  for (NodeVecIter it = this_list.begin(); it != this_list.end(); it++) {
    if (*it == old_ele) {
      this_list.insert(it, new_ele);
      return new_ele;
    }
  }
  return NULL;
}

//--------------------------------------------------------------------------------------------

UAPNode* UAPNode::add (UAPNode_list list_name, UAPNode* new_ele, NodeVecIter insert_pt) {
  NodeVec& this_list = getList(list_name);
  this_list.insert(insert_pt, new_ele);
  return new_ele;
}

//--------------------------------------------------------------------------------------------

NodeVec& UAPNode::getList(UAPNode_list list_name) {
  switch (list_name) {
    case SLAVE:        return slaves;
    case MASTER:       return masters;
    case CONTROLLER:   return controllers;
  }
  bool ok;
  cout << "Bad argument in UAPNode::get: " << 
          BasicUtilities::int_to_string(list_name, ok) << endl;
  throw;
}

//--------------------------------------------------------------------------------------------

void UAPNode::deleteNode() {
  if (parent) this->detachNode();
  this->deleteTree2();
}

//--------------------------------------------------------------------------------------------

void UAPNode::deleteTree2() {
  for (NodeVecIter it=children.begin(); it!=children.end(); ++it) {
    (*it)->deleteTree2();
  }
  delete this;
}

//--------------------------------------------------------------------------------------------

string UAPNode::toString(int indent, bool encode_all, const string& prefix) const {

  string result = string(indent, ' ') + prefix;
  if (type == ELEMENT_NODE) {
    result += "<" + this->getQName();
  } else if (type == TEXT_NODE)
    result += "TYPE: \""  + this->getQName() + "\"";
  else
    result += type + ": <"  + this->getQName();
  
  // List this node's attributes, if any.
  for (AttributeVecCIter it=attributes.begin(); it!=attributes.end(); ++it)
    result += " " + it->toString();
  
  if (type != TEXT_NODE)
    result += ">";

  if (!encode_all) return result;
  
  // Twin 
  if (twin) result += "\n" + string(indent+7, ' ') + 
                      "Twin: " + twin->toString(0, false);

  // Connect 
  if (connect) result += "\n" + string(indent+7, ' ') + 
                         "Connect: " + connect->toString(0, false);

  // Masters
  NodeVecCIter itt;
  for (itt = masters.begin(); itt != masters.end(); itt++) {
    result += "\n" + string(indent+7, ' ') + "Master: " + (*itt)->toString(0, false);
  }
  
  // Slaves
  for (itt = slaves.begin(); itt != slaves.end(); itt++) {
    result += "\n" + string(indent+7, ' ') + "Slave: " + (*itt)->toString(0, false);
  }

  // Controllers
  for (itt = controllers.begin(); itt != controllers.end(); itt++) {
    if ((*itt)->name == "slave") {
      result += "\n" + string(indent+7, ' ') + "Controller: " + 
                (*itt)->parent->toString(0, false);
      result += "\n" + string(indent+7, ' ') + "            " + (*itt)->toString(0, false);
    } else {
      result += "\n" + string(indent+7, ' ') + "Controller: " + (*itt)->toString(0, false);
    }
  }


  return result;
}

//--------------------------------------------------------------------------------------------

string UAPNode::toStringTree(int indent) const {
  return toStringTree2(indent, 0);
}

//--------------------------------------------------------------------------------------------

string UAPNode::toStringTree2(int indent, int depth) const {

  string result = "";

  if (depth == 0) result += toString(indent);
  else result += toString(3*depth+indent, true, "|- ");
 
  // Recursively print the children

  if (!children.empty()) {
    for (NodeVecCIter it=children.begin(); it!=children.end(); ++it) {
      result += "\n" + (*it)->toStringTree2(indent, depth+1);
    }
  }

  return result;
}

//--------------------------------------------------------------------------------------------

string UAPNode::toXMLTree (int indent) const {
  
  string result = string(indent, ' ');
  if (type == ELEMENT_NODE)
    result += "<"  + name;
  else if (type == TEXT_NODE) {
    result += name;
    return result;
  } else {
    result += "???";
    return result;
  }

  // List this node's attributes, if any.
  for (AttributeVecCIter it=attributes.begin(); it!=attributes.end(); ++it)
    result += " " + it->toString();

  // Recursively print the children

  if (children.empty()) {
    result += " />";

  } else {
    result += ">";
    for (NodeVecCIter it=children.begin(); it!=children.end(); ++it) {
      result += "\n" + (*it)->toXMLTree (indent+2);
    }
    result = result + "\n" + string(indent, ' ') + "</" + name + ">";
  }

  return result;

}

//--------------------------------------------------------------------------------------------

NodeVec UAPNode::getSubNodesByName(const string& _name) {

  NodeVec nList;

  if (!this) return nList;

  string uri, prefix, loc_name;
  BU::splitXMLName(_name, uri, prefix, loc_name);

  for (NodeVecIter it=children.begin(); it!=children.end(); ++it) {
    UAPNode* node = *it;
    if (node->name == loc_name && node->xml_uri == uri) 
      nList.push_back(*it);
    node->getSubNodesByName (_name, nList);
  }
  return nList;
}

//--------------------------------------------------------------------------------------------

void UAPNode::getSubNodesByName(const string& _name, NodeVec& nodeList) {

  string uri, prefix, loc_name;
  BU::splitXMLName(_name, uri, prefix, loc_name);

  for (NodeVecIter it=children.begin(); it!=children.end(); ++it) {
    UAPNode* node = *it;
    if (node->name == loc_name && node->xml_uri == uri) 
      nodeList.push_back(*it);
    node->getSubNodesByName (_name, nodeList);
  }
  return;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setChildIndexNumber (const int ix_c) {
  ix_child = ix_c;
}

//--------------------------------------------------------------------------------------------

int UAPNode::getChildIndexNumber () const {
  return ix_child;
}

//--------------------------------------------------------------------------------------------
void UAPNode::checkTree () {

  int ix_child = 0;

  for (NodeVecCIter it = children.begin(); it != children.end(); it++) {
    UAPNode* child = *it;
    if (child->parent != this) {
      cout << "Error: Parent/Child pointer mismatch!" << endl;
      cout << this->toString(4, false, "Parent: ") << endl;
      cout << child->toString(4, false, "Child: ") << endl;
    }
    if (child->ix_child != ix_child) {
      cout << "Error: Bad ix_child value!" << endl;
      cout << child->toString(4, false, "Child: ") << endl;
      cout << "    Ix_child value: " << child->ix_child << endl;
      cout << "    Correct ix_child value: " << ix_child << endl;
    }
    child->checkTree();
    ix_child++;
  }

}

//--------------------------------------------------------------------------------------------

string UAPNode::getXMLURI() const {
  return xml_uri;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setXMLURI(const string& uri) {
  xml_uri = uri;
}

//--------------------------------------------------------------------------------------------

string UAPNode::getXMLPrefix() const {
  return xml_prefix;
}

//--------------------------------------------------------------------------------------------

void UAPNode::setXMLPrefix(const string& prefix) {
  xml_prefix = prefix;
}

//--------------------------------------------------------------------------------------------

string UAPNode::getUniversalName () const {

  if (xml_uri == "")
    return name;
  else
    return "{" + xml_uri + "}" + name;

}

//--------------------------------------------------------------------------------------------

string UAPNode::getQName () const {

  if (xml_prefix == "")
    return name;
  else
    return xml_prefix + ":" + name;

}

//--------------------------------------------------------------------------------------------

void UAPNode::addXMLNSAttributes (bool close_to_root) {

  StrMap existing_xmlns, needed_xmlns;

  if (close_to_root)
    this->add_xmlns_close_to_root(true, existing_xmlns, needed_xmlns);
  else
    this->add_xmlns_far_from_root(existing_xmlns);

}

//--------------------------------------------------------------------------------------------

void UAPNode::add_xmlns_close_to_root(bool at_top_level, 
                          StrMap existing_xmlns, StrMap& needed_xmlns) {

  // First check current node for xmlns attributes.

  StrMap xmlns_here;
  for (AttributeVecCIter in = attributes.begin(); in != attributes.end(); in++) {
    string name = in->getName();
    if (name.substr(0,5) != "xmlns") continue;
    if (name.size() > 5 && name[5] != ':') continue;
    string prefix;
    if (name.size() > 5) prefix = name.substr(6);
    if (xmlns_here.find(prefix) != xmlns_here.end()) {
      cout << "Multiple XML prefixes of the same name: " + prefix << endl;
      cout << "Found in node:" << this->toString();
      throw;
    }
    xmlns_here[prefix] = in->getValue();
  }

  // Combine with existing xmlns stuff from the elders.

  for (StrMapCIter is = xmlns_here.begin(); is != xmlns_here.end(); is++) 
    existing_xmlns[is->first] = is->second;

  // Check if xmlns attribute needed for uri in this node.
  // If needed: add to list.

  if (xml_uri != "" && existing_xmlns.find(xml_prefix) == existing_xmlns.end()) 
    needed_xmlns[xml_prefix] = xml_uri;

  // Now loop over all the children and call this routine to get what needed. 
  // If a needed xmlns conflicts (same prefix, different uri) with an existing 
  //   xmlns, then add the xmlns to the child.
  // If this is the top level, add the xmlns to the current node.
  // Otherwise, add the needed xmlns to the needed_xmlns list.

  for (NodeVecCIter in = children.begin(); in != children.end(); in++) {
    UAPNode* child = *in;
    StrMap more_needed_xmlns;
    child->add_xmlns_close_to_root (false, existing_xmlns, more_needed_xmlns); 
    for (StrMapCIter is = more_needed_xmlns.begin(); is != more_needed_xmlns.end(); is++) {
      // If conflict
      if (existing_xmlns.find(is->first) != existing_xmlns.end() && 
                                  existing_xmlns[is->first] != is->second) {
        if (is->first == "") 
          child->addAttribute("xmlns", is->second);
        else
          child->addAttribute("xmlns:" + is->first, is->second);
      } else if (at_top_level) {
        if (is->first == "") 
          this->addAttribute("xmlns", is->second);
        else
          this->addAttribute("xmlns:" + is->first, is->second);
        existing_xmlns[is->first] = is->second;   // Add to existing list
      } else {
       needed_xmlns[is->first] = is->second;   // Add to needed list
      }
    }
  }

}

//--------------------------------------------------------------------------------------------

void UAPNode::add_xmlns_far_from_root(StrMap existing_xmlns) {

  // First check current node for xmlns attributes.

  StrMap xmlns_here;
  for (AttributeVecCIter in = attributes.begin(); in != attributes.end(); in++) {
    string name = in->getName();
    if (name.substr(0,5) != "xmlns") continue;
    if (name.size() > 5 && name[5] != ':') continue;
    string prefix;
    if (name.size() > 5) prefix = name.substr(6);
    if (xmlns_here.find(prefix) != xmlns_here.end()) {
      cout << "Multiple XML prefixes of the same name: " + prefix << endl;
      cout << "Found in node:" << this->toString();
      throw;
    }
    xmlns_here[prefix] = in->getValue();
  }

  // Combine with existing xmlns stuff from the elders.

  for (StrMapCIter is = xmlns_here.begin(); is == xmlns_here.end(); is++) 
    existing_xmlns[is->first] = is->second;

  // Check if xmlns attribute needed for uri in this node.
  // If needed: add to list.

  if (xml_uri != "" && existing_xmlns.find(xml_prefix) == existing_xmlns.end()) {
    if (xml_prefix == "") 
      this->addAttribute("xmlns", xml_uri);
    else
      this->addAttribute("xmlns:" + xml_prefix, xml_uri);
      existing_xmlns[xml_prefix] = xml_uri;   // Add to existing list
  }

  // Now loop over all the children and call this routine 

  for (NodeVecCIter in = children.begin(); in != children.end(); in++) {
    UAPNode* child = *in;
    child->add_xmlns_far_from_root (existing_xmlns); 
  }

}

//--------------------------------------------------------------------------------------------

ostream& operator << (ostream& os, const UAPNode& node) {
  os << node.toString();
  return os;
}

//--------------------------------------------------------------------------------------------

ostream& operator << (ostream& os, const UAPNode* node) {
  os << node->toString();
  return os;
}

