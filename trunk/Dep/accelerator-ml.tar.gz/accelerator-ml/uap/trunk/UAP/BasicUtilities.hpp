/*
 * UAP Basic Utilities
 * Universal Accelerator Parser
 * Copyright (C) 2006 Andy Wolski, Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   Andy Wolski (a.wolski@dl.ac.uk)
 *   Daniel Bates (dbates@lbl.gov)
 *   David Sagan (dcs16@cornell.edu)
 */

#ifndef UAPBasicUtilities_hpp
#define UAPBasicUtilities_hpp 1

#include <string>
#include <map>
#include <list>
#include <set>
#include <iostream>
#include <fstream>
#include <vector>
#include <valarray>

typedef std::string                                        Str;

typedef std::list<std::string>                             StrList;
typedef std::list<std::string>::iterator                   StrListIter;
typedef std::list<std::string>::const_iterator             StrListCIter;

typedef std::map<std::string, std::string>                 StrMap;
typedef std::map<std::string, std::string>::iterator       StrMapIter;
typedef std::map<std::string, std::string>::const_iterator StrMapCIter;

typedef std::map<std::string, int>                         IntMap;
typedef std::map<std::string, int>::iterator               IntMapIter;
typedef std::map<std::string, int>::const_iterator         IntMapCIter;

typedef std::vector<std::string>                           StrVec;
typedef std::vector<std::string>::iterator                 StrVecIter;
typedef std::vector<std::string>::const_iterator           StrVecCIter;

typedef std::map<std::string, StrVec>                      StrVecMap;
typedef std::map<std::string, StrVec>::iterator            StrVecMapIter;
typedef std::map<std::string, StrVec>::const_iterator      StrVecMapCIter;

typedef std::valarray<int>                                 IntArray;
typedef std::vector<int>                                   IntVec;
typedef std::list<int>                                     IntList;

typedef std::vector<double>                                DoubleVec;


StrList& operator<< (StrList& s_list, const std::string& str);
StrList& operator<< (StrList& list_out, StrList list_in);

StrVec& operator<< (StrVec& s_vector, const std::string& str);
StrVec& operator<< (StrVec& vector_out, StrVec list_in);

/** A collection of utility methods.
* @author David Sagan
* @ingroup CoreServices
*/
namespace BasicUtilities {

  const Str ERROR_STR = "!ERROR";

  /** Trim string of leading and trailing blanks.
  * @param str       String to be trimmed.
  * @return          String with blanks trimmed.
  */
  Str trim(Str str);

  /** Splits a file name into a directory string and base file name.
  * @param file_name_in The input file name.
  * @param dir          Set to the directory with trailing '/'.
  * @param file_name    The base file name stripped of the directory string.
  * @param is_relative  Set True if the directory name is relative to the
  *                     default directory (as opposed to an absolute path name).
  */
  void split_file_name (Str file_name_in, Str& dir, Str& file_name, bool& is_relative);
  void split_file_name (Str file_name_in, Str& dir, Str& file_name);

  /** Converts a string to an integer.
  * @param str    String to convert.
  * @param ok     True if conversion OK. False otherwise.
  *                 "" returns ok = false.
  * @return       Integer value.
  */
  int string_to_int (const Str& str, bool& ok);
  int string_to_int (const Str& str);

  /** Tests if a string to an integer.
  * @param str    String to convert.
  * @return       True if the string is an integer. False otherwise.
  *                 "" returns false.
  */
  bool is_int (const Str& str);

  /** Converts a string to a real (double).
  * @param str    String to convert.
  * @param ok     True if conversion OK. False otherwise.
  *                 "" returns ok = false.
  * @return       real value.
  */
  double string_to_double (const Str& str, bool& ok);
  double string_to_double (const Str& str);

  /** Tests if a string to a double.
  * @param str    String to convert.
  * @return       True if the string is a double. False otherwise.
  *                 "" returns false.
  */
  bool is_double (const Str& str);

  /** Converts a string to a logical bool.
  * @param str    String to convert.
  * @param ok     True if conversion OK. False otherwise.
  *                 "" returns ok = false.
  * @return       logical value.
  */
  bool string_to_bool (const Str& str, bool& ok);
  bool string_to_bool (const Str& str);

  /** Tests if a string to a bool.
  * @param str    String to convert.
  * @return       True if the string is a bool. False otherwise.
  *                 "" returns false.
  */
  bool is_bool (const Str& str);

  /** Converts a bool to a string.
  * @param this_bool  Bool input.
  * @return           Encoded string.
  */
  Str bool_to_string (bool this_bool);

  /** Converts an integer to a string.
  * @param i      Integer input.
  * @param ok     True if conversion OK. False otherwise.
  * @return       Encoded string.
  */
  Str int_to_string (const int i, bool& ok);
  Str int_to_string (const int i);

  /** Converts an real double to a string.
  * @param r      Double input.
  * @param ok     True if conversion OK. False otherwise.
  * @return       Encoded string.
  */
  Str double_to_string (const double r, bool& ok);
  Str double_to_string (const double r);

  /** Converts a string to upper case.
  * @param  str_in    Input string.
  * @return           Uppercased version of input string.
  */
  Str str_to_upper (const Str& str_in);

  /** Converts a string to lower case.
  * @param  str_in    Input string.
  * @return           Lowercased version of input string.
  */
  Str str_to_lower (const Str& str_in);

  /** Adds parentheses "(...)" around an expression if the expression has a "+" or a "-".
  * This is useful when adding an expression to a larger expression.
  * @param expression   Input expression
  * @return             Expression with parentheses added if needed.
  */
  Str add_parens_if_needed (const Str& expression);

  /** Converts characters "&", "<", ">", and '"' to their XML 
  * equivalents: "&amp;", "&lt;", etc. Notice that single quote is not converted
  * since it is assumed that double quotes will be used to bound the string.
  * @param     str_in  Input string.
  * @return    XML string.
  */
  Str to_xml_string (Str str_in);

  /** Converts XML character entity reference references like "&amp;", &lt;", etc 
  * to their character equivalents: "&", "<", ">", "'", and '"'.
  * @param     str_in  Input XML string.
  * @return    Converted string.
  */
  Str from_xml_string (Str str_in);

  /** Pops the front item of the list and returns it.
  * @param str_list   The list of strings.
  * @return           The front string.
  */
  Str str_pop (StrList& str_list);

  /** Returns the string value of an element in a StrList indexed by <code>index</code>
  * @param s_list     List of strings.
  * @param index      Index of element in s_list.
  * @return           String value. If index is out-of-range then return "".
  */
  Str element_val(StrList& s_list, int index);

  /** Returns true if an item is in the list.
  * @param s_list     List of strings.
  * @param item       String to search for.
  * @return           True if item is in the list. False otherwise.
  */
  bool found(StrList& s_list,     const Str& item);
  bool found(StrVec& s_vector, const Str& item);
  bool found(Str& str,    const Str& item);
  template <class T> inline bool found(std::map<Str, T>& this_map, const Str& item) 
  {
    return (this_map.find(item) != this_map.end());
  }

  /** Returns an iterator to a matching item in a list.
  * @param s_list     List of strings.
  * @param item       String to search for.
  * @return           Iterator to the item. s_list.end() if not found.
  */
  StrListIter find(StrList& s_list, const Str& item);
  StrListIter rfind(StrList& s_list, const Str& item);

  /** Returns a copy of a list: [begin, end)
  * @param begin      Beginning of copy region
  * @param end        End of copy region. end is not copied!
  * @return           Copy of the region
  */
  StrList list_copy(StrListIter begin, StrListIter end);

  /** Returns true if an item is a value in a map.
  * @param string_map  Key/Value map.
  * @param item        String to search for.
  * @return            True if item is a value in the map. False otherwise.
  */
  bool found_value(StrMap& string_map, const Str& item);

  /** Decomposes an exponent string like "0 2 1 0 0 0" into its component numbers.
  * @param  exp_str   Input exponent string.
  * @param  exp_vec   Output vector of 6 exponents.
  * @return           True if decomposition is successful. False otherwise.
  */
  bool get_taylor_exponents (const Str& exp_str, IntVec& exp_vec);

  /** Splits an XML name into a URI, prefix and local name components
  * @param _name          A local/qualified/universal/or full name.
  * @param uri            URI part of xml_name.
  * @param prefix         Prefix part of the name
  * @param loc_name       Local part of xml_name.
  * @param prefix_found   Set false if a prefix was not defined. Set true otherwise.
  *                         That is, set false when _name is a local-name or a universal-name.
  * @return               Set false if _name is malformed. EG: unmatched "{...}" found. 
  *                         Set true otherwise 
  */
  bool splitXMLName (const Str& _name, Str& uri, Str& prefix, 
            Str& loc_name);
  bool splitXMLName (const Str& _name, Str& uri, Str& prefix, 
            Str& loc_name, bool& prefix_found);

}

// file_struct_struct is used for opening files and keeping track of directory paths.

struct FileStackElement {
  bool splitName (const Str& file_name_in);
  Str this_name;         // Name of file
  Str this_dir;          // Directory part of the file name
  Str this_file_no_dir;  // File name without directory
  Str full_dir;          // Full dirctory taking into accout previous stack elements.
  Str full_name;         // Full file ma,e taking into accout previous stack elements.
};

struct FileStackList {
  void addFile (const Str& file_name);
  std::list<FileStackElement> file_list;
};


//-----------------------------------------------------------------------
//-----------------------------------------------------------------------
// stream_struct is used to break up lines that are too long when writing to a 
// lattice file (used for MAD and Bmad lattice files).

struct EndStruct {};

class StreamStruct {

public: 

  StreamStruct(Str file_name = "");

  Str continuation_char;
  int n_indent;
  int max_len;

  void close_file();
  void open_file(const Str& file_name);
  bool is_open();
  StreamStruct& operator<< (const Str& str);
  StreamStruct& operator<< (const int i);
  StreamStruct& operator<< (EndStruct& s);
  StreamStruct& operator= (StreamStruct& s);

private:

  int ix_line; 
  std::ofstream *out_file;

};


//-----------------------------------------------------------------------
//-----------------------------------------------------------------------
// PrintInfoStruct is used for error reporting

class PrintInfoStruct {

public:

  void error (Str line1, Str line2 = "", Str line3 = "");
  void warning (Str line1, Str line2 = "", Str line3 = "");

  static Str parsing_status;
  static Str file_name; 
  static Str statement;
  static int ix_line;
  static bool everything_ok;

private:

  void print (Str& line2, Str& line3);

};


#endif
