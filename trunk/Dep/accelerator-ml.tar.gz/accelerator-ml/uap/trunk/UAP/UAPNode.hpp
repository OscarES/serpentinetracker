/*
 * UAP Node
 * Universal Accelerator Parser
 * Copyright (C) 2005, 2006 David Sagan, Daniel Bates, or Andy Wolski
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 *   Andy Wolski (a.wolski@dl.ac.uk)
 */

#ifndef UAPNode_hpp
#define UAPNode_hpp 1

#include <iostream>
#include <string>
#include <map>
#include <list>
#include <cassert>

#include "UAP/UAPAttribute.hpp"
#include "UAP/UAPException.hpp"

class UAPNode;

/** Define a typedef for a list of attributes and associated iterators.
*/

typedef std::vector<UAPAttribute>                 AttributeVec;
typedef std::vector<UAPAttribute>::iterator       AttributeVecIter;
typedef std::vector<UAPAttribute>::const_iterator AttributeVecCIter;

/** Define a typedef for a list of UAPNodes and associated iterators.
*/

typedef std::vector<UAPNode*>                     NodeVec;
typedef std::vector<UAPNode*>::iterator           NodeVecIter;
typedef std::vector<UAPNode*>::reverse_iterator   NodeVecRevIter;
typedef std::vector<UAPNode*>::const_iterator     NodeVecCIter;

/** Define a typedef for a mapped list of UAPNodes and associated iterators.
*/

typedef std::map<Str, UAPNode*>                 NodeMap;
typedef std::map<Str, UAPNode*>::iterator       NodeMapIter;
typedef std::map<Str, UAPNode*>::const_iterator NodeMapCIter;

/** Constants representing the various UAPNode types. */
enum UAPNode_type {ELEMENT_NODE, TEXT_NODE};

/** Define constants for the various lists.
*/

enum UAPNode_list {SLAVE, MASTER, CONTROLLER};

/**  A <code>UAPNode</code> is the basic building block for constructing a UAP model.
* A UAP model is essentially a tree of UAPNodes. This is similar to an XML tree except
* a UAP node also contains pointers to slaves, etc.
* <p>
* Each UAPNode has:
* <ul>
*  <li>A name.
*  <li>An xml_prefix.
*  <li>An xml_uri.
*  <li>A type. Generally this is ELEMENT_NODE.
*  <li>A pointer to its parent node.
*  <li>A pointer to its twin node.
*  <li>Pointers to its children nodes.
*  <li>A list of attributes. @see UAPAttribute
*  <li>Pointers to its masters.
*  <li>Pointers to its controllers.
*  <li>Pointers to its slaves.
* </ul>
* <p>
* Note: For a node that is part of a tree, an "elder" of the node can
* be the parent, the parent of the parent, all the way up to the root node.
*  
* <p>
* Consider the XML node:
* <pre>
*     &lt;car:parts xmlns:car = "http://www.cars.com/xml" /&gt;
* </pre>
* When this is translated to a UAPNode the result is:
* <pre>
*     .name = "parts"
*     .xml_prefix = "car"
*     .xml_uri = "http://www.cars.com/xml"
* </pre>
* In this example:
* <pre>
*     local-name     = "parts"
*     qualified-name = "car:parts"
*     universal-name = "{http://www.cars.com/xml}parts"
*     full-name      = "{http://www.cars.com/xml}car:parts"
* </pre>
* Note: The qualified-name is also called the "qname".
* <p>
* Local, qualified, universal, and full-names are used in UAPnode creation.
* Some eamples of such names and how they are parsed:
* <pre>
*   Name              Type                URI          Prefix
*   ----------        ----------          -----        ----------
*   "parts"           local-name          Undefined    Undefined
*   ":parts"          qualified-name      Undefined    ""
*   "pre:parts"       qualified-name      Undefined    "pre"
*   "{uri}parts"      universal-name      "uri"        Undefined
*   "{}parts"         universal-name   Blank ("") URIs not permitted on input!
*   "{uri}:parts"     full-name           "uri"        ""
*   "{uri}pre:parts"  full-name           "uri"        "pre"
*   "{}pre:parts"     full-name        Blank ("") URIs not permitted on input!
* </pre>
* Note: While prefixes may be undefined on input, URIs are never undefined.
*/

class UAPNode{
public:
  
  /** Creates an empty UAP node. */
  UAPNode();
  
  /** Creates a UAPNode initialized with the specified type and name.
  * Undefined xml_prefix or xml_uri values will be set to blank (""). 
  * @param _type        The node's type.
  * @param _name        A local/qualified/universal/or full name. See UAPNode.
  */
  UAPNode(enum UAPNode_type _type, const Str& _name);
  
  /** Creates a UAPNode initialized with the specified name.
  * The node type will be ELEMENT_NODE.
  * Undefined xml_prefix or xml_uri values will be set to blank (""). 
  * @param _name        A local/qualified/universal/or full name. See UAPNode.
  */
  UAPNode(const Str& _name);
  
  /** Creates a copy of a UAPNode and copies of all its sub-nodes.
  * This method overrides the default copy constructor. 
  */
  UAPNode(const UAPNode& node);
  
  /** Returns the local-name of this node.
  * @return         The local-name of this node.
  */
  Str getName() const;
  
  /** Sets the local-name of this node.
  * @param _name    The name
  */
  void setName(const Str& _name);
  
  /** Returns the path to this node.
  * The path is a list of ix_child numbers starting from the root.
  * @return the path to this node.
  */
  void getPath(IntArray& path) const;
  
  /** Returns the type of this node.
  * @return the type of this node.
  */
  enum UAPNode_type getType() const;
  
  /** Sets the type of this node.
  * @param _type    The type
  */
  void setType(enum UAPNode_type _type);
  
  /** Returns the parent of this node.
  * @return         The parent of this node.
  */
  UAPNode* getParent() const;
  
  /** Sets the parent of this node to the specified node.
  * @param _parent the node
  */
  void setParent(UAPNode* _parent);
  
  /** Returns the twin of this node.
  * @return the twin of this node.
  */
  UAPNode* getTwin() const;
  
  /** Sets the twin of this node to the specified node.
  * @param _twin the node
  */
  void setTwin(UAPNode* _twin);
  
  /** Returns the connect of this node.
  * @return the connect of this node.
  */
  UAPNode* getConnect() const;
  
  /** Sets the connect of this node to the specified node.
  * @param _connect the node
  */
  void setConnect(UAPNode* _connect);
  
  /** Detaches the node from the tree it is in. If the node is the root node
  * or the node is not in a tree, nothing is done.
  * Also see <code>deleteNode</code>.
  * @return             The detached node.
  */
  UAPNode* detachNode();
  
  /** Deletes the node as well as the entire sub-tree.
  * Also see <code>detachNode</code>.
  */
  void deleteNode();

  /** Returns a list of children of this node.
  * <p>
  * This method returns a list of {@link UAPNode} objects. 
  * @return a list of children of this node.
  */
  NodeVec& getChildren();

  /** Returns an iterator pointing to the <code>child</code> node.
  * @param child    The child node.
  * @return         An iterator pointing to the node. 
  *                   If the child node is not found then returns this.children.end().
  */
  NodeVecIter getChildIter (const UAPNode* child);
  
  /** Inserts a child just before old_child in the list of children of this node.
  * This method creates a new <code>UAPNode</code> and initializes it to
  * the specified type and name for the child. The child is inserted just before
  * <code>old_child</code> in the list of children and a pointer to the child is returned.
  * <p>
  * If _name is a local-name: xml_prefix will be blank. xml_uri will be blank unless
  * there is an elder node with a blank xml_prefix.
  * In this case,  xml_uri will inherit the xml_uri of the nearest such elder.
  * <p>
  * If _name is a qualified-name, the xml_uri will be taken from the nearest elder that 
  * has the same xml_prefix value.
  * <p>
  * If _name is a universal-name, the xml_prefix will be taken from the nearest elder 
  * that has the same xml_uri. If no such error exists, an exception is thrown.
  * @param _name        A local/qualified/universal/or full name. See UAPNode.
  * @param _type        The type of the child.
  * @param old_child    The new child is put just before this existing child.
  *                       If old_child = NULL then the new child is put
  *                       at the end of the children list.
  * @return             The child node. Returns NULL if there is an error
  */
  UAPNode* addChild(const Str& _name, enum UAPNode_type _type, UAPNode* old_child = NULL);
  UAPNode* addChild(const Str& _name, UAPNode* old_child = NULL, 
                                                       enum UAPNode_type _type = ELEMENT_NODE);


  /** Adds the specified node just before the
  * <code>old_child</code> node in the list of children of this node and
  * returns a pointer to the child node.
  * @param node       The node to be added.
  * @param old_child  The new child is put just before this existing child. 
  *                     Default is at the end of the children list.
  * @return           Pointer to the node that was added.
  */
  UAPNode* addChild(UAPNode* node, const UAPNode* old_child = NULL);

  /** Adds a copy of the specified node (along with its entire subtree) just before the
  * <code>old_child</code> node in the list of children of this node and
  * returns a pointer to the child.
  * @param node       The node to be added.
  * @param old_child  The new child is put just before this existing child. 
  *                     Default is at the end of the children list.
  * @return           Pointer to the new child.
  */
  UAPNode* addChildCopy(const UAPNode* node, const UAPNode* old_child = NULL);
  
  /** Returns whether this node has any attributes.
  * @return <code>true</code if this node has attributes;
  *      <code>false</code> otherwise.
  * @deprecated Sicne 1.5.4. Use {@link #getAttributes}.empty().
  */
  bool hasAttributes() const;
  
  /** Returns a list of attributes of this a node.
  * <p>
  * This method returns a list of {@link UAPAttribute} objects. 
  * @return a list of attributes of this node.
  * @see AttributeVec
  */
  AttributeVec& getAttributes();
  
  /** Returns the attribute in this node with the specified name.
  * @param _name    The attribute name
  * @return         NULL if the attribute does not exist.
  *                   Otherwise, the attribute in this node with the specified name.
  */
  UAPAttribute* getAttribute(const Str& _name);
  
  /** Appends an attribute to the end of the list of attributes in this node.
  * <p>
  * This methods creates a new <code>UAPAttribute</code> from the specified name
  * and value and adds it to the end of the list of attributes in this node. 
  * Exception: When the argument <code>allow_repeats</code> = false, and
  * an attribute with _name already exists, no new attribute is created and
  * the matching attribute has its value replaced by <code>_value</code>.
  * @param _name          The name of the attribute.
  * @param _value         The value of the attribute.
  * @param allow_repeats  True to allow duplicate attributes.
  *                         False if attributes must be unique. Default: False.
  * @return               "this" node.     
  */
  UAPNode* addAttribute(const Str& _name, const Str& _value, bool allow_repeats=false);
  
  /** Returns the string value associated with the specified attribute.
  * <p>
  * This method stores the value of the specified attribute in the
  * @param _name The attribute name
  * @return      The string value of the attribute. Blank "" if it does not exist.
  */
  Str getAttributeString(const Str& _name);
  
  /** Removes the attribute with name <code>_name</code> from the list of attributes 
  * in this node.
  * @param _name    The name of the attribute to remove
  * @return         true if the attribute existed. false otherwise.
  */
  bool removeAttribute(const Str& _name);

  /** Returns a list of the descendent children of a given name on this node.
  * If _name is a qname, match by xml_prefix instead of xml_uri.
  * @param _name    The name of the children
  * @return         A list of the descendent children of a given name on this node.
  */
  NodeVec getChildrenByName(const Str& _name);
  
  /** Returns a descendent child of a given name on this node.
  * @param  _name   The universal-name of the child
  * @param  create  If true then create the child if it does not exist.
  *                   If created then the node type will be ELEMENT_NODE.
  * @return         A child node with the given name. NULL if not found or
  *                   if parent does not exist.
  */
  UAPNode* getChildByName (const Str& _name, bool create = false);

  /** Returns a list of sub-nodes of the current node with the specified name.
  * All sub-nodes (children and sub-children) are searched.
  * @see NodeVec
  * <p>
  * @param _name     The universal-name of the node.
  * @return          A list of sub-nodes of the current node with the specified name.
  */
  NodeVec getSubNodesByName(const Str& _name); 

  /** See {@link #getSubNodesByName(const Str&)}.
  * <p>
  */
  void getSubNodesByName(const Str& _name, NodeVec& nodeList);
  
  /** Gets the child index number for a node.
  * @return       The child index number.
  */
  int getChildIndexNumber () const;

  /** Adds a reference to a UAPNode to the slave, master, or controller list.
  * This reference will be put just before the reference to old_ele.
  * @param list_name    Name of the list.
  * @param new_ele      Node to point to
  * @param old_ele      new_ele will be put just before old_ele.
  *                       If old_ele = NULL (the default) then new_ele 
  *                       will be appended at the end of the list.
  */
  UAPNode* add (UAPNode_list list_name, UAPNode* new_ele, UAPNode* old_ele = NULL);
    
  /** Adds a reference to a UAPNode to the slave, master, or controller list.
  * This reference will be put just before the reference to old_ele.
  * @param list_name    Name of the list.
  * @param new_ele      Node to point to.
  * @param insert_pt    Iterator to an element in the list. The new_ele will 
  *                       be put just before this. 
  * @return             Pointer to the inserted element.
  */
  UAPNode* add (UAPNode_list list_name, UAPNode* new_ele, NodeVecIter insert_pt);

  /** Returns a slave, master, or controller list of this node.
  * <p>
  * This method returns a list of {@link UAPNode} objects. 
  * @param list_name    Name of the list: "SLAVE", "MASTER", or "CONTROLLER".
  * @return             A list of nodes.
  */
  NodeVec& getList(UAPNode_list list_name);
  
  /** Returns a string representing this node.
  * <p>
  * The attributes of this node are printed in brackets.
  * @param indent       Number of spaces to indent.
  * @param encode_all  If true (default) then encode information on any 
  *                       twin, master, and slave data.
  * @param prefix      Prefix string to be prepended to output.
  * @return            A string representation of this node.
  * @see #toStringTree
  */
  Str toString(int indent = 0, bool encode_all = true, const Str& prefix = "") const;
  
  /** Returns a string representing the UAP tree
  * rooted at this node. The argument depth is a specifier for the depth
  * of the tree so far and defaults to <code>0</code>.
  * <p>
  * This method recursively prints a textual representation of the tree
  * rooted at this node.
  * @param indent    Number of spaces to indent.
  * @return          A textual representation of the UAP tree rooted at this node.
  * @see #toString
  */
  Str toStringTree(int indent = 0) const;

  /** Returns an XML representation of the UAPNode and of all subnodes. 
  * Note that all information on twins, slaves, controllers, etc. is lost.
  * @param indent    Number of spaces to indent.
  * @return          An XML representation of the UAP tree rooted at this node.
  */
  Str toXMLTree (int indent = 0) const;

  /** Makes consistancy checks on the node tree.
  * 1) Checks that all pairent pointers in the tree are indeed pointing to the parent.
  * 2) Checks that ix_child is correct.
  */
  void checkTree ();

  /** Returns the Universal Resource Identifier of this node.
  * @return   The Universal Resource Identifier  of this node.
  */
  Str getXMLURI() const;
  
  /** Sets the Universal Resource Identifier of this node.
  * @param uri   The name of the URI
  */
  void setXMLURI(const Str& uri);
  
  /** Returns the XML prefix used for the Universal Resource Identifier of this node.
  * @return   The URI prefix.
  */
  Str getXMLPrefix() const;
  
  /** Sets the XML prefix of this node.
  * @param preifx   The name of the prefix
  */
  void setXMLPrefix(const Str& prefix);

  /** Get the XML qualified name for this node.
  * the qualified name is of the form "xml_prefix:local_name"
  * @return    XML qualified name.
  */
  Str getQName () const;

  /** Get the universal name for this node.
  * the Universal name is of the form "{uri}local_name"
  * @return    Universal name
  */
  Str getUniversalName () const;

  /** Adds "xmlns" attributes to create a conforming xml tree.
  * In a UAPNode tree, namespace URI information is stored as a component of the 
  * individual nodes.
  * When the tree is printed or saved to a file, this information is lost. 
  * To preserve this information, appropriate "xmlns" attributes must be present.
  * This method adds to the tree such attributes as needed.
  * There are many possibilities in the placement of "xmlns" attribues.
  * If <code>close_to_root</code> is True then this method will place the attributes as 
  * close to the root node as possible. If False, this method will try to palace 
  * the attributes close to where they are used.
  * In both cases, this method tries to minimize the number of attributes created.
  * @param close_to_root    Strategy for placing the "xmlns" attributes.
  */
  void addXMLNSAttributes (bool close_to_root = true);

  /** Overrides the default output stream operator. 
  * @see #toString
  */
  friend std::ostream& operator << (std::ostream& os, const UAPNode& node);
  friend std::ostream& operator << (std::ostream& os, const UAPNode* node);
  
private:
    
  // The name of this node.
  // Set to the XML localname if read from an XML file.
  Str name;

  // The local XML namespace prefix.
  // Rule: If xml_uri is blank (""), xml_prefix must also be blank.
  Str xml_prefix;

  // XML Universal Resource Identifier
  Str xml_uri;

  // The type of this node. 
  enum UAPNode_type type;
  
  // The parent of this node. 
  UAPNode* parent;
  
  // The twin of this node. 
  UAPNode* twin;

  // Used by branch and merger 
  UAPNode* connect;
  
  // The list of children of this node. 
  NodeVec children;
  
  // The list of attributes of this node. 
  AttributeVec attributes;
  
  // Used for controllers and girders. 
  // Used for superpositions and multipass control 
  NodeVec slaves;
  NodeVec masters;
  NodeVec controllers;

  // Index of this node in the parent's children array.
  // The index of the first child is 0.
  // Set to -1 if this node has no parent.
  // This is useful when copying trees.
  int ix_child;

  //----------------------------------------------------------------------------------

  // Used by deleteTree 
  void deleteTree2();

  // Used by toStringTree for indending the text.
  Str toStringTree2(int indent, int depth) const;

  // set method for ix_child
  void setChildIndexNumber (const int ix_c);

  // Work horse method for getPath2
  void getPath2(IntArray& path, int n) const;

  // Used by addXMLNSAttributes
  void add_xmlns_close_to_root(bool at_top_level, StrMap existing_xmlns, StrMap& needed_xmlns);
  void add_xmlns_far_from_root(StrMap existing_xmlns);

};

#endif
