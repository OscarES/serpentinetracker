#include "Fortran/UAPFortran.hpp"

using namespace std;

//-----------------------------------------------------------------

extern "C" void uap_node_tree_to_f_(UAPNode*& c_node, uap_node_f_struct* f_node) {

  // Disconnect c_node from it's parent so as to not confuse path info.

  UAPNode* parent = c_node->getParent();
  c_node->setParent(NULL);

  // Construct basic tree

  uap_node_in_node_to_f_(c_node, f_node);

  // Add in Master/Slave, etc info

  uap_master_info_to_f_(c_node, f_node);

  // Reconnect parent

  c_node->setParent(parent);

}

//-----------------------------------------------------------------

extern "C" void uap_node_in_node_to_f_(UAPNode*& c_node, uap_node_f_struct* f_node) {

  const char* node_name = (c_node->getName()).data();
  const int node_type = (c_node->getType());

  int n_name       = (c_node->getName()).length();
  int n_attrib     = (c_node->getAttributes()).size();
  int n_children   = (c_node->getChildren()).size();
  int n_master     = c_node->getList(MASTER).size();
  int n_slave      = c_node->getList(SLAVE).size();
  int n_controller = c_node->getList(CONTROLLER).size();

  uap_node_to_f2_(f_node, node_name, n_name, node_type, 
                    n_attrib, n_children, n_master, n_slave, n_controller);

  AttributeVecIter it = c_node->getAttributes().begin();
  for (int i = 0; i < n_attrib; i++) {
    string name = it->getName();
    const char* c_name = name.data();
    int n_name = name.size();
    string value = it->getValue();
    const char* c_value = value.data();
    int n_value = value.size();
    uap_attribute_in_node_to_f2_(f_node, i, c_name, n_name, c_value, n_value);
    it++;
  }

  NodeVecCIter in = c_node->getChildren().begin();
  for (int i = 0; i < n_children; i++) {
    UAPNode* c_child = *in;
    uap_node_in_node_to_f2_(f_node, i, c_child);
    in++;
  }

}

//--------------------------------------------------------------------

extern "C" void uap_master_info_to_f_(UAPNode*& c_node, uap_node_f_struct* f_node) {

  IntArray path;
  c_node->getPath(path);
  int n_path = path.size();

  // Transfer master, slave, etc info.

  master_info_single_to_f (c_node->getTwin(), "TWIN", path, f_node);
  master_info_single_to_f (c_node->getConnect(), "CONNECT", path, f_node);
  master_info_array_to_f (c_node->getList(SLAVE), "SLAVE", path, f_node);
  master_info_array_to_f (c_node->getList(MASTER), "MASTER", path, f_node);
  master_info_array_to_f (c_node->getList(CONTROLLER), "CONTROLLER", path, f_node);

  // Recursively call this routine for all the children
  
  NodeVec children = c_node->getChildren();
  for (NodeVecCIter in = children.begin(); in != children.end(); in++) {
    UAPNode* c_child = *in;
    uap_master_info_to_f_(c_child, f_node);
  }

}

//--------------------------------------------------------------------

void master_info_array_to_f (NodeVec c_list, const string& who, 
                                IntArray path, uap_node_f_struct* f_node) {

  int n_path = path.size();
  int path_v[n_path];
  for (int i = 0; i < n_path; i++) path_v[i] = path[i]; 

  int i = 0;
  for (NodeVecCIter in = c_list.begin(); in != c_list.end(); in++) {
    UAPNode* c_node = *in;
    IntArray path2;
    c_node->getPath(path2);
    int n_path2 = path2.size();
    int path2_v[n_path2];
    for (int j = 0; j < n_path2; j++) path2_v[j] = path2[j]; 
    const char* who_name = who.data();

    uap_master_info_array_to_f2_(f_node, path_v[0], n_path, i, path2_v[0], n_path2, who_name, who.size());
    i++;
  }

  return;

}

//--------------------------------------------------------------------

void master_info_single_to_f (UAPNode* c_node, const string& who, 
                                IntArray path, uap_node_f_struct* f_node) {

  if (!c_node) return;

  int n_path = path.size();
  int path_v[n_path]; 
  for (int i = 0; i < n_path; i++) path_v[i] = path[i]; 

  IntArray path2;
  c_node->getPath(path2);
  int n_path2 = path2.size();
  int path2_v[n_path2];
  for (int i = 0; i < n_path2; i++) path2_v[i] = path2[i]; 
  const char* who_name = who.data();

  uap_master_info_single_to_f2_(f_node, path_v[0], n_path, path2_v[0], n_path2, who_name, who.size());

  return;

}

//--------------------------------------------------------------------

extern "C" void uap_node_to_c2_(UAPNode*& c_node, char* node_name, Int& node_type) {
  c_node->setName(string(node_name));
  c_node->setType(static_cast<UAPNode_type>(node_type));
}

//--------------------------------------------------------------------

extern "C" void uap_attribute_in_node_to_c2_(UAPNode*& c_node,  
                                        char* attrib_name, char* attrib_value) {
  c_node->addAttribute(attrib_name, attrib_value);
}

//--------------------------------------------------------------------

extern "C" void uap_node_in_node_to_c2_(UAPNode*& c_node, uap_node_f_struct* f_child) {
  UAPNode* child = c_node->addChild("");
  uap_node_tree_to_c_(f_child, child);
}

