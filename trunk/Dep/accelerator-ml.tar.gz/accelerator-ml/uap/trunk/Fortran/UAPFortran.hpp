/*
 * UAP Node
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 */

#ifndef UAPFortran_hpp
#define UAPFortran_hpp 1

#include "UAP/UAPNode.hpp"

typedef const int         Int;
typedef const char*       Char;
typedef const int*      IntArr;

struct uap_node_f_struct;         // Fortran structure
struct uap_attribute_f_struct;    // Fortran structure

// To convert a UAPNode tree from C++ to Fortran90:
//   1) C++ program calls a Fortran routine and passes it the root node for convertion.
//   2) the Fortran routine calles uap_node_to_f.

// To convert a UAPNode tree from Fortran90 to C++:
//   1) Fortran program calls a C++ routine and passes it the root node for convertion.
//   2) the C++ routine calles uap_node_to_c_.


//---------------------------------------------------------------------------
// C++ to Fortran90 conversion 

// *_to_f_ are C++ routines.
// *_to_f2_ are Fortran90 routines.

extern "C" void uap_node_tree_to_f_(UAPNode*& c_node, uap_node_f_struct* f_node);

extern "C" void uap_node_in_node_to_f_(UAPNode*& c_node, uap_node_f_struct* f_node);

extern "C" void uap_node_to_f2_(uap_node_f_struct* f_node, Char node_name, 
            Int& n_name, Int& node_type, Int& n_attrib, Int& n_children,
            Int& n_master, Int& n_slave, Int& n_controller);

extern "C" void uap_attribute_in_node_to_f2_(uap_node_f_struct* f_node, Int& ix_attrib,
            Char attrib_name, Int& n_name, Char attrib_value, Int& n_value);

extern "C" void uap_node_in_node_to_f2_(uap_node_f_struct* f_node, 
                                                 Int& ix_child, UAPNode*& c_child);

extern "C" void uap_master_info_to_f_(UAPNode*& c_node, uap_node_f_struct* f_node);

extern "C" void uap_master_info_array_to_f2_(uap_node_f_struct* f_node, Int& path, 
      Int& n_path, Int& ix_list, Int& path2, Int& n2_path, const char* who_name, Int& n_who);

extern "C" void uap_master_info_single_to_f2_(uap_node_f_struct* f_node, Int& path, 
                    Int& n_path, Int& path2, Int& n2_path, const char* who_name, Int& n_who);


void master_info_array_to_f (NodeVec c_list, const std::string& who, 
                                IntArray path, uap_node_f_struct* f_node);

void master_info_single_to_f (UAPNode* c_node, const std::string& who, 
                                IntArray path, uap_node_f_struct* f_node);

//---------------------------------------------------------------------------
// Fortran90 to C++ conversion

// *_to_c_ are Fortran90 routines
// *_to_c2_ are C++ routines.

extern "C" void uap_node_tree_to_c_(uap_node_f_struct* f_node, UAPNode*& c_node);

extern "C" void uap_node_to_c2_(UAPNode*& c_node, char* node_name, Int& node_type);

extern "C" void uap_attribute_in_node_to_c2_(UAPNode*& c_node,  
                                              char* attrib_name, char* attrib_value);

extern "C" void uap_node_in_node_to_c2_(UAPNode*& c_node, uap_node_f_struct* f_node);

#endif
