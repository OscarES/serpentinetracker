#!/usr/bin/perl 

@d_files = glob "*/*.d";
open (F_OUT, ">DEPENDENCIES");


foreach $file (@d_files) {  
  open (F_IN, $file) || die ("Cannot Open File $file");
  @lines = ();

  # Do not include xerces dependencies

  while (<F_IN>) {
    if (/xerces-c-src/) {
      s/\S*xerces-c-src\S*//g;
      if (/\s*\\\s*/) {next;}   # If line is just "\" then discard line
    }
    push (@lines, $_);
  }

  # If last line has an "\" then delete it

  $last = pop(@lines);
  $last =~ s/\\//;
  push (@lines, $last);

  close (F_IN);

  # transfer lines to output file

  foreach $line (@lines) {
    print F_OUT "$line";
  }

}

print "Created DEPENDENCIES file\n";
close (F_OUT);
