#include "Fortran/UAPFortran.hpp"
#include <iostream>

using namespace std;

//----------------------------------------------

void uap_node_comp (UAPNode* node1, UAPNode* node2) {

  if (node1->getName() != node2->getName()) {
    cout << "ERROR: NODE NAMES DO NOT MATCH: " << endl;
    cout << "       '" << node1->getName() << "'" << endl;
    cout << "       '" << node2->getName() << "'" << endl;
  }

  AttributeVec a1 = node1->getAttributes();
  AttributeVec a2 = node2->getAttributes();
  if (a1.size() != a2.size()) {
    cout << "ERROR: ATTRIBUTE SIZE DOES NOT MATCH:" << 
            a1.size() << a2.size() << endl;
  }

  AttributeVecCIter it1 = a1.begin();
  AttributeVecCIter it2 = a2.begin();
  for (int i = 0; i < a1.size(); i++) {
    if (it1->getName() != it2->getName()) {
      cout << "ERROR: ATTRIBUTE NAME DOES NOT MATCH: " << i << endl;
      cout << "       " << '"' << it1->getName() << '"';
      cout << "       " << '"' << it2->getName() << '"';
    }
    if (it1->getValue() != it2->getValue()) {
      cout << "ERROR: ATTRIBUTE VALUE DOES NOT MATCH: " << i << endl;
      cout << "       " << '"' << it1->getValue() << '"';
      cout << "       " << '"' << it2->getValue() << '"';
    }
    it1++; it2++;
  }

  //  children

  NodeVec n1 = node1->getChildren();
  NodeVec n2 = node2->getChildren();
  if (n1.size() != n2.size()) {
    cout << "ERROR: CHILD SIZE DOES NOT MATCH:" << 
            n1.size() << n2.size() << endl;
  }

  NodeVecCIter in1 = n1.begin();
  NodeVecCIter in2 = n2.begin();
  for (int i = 0; i < n1.size(); i++) {
    uap_node_comp (*in1, *in2);
  }

}

//-----------------------------------------------

extern "C" void fortran_convert_(uap_node_f_struct* f_root, UAPNode*& c_root) {

  c_root = new UAPNode("root");

  c_root->addAttribute("a1", "v1");
  c_root->addAttribute("a2", "v2");
  c_root->addAttribute("a3", "v3");

  UAPNode* c1 = c_root->addChild("c1");
  c1->addChild("c11");

  UAPNode* c2 = c_root->addChild("c2");
  c2->addAttribute("a21", "v21");

  //

  UAPNode* c_root2 = new UAPNode("", "");
  uap_node_tree_to_c_(f_root, c_root2);

  uap_node_comp (c_root, c_root2);

  return;

}
