#include <iostream>
//#include "OPTIM/OPTIMLexer.hpp"
#include "OPTIM/OPTIMLexer.hpp"
#include <fstream>
#include <cstdlib>

int main () {
  ANTLR_USING_NAMESPACE(std)
  ANTLR_USING_NAMESPACE(antlr)
  
  try{
    OPTIMLexer lexer(cin);
            ANTLR_USE_NAMESPACE(antlr)RefToken tok=lexer.nextToken();
           while(tok)
           {
         if(tok->getType()==1)
                break;
              cout<<"token type: "<<tok->getType()<<endl;
               cout<<"token string: "<<tok->toString()<<endl;
             tok=lexer.nextToken();
            }
            
  }catch( ANTLRException& e ){
    cerr << "ANTLRException: " << e.getMessage() << endl;
    return -1;
  }catch(exception& e){
    cerr << "exception: " << e.what() << endl;
    return -1;
  }  
  return 0;
}
