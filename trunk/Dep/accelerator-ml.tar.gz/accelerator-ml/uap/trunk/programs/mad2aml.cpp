/* 
* This is a test program for AML/MAD translation using the ANTLR parser generator.
* This translation code is incomplete and not currently supported so do not
* use unless you know what you are doing.
*/

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "MAD/MADLexer.hpp"
#include "MAD/MADStreamSelector.hpp"
#include "MAD/MADParser.hpp"
#include "MAD/MADConverter.hpp"
#include "UAP/UAPUtilities.hpp"

//int main (int argc, char * const argv[]) {

int main () {
  ANTLR_USING_NAMESPACE(std)
  ANTLR_USING_NAMESPACE(antlr)
  ANTLR_USING_NAMESPACE(antlr)DEBUG_PARSER = false;
  
  try{
    std::ifstream xsifInputFile("SimpleFODO.xsif");

    MADLexer lexer(xsifInputFile);

    MADStreamSelector selector(lexer);

    MADParser parser(selector);

    parser.parseMAD();

    RefAST t = RefAST(parser.getAST());

    if(t){
      std::cout << t->toStringTree() << std::endl;
    }else
      std::cerr << "Errors encountered during parse..." << std::endl;

    MADConverter mad_converter;

    UAPNode* UAPModel = mad_converter.convert(t);

    UAPUtilities uap_utilities(UAPModel);
    // ?? uap_utilities.evaluateParameters();

    ofstream parsedFile("parsed.xml");
    UAPTranslator uap_translator(UAPModel, new AMLTranslator(parsedFile));
    uap_translator.TranslateUAP(UAPModel);

  }catch( ANTLRException& e ){
    std::cerr << "ANTLRException: " << e.getMessage() << std::endl;
    return -1;
  }catch(exception& e){
    std::cerr << "exception: " << e.what() << std::endl;
    return -1;
  }
  return 0;
}
