/*
* Test program to read in an AML file.
*/

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "UAP/UAPUtilities.hpp"
#include "AML/AMLReader.hpp"
#include "AML/AMLLatticeExpander.hpp"

using namespace std;

int main (int argc, char* argv[]) {

  UAPNode* UAPModel = NULL;

  string fileName("test_files/test.aml");

  if (argc > 2) {
    cout << "Usage: aml_driver <AMLFileName>" << endl;
    cout << "Default: <AMLFileName> = test_files/test.aml" << endl;
    return 1;
  }

  if (argc == 2) fileName = argv[1];

  // Read in the AML file and create an AML representation tree.

  AMLReader reader;
  try {
    UAPModel = reader.AMLFileToAMLRep (fileName);
  } catch (UAPFileCouldNotBeOpened err) {
    cerr << err << endl;
    return 1;
  }

  // Now back translate and create an AML file.
  // This should just look like the input file.

  reader.AMLRepToAMLFile (UAPModel, "out.aml");
  cout << "Created: out.aml" << endl;

  // Print the AML representation tree.

  cout << UAPModel->toStringTree() << endl;

  // Print the contents of the out.aml file.

  cout << "-------------------------------------------------------------" << endl;

  ifstream aml_file("out.aml");
  while (!aml_file.fail()) {
    string line;
    getline(aml_file, line); 
    cout << line << endl;
  }

  return 0;

  // This stuff is not being used at this point.

  try {
    AMLLatticeExpander LE;
    LE.AMLExpandLattice(UAPModel);
  } catch (UAPException err) {
    cerr << err << endl;
    return 1;
  }


  cout << "Tree: " << endl;
  cout << UAPModel->toStringTree() << endl;

  return 0;
}
