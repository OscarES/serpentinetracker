#include <iostream>
#include <fstream>
#include <cstdlib>

#include "UAP/UAPUtilities.hpp"
#include "AML/AMLReader.hpp"
#include "AML/AMLLatticeExpander.hpp"

using namespace std;

int main (int argc, char* argv[]) {

  UAPNode* UAPModel = NULL;

  string fileName("test_files/expand.aml");

  if (argc > 2) {
    cout << "Usage: expansion_driver <AMLFileName>" << endl;
    cout << "       Default: <AMLFileName> = test_files/expand.aml" << endl;
    return 1;
  }

  if (argc == 2) fileName = argv[1];

  // Read AML lattice file and create an AML representation subtree.

  AMLReader reader;
  UAPModel = reader.AMLFileToAMLRep (fileName);
  if (!UAPModel) {
    cout << "Stopping here." << endl;
    return 1;
  }

  // Expand the AML representation subtree.

  try {
    AMLLatticeExpander LE;
    LE.AMLExpandLattice(UAPModel);
  } catch (UAPException err) {
    cerr << err << endl;
    return 1;
  }

  // print the entire tree structure.

  cout << "Tree: " << endl;
  cout << UAPModel->toStringTree() << endl;

  // Check the tree for problems

  UAPModel->checkTree();

  return 0;
}
