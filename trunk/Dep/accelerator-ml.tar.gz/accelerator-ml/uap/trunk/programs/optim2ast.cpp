#include <iostream>
#include "OPTIM/OPTIMLexer.hpp"
#include "OPTIM/OPTIMTwissLexer.hpp"
#include "OPTIM/OPTIMParser.hpp"
#include "OPTIMConverter.hpp"
#include "OPTIM/OPTIMStreamSelector.hpp"
#include "UAP/UAPNode.hpp"
#include <fstream>
#include <cstdlib>

int main () {
  ANTLR_USING_NAMESPACE(std)
  ANTLR_USING_NAMESPACE(antlr)
  
  try{
      // create both lexers
      OPTIMLexer lexer(cin);
      OPTIMTwissLexer twisslexer(lexer.getInputState());
      // create the selector
            OPTIMStreamSelector selector;
      // and add both lexers as input streams.
      selector.addInputStream((ANTLR_USE_NAMESPACE(antlr)TokenStream*)&lexer,"main");
            selector.addInputStream((ANTLR_USE_NAMESPACE(antlr)TokenStream*)&twisslexer,"twiss");
      // start off with the main lexer.
      selector.select("main");
      lexer.setSelector(&selector);
      twisslexer.setSelector(&selector);
      // and pass that to the parser.
            OPTIMParser parser(selector);
            
    parser.parseOPTIM();

    RefAST t = RefAST(parser.getAST());
    if( t ){
      // Print the resulting AST tree out in LISP notation
      cout << "AST Tree:" << endl << endl << t->toStringTree() << endl << endl;

    }else
      cerr << "Errors encountered during parse..." << endl;
            
  }catch( ANTLRException& e ){
    cerr << "ANTLRException: " << e.getMessage() << endl;
    return -1;
  }catch(exception& e){
    cerr << "exception: " << e.what() << endl;
    return -1;
  }  
  return 0;
}
