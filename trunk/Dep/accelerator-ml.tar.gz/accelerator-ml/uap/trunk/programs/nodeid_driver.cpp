#include "AML/AMLReader.hpp"
#include "AML/AMLLatticeExpander.hpp"

using namespace std;

int main (int argc, char* args[]) {

  AMLUtilities AU;

  AMLReader reader;
  //UAPNode* root = reader.AMLFileToAMLRep("test_files/expand2.aml");

  //

  string str = args[1];
  NodeIDList id;
  cout << "Valid: " << AU.stringToNodeIDList (str, id) << endl;

  for (NodeIDListIter ix = id.begin(); ix != id.end(); ix++) {
    cout << "---------------" << endl;
    cout << "Name: " << ix->name << endl;
    for (AttribIDListIter ia = ix->attribs.begin(); ia != ix->attribs.end(); ia++) {
      cout << "    " << ia->name << " : " << ia->value << endl;
    }
  }

  AU.nodeIDListToString (id, str);
  cout << "++++++++++++++++++++" << endl;
  cout << str << endl;


  return 0;

}
