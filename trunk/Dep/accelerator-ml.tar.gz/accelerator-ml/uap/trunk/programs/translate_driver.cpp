//+
// Test program to read in a mad8, madx, sad, xsif, bmad, or aml lattice file, 
// then write a file in some other format via a translation through AML.
//-

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "UAP/UAPUtilities.hpp"

#include "Translate/MAD8Parser.hpp"
#include "Translate/MADXParser.hpp"
#include "Translate/BmadParser.hpp"
#include "Translate/XSIFParser.hpp"
#include "Translate/SADParser.hpp"
#include "Translate/AMLParser.hpp"
#include "AML/AMLLatticeExpander.hpp"

using namespace std;

//-------------------------------------------

void usage_message(string file_name) {
  cout << endl;
  cout << "Usage: translate_driver {flags} {<OutputFlag>} {<InputXFileName>}" << endl << endl;
  cout << "  Program to covert a MAD8, MADX, SAD, XSIF, Bmad, or AML lattice to " << endl;
  cout << "  another format via a translation through AML." << endl;
  cout << "  -eval" << endl; 
  cout << "       If present then run the expression evaluator on the intermediate AML tree." << endl << endl;
  cout << "  -print" << endl; 
  cout << "       If present then print the translation trees to the terminal." << endl << endl;
  cout << "  <OutputFlag>:" << endl;
  cout << "       Default: Same format as <InputXFileName>" << endl;
  cout << "       \"-aml\" --> Bmad format output file" << endl;
  cout << "       \"-bmad\" --> Bmad format output file" << endl;
  cout << "       \"-madx\" --> MAD-X format output file" << endl;
  cout << "       \"-mad8\" --> MAD-8 format output file" << endl;
  cout << "       \"-sad\"  --> SAD format output file" << endl;
  cout << "       \"-xsif\" --> XSIF format output file" << endl << endl;
  cout << "  <InputXFileName>:" << endl;
  cout << "       Default: \"" + file_name + "\"" << endl;
  cout << "       File format assumptions:" << endl;
  cout << "         \"xxx.aml\"  --> AML format input file" << endl;
  cout << "         \"xxx.bmad\" --> Bmad format input file" << endl;
  cout << "         \"xxx.madx\" --> MAD-X format input file" << endl;
  cout << "         \"xxx.mad8\" --> MAD-8 format input file" << endl;
  cout << "         \"xxx.sad\"  --> SAD format input file" << endl;
  cout << "         \"xxx.xsif\" --> XSIF format input file" << endl;
  cout << endl;
}

//------------------------------------------

int main (int argc, char* argv[]) {

  UAPNode* uap_root = NULL;

  string read_type = "";
  bool eval = false, print = false;
  string output_flag(""), out_suffix;
  string file_name_dflt("test_files/test.madx");
  string file_name(file_name_dflt);

  for (int ii = 1; ii < argc; ii++) {
    string arg = argv[ii];

    if (arg == "-help" || arg == "help") {
      usage_message(file_name_dflt);
      return 1;
    }

    if (arg == "-eval") 
      eval = true; 
    else if (arg == "-print")
      print = true;
    else if (arg == "-aml" || arg == "-bmad" || arg == "-madx" || 
             arg == "-mad8" || arg == "-xsif" || arg == "-sad") 
      output_flag = arg;
    else if (arg[0] == '-') {
      cout << "UNKNOWN SWITCH: " << arg << endl;
      usage_message(file_name_dflt);
      return 1;
    } else
      file_name = arg;

  }

  // Read in file and make an X representation and an AML representation tree.

  TranslateCore* reader;
  if (file_name.find(".madx") != string::npos) {
    reader = new MADXParser();
    read_type = "-madx";
    if (output_flag == "") output_flag = "-madx";

  } else if (file_name.find(".bmad") != string::npos) {
    reader = new BmadParser();
    read_type = "-bmad";
    if (output_flag == "") output_flag = "-bmad";

  } else if (file_name.find(".mad8") != string::npos) {
    reader = new MAD8Parser();
    read_type = "-mad8";
    if (output_flag == "") output_flag = "-mad8";

  } else if (file_name.find(".sad") != string::npos) {
    reader = new SADParser();
    read_type = "-sad";
    if (output_flag == "") output_flag = "-sad";

  } else if (file_name.find(".xsif") != string::npos) {
    reader = new XSIFParser();
    read_type = "-xsif";
    if (output_flag == "") output_flag = "-xsif";

  } else if (file_name.find(".aml") != string::npos) {
    reader = new AMLParser;
    read_type = "-aml";
    if (output_flag == "") output_flag = "-aml";

  } else {
    cout << "Error: Unknown file extension for input file: " << file_name << endl;
    usage_message(file_name_dflt);
    return 1;
  }

  TranslateCore* writer;
  if (output_flag == "-madx") {
    writer = new MADXParser();
    out_suffix = ".out.madx";

  } else if (output_flag == "-bmad") {
    writer = new BmadParser();
    out_suffix = ".out.bmad";

  } else if (output_flag == "-mad8") {
    writer = new MAD8Parser();
    out_suffix = ".out.mad8";

  } else if (output_flag == "-sad") {
    writer = new SADParser();
    out_suffix = ".out.sad";

  } else if (output_flag == "-xsif") {
    writer = new XSIFParser();
    out_suffix = ".out.xsif";

  } else if (output_flag == "-aml") {
    writer = new AMLParser;
    out_suffix = ".out.aml";

  } else {
    cout << "Error: Unknown output flag: " << output_flag << endl;
    usage_message (file_name_dflt);
    return 1;
  }

  // -------------------------------------------------------------------------------------
  // Read the input

  uap_root = reader->XFileToAMLRep (file_name);

  // Output if input file type is the same as the output file type.
  // We do this since the input sub-tree will get overwiten.

  if (print && read_type == output_flag) {
    cout << "!------------------------------------------------------------------" << endl;
    cout << uap_root->toStringTree() << endl;
  }

  // -------------------------------------------------------------------------------------
  // Evaluation if wanted.

  if (eval) {

    UAPNode* aml_rep = uap_root->getChildByName("AML_representation");
    UAPUtilities utilities(aml_rep);
    // AMLLatticeExpander::InheritBookkeeper(aml_rep);

    try{
        utilities.evaluate();
    } catch (UAPException& e) {
        e.printStackTrace();
    }

  }

  // -------------------------------------------------------------------------------------
  // Translate to the output and create a lattice file.
  // This should essentially look like the input file if the input and output formats are the same.

  UAPNode* x_root = writer->AMLRepToXFile (uap_root, "*", out_suffix);
  cout << endl << "Output file: " <<  x_root->getAttributeString("filename") << endl;

  // Print the tree which consists of the input, AML, and output sub-trees.
  // Exception: If input type == output type then there are just AML and output sub-trees.

  if (print) { 
    cout << "!------------------------------------------------------------------" << endl;
    cout << uap_root->toStringTree() << endl;
  }
  
  return 0;
}
