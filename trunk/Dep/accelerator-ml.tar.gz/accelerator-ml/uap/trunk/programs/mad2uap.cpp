/* 
* This is a test program for AML/MAD translation using the ANTLR parser generator.
* This translation code is incomplete and not currently supported so do not
* use unless you know what you are doing.
*/

#include <iostream>
#include "MAD/MADLexer.hpp"
#include "MAD/MADParser.hpp"
#include "MAD/MADConverter.hpp"
#include "MAD/MADStreamSelector.hpp"
#include "UAP/UAPNode.hpp"
#include <fstream>
#include <cstdlib>

int main () {
  ANTLR_USING_NAMESPACE(std)
  ANTLR_USING_NAMESPACE(antlr)
  ANTLR_USING_NAMESPACE(antlr)DEBUG_PARSER = false;
  
  try{
    std::ifstream xsifInputFile("SimpleTest.xsif");

    MADLexer lexer(xsifInputFile);
    MADStreamSelector selector(lexer);
    MADParser parser(selector);
    
    /* Uncomment the following lines if you're compiling with Antlr 2.7.5
    ASTFactory ast_factory;
    parser.initializeASTFactory(ast_factory);
    parser.setASTFactory(&ast_factory);
    */
    
    parser.parseMAD();
    RefAST t = RefAST(parser.getAST());
    if( t ){
      // Print the resulting AST tree out in LISP notation
      cout << "AST Tree:" << endl << endl << t->toStringTree() << endl << endl;

      // Convert AST to structure S1 and reprint
      MADConverter converter;
      UAPNode* s1_ptr= converter.convert(t);
      cout << "S1 tree:" << endl << endl << s1_ptr->toStringTree() << endl << endl;

    }else
      cerr << "Errors encountered during parse..." << endl;
    
  }catch( ANTLRException& e ){
    cerr << "ANTLRException: " << e.getMessage() << endl;
    return -1;
  }catch(exception& e){
    cerr << "exception: " << e.what() << endl;
    return -1;
  }  
  return 0;
}
