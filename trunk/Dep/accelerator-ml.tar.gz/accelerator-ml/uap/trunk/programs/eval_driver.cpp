#include <iostream>
#include "UAP/UAPNode.hpp"
#include "UAP/UAPException.hpp"
#include "UAP/UAPUtilities.hpp"
#include "AML/AMLReader.hpp"

using namespace std;

int main (int argc, char* argv[]) {
    
    string file_name("test_files/eval.aml");
    
    if (argc > 2) {
        cout << "Usage: mad8_driver <lattice>" << endl;
        cout << "       Default: <lattice> = \"" + file_name + "\"" << endl;
        return 1;
    }
    
    if (argc == 2) file_name = argv[1];
    
    AMLReader reader;
    UAPNode* root = reader.AMLFileToAMLRep(file_name);
  UAPUtilities utilities(root);
    
  cout << "----Tree----" << endl;
  cout << root->toStringTree() << endl;
  
  // Evaluate the value of the first node in <laboratory>
    
    /*
     try{
         cout << "----Evaluated Attribute----" << endl;
         UAPNode* eval_node = lab_node->getChildren().back();
         cout << "Eval Node: " << eval_node->toString() << endl;
         UAPAttribute* value_attrib = eval_node->getAttribute("value");
         cout << value_attrib->getValue() << " = " << utilities.evaluate(value_attrib->getValue()) << endl;
     }catch(UAPException& e) {
         cerr << e << endl;
     }
     */  
    
    
  cout << "----Evaluated Tree----" << endl;
  // The following operation does not preserve arithmetic expressions.
  utilities.evaluate();
  cout << root->toStringTree() << endl;
};
