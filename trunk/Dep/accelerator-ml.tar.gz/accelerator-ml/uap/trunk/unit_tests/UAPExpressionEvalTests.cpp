#include "antlr/ANTLRException.hpp"
#include <cppunit/extensions/HelperMacros.h>
#include <iostream>
#include "UAP/UAPException.hpp"
#include "UAP/UAPNode.hpp"
#include "UAP/UAPUtilities.hpp"

class UAPExpressionEvalTests : public CPPUNIT_NS::TestFixture
{
    
    CPPUNIT_TEST_SUITE( UAPExpressionEvalTests );
    CPPUNIT_TEST( TestBasicArithmetic );
    CPPUNIT_TEST( TestMalformedExpressions );
    CPPUNIT_TEST( TestAMLPaths );
    CPPUNIT_TEST( TestContants );
    CPPUNIT_TEST_SUITE_END();
    
private:
        
    UAPUtilities* utilities;
    
    double evaluate(const std::string& xpr, UAPNode* context = NULL) throw(UAPParserException)
    {
        UAPAttribute dummy("dummy", xpr);
        return utilities->evaluate(dummy, context);
    }
       
public:
        
    void setUp()
    {
        utilities = new UAPUtilities(NULL);
    }
    
    void tearDown()
    {
        delete utilities;
    }
    
    void TestBasicArithmetic()
    {
        CPPUNIT_ASSERT_THROW(evaluate("0/0"), UAPParserException);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(3, evaluate("3"), 0);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(3, evaluate("+3"), 0);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(0, evaluate("1+(-1)"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(4, evaluate("2+2"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(-1, evaluate("3-4"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(6, evaluate("3*2"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(30, evaluate("5*(2+4)"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(105, evaluate("5*(2*(3+2*(9-3*(2)))+3)"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(1.25, evaluate("5/4"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(1.414213562373, evaluate("sqrt(2)"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(3, evaluate("max(2,3)"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(2, evaluate("min(2,3)"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(1e4+2, evaluate("1e4+2"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(3.14159265358979323844, evaluate("pi"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(1, evaluate("-(-1)"), 0);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(0.5235987755983, evaluate("atan2(sqrt(3), 3)"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(-0.5235987755983, evaluate("-atan2(sqrt(3), 3)"), 0.001);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(0.05, evaluate("0.5/5/2"), 0.001);
    }
    
    void TestMalformedExpressions()
    {
        CPPUNIT_ASSERT_THROW(evaluate("0/"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("1+"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("+"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("1+"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("1+dummy"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("9d"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("(1+1"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("(1+1))"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("Q01[quadrupole(n=1 b=2)]"), UAPParserException);
    }
    
    void TestAMLPaths()
    {
        UAPNode* root = new UAPNode(ELEMENT_NODE, "ROOT");
        UAPNode* elem_1 = root->addChild("element", ELEMENT_NODE);
        elem_1->addAttribute("name", "Q01");
        UAPNode* quad = elem_1->addChild("quadrupole", ELEMENT_NODE);
        UAPNode* quad_k = quad->addChild("k", ELEMENT_NODE);
        quad_k->addAttribute("n", "1");
        quad_k->addAttribute("design", "2.5");
        quad_k->addAttribute("err", "0.05");
        UAPNode* quad_k_2 = quad->addChild("k", ELEMENT_NODE);
        quad_k_2->addAttribute("n", "2");
        quad_k_2->addAttribute("design", "6");
        quad_k_2->addAttribute("err", "0.05");
        UAPNode* elem_1_length = elem_1->addChild("length", ELEMENT_NODE);
        elem_1_length->addAttribute("design", "5.3");
        UAPNode* const_1 = root->addChild("constant", ELEMENT_NODE);
        const_1->addAttribute("name", "c1");
        const_1->addAttribute("design", "53");
        UAPNode* controller_1 = root->addChild("controller", ELEMENT_NODE);
        controller_1->addAttribute("name", "v01w");
        controller_1->addAttribute("attribute", "kicker:y_kick");
        controller_1->addAttribute("design", "7");
        UAPNode* const_3 = root->addChild("constant", ELEMENT_NODE);
        const_3->addAttribute("name", "c3");
        const_3->addAttribute("design", "-63.5");
        UAPNode* const_4 = root->addChild("constant", ELEMENT_NODE);
        const_4->addAttribute("name", "c4");
        const_4->addAttribute("design", "48");
        const_4->addAttribute("err", "5");
        
        // Structures that are circular definitions.
        UAPNode* elem_2 = root->addChild("element", ELEMENT_NODE);
        elem_2->addAttribute("name", "Q02");
        UAPNode* quad_2 = elem_2->addChild("quadrupole", ELEMENT_NODE);
        UAPNode* quad_2_k = quad_2->addChild("k", ELEMENT_NODE);
        quad_2_k->addAttribute("n", "1");
        quad_2_k->addAttribute("design", "Q02[length]");
        UAPNode* elem_2_length = elem_2->addChild("length", ELEMENT_NODE);
        elem_2_length->addAttribute("design", "5.3 * Q02[quadrupole:k(n=1)]");
        UAPNode* const_2 = root->addChild("constant", ELEMENT_NODE);
        const_2->addAttribute("name", "c2");
        const_2->addAttribute("design", "c2");

        UAPNode* const_lqm6r = root->addChild("constant", ELEMENT_NODE);
        const_lqm6r->addAttribute("name", "lqm6r");
        const_lqm6r->addAttribute("design", "5");
    
        UAPNode* const_lqm6r_len = root->addChild("constant", ELEMENT_NODE);
        const_lqm6r_len->addAttribute("name", "lqm6r_len");
        const_lqm6r_len->addAttribute("design", "lqm6r/2");
    
        UAPNode* const_g = root->addChild("constant", ELEMENT_NODE);
        const_g->addAttribute("name", "g");
        const_g->addAttribute("design", "0.5 / lqm6r_len");
    
    
        utilities->setUAPRootNode(root);
        
        CPPUNIT_ASSERT_DOUBLES_EQUAL(2.5, evaluate("Q01[quadrupole:k(n=1)@design]"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(2.5, evaluate("Q01[quadrupole:k(n=1)]"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(0.05, evaluate("Q01[quadrupole:k(n=1)@err]"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(6, evaluate("Q01[quadrupole:k(err=0.05,n=2)]"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(5.3, evaluate("element:length"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(0.05, evaluate("element:quadrupole:k(n=2)@err"), 0.001);
        CPPUNIT_ASSERT_THROW(evaluate("dummy:quadrupole:length"), UAPParserException);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(6, evaluate("[quadrupole:k(err=0.05,n=2)]", elem_1), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(2*5.3, evaluate("2*[length]", elem_1), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(0, evaluate("[dummy]", elem_1), 0);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(53, evaluate("c1"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(7, evaluate("v01w[@design]"), 0.001);
        CPPUNIT_ASSERT_THROW(evaluate("DUMMY[length]"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("c2"), UAPParserException);
        CPPUNIT_ASSERT_THROW(evaluate("Q02[quadrupole:k(n=1)]"), UAPParserException);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(63.5, evaluate("-(c3)", const_3), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(63.5, evaluate("-c3", const_3), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(64.5, evaluate("1-c3", const_3), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(-64.5, evaluate("-1+c3", const_3), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(62.5, evaluate("-1-c3", const_3), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(48, evaluate("c4"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(48, evaluate("c4[@design]"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(5, evaluate("c4[@err]"), 0.001);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(0.2, evaluate("g"), 0.001);
        // FIXME: This case fails, it throws an exception instead of returning 0.
        CPPUNIT_ASSERT_DOUBLES_EQUAL(0, evaluate("Q01[quadrupole:k(n=1)@dummy]"), 0);
        
        utilities->setUAPRootNode(NULL);
        root->deleteNode();
    }
    
    void TestContants()
    {
        // Add custom constant
        utilities->addConstant("userC1", 2.15);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(2.15, evaluate("userC1"), 0.001);
        // Try to overwrite the constant
        utilities->addConstant("userC1", 5.9);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(2.15, evaluate("userC1"), 0.001);
        // Properly overwrite the constant then remove the constant
        utilities->addConstant("userC1", 5.2, true);
        CPPUNIT_ASSERT_DOUBLES_EQUAL(5.2, evaluate("userC1"), 0.001);
        utilities->removeConstant("userC1");
        CPPUNIT_ASSERT_THROW(evaluate("userC1"), UAPParserException);
    }
    
};

CPPUNIT_TEST_SUITE_REGISTRATION( UAPExpressionEvalTests );
