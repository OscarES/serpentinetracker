#include "Translate/BmadParser.hpp"

using namespace std;
using namespace BasicUtilities;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

BmadParser::BmadParser() : TranslateCore() {
  language = "Bmad"; 
  include_file_string = "call:filename";
  knl_tn_style_multipoles = true;
  c_style_format = false;
  continuation_char =  "&";
  abbreviations_permitted = true;
  init_lists_bmad();
  init_lists_core();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

UAPNode* BmadParser::XRepToAMLRep (UAPNode* x_root, UAPNode* aml_root) {

  // Init

  lcavity_found = false;
  lattice_type_set = false;

  // All the work is done here

  UAPNode* aml_rep = TranslateCore::XRepToAMLRep (x_root, aml_root);

  // If the lattice type has not been set then set the lattice type.
  // The Bmad default is CIRCULAR unless there is an lcavity element.

  if (!lattice_type_set) {
    // Find the lattice node if it exists.
    // If not then create it.
    NodeVec lat_list = aml_rep->getSubNodesByName("lattice");
    UAPNode* lat_node;
    if (lat_list.size() == 0) {
      lat_node = aml_rep->getChildByName("laboratory")->addChild("lattice");
      lat_node->addAttribute("name", "lattice");
    } else {
      lat_node = lat_list.front();
    }
    // Now add the lattice type
    string type = "CIRCULAR";
    if (lcavity_found) type = "LINEAR";
    lat_node->addChild("geometry")->addAttribute("type", type);
  }

  // And return the aml_representation node.

  return aml_rep;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_x_statement_to_x (StrList word_list, string comment,
                                                              UAPNode* x_rep_root) {

  // Called by TranslateCore::x_statement_to_x.
  // No custom statements have less than two words.

  if (word_list.size() < 3) return false; // Unrecognized
  string word1 = next_word(word_list);  
  string word2 = next_word(word_list);  
  string word3 = next_word(word_list);  

  // use statement

  if (word1 == "use") {
    if (!word_list.size() == 0 || word2 != ",") {
      info_out.error ("Malformed USE Statement");
      return true;
    }
    UAPNode* node = x_rep_root->addChild(word1);
    node->addAttribute("line", word3);
    return true;
  } 

  // If word2 is "[" then this is an attribute set or 
  // parameter, beginning, or beam_start statement.

  if (word2 == "[") {
    string value = next_word(word_list);
    if (value != "]") {
      info_out.error ("Missing or misplaced \"]\"");
      return true;  // Recognized;
    }
    value = next_word(word_list);
    if (value == ":") value = next_word(word_list);
    if (value != "=") {
      info_out.error ("Missing or misplaced \"=\"");
      return true;  // Recognized;
    }
    value = next_word(word_list);
    while (word_list.size() != 0) value += next_word(word_list);
    if (x_attribute_case(word3) == TO_UPPER) value = str_to_upper(value);

    if (word1 == "parameter" || word1 == "beginning" || word1 == "beam_start") {
      UAPNode* node = x_rep_root->addChild(word1);
      node->addAttribute(word3, value);
    } else {
      UAPNode* node = x_rep_root->addChild("set");
      node->addAttribute("element", word1);
      node->addAttribute("attribute", word3);
      node->addAttribute("value", value);
    }
    return true;  // Recognized;
  }

  // overlay or group element?

  if (word3 == "overlay" || word3 == "group") {

    UAPNode* element_node = x_rep_root->addChild(word3);
    element_node->addAttribute("name", word1);
    name_to_x_class_map[word1] = word3;

    if (comment != "") element_node->addAttribute("comment", comment);

    if (word_list.size() < 6) {
      info_out.error ("Malformed overlay or group statement");
      return true;  // Recognized;
    }

    if (next_word(word_list) != "=" || next_word(word_list) != "{") {
      info_out.error ("Missing or misplaced \"= {\" in overllay or group statement");
      return true;  // Recognized;
    }

    while (true) {
      if (word_list.size() < 4) {
        info_out.error ("Malformed overlay or group statement");
        return true;  // Recognized;
      }
      string w1 = next_word(word_list);
      string w2 = next_word(word_list);

      string attrib = "";
      if (w2 == "[") {
        attrib = next_word(word_list);
        w2 = next_word(word_list);
        if (w2 != "]") {
          info_out.error ("Expecting ending \"]\" in overlay or group statement but got: " + w2);
          return true;  // Recognized;
        }
        w2 = next_word(word_list);
      }

      string factor = "";
      if (w2 == "/") {
        factor = next_word(word_list);
        while (true) {     // concat arathmetical expression
          w2 = next_word(word_list);
          if (w2 == "," || w2 == "}" || word_list.size() < 2) break; 
          factor += w2;
        }
      }
      
      UAPNode* slave = element_node->addChild("slave");
      slave->addAttribute("element", w1);
      if (attrib != "") slave->addAttribute("attribute", attrib);
      if (factor != "") slave->addAttribute("coef", factor);
  
      if (w2 == "}") break;
      if (w2 != ",") {
        info_out.error ("Expecting \",\" or \"}\" in slave list but got: " + w2);
        return true;  // Recognized;
      }
    }

    string attrib = next_word(word_list);
    if (attrib != ",") {
      info_out.error ("Expecting \",\" after \"}\" in overlay or group");
      return true;  // Recognized;
    }

    attrib = next_word(word_list);
    element_node->addAttribute("attribute", attrib);
    if (word_list.size() == 0) return true;  // Recognized;

    if (word_list.size() == 1) {
      info_out.error ("Extra characters in overlay or group: " + next_word(word_list));
      return true;  // Recognized;
    }    

    string sep = next_word(word_list);
    if (sep == "=") {
      word_list.push_front("=");
      word_list.push_front("value");
      word_list.push_front(",");
      x_add_attributes (word_list, word3, element_node);
      return true;  // Recognized;
    } else if (sep == ",") {
      word_list.push_front(","); 
      x_add_attributes (word_list, word3, element_node);
      return true;  // Recognized;
    } else {
      info_out.error ("Expecting \"=\" or \",\" after attribute of overlay or group");
      return true;  // Recognized;
    }

  }

  // Otherwise unrecognized

  return false; // Unrecognized

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_x_add_attributes (StrList& word_list, string ele_class, 
                                    string& attrib_name, UAPNode* x_ele_root) {

  // Check for taylor term

  if (ele_class == "taylor" && attrib_name == "{") {
    if (word_list.size() < 11) {
      info_out.error ("Malformed taylor element term");
      return true;  // Recognized;
    }
    string i_out = next_word(word_list);
    string delim = next_word(word_list);
    if (delim != ":") {
      info_out.error ("Expected \":\" in a taylor term but got: " + delim);
      return true;  // Recognized;
    }
    string coef = next_word(word_list);
    delim = next_word(word_list);
    if (delim != ",") {
      info_out.error ("Expected \",\" in a taylor term but got: " + delim);
      return true;  // Recognized;
    }
    string exp;
    for (int i = 0; i < 6; i++) {
      exp += next_word(word_list);
      if (i != 5) exp += " ";
    }
    delim = next_word(word_list);
    if (delim != "}") {
      info_out.error ("Expected \"}\" in a taylor term but got: " + delim);
      return true;  // Recognized;
    }
    UAPNode* term = x_ele_root->addChild("term");
    term->addAttribute("i_out", i_out);
    term->addAttribute("coef", coef);
    term->addAttribute("exp", exp);
    return true;  // Recognized;
  }

  // Check for wiggler term

  if (attrib_name == "term" && ele_class == "wiggler") {
    if (word_list.size() < 15) {
      info_out.error ("Malformed wiggler term.");
      return true;  // Recognized;
    }
    if (next_word(word_list) != "(" || !is_int(next_word(word_list)) ||
                  next_word(word_list) != ")" || next_word(word_list) != "=" || 
                  next_word(word_list) != "{") {
      info_out.error ("Bad \"term(int)={\" in wiggler term.");
      return true;  // Recognized;
    }
    UAPNode* term = x_ele_root->addChild("term");
    for (int i = 0; i < 5; i++) {
      string val = next_word(word_list);
      string d;
      while (word_list.size() > 0) {
        d = next_word(word_list);
        if (d == "," || d == "}") break;
        val += d;
      }
      string who;
      switch (i) {
        case 0: who = "coef"; break;
        case 1: who = "k_x"; break;
        case 2: who = "k_y"; break;
        case 3: who = "k_z"; break;
        case 4: who = "phi_z"; break;
      }
      term->addAttribute(who, val);
      if (i == 4 && d != "}") {
        info_out.error ("Missing or misplaced \"}\" in wiggler term.");
        return true;  // Recognized;
      }
      if (i < 4 && d != ",") {
        info_out.error ("Missing or misplaced \",\" in wiggler term.");
        return true;  // Recognized;
      }
    }
    return true;  // Recognized;
  }

  return false; // Unrecognized

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_x_node_to_aml (UAPNode* x_node, UAPNode* aml_root, UAPNode* aml_node) {

  string x_class = x_node_to_x_class (x_node);

  // Record if this is an lcavity element or

  if (x_class == "lcavity") lcavity_found = true;
  if (x_class == "parameter" && x_node->getAttribute("lattice_type")) lattice_type_set = true;

  // Groups and overlays...
  // Problem: An "hkick" in Bmad can translate to "electric_kicker:x_kick" or "kicker:x_kick".
  //          And there are more examples of this...
  //          So what to use as the default controller attribute?
  // Solution: Use the attribute that is the most frequently used in the slaves.

  UAPNode* aml_class_node;

  if (x_class == "group" || x_class == "overlay") {

    // Add controller to AML

    UAPNode* aml_control_node = aml_node->addChild("controller");
    aml_class_node = aml_control_node;
    string ele_name = x_node->getAttributeString("name");
    aml_control_node->addAttribute ("name", ele_name);
    string aml_class = "controller";
    name_to_aml_node_map[ele_name] = aml_control_node;

    if (x_class == "group") aml_control_node->addAttribute("variation", "DELTA");

    // Transfer value from X to AML

    string design_str = x_node->getAttributeString("value");
    if (design_str != "") aml_control_node->addAttribute("design", design_str);

    // Loop over all children

    string dflt_attrib = x_node->getAttributeString("attribute");
    IntMap counter;

    NodeVec child_list = x_node->getChildren();
    for (NodeVecCIter in = child_list.begin(); in != child_list.end(); in++) {

      UAPNode* x_slave = *in;
      UAPNode* aml_slave = aml_control_node->addChild("slave");
      string element = x_slave->getAttributeString("element");
      string x_attrib = x_slave->getAttributeString("attribute");
      if (x_attrib == "") x_attrib = dflt_attrib;

      string slave_x_class = ele_name_to_x_class(element);
      if (slave_x_class == "") {
        info_out.error ("Cannot find element: " + element, 
                     "Which is a slave of an overlay or group.");
      }
      string aml_attrib;
      if (slave_x_class == "overlay" || slave_x_class == "group") {
        aml_attrib = "";
      } else {
        attribute_convert_struct attrib_info;
        if (!found_x_attrib (slave_x_class, x_attrib, attrib_info)) {
          info_out.error ("Unknown attribute: " + x_attrib, 
                       "In: " + x_node->toString());
          return false;
        }
        aml_attrib = attrib_info.aml_twig.toNodeString();
      }
      aml_slave->addAttribute ("target", element);
      aml_slave->addAttribute ("attribute", aml_attrib);    // This is temporary

      if (counter.find(aml_attrib) == counter.end()) {
        counter[aml_attrib] = 1;
      } else {
        counter[aml_attrib]++;
      }

      string coef = x_slave->getAttributeString("coef");
      if (coef != "") aml_slave->addAttribute("expression", coef + " * " + ele_name + "[@actual]");

    }

    name_to_x_class_map[ele_name] = x_class;
    x_element_attributes_to_aml (x_node, aml_root, aml_control_node);

    // Now find what attribute is most used and use it as the default.

    IntMapIter it;
    IntMapIter heighest = counter.begin();

    for (it = counter.begin(); it != counter.end(); it++) {
      if ((*it).second > (*heighest).second) heighest = it;
    }

    dflt_attrib = (*heighest).first;
    aml_control_node->addAttribute("default_attribute", dflt_attrib);

    // Return to the slaves and delete attributes that use the default.

   child_list = aml_control_node->getChildren();
   for (NodeVecCIter in = child_list.begin(); in != child_list.end(); in++) {
      UAPNode* aml_slave = *in;
      if (aml_slave->getName() != "slave") continue;
      if (aml_slave->getAttributeString("attribute") != dflt_attrib)
        aml_slave->addAttribute ("target", aml_slave->getAttributeString("target") + 
                                     "[" + aml_slave->getAttributeString("attribute") + "]");
      aml_slave->removeAttribute("attribute");
    }

    return true;
  }

  // not recognized

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_x_element_attribute_to_aml (string x_class, 
                                        UAPAttribute x_attrib, UAPNode* aml_node) {

  // These attributes are handled by another routine but should be ignored by
  // x_element_attribute_to_aml

  if ((x_attrib.getName() == "design" || x_attrib.getName() == "err") && 
                  (x_class == "overlay" || x_class == "group")) return true;

  // Unrecognized.

  return false;

}


//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BmadParser::custom2_x_element_attribute_to_aml (UAPNode* x_node, UAPNode* aml_node) { 

  string x_class = x_node_to_x_class (x_node);

  // Taylor map.
    
  if (x_class == "taylor") {
    UAPNode* aml_taylor_node = aml_node->getChildByName("taylor_map");
    NodeVec terms = x_node->getChildren();
    for (NodeVecCIter in = terms.begin(); in != terms.end(); in++) 
      aml_taylor_node->addChildCopy(*in);
  }

  // wiggler
    
  if (x_class == "wiggler") {

    UAPNode* aml_wiggler_node = aml_node->getChildByName("wiggler");
    NodeVec terms = x_node->getChildren();
    UAPNode* wig_field;
    if (terms.size() > 0) {
      wig_field = aml_wiggler_node->addChild("wiggler_field");
    }
    for (NodeVecCIter in = terms.begin(); in != terms.end(); in++)
      wig_field->addChildCopy(*in);
  }

  // If there is Superposition then add a child to handle this. 

  if (x_node->getAttribute("superimpose")) {
    UAPNode* aml_super = aml_node->addChild("superimpose");

    if (UAPAttribute* attrib = x_node->getAttribute("ref")) 
      aml_super->addAttribute("ref_element", attrib->getValue());

    if (UAPAttribute* attrib = x_node->getAttribute("offset")) 
      aml_super->addAttribute("offset", attrib->getValue());

    if (UAPAttribute* attrib = x_node->getAttribute("ref_beginning")) 
      aml_super->addAttribute("ref_origin", "ENTRANCE");

    if (x_node->getAttribute("ref_center"))
      aml_super->addAttribute("ref_origin", "CENTER");

    if (x_node->getAttribute("ref_end"))
      aml_super->addAttribute("ref_origin", "EXIT");

    if (x_node->getAttribute("ele_beginning")) 
      aml_super->addAttribute("ele_origin", "ENTRANCE");

    if (x_node->getAttribute("ele_center"))
      aml_super->addAttribute("ele_origin", "CENTER");

    if (x_node->getAttribute("ele_end"))
      aml_super->addAttribute("ele_origin", "EXIT");
  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BmadParser::custom_aml_rep_to_x (UAPNode* lab, UAPNode* x_rep) {

  // Make a list of group and overlay nodes

  NodeVec overlay_list = x_rep->getSubNodesByName("overlay");
  NodeVec lord_list = x_rep->getSubNodesByName("group");
  lord_list.insert(lord_list.begin(), overlay_list.begin(), overlay_list.end());

  // Setting default and slave attribute values is an iterative process
  // since we don't know what depends upon what.
  // Loop 100 times before we give up.

  bool resolved_all;
  for (int i = 0; i < 100; i++) {

    resolved_all = true;
    set_overlay_group_slave_attribute (x_rep, resolved_all);

    // Set the default attribute for groups and overlays...

    for (NodeVecIter il = lord_list.begin(); il != lord_list.end(); il++) {

      UAPNode* lord = *il;
      if (lord->getAttributeString("attribute") != "") continue;  // Already set.

      // Go through all the slaves and look for the most common X attribute.
      // First count the number of times each attribute shows up.

      IntMap counter;
      bool found_dummy = false;

      NodeVec slaves = lord->getChildren();
      for (NodeVecCIter is = slaves.begin(); is != slaves.end(); is++) {
        UAPNode* slave = *is;

        string attrib_str = slave->getAttributeString("attribute");
        if (attrib_str == "DUMMY!") {
          resolved_all = false;
          found_dummy = true;
          break;
        }
        if (counter.find(attrib_str) == counter.end()) {
          counter[attrib_str] = 1;
        } else {
          counter[attrib_str]++;
        }

      }

      // Now find the attribute with the largest number.
      if (found_dummy) continue;

      IntMapIter it;
      IntMapIter heighest = counter.begin();

      for (it = counter.begin(); it != counter.end(); it++) {
        if ((*it).second > (*heighest).second) heighest = it;
      }

      // Now add this attribute as the default.

      lord->addAttribute ("attribute", (*heighest).first);
    }

    if (resolved_all) break;

  }

  if (!resolved_all) info_out.error ("CANNOT RESOLVE OVERLAY/GROUP DEFAULT ATTRIBUTES.");

  // Remove group/overlay slave attributes if they are the same as the default

  for (NodeVecIter il = lord_list.begin(); il != lord_list.end(); il++) {

    UAPNode* lord = *il;
    string dflt_attrib = lord->getAttributeString("attribute");

    // Go through all the slaves and look for attributes that are the same as the default.

    NodeVec slaves = lord->getChildren();
    for (NodeVecCIter is = slaves.begin(); is != slaves.end(); is++) {
      UAPNode* slave = *is;
      string attrib = slave->getAttributeString("attribute");
      if (attrib == dflt_attrib) slave->removeAttribute("attribute");
    }

  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BmadParser::set_overlay_group_slave_attribute (UAPNode* x_rep, bool& resolved_all) {

  // Go through and look for and look for any overlay/group slave attributes
  // that need to be finalized. These attributes where marked with the "DUMMY!" 
  // string by BmadParser::custom_aml_element_attribute_to_x.

  NodeVec nl = x_rep->getChildren();
  for (NodeVecIter ic = nl.begin(); ic != nl.end(); ic++) {
    UAPNode* child = *ic;

    set_overlay_group_slave_attribute (child, resolved_all);  // Recursive
    if (child->getName() != "slave") continue;
    if (child->getAttributeString("attribute") != "DUMMY!") continue;
    string dflt_attrib = x_rep->getAttributeString("attribute");
    string ele_name = child->getAttributeString("element");
    UAPNode* element_node = name_to_x_node_map[ele_name];

    if (!element_node) {
      info_out.error ("CANNOT FIND GROUP OR OVERLAY NAMED: " + ele_name);
      continue;
    } 

    string element_attrib_str = element_node->getAttributeString("attribute");
    if (element_attrib_str == "") {
      resolved_all = false;
      continue;
    }

    child->addAttribute("attribute", element_attrib_str);
    
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep) {

  string aml_name = aml_ele->getName();
  bool ok;

  if (aml_name == "set") {
    Twig twig;
    if (!twig.fromString(aml_ele->getAttributeString("attribute"))) return false;
    string ele_name = twig.name;
    string x_class = ele_name_to_x_class(ele_name);

    if (twig.nodeid_vec.size() != 2) return false;
    string n0 = twig.nodeid_vec[0].name, n1 = twig.nodeid_vec[1].name;

    // AB_Multipole set

    if (x_class == "ab_multipole" && n0 == "multipole" && 
                          (n1 == "kl" || n1 == "ksl" || n1 == "tilt")) {
      string n_str = twig.nodeid_vec[1].attribute[0].value;
      int n_int = string_to_int(n_str, ok);
      if (!ok) {
        info_out.error ("Bad multipole integer order: " + n_str, 
                       "In AML element:", aml_ele->toStringTree());
        return true;
      }
      string ele_name = twig.name;

      string kl_set, ksl_set, tilt_set;
      string value = aml_ele->getAttributeString("value");
      if (n1 == "kl")        kl_set = value;
      else if (n1 == "ksl")  ksl_set = value;
      else if (n1 == "tilt") tilt_set = value;

      string kl_ele, ksl_ele, tilt_ele;
      if (found (aml_multi_tilt_map, ele_name)) {
        kl_ele   = aml_multi_kl_map[ele_name][n_int];
        ksl_ele  = aml_multi_ksl_map[ele_name][n_int];
        tilt_ele = aml_multi_tilt_map[ele_name][n_int];
        required_multipole_transfer ("tilt", kl_ele, ksl_ele, tilt_ele, 
                                             kl_set, ksl_set, tilt_set);
      } else {                                                  // Init if needed
        aml_multi_kl_map[ele_name]   = StrVec(N_MULTIPOLE);
        aml_multi_ksl_map[ele_name]  = StrVec(N_MULTIPOLE);
        aml_multi_tilt_map[ele_name] = StrVec(N_MULTIPOLE);
      }


      string knl, ksl;
      multipole_to_k_ks (kl_set, ksl_set, tilt_set, n_str, knl, ksl);

      if (knl != "") {
        UAPNode* x_set = x_rep->addChild("set");
        x_set->addAttribute("element", ele_name);
        x_set->addAttribute("attribute", "b" + n_str);
        x_set->addAttribute("value", divide_by_n_factorial (n_int, knl));
      }

      if (ksl != "") {
        UAPNode* x_set = x_rep->addChild("set");
        x_set->addAttribute("element", ele_name);
        x_set->addAttribute("attribute", "a" + n_str);
        x_set->addAttribute("value", divide_by_n_factorial (n_int, ksl));
      }

      // record value for next set.

      if (n1 == "kl")        aml_multi_kl_map[ele_name][n_int]   = value;
      else if (n1 == "ksl")  aml_multi_ksl_map[ele_name][n_int]  = value;
      else if (n1 == "tilt") aml_multi_tilt_map[ele_name][n_int] = value;

      return true;
    }

  }    

  // Controller node...
  // There can be a problem translating a default attribute like kicker:x_kick
  // since it can translate into either kick or hkick.
  // The strategy used is to use the most common X attribute.

  if (aml_name == "controller") {

    // Create group or overlay node.
    // Translating the default attribute is complicated so we defer that until later.

    string x_class;
    aml_ele_to_x_class(aml_ele, x_class);
    UAPNode* x_ele = x_rep->addChild(x_class);

    // Transfer name.

    string name = aml_ele->getAttributeString("name");
    x_ele->addAttribute("name", name);
    name_to_x_node_map[name] = x_ele;

    // Add the value if present.

    string design = aml_ele->getAttributeString("design");
    if (design != "") x_ele->addAttribute("value", design);

    aml_element_attributes_to_x (aml_ele, aml_ele, x_ele);
    return true;

  }

  // Unrecognized

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib_node, UAPNode* x_ele) {

  string aml_parent_name = aml_ele->getName();
  string aml_name = aml_attrib_node->getName();

  // Taylor terms

  if (aml_parent_name == "taylor_map" && aml_name == "term") {
    x_ele->addChildCopy(aml_attrib_node);
    return true;
  }

  // Wiggler term

  if (aml_name == "term" & aml_parent_name == "wiggler_field") {
    x_ele->addChildCopy(aml_attrib_node);
    return true;
  }

  // Controller slaves -> group/overlay slaves

  if (aml_name == "slave") {
    UAPNode* x_slave = x_ele->addChild("slave");
    string dflt_attrib = x_ele->getAttributeString("attribute");

    // The "target" string contains the element name and 
    // possibly the attribute to be controlled.

    string target_name = aml_attrib_node->getAttributeString("target");

    // Split the target name into its components and 
    // add the element name to the slave.

    Twig twig(target_name, true);   
    x_slave->addAttribute("element", twig.name);  

    // Find the class this element belongs to.

    string x_slave_class = ele_name_to_x_class(twig.name);
    if (x_slave_class == "")
      info_out.error ("Cannot find AML element: " + twig.name,
                   "Which is a slave of a controller.");

    // Form the attribute string.

    string aml_attrib;
    if (twig.has_brackets)
      aml_attrib = twig.toNodeString();
    else
      aml_attrib = aml_ele->getAttributeString("default_attribute");

    // If the slave element is a group then the attribute to vary is "command".

    if (x_slave_class == "group") {
      if (dflt_attrib != "command") x_slave->addAttribute ("attribute", "command");
      aml_attrib == "";

    // If the slave element is an overlay then we need to know the default_attribute that
    // is being used. This we may not know now so we wait until the end to set this.

    } else if (x_slave_class == "overlay") {

      x_slave->addAttribute ("attribute", "DUMMY!"); // Temporary. 

    // Else the slave is not an overlay or group.

    } else {
      attribute_convert_struct attrib_info;
      if (!found_aml_attrib (x_slave_class, aml_attrib, attrib_info)) {
        info_out.error ("Unknown controller slave attribute: " + aml_attrib,
                     "Of: " + aml_attrib_node->toString(),
                     "In: " + aml_attrib_node->getParent()->toString());
        return false;
      }
      if (attrib_info.aml_to_x_template == IGNORE) return false;
      if (attrib_info.x_name != dflt_attrib) 
        x_slave->addAttribute ("attribute", attrib_info.x_name);
    }

    // Convert something like "con_name * coef[@actual]" to "coef"

    string expression = aml_attrib_node->getAttributeString("expression");
    if (expression != "") {
      bool ok = false;
      string con_name = aml_attrib_node->getParent()->getAttributeString("name") + "[@actual]";
      size_t n_exp = expression.size();
      size_t n_con = con_name.size();
      if (n_con < n_exp) {
        if (expression.substr(0, n_con) == con_name) {
          expression.erase(0, n_exp);
          while(true) {
            if (expression.size() == 0) break;
            char c0 = expression[0];
            if (ok && c0 != ' ') break;
            if (!ok && c0 != ' ' && c0 != '*') break;
            expression.erase(0,1);
            if (c0 == ' ') continue;
            if (c0 == '*') ok = true;
          }
        }

        if (expression.substr(n_exp-n_con, n_con) == con_name) {
          expression.erase(n_exp-n_con, n_con);
          while (true) {
            n_exp = expression.size();
            if (n_exp == 0) break;
            char c0 = expression[n_exp-1];
            if (ok && c0 != ' ') break;
            if (!ok && c0 != ' ' && c0 != '*') break;
            expression.erase(n_exp-1,1);
            if (c0 == ' ') continue;
            if (c0 == '*') ok = true;
          }
        }
      }

      x_slave->addAttribute ("coef", expression);
      if (!ok) {
        info_out.error ("Cannot form valid coefficient for overlay or group slave.",
                     aml_attrib_node->getParent()->toString());
      }
    }

    return true;
  }

  // Superimpose

  if (aml_name == "superimpose") {

    x_ele->addAttribute("superimpose", "");

    AttributeVec attribs = aml_attrib_node->getAttributes();
    for (AttributeVecIter ia = attribs.begin(); ia != attribs.end(); ia++) {
      string name = ia->getName();
      string value = ia->getValue();

      if (name == "ref_element")
        x_ele->addAttribute("ref", value);

      else if (name =="offset")
        x_ele->addAttribute("offset", value);

      else if (name =="ele_origin") {
        string a_name = value;
        if (a_name == "ENTRANCE") x_ele->addAttribute("ele_beginning", "");
        else if (a_name == "CENTER" || a_name == "") x_ele->addAttribute("ele_center", "");
        else if (a_name == "EXIT") x_ele->addAttribute("ele_end", "");
        else info_out.error("Bad ele_origin superimose attribute: " + aml_ele->toStringTree());
      }

      else if (name =="ref_origin") {
        string a_name = value;
        if (a_name == "ENTRANCE") x_ele->addAttribute("ref_beginning", "");
        else if (a_name == "CENTER" || a_name == "") x_ele->addAttribute("ref_center", "");
        else if (a_name == "EXIT") x_ele->addAttribute("ref_end", "");
        else info_out.error("Bad ref_origin superimose attribute: " + aml_ele->toStringTree());
      }
      
      else 
        info_out.error ("superimpose attribute not recognized: " + name, 
                     "For: " + aml_ele->toStringTree());
    }

    return true;
  }

  // Unrecognized

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BmadParser::custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_ele) {

  string aml_attrib_name = aml_ele->getName();
  string ele_name = x_ele->getAttributeString("name");

  // Multipole

  if (aml_attrib_name == "multipole" && name_to_x_class_map[ele_name] == "ab_multipole") {

    string inherit = x_ele->getAttributeString("inherit");
    if (aml_multi_kl_map.find(inherit) == aml_multi_kl_map.end()) inherit = "";

    for (int n = 0; n < N_MULTIPOLE; n++) {
      string kl_base, ksl_base, tilt_base, kl_ele, ksl_ele, tilt_ele;
      if (inherit != "") {
        kl_base   = aml_multi_kl_map[inherit][n];
        ksl_base  = aml_multi_ksl_map[inherit][n];
        tilt_base = aml_multi_tilt_map[inherit][n];
      }
      kl_ele   = aml_multi_kl_map[ele_name][n];
      ksl_ele  = aml_multi_ksl_map[ele_name][n];
      tilt_ele = aml_multi_tilt_map[ele_name][n];
      string kl, ksl, n_str = int_to_string(n);
      if (inherit != "") required_multipole_transfer ("tilt", 
                              kl_base, ksl_base, tilt_base, kl_ele, ksl_ele, tilt_ele); 

      multipole_to_k_ks (kl_ele, ksl_ele, tilt_ele, n_str, kl, ksl);

      string n_fact = n_factorial[n];

      if (kl != "") x_ele->addAttribute("b" + n_str, divide_by_n_factorial (n, kl));
      if (ksl != "") x_ele->addAttribute("a" + n_str, divide_by_n_factorial (n, ksl));

      if (inherit != "") {
        if (kl_ele   == "") aml_multi_kl_map[ele_name][n]   = kl_base;
        if (ksl_ele  == "") aml_multi_ksl_map[ele_name][n]  = ksl_base;
        if (tilt_ele == "") aml_multi_tilt_map[ele_name][n] = tilt_base;
      }

    }

    return;
  }

  //

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_x_element_to_x_file (UAPNode* x_node, string& comment, 
                                                             StreamStruct& x_out) {

  string x_name = x_node->getName();

  // use

  if (x_name == "use") {
    x_out << "use, " << x_node->getAttributeString("line") << comment << fini;
    return true;
  }

  // set

  if (x_name == "set") {
    x_out << x_node->getAttributeString("element") << "[" <<
              x_node->getAttributeString("attribute") << "] = " <<
              x_node->getAttributeString("value") << comment << fini;
    return true;
  }

  // beginning, beam_start, or parameter

  if (x_name == "beginning" || x_name == "beam_start" || x_name == "parameter") {
    x_out << x_name;
    AttributeVec al = x_node->getAttributes();
    for (AttributeVecCIter it = al.begin(); it != al.end(); it++) {
      if (it->getName() == "comment") continue;
      x_out << "[" << it->getName() << "] = " << it->getValue();
    }
    x_out << comment << fini;
    return true;
  }

  // overlay and group

  if (x_name == "overlay" || x_name == "group") {
    x_out <<  x_node->getAttributeString("name") << ": " << 
                 x_node->getName() << " = {";
    NodeVec nt = x_node->getChildren();
    for (NodeVecCIter it = nt.begin(); it != nt.end(); it++) {
      UAPNode* slave = *it;
      if (it != nt.begin()) x_out << ", ";
      x_out << slave->getAttributeString("element");
      string attrib = slave->getAttributeString("attribute");
      if (attrib != "") x_out << "[" << attrib << "]";
      string coef = slave->getAttributeString("coef");
      if (coef != "") x_out << "/" << coef;
    }
    string attrib = x_node->getAttributeString("attribute");
    string value = x_node->getAttributeString("value");
    x_out << "}, " << attrib;
    if (value != "") x_out << " = " << value;

    AttributeVec al = x_node->getAttributes();
    for (AttributeVecCIter att = al.begin(); att != al.end(); att++) {
      string a_name = att->getName();
      string a_value = att->getValue();
      if (a_name == "name") continue;
      if (a_name == "comment") continue;
      if (a_name == "attribute") continue;
      if (a_name == "value") continue;
      x_out << ", " << a_name;
      x_add_quote_marks (a_name, a_value);
      if (a_value != "") x_out << " = " << a_value;
    }

    x_out << comment << fini;
    return true;
  }


  // not recognized

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BmadParser::custom_x_ele_attributes_to_x_file (UAPNode* x_node, 
                                const string& ele_class, StreamStruct& x_out) {

  if (ele_class == "taylor") {
    NodeVec nt = x_node->getChildren();
    for (NodeVecCIter it = nt.begin(); it != nt.end(); it++) {
      UAPNode* term = *it;
      x_out << ", {" << term->getAttributeString("i_out") << ": " <<
              term->getAttributeString("coef") << ", " << 
              term->getAttributeString("exp") << "}";
    }
  }

  if (ele_class == "wiggler") {
    NodeVec nt = x_node->getChildren();
    int i = 0;
    for (NodeVecCIter it = nt.begin(); it != nt.end(); it++) {
      UAPNode* term = *it;
      i++;
      x_out << ", term(" << i << ") = {" <<
              term->getAttributeString("coef") << ", " << 
              term->getAttributeString("k_x") << ", " <<
              term->getAttributeString("k_y") << ", " << 
              term->getAttributeString("k_z") << ", " << 
              term->getAttributeString("phi_z") <<  "}";
    }
  }


}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::aml_ele_to_x_class (UAPNode* aml_ele, string& x_class) {

  // Since an AML element can be a combination of quadrupole, bend, etc., we
  // Need to see if there is a possible corresponding MAD element.

  x_class = "BAD!";

  // Controllers are either Bmad groups or overlays

  if (aml_ele->getName() == "controller") {
    string var = aml_ele->getAttributeString("variation");
    if (var == "" || var == "ABSOLUTE") {
      x_class = "overlay";
    } else {
      x_class = "group";
    }
    return true;
  }

  // First make a list of what element children like <quadrupole> are present.

  StrList names;
  NodeVec children = aml_ele->getChildren();
  for (NodeVecCIter it = children.begin(); it != children.end(); it++) {
    string name = (*it)->getName();
    if (!found(aml_class_names, name)) continue;
    if (name == "rf_cavity") {
      if ((*it)->getAttributeString("type") == "LINAC") {
        names << "lcavity";
        continue;
      }
    } 
    names << name;
  }

  UAPNode* instrument = aml_ele->getChildByName("instrument");

  // If there are no children then must be a drift or a type of instrument.

  if (names.size() == 0) {
    x_class = "drift";
    if (instrument) {
      x_class = "instrument";
      string i_type = instrument->getAttributeString("type");
      if (i_type == "monitor") x_class = i_type;
    }
    return true;
  }

  // Ignore aperture, etc. if there is something else


  if (names.size() > 1) names.remove("aperture");
  if (names.size() > 1) names.remove("scaled_multipole");
  if (names.size() > 1) names.remove("multipole");
  if (names.size() > 1) names.remove("kicker");

  // Translation where there is exactly one match

  if (names.size() == 1) {

    x_class = names.front();

    if (x_class == "taylor_map")      x_class = "taylor";
    if (x_class == "bend")            x_class = "sbend";
    if (x_class == "electric_kicker") x_class = "elseparator";
    if (x_class == "rf_cavity")       x_class = "rfcavity";
    if (x_class == "lcavity")         x_class = "lcavity";

    if (x_class == "aperture") {
      x_class = "rcollimator";
      string shape = aml_ele->getChildByName("aperture")->getAttributeString("shape");
      if (shape == "ELLIPTICAL") x_class = "ecollimator";
    }

    // AML multipole can be converted into either a Bmad multipole or ab_multipole 
    // Rule: If number of <tilt>s = 0 and have as least one <ksl> --> ab_multipole. 
    //       Otherwise multipole.
    
    if (x_class == "multipole") {
      int n_tilt(0), n_ksl(0);
      UAPNode* mult = aml_ele->getChildByName("multipole");

      NodeVec children = mult->getChildren();
      for (NodeVecCIter it = children.begin(); it != children.end(); it++) {
        UAPNode* child = *it;
        if (child->getName() == "tilt") n_tilt++;
        if (child->getName() == "ksl")  n_ksl++;
      }
      if (n_tilt == 0 && n_ksl > 0) x_class = "ab_multipole";
    }

    return true;    
  }

  // More than one item in the list:

  if (found(names, "solenoid") && found(names, "quadrupole")) {
    if (names.size() == 2) x_class = "sol_quad";
  }

  if (x_class == "BAD!" && found(names, "bend")) x_class = "sbend";

  if (x_class == "BAD!") {
    info_out.error ("AML element does not have a corresponding " + language + 
                                                        " type", aml_ele->toStringTree());
    return false;
  }

  return true;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string BmadParser::divide_by_n_factorial (int n, string k) {

  // For n! = 1 there is nothing to do.

  if (n < 2) return k;

  // Try to take out a factor of " * n!" if this appears at the end of the string.
  // otherwise add " / n!" to the end.

  int m = k.size() - (3 + n_factorial[n].size());

  if (m > 0 && k.substr(m) == " * " + n_factorial[n])
    return k.substr(0, m);
  else
    return add_parens_if_needed(k) + " / " + n_factorial[n];

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool BmadParser::custom_aml_sector_or_element_to_x (UAPNode* aml_sector, 
                                            UAPNode* x_root) {

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void BmadParser::init_lists_bmad () {

  x_param_names << "beam" << "parameter" << "beginning" << "beam_start";

  x_attributes_needing_quote_marks << "type" << "alias" << "descrip";
  x_attributes_to_upper_case << "lattice_type" << "tracking_method" 
                             << "mat6_calc_method" << "aperture_at";
  x_attributes_no_case_change << "alias" << "descrip";

  x_class_to_aml_map["sol_quad"] =         "quadrupole:solenoid";
  x_class_to_aml_map["bend_sol_quad"] =    "quadrupole:solenoid:dipole";
  x_class_to_aml_map["custom"] =           "custom";
  x_class_to_aml_map["ab_multipole"] =     "multipole";
  x_class_to_aml_map["girder"] =           "girder";
  x_class_to_aml_map["match"] =            "match";
  x_class_to_aml_map["patch"] =            "patch";
  x_class_to_aml_map["taylor"] =           "taylor_map";
  x_class_to_aml_map["wiggler"] =          "wiggler";
  x_class_to_aml_map["overlay"] =          "controller";
  x_class_to_aml_map["group"] =            "controller(variation=DELTA)";

  StrVec ab_mul_attrib;
  ab_mul_attrib << "a1" << "a2" << "a3" << "a4" << "a5" 
         << "a6" << "a7" << "a8" << "a9" << "a10" << "a11" << "a12" << "a13"
         << "a14" << "a15" << "a16" << "a17" << "a18" << "a19" << "a20" << "b1"
         << "b2" << "b3" << "b4" << "b5" << "b6" << "b7" << "b8" << "b9"
         << "b10" << "b11" << "b12" << "b13" << "b14" << "b15" << "b16" << "b17"
         << "b18" << "b19" << "b20";

  StrVec scaled_mul_attrib;
  scaled_mul_attrib << "k_coef(n=0)" 
         << "k_coef(n=1)" << "k_coef(n=2)" << "k_coef(n=3)" << "k_coef(n=4)" << "k_coef(n=5)"
         << "k_coef(n=6)" << "k_coef(n=7)" << "k_coef(n=8)" << "k_coef(n=9)" << "k_coef(n=10)" 
         << "k_coef(n=11)" << "k_coef(n=12)" << "k_coef(n=13)" << "k_coef(n=14)" << "k_coef(n=15)" 
         << "k_coef(n=16)" << "k_coef(n=17)" << "k_coef(n=18)" << "k_coef(n=19)" << "k_coef(n=20)" 
         << "k_coef(n=0)" << "ks_coef(n=1)" << "ks_coef(n=2)" << "ks_coef(n=3)" << "ks_coef(n=4)" 
         << "ks_coef(n=5)" << "ks_coef(n=6)" << "ks_coef(n=7)" << "ks_coef(n=8)" << "ks_coef(n=9)"
         << "ks_coef(n=10)" << "ks_coef(n=11)" << "ks_coef(n=12)" << "ks_coef(n=13)" << "ks_coef(n=14)" 
         << "ks_coef(n=15)" << "ks_coef(n=16)" << "ks_coef(n=17)"
         << "ks_coef(n=18)" << "ks_coef(n=19)" << "ks_coef(n=20)" << "radius";

  StrVec superimpose_attrib;
  superimpose_attrib << "superimpose" << "ref_beginning" << "ref_center" <<
                        "ref_end" << "ele_beginning" << "ele_center" <<
                        "ele_end" << "reference" << "offset" << "ref";

  StrVec descrip_attrib;
  descrip_attrib <<"descrip" << "type" << "alias";

  StrVec method_attrib;
  method_attrib << "x1_limit" << "y1_limit" << "x2_limit" << "y2_limit" 
                << "x_limit" << "y_limit" << "aperture" << "aperture_at"
                << "mat6_calc_method" << "tracking_method" << "is_on";

  StrVec track_attrib;
  track_attrib << "symplectify" << "map_with_offsets" << "integrator_order" 
                       << "ds_step" << "rel_tol" << "abs_tol" << "csr_calc_on"
                       << "num_steps";

  StrVec kick_attrib;
  kick_attrib << "hkick" << "vkick" << "bl_hkick" << "bl_vkick";

  StrVec offset_attrib;
  offset_attrib << "x_offset" << "y_offset" << "s_offset";

  StrVec pitch_attrib;
  pitch_attrib << "x_pitch" << "y_pitch";

  StrVec drift_attrib;
  drift_attrib << "l" << "rel_tol";
  map_element_to_attribs["drift"] << kick_attrib;
  map_element_to_attribs["drift"] << method_attrib;
  map_element_to_attribs["drift"] << track_attrib;
  map_element_to_attribs["drift"] << descrip_attrib;
  map_element_to_attribs["drift"] << drift_attrib;
 
  StrVec bend_attrib;
  bend_attrib << "l" << "tilt" << "angle" << "k1" << "k2" << "g_err" 
              << "g" << "e1" << "l_chord" << "roll"
              << "e2" << "fint" << "fintx" << "rho" << "hgap" << "hgapx" 
              << "h1" << "h2" << "rel_tol" << "b_field" << "b_field_err";
  bend_attrib << pitch_attrib;
  bend_attrib << kick_attrib;
  bend_attrib << offset_attrib;
  bend_attrib << method_attrib;
  bend_attrib << track_attrib;
  bend_attrib << descrip_attrib;
  bend_attrib << scaled_mul_attrib;
  bend_attrib << superimpose_attrib;
  map_element_to_attribs["sbend"] << bend_attrib;
  map_element_to_attribs["rbend"] << bend_attrib;
 

  StrVec quadrupole_attrib;
  quadrupole_attrib << "l" << "tilt" << "k1" << "rel_tol" << "b1_gradient";
  map_element_to_attribs["quadrupole"] << pitch_attrib;
  map_element_to_attribs["quadrupole"] << kick_attrib;
  map_element_to_attribs["quadrupole"] << offset_attrib;
  map_element_to_attribs["quadrupole"] << method_attrib;
  map_element_to_attribs["quadrupole"] << track_attrib;
  map_element_to_attribs["quadrupole"] << descrip_attrib;
  map_element_to_attribs["quadrupole"] << scaled_mul_attrib;
  map_element_to_attribs["quadrupole"] << superimpose_attrib;
  map_element_to_attribs["quadrupole"] << quadrupole_attrib;
 
  StrVec group_attrib;
  group_attrib << "command" << "old_command" << "coef" << "symmetric_edge"
               << "start_edge" << "end_edge" << "accordion_edge" << "value" << "err";
  map_element_to_attribs["group"] << descrip_attrib;
  map_element_to_attribs["group"] << group_attrib;
 
  StrVec sextupole_attrib;
  sextupole_attrib << "l" << "tilt" << "k2" << "rel_tol" << "b2_gradient";
  map_element_to_attribs["sextupole"] << pitch_attrib;
  map_element_to_attribs["sextupole"] << kick_attrib;
  map_element_to_attribs["sextupole"] << offset_attrib;
  map_element_to_attribs["sextupole"] << method_attrib;
  map_element_to_attribs["sextupole"] << track_attrib;
  map_element_to_attribs["sextupole"] << descrip_attrib;
  map_element_to_attribs["sextupole"] << scaled_mul_attrib;
  map_element_to_attribs["sextupole"] << superimpose_attrib;
  map_element_to_attribs["sextupole"] << sextupole_attrib;
 
  StrVec overlay_attrib;
  overlay_attrib << "attribute" << "value" << "err";
  map_element_to_attribs["overlay"] << descrip_attrib;
  map_element_to_attribs["overlay"] << overlay_attrib;
 
  StrVec custom_attrib;
  custom_attrib << "l" << "tilt" << "val1" << "val2" << "val3" << "val4" 
                << "val6" << "val7" << "val8" << "val9" << "val10" << "val5" 
                << "val11" << "delta_e" << "val12" << "rel_tol";
  map_element_to_attribs["custom"] << pitch_attrib;
  map_element_to_attribs["custom"] << offset_attrib;
  map_element_to_attribs["custom"] << method_attrib;
  map_element_to_attribs["custom"] << track_attrib;
  map_element_to_attribs["custom"] << descrip_attrib;
  map_element_to_attribs["custom"] << custom_attrib;
 
  StrVec taylor_attrib;
  taylor_attrib << "l" << "tilt";
  map_element_to_attribs["taylor"] << pitch_attrib;
  map_element_to_attribs["taylor"] << offset_attrib;
  map_element_to_attribs["taylor"] << method_attrib;
  map_element_to_attribs["taylor"] << track_attrib;
  map_element_to_attribs["taylor"] << descrip_attrib;
  map_element_to_attribs["taylor"] << taylor_attrib;
 
  StrVec rfcavity_attrib;
  rfcavity_attrib << "l" << "harmon" << "voltage" << "dphi0"
                  << "rf_frequency" << "phi0" << "rel_tol";
  map_element_to_attribs["rfcavity"] << pitch_attrib;
  map_element_to_attribs["rfcavity"] << kick_attrib;
  map_element_to_attribs["rfcavity"] << offset_attrib;
  map_element_to_attribs["rfcavity"] << method_attrib;
  map_element_to_attribs["rfcavity"] << track_attrib;
  map_element_to_attribs["rfcavity"] << descrip_attrib;
  map_element_to_attribs["rfcavity"] << rfcavity_attrib;
 
  StrVec elseparator_attrib;
  elseparator_attrib << "l" << "tilt" << "voltage" << "gap" << "rel_tol" << "e_field";
  map_element_to_attribs["elseparator"] << pitch_attrib;
  map_element_to_attribs["elseparator"] << kick_attrib;
  map_element_to_attribs["elseparator"] << offset_attrib;
  map_element_to_attribs["elseparator"] << method_attrib;
  map_element_to_attribs["elseparator"] << track_attrib;
  map_element_to_attribs["elseparator"] << descrip_attrib;
  map_element_to_attribs["elseparator"] << scaled_mul_attrib;
  map_element_to_attribs["elseparator"] << superimpose_attrib;
  map_element_to_attribs["elseparator"] << elseparator_attrib;
 
  StrVec beambeam_attrib;
  beambeam_attrib << "tilt" << "sig_x" << "sig_y" << "sig_z"
                  << "charge" << "n_slice";
  map_element_to_attribs["beambeam"] << pitch_attrib;
  map_element_to_attribs["beambeam"] << offset_attrib;
  map_element_to_attribs["beambeam"] << method_attrib;
  map_element_to_attribs["beambeam"] << descrip_attrib;
  map_element_to_attribs["beambeam"] << beambeam_attrib;
 
  StrVec wiggler_attrib;
  wiggler_attrib << "l" << "tilt" << "k1" << "b_max" << "n_pole" << "polarity" 
                 << "z_patch" << "rho" << "x_patch" << "l_pole" << "x_ray_line_len" 
                 << "rel_tol" << "term";
  map_element_to_attribs["wiggler"] << pitch_attrib;
  map_element_to_attribs["wiggler"] << kick_attrib;
  map_element_to_attribs["wiggler"] << offset_attrib;
  map_element_to_attribs["wiggler"] << method_attrib;
  map_element_to_attribs["wiggler"] << track_attrib;
  map_element_to_attribs["wiggler"] << descrip_attrib;
  map_element_to_attribs["wiggler"] << scaled_mul_attrib;
  map_element_to_attribs["wiggler"] << superimpose_attrib;
  map_element_to_attribs["wiggler"] << wiggler_attrib;
 
  StrVec sol_quad_attrib;
  sol_quad_attrib << "l" << "tilt" << "k1" << "ks" << "rel_tol";
  map_element_to_attribs["sol_quad"] << pitch_attrib;
  map_element_to_attribs["sol_quad"] << kick_attrib;
  map_element_to_attribs["sol_quad"] << offset_attrib;
  map_element_to_attribs["sol_quad"] << method_attrib;
  map_element_to_attribs["sol_quad"] << track_attrib;
  map_element_to_attribs["sol_quad"] << descrip_attrib;
  map_element_to_attribs["sol_quad"] << scaled_mul_attrib;
  map_element_to_attribs["sol_quad"] << superimpose_attrib;
  map_element_to_attribs["sol_quad"] << sol_quad_attrib;
 
  StrVec marker_attrib;
  marker_attrib << "tilt";
  map_element_to_attribs["marker"] << offset_attrib;
  map_element_to_attribs["marker"] << method_attrib;
  map_element_to_attribs["marker"] << descrip_attrib;
  map_element_to_attribs["marker"] << superimpose_attrib;
  map_element_to_attribs["marker"] << marker_attrib;
 
  StrVec kicker_attrib;
  kicker_attrib << "l"  << "tilt"  << "h_displace"  << "v_displace" << "rel_tol";
  map_element_to_attribs["kicker"] << kick_attrib;
  map_element_to_attribs["kicker"] << method_attrib;
  map_element_to_attribs["kicker"] << track_attrib;
  map_element_to_attribs["kicker"] << descrip_attrib;
  map_element_to_attribs["kicker"] << scaled_mul_attrib;
  map_element_to_attribs["kicker"] << superimpose_attrib;
  map_element_to_attribs["kicker"] << kicker_attrib;
 
  StrVec octupole_attrib;
  octupole_attrib << "l" << "tilt" << "k3" << "rel_tol" << "b3_gradient";
  map_element_to_attribs["octupole"] << pitch_attrib;
  map_element_to_attribs["octupole"] << kick_attrib;
  map_element_to_attribs["octupole"] << offset_attrib;
  map_element_to_attribs["octupole"] << method_attrib;
  map_element_to_attribs["octupole"] << track_attrib;
  map_element_to_attribs["octupole"] << descrip_attrib;
  map_element_to_attribs["octupole"] << scaled_mul_attrib;
  map_element_to_attribs["octupole"] << superimpose_attrib;
  map_element_to_attribs["octupole"] << octupole_attrib;
 
  StrVec multipole_attrib;
  multipole_attrib << "l" << "tilt" << "k0l" << "k1l"
         << "k2l" << "k3l" << "k4l" << "k5l" << "k6l" << "k7l" << "k8l" << "k9l"
         << "k10l" << "k11l" << "k12l" << "k13l" << "k14l" << "k15l" << "k16l" << "k17l"
         << "k18l" << "k19l" << "k20l" << "t0" << "t1" << "t2" << "t3" << "t4"
         << "t5" << "t6" << "t7" << "t8" << "t9" << "t10" << "t11" << "t12"
         << "t13" << "t14" << "t15" << "t16" << "t17" << "t18" << "t19" << "t20";
  map_element_to_attribs["multipole"] << offset_attrib;
  map_element_to_attribs["multipole"] << method_attrib;
  map_element_to_attribs["multipole"] << descrip_attrib;
  map_element_to_attribs["multipole"] << superimpose_attrib;
  map_element_to_attribs["multipole"] << multipole_attrib;

  StrVec ab_multipole_attrib;
  ab_multipole_attrib << "l" << "tilt";
  map_element_to_attribs["ab_multipole"] << offset_attrib;
  map_element_to_attribs["ab_multipole"] << method_attrib;
  map_element_to_attribs["ab_multipole"] << descrip_attrib;
  map_element_to_attribs["ab_multipole"] << ab_mul_attrib;
  map_element_to_attribs["ab_multipole"] << superimpose_attrib;
  map_element_to_attribs["ab_multipole"] << ab_multipole_attrib;
 
  StrVec beam_attrib;
  beam_attrib << "particle" << "n_part" << "energy";
  map_element_to_attribs["beam"] << beam_attrib;
 
  StrVec solenoid_attrib;
  solenoid_attrib << "l" << "ks" << "rel_tol" << "bs_field";
  map_element_to_attribs["solenoid"] << pitch_attrib;
  map_element_to_attribs["solenoid"] << kick_attrib;
  map_element_to_attribs["solenoid"] << offset_attrib;
  map_element_to_attribs["solenoid"] << method_attrib;
  map_element_to_attribs["solenoid"] << track_attrib;
  map_element_to_attribs["solenoid"] << descrip_attrib;
  map_element_to_attribs["solenoid"] << scaled_mul_attrib;
  map_element_to_attribs["solenoid"] << superimpose_attrib;
  map_element_to_attribs["solenoid"] << solenoid_attrib;
 
  StrVec patch_attrib;
  patch_attrib << "l" << "tilt" << "z_offset" << "pz_offset";
  map_element_to_attribs["patch"] << pitch_attrib;
  map_element_to_attribs["patch"] << offset_attrib;
  map_element_to_attribs["patch"] << method_attrib;
  map_element_to_attribs["patch"] << descrip_attrib;
  map_element_to_attribs["patch"] << patch_attrib;
 
  StrVec lcavity_attrib;
  lcavity_attrib << "l" << "tilt" << "gradient_err" << "coupler_angle"
                 << "phi0_err" << "lrad" << "dphi0" << "rf_frequency" << "e_loss" 
                 << "gradient" << "phi0" << "delta_e" << "freq_spread"
                 << "rel_tol" << "coupler_strength" << "coupler_phase" 
                 << "sr_wake_file" << "lr_wake_file" << "coupler_at";
  map_element_to_attribs["lcavity"] << pitch_attrib;
  map_element_to_attribs["lcavity"] << kick_attrib;
  map_element_to_attribs["lcavity"] << offset_attrib;
  map_element_to_attribs["lcavity"] << method_attrib;
  map_element_to_attribs["lcavity"] << track_attrib;
  map_element_to_attribs["lcavity"] << descrip_attrib;
  map_element_to_attribs["lcavity"] << lcavity_attrib;
 
  StrVec parameter_attrib;
  parameter_attrib << "n_part" << "taylor_order" << "lattice_type"
                   << "ran_seed" << "lattice";
  map_element_to_attribs["parameter"] << parameter_attrib;
 
  StrVec match_attrib;
  match_attrib << "l" << "beta_a0" << "alpha_a0" << "beta_b0"
               << "alpha_b0" << "beta_a1" << "alpha_a1" << "beta_b1"
               << "alpha_b1" << "dphi_a" << "dphi_b" << "eta_a0"
               << "etap_a0" << "eta_b0" << "etap_b0" << "eta_a1"
               << "etap_a1" << "eta_b1" << "etap_b1";
  map_element_to_attribs["match"] << method_attrib;
  map_element_to_attribs["match"] << descrip_attrib;
  map_element_to_attribs["match"] << match_attrib;
 
  StrVec monitor_attrib;
  monitor_attrib << "l" << "tilt" << "rel_tol";
  map_element_to_attribs["monitor"] << pitch_attrib;
  map_element_to_attribs["monitor"] << kick_attrib;
  map_element_to_attribs["monitor"] << offset_attrib;
  map_element_to_attribs["monitor"] << method_attrib;
  map_element_to_attribs["monitor"] << track_attrib;
  map_element_to_attribs["monitor"] << descrip_attrib;
  map_element_to_attribs["monitor"] << monitor_attrib;
 
  StrVec instrument_attrib;
  instrument_attrib << "l" << "tilt" << "rel_tol";
  map_element_to_attribs["instrument"] << pitch_attrib;
  map_element_to_attribs["instrument"] << kick_attrib;
  map_element_to_attribs["instrument"] << offset_attrib;
  map_element_to_attribs["instrument"] << method_attrib;
  map_element_to_attribs["instrument"] << track_attrib;
  map_element_to_attribs["instrument"] << descrip_attrib;
  map_element_to_attribs["instrument"] << instrument_attrib;
 
  StrVec hvkicker_attrib;
  hvkicker_attrib << "l" << "tilt" << "kick" << "rel_tol" << "bl_kick";
  map_element_to_attribs["hvkicker"] << method_attrib;
  map_element_to_attribs["hvkicker"] << track_attrib;
  map_element_to_attribs["hvkicker"] << descrip_attrib;
  map_element_to_attribs["hvkicker"] << scaled_mul_attrib;
  map_element_to_attribs["hvkicker"] << superimpose_attrib;
  map_element_to_attribs["hkicker"] << hvkicker_attrib;
  map_element_to_attribs["vkicker"] << hvkicker_attrib;
 
  StrVec collimator_attrib;
  collimator_attrib << "l" << "rel_tol";
  map_element_to_attribs["collimator"] << kick_attrib;
  map_element_to_attribs["collimator"] << offset_attrib;
  map_element_to_attribs["collimator"] << method_attrib;
  map_element_to_attribs["collimator"] << track_attrib;
  map_element_to_attribs["collimator"] << descrip_attrib;
  map_element_to_attribs["rcollimator"] << collimator_attrib;
  map_element_to_attribs["ecollimator"] << collimator_attrib;
 
  StrVec girder_attrib;
  girder_attrib << "tilt" << "s_center";
  map_element_to_attribs["girder"] << pitch_attrib;
  map_element_to_attribs["girder"] << offset_attrib;
  map_element_to_attribs["girder"] << descrip_attrib;
  map_element_to_attribs["girder"] << girder_attrib;
 
  map_element_to_attribs["bend_sol_quad"] << pitch_attrib;
  map_element_to_attribs["bend_sol_quad"] << kick_attrib;
  map_element_to_attribs["bend_sol_quad"] << offset_attrib;
  map_element_to_attribs["bend_sol_quad"] << method_attrib;
  map_element_to_attribs["bend_sol_quad"] << track_attrib;
  map_element_to_attribs["bend_sol_quad"] << descrip_attrib;
  map_element_to_attribs["bend_sol_quad"] << scaled_mul_attrib;
  map_element_to_attribs["bend_sol_quad"] << superimpose_attrib;
  map_element_to_attribs["bend_sol_quad"] << "l" << "tilt" << "angle" << "k1" << "g"
            << "dks_ds" << "ks" << "rho" << "quad_tilt" << "bend_tilt" 
            << "y_quad" << "rel_tol"  << "x_quad";
;
 
  
  map_element_to_attribs["beam_start"] << "x" << "p_x" << "y" << "p_y" << "z" << "p_z";
 
  //----------------------------------------------------------

  int n_fact = 1;
  n_factorial.resize(N_MULTIPOLE);

  for (int i = 0; i < 20; i++) {
    string order = int_to_string(i), n_f;

    string a = "a" + order;
    string b = "b" + order;
    string n = "(n=" + order + ")";
    string x_to_aml, aml_to_x;
    if (i == 0 || i == 1) {
      x_to_aml = "";
      aml_to_x = "";
    } else {
      n_fact = n_fact * i;
      n_f = int_to_string(n_fact);
      n_factorial[i] = n_f;
      x_to_aml = "# * " + n_f;
      aml_to_x = "# / " + n_f;
    }

    register_attribute("ab_multipole:" + a, "multipole:ksl" + n, x_to_aml, IGNORE);
    register_attribute("ab_multipole:" + b, "multipole:kl" + n,  x_to_aml, IGNORE);
    register_attribute("sbend:" + a,      "bend:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("sbend:" + b,      "bend:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("rbend:" + a,      "bend:scaled_multipole:ks_coef" + n, "", IGNORE);
    register_attribute("rbend:" + b,      "bend:scaled_multipole:k_coef" + n, "", IGNORE);
    register_attribute("kicker:" + a,     "kicker:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("kicker:" + b,     "kicker:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("hkicker:" + a,    "kicker:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("hkicker:" + b,    "kicker:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("vkicker:" + a,    "kicker:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("vkicker:" + b,    "kicker:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("octupole:" + a,   "octupole:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("octupole:" + b,   "octupole:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("quadrupole:" + a, "quadrupole:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("quadrupole:" + b, "quadrupole:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("sextupole:" + a,  "sextupole:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("sextupole:" + b,  "sextupole:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("solenoid:" + a,   "solenoid:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("solenoid:" + b,   "solenoid:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
    register_attribute("elseparator:" + a, "electric_kicker:scaled_multipole:ks_coef" + n, x_to_aml, aml_to_x);
    register_attribute("elseparator:" + b, "electric_kicker:scaled_multipole:k_coef" + n, x_to_aml, aml_to_x);
  }

  register_attribute("sbend:radius",      "bend:scaled_multipole:radius");
  register_attribute("rbend:radius",      "bend:scaled_multipole:radius", "", IGNORE);
  register_attribute("kicker:radius",     "kicker:scaled_multipole:radius");
  register_attribute("hkicker:radius",    "kicker:scaled_multipole:radius");
  register_attribute("vkicker:radius",    "kicker:scaled_multipole:radius");
  register_attribute("octupole:radius",   "octupole:scaled_multipole:radius");
  register_attribute("quadrupole:radius", "quadrupole:scaled_multipole:radius");
  register_attribute("sextupole:radius",  "sextupole:scaled_multipole:radius");
  register_attribute("solenoid:radius",   "solenoid:scaled_multipole:radius");
  register_attribute("elseparator:radius", "electric_kicker:scaled_multipole:radius");

  // beam statement

  register_attribute("beam:n_part",      "beam[n_particles]", "", IGNORE);
  register_attribute("beam:particle",    "beam[particle@type]", "", IGNORE);
  register_attribute("beam:energy",      "beam[total_energy]", "# * 1e9", IGNORE);

  // parameter statement

  register_attribute("parameter:lattice",           "lattice[label@string]");
  register_attribute("parameter:lattice_type",      "lattice[geometry@type]");
  register_attribute("parameter:e_tot",             "beam[total_energy]");
  register_attribute("parameter:particle",          "beam[particle@type]");
  register_attribute("parameter:n_part",            "beam[n_particles]");
  register_attribute("parameter:taylor_order",      "parameter[taylor_order@value]");
  register_attribute("parameter:ran_seed",          "parameter[ran_seed@value]");

  // beam_start statement

  register_attribute("beam_start:x",             "beam[position:x]");
  register_attribute("beam_start:p_x",           "beam[position:p_x]");
  register_attribute("beam_start:y",             "beam[position:y]");
  register_attribute("beam_start:p_y",           "beam[position:p_y]");
  register_attribute("beam_start:z",             "beam[position:z]");
  register_attribute("beam_start:p_z",           "beam[position:p_z]");
  register_attribute("beam_start:emittance_a",   "beam[emittance_a]");
  register_attribute("beam_start:emittance_b",   "beam[emittance_b]");
  register_attribute("beam_start:emittance_z",   "beam[emittance_z]");  

  // beginning statement

  register_attribute("beginning:beta_a",         "lattice[twiss:beta_a]");
  register_attribute("beginning:beta_b",         "lattice[twiss:beta_b]");
  register_attribute("beginning:alpha_a",        "lattice[twiss:alpha_a]");
  register_attribute("beginning:alpha_b",        "lattice[twiss:alpha_b]");
  register_attribute("beginning:phi_a",          "lattice[twiss:phase_a]");
  register_attribute("beginning:phi_b",          "lattice[twiss:phase_b]");
  register_attribute("beginning:eta_a",          "lattice[twiss:eta_a]");
  register_attribute("beginning:eta_b",          "lattice[twiss:eta_b]");
  register_attribute("beginning:etap_a",         "lattice[twiss:etap_a]");
  register_attribute("beginning:etap_b",         "lattice[twiss:etap_b]");
  register_attribute("beginning:eta_x",          "lattice[twiss:eta_x]");
  register_attribute("beginning:eta_y",          "lattice[twiss:eta_y]");
  register_attribute("beginning:etap_x",         "lattice[twiss:etap_x]");
  register_attribute("beginning:etap_y",         "lattice[twiss:etap_y]");
  register_attribute("beginning:c11",            "lattice[twiss:c11]");
  register_attribute("beginning:c12",            "lattice[twiss:c12]");
  register_attribute("beginning:c21",            "lattice[twiss:c21]");
  register_attribute("beginning:c22",            "lattice[twiss:c22]");
  register_attribute("beginning:x_position",     "lattice[floor:x]");
  register_attribute("beginning:y_position",     "lattice[floor:y]");
  register_attribute("beginning:z_position",     "lattice[floor:z]");
  register_attribute("beginning:theta_position", "lattice[floor:theta]");
  register_attribute("beginning:phi_position",   "lattice[floor:phi]");
  register_attribute("beginning:psi_position",   "lattice[floor:psi]");
  register_attribute("beginning:e_tot",          "beam[total_energy]");

  // element attributes

  register_attribute("alias",      "description:alias@string");
  register_attribute("descrip",    "description:descrip@string");

  register_attribute("x_offset",   "orientation:x_offset");
  register_attribute("y_offset",   "orientation:y_offset");
  register_attribute("s_offset",   "orientation:s_offset");
  register_attribute("x_pitch",    "orientation:x_pitch");
  register_attribute("y_pitch",    "orientation:y_pitch");
  register_attribute("roll",       "orientation:roll");

  register_attribute("beta_a0",    "match:twiss(at=ENTRANCE):beta_a");
  register_attribute("alpha_a0",   "match:twiss(at=ENTRANCE):alpha_a");
  register_attribute("eta_a0",     "match:twiss(at=ENTRANCE):eta_a");
  register_attribute("etap_a0",    "match:twiss(at=ENTRANCE):etap_a");
  register_attribute("beta_b0",    "match:twiss(at=ENTRANCE):beta_b");
  register_attribute("alpha_b0",   "match:twiss(at=ENTRANCE):alpha_b");
  register_attribute("eta_b0",     "match:twiss(at=ENTRANCE):eta_b");
  register_attribute("etap_b0",    "match:twiss(at=ENTRANCE):etap_b");

  register_attribute("beta_a1",    "match:twiss(at=EXIT):beta_a");
  register_attribute("alpha_a1",   "match:twiss(at=EXIT):alpha_a");
  register_attribute("eta_a1",     "match:twiss(at=EXIT):eta_a");
  register_attribute("etap_a1",    "match:twiss(at=EXIT):etap_a");
  register_attribute("beta_b1",    "match:twiss(at=EXIT):beta_b");
  register_attribute("alpha_b1",   "match:twiss(at=EXIT):alpha_b");
  register_attribute("eta_b1",     "match:twiss(at=EXIT):eta_b");
  register_attribute("etap_b1",    "match:twiss(at=EXIT):etap_b");

  register_attribute("dphi_a",     "match:twiss(at=EXIT):phi_a");
  register_attribute("dphi_b",     "match:twiss(at=EXIT):phi_b");

  register_attribute("superimpose",    "", IGNORE);
  register_attribute("ref_beginning",  "", IGNORE);
  register_attribute("ref_center",     "", IGNORE);
  register_attribute("ref_end",        "", IGNORE);
  register_attribute("ele_beginning",  "", IGNORE);
  register_attribute("ele_center",     "", IGNORE);
  register_attribute("ele_end",        "", IGNORE);
  register_attribute("reference",      "", IGNORE);
  register_attribute("offset",         "", IGNORE);
  register_attribute("ref",            "", IGNORE);

  register_attribute("group:command",        "", IGNORE);
  register_attribute("group:old_command",    "", IGNORE);
  register_attribute("group:value",          "@design");
  register_attribute("overlay:value",        "@design");

  register_attribute("tracking_method",      "methods:tracking_method@string");
  register_attribute("mat6_calc_method",     "methods:map_creation_method@string");
  register_attribute("symplectify",          "methods:symplectify@logical");
  register_attribute("integrator_order",     "methods:itegrator_order@value");
  register_attribute("num_steps",            "methods:num_steps");
  register_attribute("ds_step",              "methods:ds_step");
  register_attribute("rel_tol",              "methods:relative_tollerance");
  register_attribute("abs_tol",              "methods:absolute_tollerance");

  register_attribute("polarity",             "wiggler:polarity");

  register_attribute("patch:pz_offset",      "orientation:pz_offset");

  register_attribute("lcavity:gradient",     "rf_cavity:gradient");
  register_attribute("lcavity:gradient_err", "rf_cavity:gradient@err");
  register_attribute("eloss",                "rf_cavity:e_loss");
  register_attribute("rfcavity:voltage",     "rf_cavity:gradient", "# / ![length]", "# * ![length]");
  register_attribute("rf_frequency",         "rf_cavity:rf_freq");
  register_attribute("eloss",                "rf_cavity:e_loss");
  register_attribute("phi0",                 "rf_cavity:phase0");
  register_attribute("phi0_err",             "rf_cavity:phase0@err");
  register_attribute("dphi0",                "rf_cavity:phase0_offset");

  register_attribute("b_max",            "wiggler:wiggler_params:b_max");
  register_attribute("l_pole",           "wiggler:wiggler_params:length_pole");
  register_attribute("n_pole",           "wiggler:wiggler_params:length_pole", 
                                                 "![length] / #", IGNORE); 

  register_attribute("is_on",                "state@is_on");

  register_attribute("hkick",            "kicker:x_kick");
  register_attribute("vkick",            "kicker:y_kick");  
  register_attribute("bl_hkick",         "kicker:x_kick_u");
  register_attribute("bl_vkick",         "kicker:y_kick_u");  

  register_attribute("elseparator:hkick",    "electric_kicker:x_kick");
  register_attribute("elseparator:vkick",    "electric_kicker:y_kick");
  register_attribute("elseparator:bl_hkick", "electric_kicker:x_kick_u");
  register_attribute("elseparator:bl_vkick", "electric_kicker:y_kick_u");
  register_attribute("elseparator:gap",      "electric_kicker:gap");

  register_attribute("hkicker:bl_kick",  "kicker:x_kick_u");
  register_attribute("vkicker:bl_kick",  "kicker:y_kick_u");

  register_attribute("bend_sol_quad:bend_tilt", "bend:orientation:tilt");
  register_attribute("bend_sol_quad:x_quad",    "quadrupole:orientation:x_offset");
  register_attribute("bend_sol_quad:y_quad",    "quadrupole:orientation:y_offset");
  register_attribute("bend_sol_quad:quad_tilt", "quadrupole:orientation:tilt");
  register_attribute("bend_sol_quad:dks_ds",    "solenoid:dks");

  register_attribute("g",                "bend:g");
  register_attribute("g_err",            "bend:g@err");
  register_attribute("rho",              "bend:g", "1 / #", IGNORE);
  register_attribute("sbend:angle",      "bend:angle");

  register_attribute("b1_gradient",      "quadrupole:k_u");
  register_attribute("b2_gradient",      "sextupole:k_u");
  register_attribute("b3_gradient",      "octupole:k_u");
  register_attribute("b_field",          "bend:g_u");
  register_attribute("b_field_err",      "bend:g_u@err");
  register_attribute("bs_field",         "solenoid:ks_u");

  register_attribute("beambeam:sig_x",   "beambeam:sig_x");
  register_attribute("beambeam:sig_y",   "beambeam:sig_y");
  register_attribute("beambeam:sig_z",   "beambeam:sig_z");
  register_attribute("beambeam:n_slice", "beambeam:n_slice");
  register_attribute("beambeam:charge",  "beambeam:rel_charge");

  register_attribute("aperture",         "aperture:xy_limit");
  register_attribute("x1_limit",         "aperture:x_limit(side=-)");
  register_attribute("y1_limit",         "aperture:y_limit(side=-)");
  register_attribute("x2_limit",         "aperture:x_limit(side=+)");
  register_attribute("y2_limit",         "aperture:y_limit(side=+)");
  register_attribute("x_limit",          "aperture:x_limit");
  register_attribute("y_limit",          "aperture:y_limit");
  register_attribute("aperture_at",      "aperture@at");

  // Some AML stuff to ignore

  register_attribute("",    "beam[mass]", "", IGNORE);
  register_attribute("",    "beam[charge]", "", IGNORE);
  register_attribute("",    "beam[pc]", "", IGNORE);
  register_attribute("",    "beam[gamma]", "", IGNORE);
  register_attribute("",    "beam[emittance_a]", "", IGNORE);
  register_attribute("",    "beam[norm_emittance_a]", "", IGNORE);
  register_attribute("",    "beam[emittance_b]", "", IGNORE);
  register_attribute("",    "beam[norm_emittance_b]", "", IGNORE);
  register_attribute("",    "beam[emittance_z]", "", IGNORE);
  register_attribute("",    "beam[sig_t]", "", IGNORE);
  register_attribute("",    "beam[sig_e]", "", IGNORE);
  register_attribute("",    "beam[n_bunches]", "", IGNORE);
  register_attribute("",    "beam[n_particles]", "", IGNORE);
  register_attribute("",    "beam[bunch_current]", "", IGNORE);
  register_attribute("",    "beam[bunched@logical]", "", IGNORE);
  register_attribute("",    "beam[radiate@logical]", "", IGNORE);

  //

  register_param_value_conversion ("LINEAR_LATTICE", "LINEAR");
  register_param_value_conversion ("CIRCULAR_LATTICE", "CIRCULAR");
  register_param_value_conversion ("ENTRANCE_END", "ENTRANCE");
  register_param_value_conversion ("BOTH_ENDS", "BOTH");
  register_param_value_conversion ("EXIT_END", "EXIT");
  register_param_value_conversion ("f", "false");
  register_param_value_conversion ("t", "true");

  x_attribs_that_can_have_default << "tilt" << "fint"
            << "fintx" << "charge" << "radiate" << "bunched"
            << "superimpose" << "ref_beginning" << "ref_center" << "ref_end"
            << "ele_beginning" << "ele_center" << "ele_end";

  // Constants

  register_constant("degrad",         "pi",         "pi / 180", IGNORE);
  register_constant("raddeg",         "degrees",    "", IGNORE);
  register_constant("emass",          "m_electron", "m_electron * 1e-6", IGNORE);
  register_constant("pmass",          "m_proton",   "m_proton * 1e-6", IGNORE); 
  register_constant("clight",         "c_light",    "", IGNORE);

}
