/*
 * AMLParser
 * Universal Accelerator Parser
 * Copyright (C) 2006 Daniel Bates, David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   Daniel Bates <dbates@lbl.gov>
 *   David Sagan <dcs16@cornell.edu>
 */

#include "Translate/AMLParser.hpp"
#include "AML/AMLReader.hpp"

using namespace std;

//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------

AMLParser::AMLParser() : TranslateCore() {
  language = "AML"; 
  include_file_string = "'{http://www.w3.org/2001/XInclude}include':href";
}

UAPNode* AMLParser::XFileToAMLRep (const string& file_name, UAPNode* uap_root) {
  AMLReader* reader = new AMLReader;
  UAPNode* node = reader->AMLFileToAMLRep (file_name);
  delete reader;
  return node;
}

UAPNode* AMLParser::XFileToXRep (const string& file_name, UAPNode* uap_root) {
  AMLReader* reader = new AMLReader;
  UAPNode* node = reader->AMLFileToAMLRep (file_name);
  delete reader;
  return node;
}

UAPNode* AMLParser::XRepToAMLRep (UAPNode* x_root, UAPNode* aml_root) {
  throw;  // Not yet implemented
}

UAPNode* AMLParser::AMLRepToXFile (UAPNode* aml_root, const string& file_name, 
                                        const string& out_suffix, bool one_file) {
  return XRepToXFile (aml_root, file_name, out_suffix, one_file);
}

UAPNode* AMLParser::AMLRepToXRep (UAPNode* aml_root, UAPNode* x_root) {
  throw;  // Not yet implemented
}

UAPNode* AMLParser::XRepToXFile (UAPNode* x_root, const string& file_name, 
                                      const string& out_suffix, bool one_file) {
  // Set the file name

  UAPNode* aml_rep = x_root;
  if (aml_rep->getName() == "UAP_root") aml_rep = x_root->getChildByName("AML_representation");

  string this_file;

  if (file_name == "*") {
    string old_name = aml_rep->getAttributeString("filename");
    size_t n = old_name.find_last_of(".");
    if (n == string::npos) 
      this_file = old_name + out_suffix;
    else
      this_file = old_name.substr(0,n) + out_suffix;
  } else if (file_name != "") {
    this_file = file_name;
  }

  aml_rep->addAttribute("filename", this_file);

  // Change all the include files

  if (out_suffix != "") {
    Twig tinfo(include_file_string); 
    include_filename_replace_suffix (aml_rep, out_suffix, tinfo);
  }

  // Create the file

  AMLReader* reader = new AMLReader;
  aml_rep = reader->AMLRepToAMLFile (aml_rep, this_file, one_file);
  delete reader;
  return aml_rep;
}
