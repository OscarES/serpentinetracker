/*
* TranslateCore
* Universal Accelerator Parser
* Copyright (C) 2006 David Sagan
* 
* This library is free software; you can redistribute it and/or modify it
* under the terms of the GNU Lesser General Public License as published by
* the Free Software Foundation; either version 3 of the License, or (at
* your option) any later version. 
* 
* This library is distributed in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
* for more details. 
* 
* You should have received a copy of the GNU Lesser General Public License
* along with this library; if not, write to the Free Software Foundation, Inc., 
* 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
* 
* Direct questions, comments, etc to:
*   David Sagan (dcs16@cornell.edu)
*/

#ifndef TranslateCore_hpp
#define TranslateCore_hpp 1

#include "UAP/UAPNode.hpp"
#include "AML/Twig.hpp"
#include "AML/AMLUtilities.hpp"

//-----------------------------------------------------------------------

// This structure holds the information for translations of
// attribute names between X and AML.
// The components x_to_aml_template and aml_to_x_template are for
// cases where the conversion involves, for example, a change of units.

struct attribute_convert_struct {
                              // Eg: "sbend:angle" 
  Str x_parent;       //        -> x_parent = "sbend"
  Str x_name;         //        -> x_name   = "angle"
  Twig aml_twig;              // AML equivalent
  Str x_to_aml_template;
  Str aml_to_x_template;
};

struct constants_struct {
  Str x_const;
  Str aml_const;
  Str x_to_aml_template;
  Str aml_to_x_template;
};

// The bend_struct holds bend attributes and is used in the conversion from X to AML. 
// This structure is needed since the conversion from rbends to AML's l and g attributes 
// can be complicated. 
// To eliminate problems when bend attributes are set after the bend definition, constants
// may be defined outside the AML bend definition. 

// angle_const is the name of the angle constant which will be different from angle if
// l and g are being specified.

struct bend_struct {
  Str l_true;      // This is the true arc length with an rbend
  Str l;           // Input length. This is the chord length with an rbend
  Str g;           // Input g or rho.
  Str angle;       // Input angle
  Str angle_const; 
  Str e1;
  Str e2;
  bool complete;   // Have values for two of (l, angle, g) ?
  bool consts_constructed;

  bend_struct() : complete(false), consts_constructed(false) {};

};

typedef std::vector<attribute_convert_struct>               AttributeConvertVec;
typedef std::vector<attribute_convert_struct>::iterator     AttributeConvertVecIter;

typedef std::vector<constants_struct>               ConstantsVec;
typedef std::vector<constants_struct>::iterator     ConstantsVecIter;

typedef std::map<Str, bend_struct>                BendMap;

//-----------------------------------------------------------------------

struct param_value_struct {
  Str x_value;
  Str aml_value;
};

typedef std::vector<param_value_struct>             ParamValueStructVec;
typedef std::vector<param_value_struct>::iterator   ParamValueStructVecIter ;

//-----------------------------------------------------------------------

/** This class contains the methods that are shared by all the MAD-like 
* parsing classes. Currently: MAD-8, MAD-X, and Bmad.
*/

class TranslateCore {

public:

  /** Initializes internal variables.
  */
  TranslateCore();

  /** Searches for the file names specified in the &lt;include&gt; or 
  * &lt;call&gt; nodes in the given tree. The ending suffix (everything after
  * the last dot "." in the name) of these names are then replaced by replacement_suffix.
  * @param root                 Root of tree.
  * @param replacement_suffix   text to replace with.
  * @return                     true if everything OK. false otherwise.
  */ 
  bool ModifyIncludedFileNames (UAPNode* root, const Str& replacement_suffix);


  /** Reads in a X file (or files if there are include statements)
  * and constructs the appropriate X representation tree and AML representation tree.
  * The constructed trees have the root &lt;UAP_Root&gt;.
  * @param file_name   The root X file to use.
  * @param uap_root    The root of the UAP tree. If not present then
  *                    a new tree will be formed with the root called &lt;UAP_Root&gt;,
  * @return            The AML representation subtree root.
  */
  virtual UAPNode* XFileToAMLRep (const Str& file_name, UAPNode* uap_root = NULL);

  /** Reads in a X file (or files if there are include statements)
  * and constructs the appropriate  Representation tree.
  * The constructed UAP tree has the root &lt;_representation&gt;.
  * @param file_name   The root X file to use.
  * @param uap_root    The root of the subtree (typeically &lt;UAP_Root&gt;)
  * @return            The child of root that is the &lt;_representation&gt;.
  */
  virtual UAPNode* XFileToXRep (const Str& file_name, UAPNode* uap_root = NULL);

  /** Constructs from an X representation tree the corresponding AML representation tree.
  * @param x_root   May be a &lt;X_representation&gt; node or a &lt;UAP_root&gt; node.
  * @param aml_root    May be a &lt;AML_representation&gt; node or a 
  *                     &lt;UAP_root&gt; node, or NULL. If it is a &lt;UAP_root&gt; 
  *                     node then all existing &lt;AML_representation&gt; 
  *                     children are deleted. If it is NULL (the default) then, if
  *                     the x_root is a &lt;UAP_root&gt; or has a a &lt;UAP_root&gt;
  *                     parent, a &lt;AML_representation&gt; child is created.
  *                     Otherwise if x_root is NULL a new &lt;AML_representation&gt; 
  *                     node is created.
  * @return            &lt;AML_representation&gt; node.
  */
  virtual UAPNode* XRepToAMLRep (UAPNode* x_root, UAPNode* aml_root = NULL);

  /** Constructs a X file (or files) from a AML_representation tree.
  * Also the intermediate X representation tree is constructed.
  * If the argument one_file is set false, then the file names used for each included
  * file are obtained from the href attribute of the &lt;xi:include&gt; node.
  * See the ModifyIncludedFileNames routine.
  * @param aml_root    May be a &lt;AML_representation&gt; node or 
  *                     a &lt;UAP_root&gt; node.
  * @param file_name   The root X file to create. 
  *                        If not present or "" then the present file name will be used.
  *                        If "*" then use the out_suffix to replace the current suffix.
  * @param out_suffix  The suffix to use for include files in place of the current suffix.
  *                        The file suffix is defined as everything after and including the last ".".
  *                        If not present or "" then the present files name will be used.
  * @param one_file    If true then concatinate everything into one file. 
  *                        Default is false.
  * @return            X &lt;X_representation&gt; node.
  */
  virtual UAPNode* AMLRepToXFile (UAPNode* aml_root, 
                    const Str& file_name = "", const Str& out_suffix = "", bool one_file = false);

  /** Constructs from an AML representation tree
  * the corresponding X representation tree.
  * @param aml_root    May be a &lt;AML_representation&gt; node or 
  *                     a &lt;UAP_root&gt; node.
  * @param x_root   May be a &lt;X_representation&gt; node or a 
  *                     &lt;UAP_root&gt; node, or NULL. If it is a &lt;UAP_root&gt; 
  *                     node then all existing &lt;X_representation&gt; 
  *                     children are deleted. If it is NULL (the default) then, if
  *                     the aml_root is a &lt;UAP_root&gt; or has a a &lt;UAP_root&gt;
  *                     parent, a &lt;X_representation&gt; child is created.
  *                     Otherwise if x_root is NULL a new &lt;X_representation&gt; 
  *                     node is created.
  * @return            X &lt;X_representation&gt; node.
  */
  virtual UAPNode* AMLRepToXRep (UAPNode* aml_root, UAPNode* x_root = NULL);

  /** Creates a X file (or files if there are include statements)
  * from a X_representation tree.
  * If the argument one_file is set false, then the file names used for each included
  * file are obtained from the href attribute of the &lt;xi:include&gt; node.
  * See the ModifyIncludedFileNames routine.
  * @param x_root      May be a &lt;X_representation&gt; node or a &lt;UAP_root&gt; node.
  * @param file_name   The root X file to create. 
  *                        If not present or "" then the present file name will be used.
  *                        If "*" then use the out_suffix to replace the current suffix.
  * @param out_suffix  The suffix to use for include files in place of the current suffix.
  *                        The file suffix is defined as everything after and including the last ".".
  *                        If not present or "" then the present files name will be used.
  * @param one_file    If true then concatinate everything into one file. 
  *                        Default is false.
  * @return            X &lt;X_representation&gt; node.
  */
  virtual UAPNode* XRepToXFile (UAPNode* x_root, 
                const Str& file_name = "", const Str& out_suffix = "", bool one_file = false);

protected:

  /** Method to process statements read from an X-file that are unique to
  * the particular language under consideration.
  * @param word_list    List of words that make up the x-statement.
  * @param comment      Possible comment that went with the statement.
  * @param x_rep_root   Root node of the x-representation sub-tree.
  * @param recognized   True if the statement is recognized. False otherwise.
  */
  virtual bool custom_x_statement_to_x (StrList word_list, Str comment,
                                                              UAPNode* x_rep_root);

  virtual bool custom_x_add_attributes (StrList& word_list, Str ele_class, 
                             Str& attrib_name, UAPNode* x_ele_root);

  virtual bool custom_x_node_to_aml (UAPNode* x_node, UAPNode* aml_root, UAPNode* aml_node);

  virtual void custom2_x_element_attribute_to_aml (UAPNode* x_node, UAPNode* aml_node);

  virtual void custom_aml_rep_to_x (UAPNode* lab, UAPNode* x_node);

  virtual bool custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep);

  virtual bool custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele);

  virtual void custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_ele);

  virtual bool custom_x_element_to_x_file (UAPNode* x_node, Str& comment, 
                                                                StreamStruct& x_out);

  virtual void custom_x_ele_attributes_to_x_file (UAPNode* x_node, 
                                   const Str& ele_class, StreamStruct& x_out);

  virtual bool custom_x_element_attribute_to_aml (Str x_class, 
                                        UAPAttribute ia, UAPNode* aml_node);

  virtual bool custom_aml_sector_or_element_to_x (UAPNode* aml_sector,
                                                                  UAPNode* x_root);

  virtual void custom_x_attrib_to_x_file_translate (Str& attrib_name, Str& attrib_value);

  Str continuation_char;
  Str language;         // "Bmad", "XSIF", "MAD8", or "MADX" 
  bool c_style_format;
  bool abbreviations_permitted;
  bool knl_tn_style_multipoles; // Multipoles (including quadrupoles, etc.) specified by KnL and Tn? (EG: MAD8).

  static const int N_MULTIPOLE = 21;
  Str IGNORE;

  enum CaseConvert {TO_LOWER, NO_CONVERT, TO_UPPER};

  StrMap x_class_to_aml_map;

  // Used to map the name of an element to the X class it is assigned to ("quadrupole", "sbend", etc.).

  StrMap name_to_x_class_map;

  // name_to_x_type_map is used when converting X to AML. Maps a name to one of: 
  // "line", "list", "sequence", "overlay", "group", or "element".

  StrMap name_to_x_type_map;          

  // name_to_aml_type_map is used when converting AML to X. Maps a name to one of: 
  // "sector", "list", "sequence", "lattice", "beam", "parameter", "controller", or "element".

  StrMap name_to_aml_type_map; 

  // Map quad, sextupole, or octupole name to k, ks, and tilt values.

  StrMap aml_k_map, aml_ks_map, aml_tilt_map; 

  // Map multipole name to k, ks, and tilt values.

  StrVecMap aml_multi_kl_map, aml_multi_ksl_map, aml_multi_tilt_map; 

  // Maps from bend name to bend X parameters

  BendMap bend_map;

  // 

  StrVec aml_ignore_these_attribs;
  StrVec aml_class_names;
  StrVec x_param_names;
  StrVec aml_param_names;
  StrVec line_or_list_names;
  StrVec x_attribs_that_can_have_default;
  StrVec x_attributes_needing_quote_marks;   
  StrVec x_attributes_to_upper_case;         // Eg: "beam, particle = POSITRON"
  StrVec x_attributes_no_case_change;        // Eg: type = "My Description"
  Str use_line;                       // Store line used.

  NodeMap name_to_aml_node_map;  
  NodeMap name_to_x_node_map;    

  NodeVec aml_set_nodes;
  NodeVec x_set_nodes;

  UAPNode* use_parent;              
  UAPNode* aml_lab_root;

  PrintInfoStruct info_out;

  EndStruct fini;
  bool in_sequence;
  UAPNode* seq_node;

  AttributeConvertVec attribute_list;
  ParamValueStructVec param_values_list;
  ConstantsVec constants_list;

  StrVecMap map_element_to_attribs;

  Str include_file_string;

  // x-file to x-rep methods

  void x_file_to_x (UAPNode* input_node, Str file_name, 
                                  FileStackList this_file_stack);
  void add_word_to_list (Str& word, StrList& word_list);
  void x_statement_to_x (StrList& word_list, Str comment, 
                      UAPNode* x_rep_root, char& string_delim, 
                      bool& close_file, int ix_line, FileStackList this_file_stack);
  Str next_word (StrList& word_list, CaseConvert this_case = TO_LOWER);
  bool valid_attribute (const Str& ele_class, Str& name);
  bool valid_variable (const Str& var);

  bool parse_this_line_or_list (StrList& word_list, UAPNode* seq_root);
  bool parse_this_line_or_list_element (StrList& word_list, UAPNode* seq_root);
  bool get_args (StrList& word_list, Str& args);
  void x_add_attributes (StrList& word_list, Str ele_class, UAPNode* x_ele_root);
  bool x_attribute_can_have_default (Str attrib_name);
  Str named_x_class (const Str& name);
  Str ele_name_to_x_class (const Str& name, bool include_param_names = false);
  Str concat_value_expression (StrList& word_list, CaseConvert this_case, Str& value);
  CaseConvert x_attribute_case(const Str& attrib_name);

  // x-rep to aml-rep methods

  void x_rep_to_aml_init (UAPNode* x_rep);
  void x_rep_make_name_lists (UAPNode* x_rep);
  void x_rep_to_aml (UAPNode* x_rep_root, UAPNode* lab);
  void x_node_to_aml (UAPNode* x_ele, UAPNode* aml_root, UAPNode* aml_node, 
                        const Str& ignore_this1 = "", const Str& ignore_this2 = "");
  bool x_to_aml_sector (UAPNode* x_line, UAPNode* aml_sector, StrList& arg_list);
  Str x_expression_to_aml (const Str& x_expression,
    attribute_convert_struct attrib_info = attribute_convert_struct(), const Str& ele_name = "");
  void x_parameter_to_aml (UAPNode* x_param_node, UAPNode* aml_root);
  void x_element_attributes_to_aml (UAPNode* x_node, UAPNode* aml_root, UAPNode* aml_node, 
                    const Str& ignore_this1 = "", const Str& ignore_this2 = "");
  bool found_x_attrib (const Str& x_class, const Str& x_attrib,
                                                            attribute_convert_struct& at);
  Str x_node_to_x_class (UAPNode* x_ele);

  // aml-rep to x-rep methods

  void aml_rep_to_x_init (UAPNode* x_rep);
  void aml_rep_make_name_lists (UAPNode* aml_rep);
  void aml_rep_to_x (UAPNode* lab, UAPNode* x_node);
  void aml_node_to_x (UAPNode* aml_ele, UAPNode* x_root, const Str& ignore_this_attribute = "");
  void aml_sector_or_element_to_x (UAPNode* aml_sector, UAPNode* x_root);
  void aml_element_attributes_to_x (UAPNode* aml_root, UAPNode* aml_ele, UAPNode* x_ele, 
                                                            const Str& ignore_this_attribute = "");
  void aml_param_to_x (UAPNode* aml_root, UAPNode* aml_param, UAPNode* x_rep);
  Str aml_expression_to_x (const Str& expression, 
    attribute_convert_struct attrib_info = attribute_convert_struct(), const Str& ele_name = "");
  bool found_aml_attrib (const Str& x_class, UAPNode* aml_root, 
                 UAPNode* aml_attrib_node, const Str& design_name, attribute_convert_struct& at);
  bool found_aml_attrib (const Str& x_class, const Str& aml_attrib, attribute_convert_struct& attrib_info);

  // x-rep to x-file methods

  bool x_rep_to_x_file (UAPNode* x_rep, const Str& file_name, 
                        bool one_file, StreamStruct& x_out, FileStackList file_stack);
  void write_line_or_list_to_x_file(UAPNode* line_node, Str separator_str, StreamStruct& x_out);
  void x_add_quote_marks (const Str& name, Str& value);
  Str add_comment_token (const Str& str);
  void include_filename_replace_suffix (UAPNode* node, 
                                   const Str& out_suffix, const Twig& info);

  // Init stuff

  void register_attribute (Str x, Str aml, Str x_to_aml_template = "", Str aml_to_x_template = "");
  void register_constant (const Str& x, const Str& aml, 
            const Str& x_to_aml_template = "", const Str& aml_to_x_template = "");
  void register_param_value_conversion (const Str& x, const Str& aml);

  // misc

  bool modify_file_names (const Str& node_name, 
        const Str& attrib_name, UAPNode* root, const Str& replace_str);
  bool transfer_attribute(UAPNode* ele_in, const Str& attrib_in, 
                                    UAPNode* ele_out, const Str& attrib_out);
  Str convert_single_attribute (Str expression, Str forward_template = "", 
                                   Str back_template = "", Str ele_name = "");
  Str next_token_in_expression (Str expression, bool c_style, size_t& i0, size_t& n);
  void init_lists_core();
  void init_lists_mad();

  /** Finds the Bmad class (Eg: sol_quad, rfcavity, etc.) of an element.
  * @param aml_ele    Element node
  * @param x_class    Class of element
  * @return           True if a class is found. False otherwise
  */
  virtual bool aml_ele_to_x_class (UAPNode* aml_ele, Str& x_class);

  /** Translates a multipole component given by k_in, ks_in, and tilt_in and eliminates
  * ks_in to give the multipole solely in terms of k and tilt.
  * Note: If k is zero the output string is blank (""). Similarly with tilt.
  * @param k_in       Input normal component.
  * @param ks_in      Input skew component.
  * @param tilt_in    Input multipole tilt.
  * @param n          Input multipole order.
  * @param k          Output normal component.
  * @param tilt       Output tilt.
  */
  void multipole_to_k_tilt (Str k_in, Str ks_in, Str tilt_in, 
                                              Str n, Str& k, Str& tilt);

  /** Translates a multipole component given by k_in, ks_in, and tilt_in and eliminates
  * tilt_in to give the multipole solely in terms of k and ks.
  * Note: If k is zero the output string is blank (""). Similarly with tilt.
  * @param k_in       Input normal component.
  * @param ks_in      Input skew component.
  * @param tilt_in    Input multipole tilt.
  * @param n          Input multipole order.
  * @param k          Output normal component.
  * @param ks         Output ks.  
  */
  void multipole_to_k_ks (Str k_in, Str ks_in, Str tilt_in, 
                                              Str n, Str& k, Str& ks);


  /** Translation of multipole parameters, either from a multipole, quadrupole, sextupole, 
  & or octupole, from AML to X is tricky since in AML you can specify
  * (k, ks, tilt) while in X you generally specify (k, ks) or (k, tilt). 
  * Now given values for (k, ks, tilt) for an element, there are standard formula
  * that can be used to convert to (k, tilt) or (k, ks) as given in the AML manual.
  *
  * However, there is an additional complication in that elements can inherit parameters from 
  * other elements and the setting of parameters can happen after an element has been defined.
  * To see why this is a problem, consider the following example: 
  * A base element, call it q0, specifies a tilt which will be called it q0::tilt. 
  * Another element, call it q1, inherits from q0 and additionally specifies a k1 (called q1:k1).
  * Assume that the X representation wants to see things specified by (k, ks). 
  * When the parameters from q0 are converted to X, we have q0::k(X) = 0 and q0::ks(X) = 0! 
  * When the parameters from q1 are converted we have q1::k1(X) = q1::k1(AML) and q1::ks(X) = 0. 
  * Thus in the X rep, q1 does not have a skew component but in AML there is one (since it will
  * inherit a tilt from q0).
  *
  * The solution involves some bookkeeping: 
  * First, the (k, ks, tilt) parameters are saved For each element.
  * For quadrupoles, sextupoles, and octupoles the storage is in:
  *   aml_k_map[ele_name]    -> k value string
  *   aml_ks_map[ele_name]   -> ks value string
  *   aml_tilt_map[ele_name] -> tilt value string 
  * ele_name is the name of the element.
  * For multipoles this is in:
  *   aml_multi_kl_map[ele_name]   -> kl value string vector
  *   aml_multi_ksl_map[ele_name]  -> ksl value string vector
  *   aml_multi_tilt_map[ele_name] -> tilt value string vector
  * ele_name is the name of the multipole element.
  *
  * [It is important to note here that if q1 inherits from q0, then
  * q0 must be defined first, also sets must be done after an element is defined.]
  * 
  * As the elements are precessed in order, if the element does not inherit from a 
  * base element then the conversion from AML (k, ks, tilt) to X values is straight forward.
  * 
  * If an element does inherit from a base element, the following procedure is used:
  *
  * If it is "required" (defined below), the (k, ks, tilt) values from the base element 
  * are transfered to the current element for each k, ks, or tilt that is defined in 
  * the base element but not defined in the current element. 
  * The conversion from (k, ks, tilt) to X is now done.
  *
  * If it is not "required", the AML (k, ks, tilt) values are converted to X
  * ignoring the base element.
  *
  * After the conversion to X, in both required and non-required cases, 
  * the values from the base element are transferred to the maps that save the parameters. 
  * This is done in case a future element inherits from the current element.
  *
  * Note that even in the non-required case it would be technically OK to transfer 
  * the base values to the current element. 
  * That is, the correct X parameters would be produced. There are several reasons not to, 
  * for one, the transfer can potentially be confusing to someone looking at the output.
  *
  * Now to define "required": It is required to transfer when the multipole in the X 
  * representation and the multipole in the AML representation are not equivalent. 
  * Specifically, when the X representation is (k, ks), it is required if all of the 
  * following conditions apply:
  *   1) At least one of the k, ks or tilt is defined in the current element, and
  *   2) The element tilt or the base tilt is defined.
  * When the X representation is (k, tilt), substitute "ks' for "tilt" in condition (2) above.
  *
  * Note: for multipoles the procedure is the same as the above with each order n 
  * being processed separately.
  */ 

  void required_multipole_transfer (const Str& odd_man_out, const Str& k_base, 
             const Str& ks_base, const Str& tilt_base, Str& k_ele, Str& ks_ele, Str& tilt_ele); 

private:

  AMLUtilities AU;


};

#endif
