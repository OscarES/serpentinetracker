/*
 * BmadParser
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 */

#ifndef BmadParser_hpp
#define BmadParser_hpp 1

#include "Translate/TranslateCore.hpp"

//-----------------------------------------------------------------------

class BmadParser : public TranslateCore {
public:

  /** Constructs from an X representation tree the corresponding AML representation tree.
  * @param x_root   May be a &lt;X_representation&gt; node or a &lt;UAP_root&gt; node.
  * @param aml_root    May be a &lt;AML_representation&gt; node or a 
  *                     &lt;UAP_root&gt; node, or NULL. If it is a &lt;UAP_root&gt; 
  *                     node then all existing &lt;AML_representation&gt; 
  *                     children are deleted. If it is NULL (the default) then, if
  *                     the x_root is a &lt;UAP_root&gt; or has a a &lt;UAP_root&gt;
  *                     parent, a &lt;AML_representation&gt; child is created.
  *                     Otherwise if x_root is NULL a new &lt;AML_representation&gt; 
  *                     node is created.
  * @return            &lt;AML_representation&gt; node.
  */
  UAPNode* XRepToAMLRep (UAPNode* x_root, UAPNode* aml_root = NULL);

  /** Initializes internal variables.
  */
  BmadParser();

protected:

  void init_lists_bmad ();
  bool lcavity_found;    // Lattice contains an lcavity element?
  bool lattice_type_set; // Has the lattice type been set in the lattice?
  StrVec n_factorial;

  /** Finds the Bmad class (Eg: sol_quad, rfcavity, etc.) of an element.
  * @param aml_ele    Element node
  * @param x_class    Class of element
  * @return           True if a class is found. False otherwise
  */
  bool aml_ele_to_x_class (UAPNode* aml_ele, Str& x_class);

  bool custom_x_statement_to_x (StrList word_list, Str comment, UAPNode* file_root);

  bool custom_x_add_attributes (StrList& word_list, Str ele_class, 
                             Str& attrib_name, UAPNode* x_ele_root);

  bool custom_x_node_to_aml (UAPNode* x_node, UAPNode* aml_root, UAPNode* aml_node);

  void custom2_x_element_attribute_to_aml (UAPNode* x_node, UAPNode* aml_node);

  void custom_aml_rep_to_x (UAPNode* lab, UAPNode* x_node);

  void set_overlay_group_slave_attribute (UAPNode* x_rep, bool& resolved_all);

  bool custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep);

  bool custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele);

  void custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_rep);

  bool custom_x_element_to_x_file (UAPNode* x_node, Str& comment, StreamStruct& x_out);

  bool custom_x_element_attribute_to_aml (Str x_class, UAPAttribute x_attrib, UAPNode* aml_node);

  void custom_x_ele_attributes_to_x_file (UAPNode* x_node, const Str& ele_class, StreamStruct& x_out);

  bool custom_aml_sector_or_element_to_x (UAPNode* aml_sector, UAPNode* x_root);

  Str divide_by_n_factorial (int n, Str k);

};


#endif
