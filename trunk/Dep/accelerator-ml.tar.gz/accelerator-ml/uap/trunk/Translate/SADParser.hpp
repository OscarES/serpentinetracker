/*
 * SADParser
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 */

#ifndef SADParser_hpp
#define SADParser_hpp 1

#include "Translate/TranslateCore.hpp"

//-----------------------------------------------------------------------

class SADParser : public TranslateCore {
public:

  /** Initializes internal variables.
  */
  SADParser();

private:

  StrVec a_vec;
  StrVec b_vec;

  // data

  // methods

  void init_lists_sad ();

  bool aml_ele_to_x_class (UAPNode* aml_ele, std::string& x_class);

  bool custom_x_element_to_x_file (UAPNode* x_node, std::string& comment, 
                                                            StreamStruct& x_out);


// multipole
  bool custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep); 
  bool custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele);
  void custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_rep);



  void custom_aml_rep_to_x (UAPNode* lab, UAPNode* x_rep);




};

#endif
