#include "Translate/MADXParser.hpp"

using namespace std;
using namespace BasicUtilities;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

MADXParser::MADXParser() : TranslateCore() {

  language = "MADX"; 
  include_file_string = "call:filename";
  continuation_char =  "";
  knl_tn_style_multipoles = false;
  c_style_format = true;
  abbreviations_permitted = false;

  x_attributes_to_upper_case << "apertype";
  
  init_lists_madx();
  init_lists_mad();
  init_lists_core();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_x_statement_to_x (StrList word_list, string comment,
                                                              UAPNode* x_rep_root) {

  // No custom statements have less than three words.

  if (word_list.size() < 3) return false; // Unrecognized

  // Get rid of beginning "const", "real", and/or "int".

  string word1 = next_word(word_list);  

  while (true) {
    if (word1 == "const" || word1 == "real" || word1 == "int") {
      word1 = next_word(word_list);  
      continue;
    } 
    break;
  }

  //

  if (word_list.size() < 2) return false; // Unrecognized
  
  string word2 = next_word(word_list);  
  string word3 = next_word(word_list);  

  // Statement where the second word is "=" defines a constant

  if (word2 == "=") {
    UAPNode* node = x_rep_root->addChild("constant");
    node->addAttribute("name", word1);
    while (word_list.size() != 0) word3 += next_word(word_list); // concat
    node->addAttribute("design", word3);
    if (comment != "") node->addAttribute("comment", comment);
    return true;
  }

  // use statement

  if (word1 == "use") {
    UAPNode* node = x_rep_root->addChild(word1);
    while (true) {
      if (word_list.size() < 2 || word2 != "," || next_word(word_list) != "=") {
        info_out.error ("Malformed USE Statement");
        return true;
      }
      if (word3 == "period") 
        node->addAttribute("line", next_word(word_list));
      else if (word3 == "range") 
        node->addAttribute("range", next_word(word_list));
      else {
        info_out.error ("Unknown USE argument: " + word3);
        return true;
      }
      if (word_list.size() == 0) break;
      word2 = next_word(word_list);
      word3 = next_word(word_list);
    }
    return true;
  } 

  // If word2 is "->" then this is an attribute set or 
  // parameter, beginning, or beam_start statement.

  string value;
  if (word2 == "->") {
    value = next_word(word_list);
    if (value == ":") value = next_word(word_list);
    if (value != "=") {
      info_out.error ("Missing or misplaced \"=\"");
      return true;  // Recognized;
    }
    value = next_word(word_list);
    while (word_list.size() != 0) value += next_word(word_list);

    if (word1 == "parameter" || word1 == "beginning" || word1 == "beam_start") {
      UAPNode* node = x_rep_root->addChild(word1);
      node->addAttribute(word3, value);
    } else {
      UAPNode* node = x_rep_root->addChild("set");
      node->addAttribute("element", word1);
      node->addAttribute("attribute", word3);
      node->addAttribute("value", value);
    }
    return true;  // Recognized;
  }

  // Otherwise unrecognized

  return false; // Unrecognized

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_x_add_attributes (StrList& word_list, string ele_class, 
                                    string& attrib_name, UAPNode* x_ele_root) {

  // aperture, knl and ksl attributes are in the form "{....}". 
  // Strip off these brackets.

  if (attrib_name == "aperture" || 
        (ele_class == "multipole" && (attrib_name == "knl" || attrib_name == "ksl"))) {

    if (word_list.size() < 4 || 
               (next_word(word_list) != "=" || next_word(word_list) != "{")) {
      info_out.error ("MALFORMED " + attrib_name + " ATTRIBUTE.");
      return true;
    }

    string value;
    while (true) {
      if (word_list.size() == 0) {
        info_out.error ("NO CLOSING \"}\" FOUND IN ATTRIBUTE: " + attrib_name);
        return true;
      }
      string word = next_word(word_list);
      if (word == "}") break;
      value += word;
      if (word == ",") value += " ";
    }

    x_ele_root->addAttribute(attrib_name, value); 
    return true;  // Recognized
  }

  // Not recognized

  return false; // Unrecognized
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_x_node_to_aml (UAPNode* x_node, UAPNode* aml_root, UAPNode* aml_ele) {

  // Multipole <set> needs to be handled.

  if (x_node->getName() == "set") {
    string attrib = x_node->getAttributeString("attribute");
    string value = x_node->getAttributeString("value");
    string val1;
    if (attrib == "knl" || attrib == "ksl") {
      for (int n = 0;; n++) {
        size_t ix_comma = value.find(",");
        if (ix_comma == string::npos) {
          val1 = value;
          value = "";
        } else {
          val1 = trim(value.substr(0,ix_comma));
          value.erase(0,++ix_comma);
        }
        if (val1.find_first_not_of("0. ") != string::npos) {
          UAPNode* aml_node = aml_ele->addChild("set");
          string n_str = int_to_string(n);
          string name = x_node->getAttributeString("element");
          if (attrib == "knl") {
            aml_node->addAttribute("attribute", name + "[multipole:kl(n=" + n_str + ")]");
          } else {
            aml_node->addAttribute("attribute", name + "[multipole:ksl(n=" + n_str + ")]");
          }
          aml_node->addAttribute("value", val1); 
        }
        if (value == "") break;
      }
    
    return true;
    }
  }

  // not recognized.

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_x_element_attribute_to_aml (string x_class, 
                                        UAPAttribute ia, UAPNode* aml_node) { 

  string attrib_name = ia.getName();
  string attrib_value = ia.getValue();

  // multipole: custom2_x_element_attribute_to_aml will handle everything.

  if (attrib_name == "aperture" || 
        (x_class == "multipole" && (attrib_name == "knl" || attrib_name == "ksl"))) {
    return true;
  }

  // apertype attribute

  if (attrib_name == "apertype") {
    if (attrib_value != "CIRCLE" && attrib_value != "ELLIPSE" && 
                                         attrib_value != "RECTANGLE") {
      info_out.error ("NO CORRESPONDING APERTURE TYPE FOR: " + attrib_value);
    }
    return false;
  }

  // Not recognized

  return false; // Unrecognized

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void MADXParser::custom2_x_element_attribute_to_aml (UAPNode* x_node, UAPNode* aml_node) {

  bool ok;
  string x_class = x_node_to_x_class (x_node);

  // Multipole components

  if (x_class == "multipole") {

    // Get <multipole> node

    UAPNode* m_node = aml_node->getChildByName("multipole", true);

    // Get knl and ksl attributes and convert

    StrList knl_list, ksl_list; 

    AttributeVec a_list = x_node->getAttributes();
    for (AttributeVecCIter ia = a_list.begin(); ia != a_list.end(); ia++) {

      string attrib_name = ia->getName();
      string attrib_value = ia->getValue();

      if (attrib_name != "knl" && attrib_name != "ksl") continue;

      for (int n = 0;; n++) {
        size_t ix_comma = attrib_value.find(",");
        string val = trim(attrib_value.substr(0,ix_comma));
        if (val.find_first_not_of("0. ") != string::npos) {
          if (attrib_name == "knl") {
            UAPNode* knl_node = m_node->addChild("kl");
            knl_node->addAttribute("n", int_to_string(n));
            knl_node->addAttribute("design", val);
          } else if (attrib_name == "ksl") {
            UAPNode* ksl_node = m_node->addChild("ksl");
            ksl_node->addAttribute("n", int_to_string(n));
            ksl_node->addAttribute("design", val);
          }
        }
        if (ix_comma == string::npos) break;
        attrib_value.erase(0,++ix_comma);
      }
    }

    return;
  }

  //

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep) {

  bool ok;

  // set

  if (aml_ele->getName() == "set") {
    Twig twig;
    if (!twig.fromString(aml_ele->getAttributeString("attribute"))) return false;
    string ele_name = twig.name;
    string x_class = ele_name_to_x_class(ele_name);

    if (twig.nodeid_vec.size() != 2) return false;
    string n0 = twig.nodeid_vec[0].name, n1 = twig.nodeid_vec[1].name;

    // Multipole set

    if (n0 == "multipole" && (n1 == "kl" || n1 == "ksl" || n1 == "tilt")) { 
      string n = twig.nodeid_vec[1].attribute[0].value;
      int n_int = string_to_int(n);
      if (!ok) {
        info_out.error ("Bad multipole integer order: " + n, 
                       "In AML element:", aml_ele->toStringTree());
        return true;
      }
      string ele_name = twig.name;

      string kl_set, ksl_set, tilt_set;
      string value = aml_ele->getAttributeString("value");
      if (n1 == "kl")        kl_set = value;
      else if (n1 == "ksl")  ksl_set = value;
      else if (n1 == "tilt") tilt_set = value;

      string kl_ele, ksl_ele, tilt_ele;
      if (found (aml_multi_tilt_map, ele_name)) {
        kl_ele   = aml_multi_kl_map[ele_name][n_int];
        ksl_ele  = aml_multi_ksl_map[ele_name][n_int];
        tilt_ele = aml_multi_tilt_map[ele_name][n_int];
        required_multipole_transfer ("tilt", kl_ele, ksl_ele, tilt_ele, 
                                             kl_set, ksl_set, tilt_set);
      } else {  // Init if needed
        aml_multi_kl_map[ele_name]   = StrVec(N_MULTIPOLE);
        aml_multi_ksl_map[ele_name]  = StrVec(N_MULTIPOLE);
        aml_multi_tilt_map[ele_name] = StrVec(N_MULTIPOLE);
      }

      string knl, ksl;
      multipole_to_k_ks (kl_set, ksl_set, tilt_set, n, knl, ksl);

      if (knl != "") {
        string prefix = "";
        for (int i = 0; i < n_int; i++) {
          if (aml_multi_kl_map[ele_name][i] == "")
            prefix += "0, ";
          else
            prefix += aml_multi_kl_map[ele_name][i] + ", ";
        }
        UAPNode* x_set = x_rep->addChild("set");
        x_set->addAttribute("element", ele_name);
        x_set->addAttribute("attribute", "knl");
        x_set->addAttribute("value", prefix + knl);
      }

      if (ksl != "") {
        string prefix = "";
        for (int i = 0; i < n_int; i++) {
          if (aml_multi_ksl_map[ele_name][i] == "")
            prefix += "0, ";
          else
            prefix += aml_multi_ksl_map[ele_name][i] + ", ";
        }
        UAPNode* x_set = x_rep->addChild("set");
        x_set->addAttribute("element", ele_name);
        x_set->addAttribute("attribute", "ksl");
        x_set->addAttribute("value", prefix + ksl);
      }

      // record value for next set.
      if (n1 == "kl")        aml_multi_kl_map[ele_name][n_int]   = value;
      else if (n1 == "ksl")  aml_multi_ksl_map[ele_name][n_int]  = value;
      else if (n1 == "tilt") aml_multi_tilt_map[ele_name][n_int] = value;

      return true;
    }

  }    

  // We want TranslateCore to keep on going...

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_aml_sector_or_element_to_x (UAPNode* aml_sec_or_ele, 
                                            UAPNode* x_rep) {

  // If the sector has a length then turn it into a sequence.

  string aml_name = aml_sec_or_ele->getName();

  if (aml_name == "sector" && aml_sec_or_ele->getAttribute("length")) {

    string length = aml_sec_or_ele->getAttributeString("length");

    // Make a sequence out of it

    UAPNode* x_seq = x_rep->addChild("sequence");
    x_seq->addAttribute("name", aml_sec_or_ele->getAttributeString("name"));
    x_seq->addAttribute("l", length);

    if (aml_sec_or_ele->getChildren().size() == 0) return true;

    // The refer attribute is obtained from the first element in the sequence

    UAPNode* super_node = aml_sec_or_ele->getChildren().front()->getChildByName("superimpose");
    if (!super_node) {
      info_out.error ("No superimpose found for sector with a length attribute: " +
                    aml_sec_or_ele->toStringTree());
      return true;
    }

    string ele_origin0 = super_node->getAttributeString("ele_origin");
    string refer;
    if (ele_origin0 == "ENTRANCE") {
      refer = "enter";
    } else if (ele_origin0 == "CENTER") {
      refer = "centre";
    } else if (ele_origin0 == "EXIT") {
      refer = "exit";
    }
    if (refer != "") x_seq->addAttribute("refer", refer);
    if (ele_origin0 == "") ele_origin0 = "CENTER";

    // Loop over all elements

    NodeVec eles = aml_sec_or_ele->getChildren();
    for (NodeVecCIter ie = eles.begin(); ie != eles.end(); ie++) {
      UAPNode* aml_seq_ele = *ie;
      UAPNode* x_seq_ele;

      // If the aml child has a "ref" attribute:  Convert to <element> or <sequence>
      // If the aml child has a "name" attribute: Convert to <element>

      if (aml_seq_ele->getAttribute("ref")) {
        x_seq_ele = x_seq->addChild("element");
        if (aml_seq_ele->getName() == "sector") x_seq_ele->setName("sequence");
        x_seq_ele->addAttribute("ref", aml_seq_ele->getAttributeString("ref"));

      } else {  // has a name attribute
        UAPNode* temp = x_rep->addChildCopy(aml_seq_ele);
        temp->getChildByName("superimpose")->deleteNode();
        aml_node_to_x (temp, x_seq);
        temp->deleteNode();
        x_seq_ele = x_seq->getChildren().back();
      }

      super_node = aml_seq_ele->getChildByName("superimpose");
      if (!super_node) {
        info_out.error ("No superimpose found for sector with a length attribute: " +
                    aml_sec_or_ele->toStringTree());
        continue;
      }

      string ele_origin = super_node->getAttributeString("ele_origin");
      if (ele_origin == "") ele_origin = "CENTER";
      if (ele_origin != ele_origin0) {
        info_out.error ("Bad \"ele_origin\" attribute for conversion to a sequence.",
                     "Must be all the same for all sub-elements.",
                      aml_sec_or_ele->toStringTree());
        return true;
      }

      if (super_node->getAttribute("ref_origin")) {
        info_out.error ("Bad \"ref_origin\" attribute for conversion to a sequence.",
                     "This attribute cannot be present.",
                      aml_sec_or_ele->toStringTree());
        return true;
      }

      string offset = super_node->getAttributeString("offset");
      super_node->deleteNode();
      x_seq_ele->addAttribute("at", offset);

    }

    return true;
  }

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele) {

  string aml_parent_name = aml_ele->getName();  
  string ele_name = x_ele->getAttributeString("name");
  string aml_attrib_name = aml_attrib->getName();
  string aml_attrib_value = aml_attrib->getAttributeString("design");

  // Aperture

  if (aml_attrib_name == "x_limit") {
    x_limit = aml_attrib_value;
    return true;
  } else if (aml_attrib_name == "y_limit") {
    y_limit = aml_attrib_value;
    return true;
  } else if (aml_attrib_name == "xy_limit") {
    xy_limit = aml_attrib_value;
    return true;
  }

  // Unrecognized.

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void MADXParser::custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_ele) {

  string aml_attrib_name = aml_ele->getName();
  string ele_name = x_ele->getAttributeString("name");

  // Multipole

  if (aml_attrib_name == "multipole" && found(aml_multi_kl_map, ele_name)) {

    string inherit = x_ele->getAttributeString("inherit");
    if (aml_multi_kl_map.find(inherit) == aml_multi_kl_map.end()) inherit = "";

    StrVec knl_vec(N_MULTIPOLE), ksl_vec(N_MULTIPOLE);

    for (int n = 0; n < N_MULTIPOLE; n++) {
      string kl_base, ksl_base, tilt_base, kl_ele, ksl_ele, tilt_ele;
      if (inherit != "") {
        kl_base   = aml_multi_kl_map[inherit][n];
        ksl_base  = aml_multi_ksl_map[inherit][n];
        tilt_base = aml_multi_tilt_map[inherit][n];
      }
      kl_ele   = aml_multi_kl_map[ele_name][n];
      ksl_ele  = aml_multi_ksl_map[ele_name][n];
      tilt_ele = aml_multi_tilt_map[ele_name][n];
      string knl, ksl, n_str = int_to_string(n);
      if (inherit != "") required_multipole_transfer ("tilt", 
                              kl_base, ksl_base, tilt_base, kl_ele, ksl_ele, tilt_ele); 

      multipole_to_k_ks (kl_ele, ksl_ele, tilt_ele, n_str, knl_vec[n], ksl_vec[n]);

      if (inherit != "") {
        if (kl_ele   == "") aml_multi_kl_map[ele_name][n]   = kl_base;
        if (ksl_ele  == "") aml_multi_ksl_map[ele_name][n]  = ksl_base;
        if (tilt_ele == "") aml_multi_tilt_map[ele_name][n] = tilt_base;
      }

    }

    // Find maximum order needed

    int n_knl_max(-1), n_ksl_max(-1);
    for (int i = 0; i < N_MULTIPOLE; i++) {
      if (knl_vec[i] != "") n_knl_max = i;
      if (ksl_vec[i] != "") n_ksl_max = i;
    }    

    // Construct vectors

    string knl_tot, ksl_tot;

    for (int n = 0; n < N_MULTIPOLE; n++) {

      if (n <= n_knl_max) { 
        if (knl_vec[n] == "") knl_tot += "0";
        else                  knl_tot += knl_vec[n];
      }

      if (n <= n_ksl_max) { 
        if (ksl_vec[n] == "") ksl_tot += "0";
        else                  ksl_tot += ksl_vec[n];
      }

      if (n < n_knl_max) knl_tot += ", ";
      if (n < n_ksl_max) ksl_tot += ", ";

    }

    if (knl_tot != "") x_ele->addAttribute("knl", knl_tot);
    if (ksl_tot != "") x_ele->addAttribute("ksl", ksl_tot);

  }


  // quadrupole, sextupole, octupole

  if (aml_attrib_name == "quadrupole" && found(aml_k_map, ele_name)) {
    if (aml_k_map[ele_name] != "")    x_ele->addAttribute("k1", aml_k_map[ele_name]);
    if (aml_ks_map[ele_name] != "")   x_ele->addAttribute("k1s", aml_ks_map[ele_name]);
    if (aml_tilt_map[ele_name] != "") x_ele->addAttribute("tilt", aml_tilt_map[ele_name]);
  }

  if (aml_attrib_name == "sextupole" && found(aml_k_map, ele_name)) {
    if (aml_k_map[ele_name] != "")    x_ele->addAttribute("k2", aml_k_map[ele_name]);
    if (aml_ks_map[ele_name] != "")   x_ele->addAttribute("k2s", aml_ks_map[ele_name]);
    if (aml_tilt_map[ele_name] != "") x_ele->addAttribute("tilt", aml_tilt_map[ele_name]);
  }

  if (aml_attrib_name == "octupole" && found(aml_k_map, ele_name)) {
    if (aml_k_map[ele_name] != "")    x_ele->addAttribute("k3", aml_k_map[ele_name]);
    if (aml_ks_map[ele_name] != "")   x_ele->addAttribute("k3s", aml_ks_map[ele_name]);
    if (aml_tilt_map[ele_name] != "") x_ele->addAttribute("tilt", aml_tilt_map[ele_name]);
  }

  // Aperture

  if (x_limit != "") x_ele->addAttribute("aperture", x_limit + ", " + y_limit);
  if (xy_limit != "") x_ele->addAttribute("aperture", xy_limit);

  // Unrecognized

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MADXParser::custom_x_element_to_x_file (UAPNode* x_node, string& comment, 
                                                             StreamStruct& x_out) {

  string x_name = x_node->getName();

  // use

  if (x_name == "use") {
    x_out << "use, period = " << x_node->getAttributeString("line") << comment << fini;
    return true;
  }

  // set

  if (x_name == "set") {
    x_out << x_node->getAttributeString("element") << "->" <<
              x_node->getAttributeString("attribute") << 
              x_node->getAttributeString("design") << comment << fini;
    return true;
  }


  // Unrecognized

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void custom_x_ele_attributes_to_x_file (UAPNode* x_node, 
                                   const string& ele_class, StreamStruct& x_out) {

  if (ele_class == "multipole") {
    string knl_str = x_node->getAttributeString("knl");
    if (knl_str != "") x_out << ", knl = {" << knl_str << "}";
    string ksl_str = x_node->getAttributeString("ksl");
    if (ksl_str != "") x_out << ", ksl = {" << ksl_str << "}";
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void MADXParser::custom_x_attrib_to_x_file_translate (string& attrib_name,
                                                            string& attrib_value) {

  if (attrib_name == "aperture" || attrib_name == "knl" || attrib_name == "ksl") {
    attrib_value = "{" + attrib_value + "}";
  }

  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void MADXParser::init_lists_madx () {


  StrVec aper, madx_extra;
  madx_extra << "lrad" << "calib" << "polarity" << "slot_id" 
                    << "assembly_id" << "mech_sep" << "kmin" << "kmax" << "from";
  aper << "aperture" << "apertype";

  map_element_to_attribs["marker"] << "l" << aper << madx_extra;
  map_element_to_attribs["matrix"] << aper << madx_extra;
  map_element_to_attribs["drift"] << aper << madx_extra; 
  map_element_to_attribs["sbend"] << "k0" << aper << madx_extra;
  map_element_to_attribs["rbend"] << "k0" << aper << madx_extra; 
  map_element_to_attribs["rcollimator"] << aper << madx_extra; 
  map_element_to_attribs["ecollimator"] << aper << madx_extra; 
  map_element_to_attribs["quadrupole"] << "k1s" << aper << madx_extra;
  map_element_to_attribs["sextupole"] << "k2s" << aper << madx_extra;
  map_element_to_attribs["octupole"] << "k3s" << aper << madx_extra;
  map_element_to_attribs["multipole"] << aper << madx_extra;
  map_element_to_attribs["solenoid"] << aper << madx_extra;
  map_element_to_attribs["hkicker"] << "hkick" << aper << madx_extra;
  map_element_to_attribs["vkicker"] << "vkick" << aper << madx_extra;
  map_element_to_attribs["kicker"] << aper << madx_extra;
  map_element_to_attribs["rfcavity"] << aper << madx_extra;
  map_element_to_attribs["lcavity"] << aper << madx_extra;
  map_element_to_attribs["elseparator"] << aper << madx_extra;
  map_element_to_attribs["monitor"] << aper << madx_extra;
  map_element_to_attribs["instrument"] << aper << madx_extra;
  map_element_to_attribs["beambeam"] << aper << madx_extra;
  map_element_to_attribs["beam"] << "sequence" << "dtbyds" << "deltap" << "beta" 
                                 << "alfa" << "u0" << "qs" << "arad" << "bv"
                                 << "pdamp" << "n1min" << "freq0" << "circ";

  map_element_to_attribs["multipole"] << "l" << "tilt" << "knl" << "ksl" << "type" 
                                      << "at" << madx_extra;

  register_attribute("beam:dtbyds",    "beam['{http://cern.ch/madx}madx:dtbyds']");
  register_attribute("beam:u0",        "beam['{http://cern.ch/madx}madx:u0']");
  register_attribute("beam:qs",        "beam['{http://cern.ch/madx}madx:qs']");
  register_attribute("beam:arad",      "beam['{http://cern.ch/madx}madx:arad']");
  register_attribute("beam:bv",        "beam['{http://cern.ch/madx}madx:bv']");
  register_attribute("beam:pdamp",     "beam['{http://cern.ch/madx}madx:pdamp']");
  register_attribute("beam:n1min",     "beam['{http://cern.ch/madx}madx:n1min']");
  register_attribute("beam:freq0",     "beam['{http://cern.ch/madx}madx:freq0']");
  register_attribute("beam:circ",      "beam['{http://cern.ch/madx}madx:circ']");
  register_attribute("beam:sequence",  "beam['{http://cern.ch/madx}madx:sequence']");
  register_attribute("beam:deltap",    "beam['{http://cern.ch/madx}madx:deltap']");
  register_attribute("beam:beta",      "beam['{http://cern.ch/madx}madx:beta']");
  register_attribute("beam:alfa",      "beam['{http://cern.ch/madx}madx:alfa']");

  register_attribute("sbend:k0",    "'{http://cern.ch/madx}madx:madx':'madx:k0'");
  register_attribute("rbend:k0",    "'{http://cern.ch/madx}madx:madx':'madx:k0'");

  register_attribute("kmin",        "'{http://cern.ch/madx}madx:madx':'madx:kmin'");
  register_attribute("kmax",        "'{http://cern.ch/madx}madx:madx':'madx:kmax'");
  register_attribute("lrad",        "'{http://cern.ch/madx}madx:madx':'madx:lrad'");
  register_attribute("calib",       "'{http://cern.ch/madx}madx:madx':'madx:calib'");
  register_attribute("polarity",    "'{http://cern.ch/madx}madx:madx':'madx:polarity'");
  register_attribute("slot_id",     "'{http://cern.ch/madx}madx:madx':'madx:slot_id'");
  register_attribute("assembly_id", "'{http://cern.ch/madx}madx:madx':'madx:assembly_id'");
  register_attribute("mech_sep",    "'{http://cern.ch/madx}madx:madx':'madx:mech_sep'");

  register_attribute("quadrupole:k1s", "quadrupole:ks");
  register_attribute("sextupole:k2s",  "sextupole:ks");
  register_attribute("octupole:k3s",   "octupole:ks");

  register_attribute("apertype", "aperture@shape");
  register_attribute("aperture", "aperture:xy_limit");

  StrVec matrix_attrib;
  matrix_attrib << "type" << "at" << "l";
  for (int i = 1; i < 7; i++) {
    ostringstream iss; iss << i;
    matrix_attrib << "kick" + iss.str();
    for (int j = 1; j < 7; j++) {
      ostringstream jss; jss << j;
      matrix_attrib << "rm" + iss.str() + jss.str();
      for (int k = 1; k < 7; k++) {
        ostringstream kss; kss << k;
        matrix_attrib << "tm" + iss.str() + jss.str() + kss.str();        
      }
    }
  }
  map_element_to_attribs["matrix"] = matrix_attrib;

  for (int i = 1; i < 7; i++) {
    ostringstream iss; iss << i;
    string kick = "matrix:kick" + iss.str();
    string taylor = "taylor_map:term(i_out=" + iss.str() + ",exp=\"0 0 0 0 0 0\")@coef";
    register_attribute (kick, taylor);
    for (int j = 1; j < 7; j++) {
      ostringstream jss; jss << j;
      string rm = "matrix:rm" + iss.str() + jss.str();
      string exp = "\"0 0 0 0 0 0\"";
      exp[2*j-1] = '1';
      taylor = "taylor_map:term(i_out=" + iss.str() + ",exp=" + exp + ")@coef";
      register_attribute (rm, taylor);
      for (int k = 1; k < 7; k++) {
        ostringstream kss; kss << k;
        exp = "\"0 0 0 0 0 0\"";
        exp[2*j-1] = '1';
        if (j == k)
          exp[2*k-1] = '2';
        else
          exp[2*k-1] = '1';
        taylor = "taylor_map:term(i_out=" + iss.str() + ",exp=" + exp + ")@coef";
        string tm = "matrix:tm" + iss.str() + jss.str() + kss.str();
        register_attribute (tm, taylor);
      }
    }
  }

  // This is not documented but MADX does accept this (and MAD8 does not)!

  register_attribute("hkicker:hkick",         "kicker:x_kick");
  register_attribute("vkicker:vkick",         "kicker:y_kick");

  return;

}
