#include "Translate/TranslateCore.hpp"
#include "AML/AMLUtilities.hpp"

using namespace std;
using namespace BasicUtilities;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

TranslateCore::TranslateCore() { 

  IGNORE = "IGNORE";

  aml_ignore_these_attribs.clear();
  attribute_list.clear();
  x_class_to_aml_map.clear();

  aml_class_names << "beambeam";
  aml_class_names << "bend";
  aml_class_names << "electric_kicker";
  aml_class_names << "field_table";
  aml_class_names << "kicker";
  aml_class_names << "marker";
  aml_class_names << "match";
  aml_class_names << "multipole";
  aml_class_names << "octupole";
  aml_class_names << "patch";
  aml_class_names << "quadrupole";
  aml_class_names << "rf_cavity";
  aml_class_names << "sextupole";
  aml_class_names << "solenoid";
  aml_class_names << "taylor_map";
  aml_class_names << "wiggler";
  aml_class_names << "aperture";

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::ModifyIncludedFileNames (UAPNode* root, 
                                      const string& replacement_suffix) {

  // Make sure replacement string has a beginning dot

  string replace_str = replacement_suffix;
  if (replace_str[0] != '.') replace_str = "." + replace_str;

  // Look for <include> nodes, etc.

  bool ok = true;
  if (!modify_file_names ("{http://www.w3.org/2001/XInclude}include", "href", 
                                                            root, replace_str)) ok = false;
  if (!modify_file_names ("AML_representation", "filename", root, replace_str)) ok = false;
  if (!modify_file_names (language + "_representation", 
                                             "filename", root, replace_str)) ok = false;
  if (!modify_file_names ("call", "filename", root, replace_str)) ok = false;

  return ok;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::modify_file_names (const string& node_name, 
        const string& attrib_name, UAPNode* root, const string& replace_str) {

  bool ok = true;

  string dir, file;
  NodeVec incs = root->getSubNodesByName (node_name);
  for (NodeVecIter it = incs.begin(); it != incs.end(); it++) {
    UAPAttribute* attrib = (*it)->getAttribute(attrib_name);
    if (!attrib) {
      info_out.error ("No " + attrib_name + " attribute found for <" + 
                   node_name + "> node: " + (*it)->toString());
      ok = false;
      continue;
    }
    string name = attrib->getValue();
    split_file_name (name, dir, file);
    size_t ip = file.rfind(".");
    if (ip != string::npos) file.erase(ip);
    attrib->setValue(dir + file + replace_str);
  }   

  return ok;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

UAPNode* TranslateCore::XFileToAMLRep (const string& filename, UAPNode* uap_root) {

  // Create the root node 

  UAPNode* root = uap_root;
  if (!root) root = new UAPNode("UAP_root");

  // Add the X_rep subtree 

  UAPNode* x_rep = XFileToXRep (filename, root);

  // construct the AML_rep

  XRepToAMLRep (root);

  return root;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

UAPNode* TranslateCore::XFileToXRep (const string& filename, UAPNode* root) {

  // Init

  name_to_x_class_map.clear();

  // Create the X_rep node which is the root of the subtree

  UAPNode* this_root = root;
  if (!this_root) this_root = new UAPNode("UAP_root");
  UAPNode* x_rep = this_root->addChild(language + "_representation");
  x_rep->addAttribute ("source_language", language);

  // Read the X file

  FileStackList file_stack;
  info_out.ix_line = -1;
  info_out.parsing_status = "Parsing " + language + " file.";
  info_out.statement = "";
  x_rep->addAttribute("filename", filename);
  x_file_to_x (x_rep, filename, file_stack);

  info_out.file_name = "";

  return x_rep;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_file_to_x (UAPNode* x_rep_root, 
                   string file_name, FileStackList file_stack) {

  // This routine splits each statement in an x-file into an array of words and
  // then calls x_statement_to_x to do a translation to the x-representation.

  StrList word_list;

  file_stack.addFile(file_name);
  string this_file = file_stack.file_list.back().full_name;

  // Open the X-file

  ifstream x_input_file(this_file.c_str());
  if (!x_input_file.good()) {
    info_out.error("Cannot open file: " + this_file);
    return;
  }
  bool close_file = false;

  in_sequence = false;
  string comment = "";
  info_out.statement = "";  

  // quote_delim indicates whether a quoted string is being parsed.
  // quote_delim = ' ' -> Not parsing a quote.
  // Quotes can begin with double (") or single (') quotation marks. 

  string line, word;
  bool line_continue_found;
  char quote_delim = ' '; 
  int ix_line = 0;
  bool continued_line = false;
  bool in_extended_comment = false;
  bool init_for_new_command = false;

  while (!x_input_file.eof()) {

    // Get a line of input.

    getline(x_input_file, line);
    if (word_list.size() == 0) 
      info_out.statement = line;
    else {
      info_out.statement += '\n';
      info_out.statement += line;
    }
    line_continue_found = false;
    bool delim_found = true;
    bool space_found = false;
    bool blank_line = true;
    ix_line++;

    if (in_extended_comment) comment += '\n';

    // After a command is parsed need to reset some stuff.
    // This must be done here due to presence of any blank lines.

    if (init_for_new_command) {
      word_list.clear();
      delim_found = true;
      info_out.statement = line; comment = "";
      continued_line = false;
      init_for_new_command = false;
    }

    // Break the line into its component words
    // We do this by checking each character to see where the word boundries are.

    for (size_t ix_char = 0; ix_char < line.length(); ix_char++) {

      // After a command is parsed need to reset some stuff

      if (init_for_new_command) {
        word_list.clear();
        delim_found = true;
        info_out.statement = line; comment = "";
        continued_line = false;
        init_for_new_command = false;
      }

      // Get a character from input and add it to info_out.statement string

      char ch = line[ix_char];
      char ch2 = ' ';
      if (ix_char+1 != line.length()) ch2 = line[ix_char+1];

      // Check for a c-style "/* ... */" comment

      if (c_style_format && ch == '/' && ch2 == '*') {
        in_extended_comment = true;
        ix_char++;
        continue;
      }

      if (in_extended_comment) {
        if (ch == '*' && ch2 == '/') {
          ix_char++;
          in_extended_comment = false;
          x_statement_to_x (word_list, comment, x_rep_root, 
                                     quote_delim, close_file, ix_line, file_stack);
          if (close_file) return;
          init_for_new_command = true;
        } else {
          comment += ch;
        }
        continue;
      }

      // Add character to the error string (used for error reporting).
      if (ch != ' ' && ch != '\t' && ch != '!') blank_line = false;

      // Check for quotation mark which indicates we are going into or out of a quote.

      if (ch == '\'' || ch == '\"') {
        if (quote_delim == ' ') {     // if at beginning of quote...
          add_word_to_list (word, word_list); 
          quote_delim = ch;           
          word += ch;
          continue;
        }
        if (quote_delim == ch)  {    // if at end of quote...
          quote_delim = ' ';
          word += ch;
          add_word_to_list (word, word_list);
          continue;
        }
      }

      // If in a quote then always add the character to the word

      if (quote_delim != ' ') { 
        word += ch;
        continue;
      }

      // Skip tabs and spaces except if they are significant. 
      // They are significant if they separate alphanumeric characters.

      if (ch == ' ' || ch == '\t') {
        space_found = true;
        continue;
      }

      // A ";" indicates the end of a statement.
      // If this is followed by a comment indicator then the comment is added to the statement.

      if (ch == ';') { 
        add_word_to_list (word, word_list);
        ix_char++;
        while (ix_char != line.length() && line[ix_char] == ' ') ix_char++;

        if (ix_char != line.length()) {
          if (line[ix_char] == '!' || 
                (c_style_format && line[ix_char] == '/' && line[ix_char+1] == '/')) {
            ix_char++;
            if (line[ix_char] == '/') ix_char++;
            comment = line.substr(ix_char);
            ix_char = line.length();
          } else if (c_style_format && line[ix_char] == '/' && line[ix_char+1] == '*') {
            in_extended_comment = true;
            ix_char++;
            continue;
          } else {
            ix_char--;
          }
        }

        x_statement_to_x (word_list, comment, x_rep_root, 
                                   quote_delim, close_file, ix_line, file_stack);
        if (close_file) return;
        init_for_new_command = true;
        continue;
      }

      // The '&' character continues the command from one line to another.

      if (ch == '&' && !c_style_format) {
        line_continue_found = true;
        break;
      }

      // A "!" or a "//" indicates a comment.

      if (ch == '!' || (c_style_format && ch == '/' && ch2 == '/')) {
        add_word_to_list (word, word_list);
        if (ch == '/') ix_char++;
        comment = line.substr(ix_char+1);  
        // Check if this is a stand alone comment. If so call x_statement_to_x.
        if (word_list.size() == 0) {
          x_statement_to_x (word_list, comment, x_rep_root, 
                                   quote_delim, close_file, ix_line, file_stack);
          init_for_new_command = true;
        }
        break;
      }

      // Check for a delimiter between words

      if (ch == '=' || ch == ',' || ch == ':' || ch == '(' || ch == ')' ||
          ch == '-' || ch == '*' || ch == '{' || ch == '}' || ch == '/' ||
          ch == '[' || ch == ']') {
        add_word_to_list (word, word_list);
        word = ch;
        if (ch == '-' && ch2 == '>') {
          word = "->"; 
          ix_char++; 
        }
        if (ch == ':' && ch2 == '=') {  
          word = "=";    // Translate ":=" -> "="
          ix_char++;
        }
        add_word_to_list (word, word_list);
        delim_found = true;
        continue;
      }

      if (!delim_found && space_found) add_word_to_list (word, word_list);
      word += ch;
      space_found = false;
      delim_found = false;

    }

    // We have come to the end of the line

    add_word_to_list (word, word_list);

    if (line_continue_found || c_style_format) {
      continued_line = true;

    } else if (!blank_line || !continued_line) {
      x_statement_to_x (word_list, comment, x_rep_root, 
                                 quote_delim, close_file, ix_line, file_stack);
      if (close_file) return;
      init_for_new_command = true;
    }

  }

  // End must have closing ";"

  if (c_style_format && word_list.size() > 0) {
    info_out.error ("FINAL \";\" NOT FOUND IN INPUT FILE.");
  }

  if (in_extended_comment) {
    info_out.error ("OPENING '/*' DOES NOT HAVE A CLOSING '*/' IN INPUT FILE");
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::add_word_to_list (string& word, StrList& word_list) {

  // Don't add blank words to the list (except for quoted words).

  if (word.length() == 0) return;

  // If the word is in quotes then strip the quotes from the word
  // In this case there can be a blank word.

  if (word[0] == '\'' || word[0] == '\"') {
    word.erase(0,1);
    word.erase(word.length()-1,1);
  }

  // Add the word to the list and clear the word.

  word_list.push_back(word);
  word.clear();

  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_statement_to_x (StrList& word_list, 
                     string comment, UAPNode* x_rep_root, char& quote_delim, 
                     bool& close_file, int ix_line, FileStackList file_stack) {

  // This routine translates from a statement read from a file to the appropriate
  // x_representation that will be part of the UAP Node tree.

  // Load file name and line number for error reporting purposes.

  info_out.file_name = x_rep_root->getAttributeString("filename");
  info_out.ix_line = ix_line;

  // Check for unmatched quote mark.

  if (quote_delim != ' ') {
    info_out.error ("String not terminated with quotation mark");
    quote_delim = ' ';
    return;    
  }

  // Trim leading and trailing blanks in comment

  comment = trim(comment);

  // Empty statement (it may be a pure comment).

  if (word_list.size() == 0) {
    if (comment != "") {
      UAPNode* node = x_rep_root->addChild("comment");
      node->addAttribute("text", comment);
    }
    return;
  }

  // First see if a "custom" translation is called for

  if (custom_x_statement_to_x (word_list, comment, x_rep_root)) return;

  // Here when a custom translation has not been done...

  string word1 = next_word(word_list);  

  // endsequence

  if (word1 == "endsequence") {
    if (!in_sequence) info_out.error ("endsequence found without beginning sequence line.");
    in_sequence = false;
    return;
  }

  // Between sequence and endsequence statements.

  if (in_sequence) {

    if (word_list.size() < 4) {
      info_out.error("Malformed line in sequence construct");
      return;
    }

    string word2 = next_word(word_list);

    if (word2 == ":") {                 // "label: class" construct
      in_sequence = false;              // Lie for now.
      word_list.push_front(word2);     
      word_list.push_front(word1);      // Restore word_list to initial state
      x_statement_to_x (word_list, comment, seq_node, 
                                          quote_delim, close_file, ix_line, file_stack);
      in_sequence = true;               // Restore the truth
      return;
    }

    string at, from;
    while (true) {
      string word3 = next_word(word_list);
      string word4 = next_word(word_list);
      if (word2 != "," || (word3 != "at" && word3 != "from") || word4 != "=") {
        info_out.error ("Bad line in sequence construct");
        return;
      }
      if (word3 == "at") {
        while (word_list.size() > 0 && word_list.front() != ",") at += next_word(word_list);
      } else {
        while (word_list.size() > 0 && word_list.front() != ",") from += next_word(word_list);
      }

      if (word_list.size() == 0) break;

      if (word_list.size() < 4) {
        info_out.error("Malformed sub-sequence or element in sequence construct");
        return;
      }
      word2 = next_word(word_list);

    }

    // Find if an element or a sequence

    if (!found(name_to_x_class_map, word1)) {
      info_out.error ("UNKNOWN ELEMENT OR SEQUENCE: " + word1);
      return;
    }

    UAPNode* node;
    if (name_to_x_class_map[word1] == "sequence") 
      node = seq_node->addChild("sequence");
    else
      node = seq_node->addChild("element");

    node->addAttribute("ref", word1);
    node->addAttribute("at", at);

    return;
  }

  // return statement is the only statement with one word

  if (word_list.size() == 0) {

    if (word1 == "return" || word1 == "end_file") {
      UAPNode* node = x_rep_root->addChild(word1);
      close_file = true;
      if (comment != "") node->addAttribute("comment", comment);
      return;
    }
    info_out.error ("Invalid or incomplete statement");
    return;

  }

  // Statements where second word is ","...

  if (word_list.size() < 2) {
    info_out.error ("Invalid or incomplete statement");
    return;
  }

  if (word1 == "beam" || word1 == "twiss") {
    UAPNode* node = x_rep_root->addChild(word1);
    if (comment != "") node->addAttribute("comment", comment);
    x_add_attributes (word_list, word1, node);
    return;
  } 

  string word2 = next_word(word_list);
  string word3 = next_word(word_list);

  if (word2 == ",") {

    if (word1 == "call") {
      if (word_list.size() < 2) {
        info_out.error ("Malformed call statement.");
        return;
      }
      string word4 = next_word(word_list);
      if (word3 != string("filename").substr(0,word3.size()) || word4 != "=") {
        info_out.error ("\"Filename =\" missing or misplaced in call statement");
        return;
      }
      string file_name = next_word(word_list, NO_CONVERT);
      while (word_list.size() > 0) {
        file_name += next_word(word_list, NO_CONVERT);
      }
      UAPNode* call_root = x_rep_root->addChild("call");
      if (comment != "") x_rep_root->addAttribute("comment", comment);
      call_root->addAttribute("filename", file_name);
      x_file_to_x (call_root, file_name, file_stack);
      return;
    } 

    // Might be an element attribute set. 
    // Since a MAD statement can set more than one attribute we need to possibly 
    //   create more than one child.

    string x_class = ele_name_to_x_class(word1);
    if (x_class != "") {
      UAPNode* node0 = x_rep_root->addChild("temporary");
      word_list.push_front(word3);
      word_list.push_front(",");
      x_add_attributes (word_list, x_class, node0);
      AttributeVec attribs = node0->getAttributes();
      for (AttributeVecIter ia = attribs.begin(); ia != attribs.end(); ia++) {
        UAPNode* set = x_rep_root->addChild("set");
        set->addAttribute("element", word1);
        set->addAttribute("attribute", ia->getName());
        set->addAttribute("value", ia->getValue());
      }
      node0->deleteNode();
      return;
    }

    // Use or title statement

    UAPNode* node = x_rep_root->addChild(word1);
    if (comment != "") node->addAttribute("comment", comment);

    if (word1 == "title") {
      node->addAttribute ("text", word3);
      return;
    } 

    // Unrecognized

    info_out.error ("Unrecognized statement");
    return;
  }

  // Statement where the second word is "=" defines a constant

  if (word2 == "=") {
    UAPNode* node = x_rep_root->addChild("constant");
    node->addAttribute("name", word1);
    while (word_list.size() != 0) word3 += next_word(word_list); // concat
    node->addAttribute("design", word3);
    if (comment != "") node->addAttribute("comment", comment);
    return;
  }

  // Look for an ":" 

  string args;

  if (word2 == "(") {               // line with arguments?
    word_list.push_front(word3);
    if (!get_args (word_list, args)) return;
    if (word_list.size() < 6) {
      info_out.error ("Malformed replacement list");
      return;
    }
    word2 = next_word(word_list);
    word3 = next_word(word_list);
  }

  if (word2 != ":") {
    info_out.error ("Missing or misplaced \":\"");
    return;
  }

  bool constant = false;
  if (word3 == "constant") {
    if (word_list.size() < 2) {
      info_out.error ("Malformed constant definition statement");
      return;
    }
    if (word_list.front() != "=") {
      info_out.error ("Missing or misplaced \"=\"");
      return;
    }
    constant = true;
    word3 = next_word(word_list);
  }

  // "var :=" is a constant definition

  if (word3 == "=") {
    UAPNode* node = x_rep_root->addChild("constant");
    node->addAttribute("name", word1);
    string wrd = next_word(word_list);
    while (word_list.size() != 0) wrd += next_word(word_list);
    node->addAttribute("design", wrd);
    if (constant) node->addAttribute("type", "constant");
    if (comment != "") node->addAttribute("comment", comment);
    return;
  }

  // possibilities now are line, list, or an element.

  if (!valid_variable(word1)) {
    info_out.error ("Malformed statement first word: " + word1);
    return;
  }

  // Match "word3" to the list of element class words ("quadrupole", etc.) or prior element names. 

  string x_class = ele_name_to_x_class(word3);
  if (x_class == "") {
    x_class = named_x_class(word3);
    if (x_class == "") {
      info_out.error ("Unrecognized element class: " + word3);
      return;
    }
    word3 = x_class;
  }

  if (args != "") {
    if (word3 != "line") {
      info_out.error ("Only lines can have arguments");
      return;
    }
  }

  // Sequence

  if (word3 == "sequence") {
    seq_node = x_rep_root->addChild("sequence");
    seq_node->addAttribute("name", word1);
    name_to_x_class_map[word1] = "sequence";

    x_add_attributes (word_list, "sequence", seq_node);
    if (comment != "") seq_node->addAttribute("comment", comment);
    in_sequence = true;

    while(true) {
      if (word_list.size() == 0) break;
      string word4 = next_word(word_list);
      string word5 = next_word(word_list);
      string word6 = next_word(word_list);
      string word7 = next_word(word_list);
      if (word4 != "," || word6 != "=" || word7 == "") {
        info_out.error ("Malformed SEQUENCE");
        return;
      }
      seq_node->addAttribute(word5, word7);
    }
    return;
  }

  // lines and lists must be parsed to separate the elments

  if (word3 == "line" || word3 == "list") {
    UAPNode* class_node = x_rep_root->addChild(word3);
    class_node->addAttribute("name", word1);
    if (comment != "") class_node->addAttribute("comment", comment);
    if (word_list.size() < 4) {
      info_out.error ("Malformed line or list of elements"); 
      return;
    }   

    string word4 = next_word(word_list);
    string word5 = next_word(word_list);

    if (word3 == "line" && word4 == "[") {
      if (word5 != "multipass" || next_word(word_list) != "]") {
        info_out.error ("Malformed line statement");
        return;
      }
      class_node->addAttribute("multipass", "TRUE");
      word4 = next_word(word_list);
      word5 = next_word(word_list);
    }

    if (word4 != "=" || word5 != "(") {
      info_out.error ("Expecting an \"= (\" after line or list");
      return;
    }

    word_list.push_front("(");    // Used by parse_this_line_or_list
    if (!parse_this_line_or_list (word_list, class_node)) return;
    if (word_list.size() > 0) {
      string rest = next_word(word_list);
      while (word_list.size() != 0) rest += next_word(word_list);
      info_out.error ("Statement did not end after final \")\" in line or list: " + rest);
      return;
    } 
    if (args != "") class_node->addAttribute("args", args);
    return;
  }

  // must be an element definition.

  UAPNode* element_node = x_rep_root->addChild("element");
  element_node->addAttribute("name", word1);
  name_to_x_class_map[word1] = x_class;
  
  if (found (name_to_x_class_map, word3)) {
    element_node->addAttribute("inherit", word3);
  } else {
    element_node->addAttribute("class", word3);
  }
  if (comment != "") element_node->addAttribute("comment", comment);
  
  x_add_attributes (word_list, x_class, element_node);
  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::named_x_class (const string& name) {

  // First see if this is an element class

  string x_class = ele_name_to_x_class(name);
  if (x_class != "") return x_class;

  // When matching to an element class word, the first 4 letters must match.

  size_t isize = name.size();
  if (isize < 2) return "";

  for (StrMapCIter im = x_class_to_aml_map.begin(); 
                                        im != x_class_to_aml_map.end(); im++) {
    string x_class = im->first; 
    if (isize > x_class.size()) continue;
    if (name.substr(0,isize) == x_class.substr(0,isize)) return x_class;
  }

  return "";

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::ele_name_to_x_class (const string& name, bool include_param_names) {

  if (found(name_to_x_class_map, name)) return name_to_x_class_map[name];
  if (include_param_names && found(x_param_names, name)) return name;
  return "";

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::next_word (StrList& word_list, CaseConvert this_case) {

  if (this_case == TO_LOWER) 
     return str_to_lower(str_pop(word_list));
  if (this_case ==  NO_CONVERT) 
     return str_pop(word_list);
  if (this_case ==  TO_UPPER)   
     return str_to_upper(str_pop(word_list));

  info_out.error("Bad this_case argument");
  return str_pop(word_list);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::valid_variable (const string& var) {
  if (!isalpha(var[0])) return false;
  for (size_t i = 1; i < var.length(); i++) {
    if (!isalpha(var[i]) && !isdigit(var[i]) && var[i] != '_' && var[i] != '.') return false;
  }
  return true;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::parse_this_line_or_list (StrList& word_list, UAPNode* seq_root) {

  // loop over all elements in the list

  while (true) {
    if (word_list.size() == 0) {
      info_out.error ("Line or list ended without final \"\"");
      return false;
    }
    string delim = next_word(word_list, NO_CONVERT); 
    if (delim == ")") return true;
    if (delim == "," || delim == "(") {
      bool good = parse_this_line_or_list_element (word_list, seq_root);
      if (!good) return false;
    } else {
      info_out.error ("Expecting \"(\", \")\" or \",\" in line expansion but got: " + delim);
      return false;
    }
  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::parse_this_line_or_list_element (StrList& word_list, UAPNode* seq_root) {

  // check for negative sign

  if (word_list.size() < 2) {
    info_out.error ("Malformed end of line or list");
    return false;
  }

  string w1 = next_word(word_list);

  string negative = "";
  if (w1 == "-") {
    negative = "-";
    w1 = next_word(word_list);
  }

  // check for a number
  
  string repeat("1");
  if (isdigit(w1[0])) {
    if (!is_int(w1)) {
      info_out.error ("Malformed integer: " + w1);
      return false;
    }
    repeat = negative + w1;
    if (word_list.size() < 3) {
      info_out.error ("Incomplete line or list");
      return false;
    }
    string times = next_word(word_list, NO_CONVERT);
    if (times != "*") {
      info_out.error ("Missing \"*\"");
      return false;
    }
    w1 = next_word(word_list);
  } else {
    if (negative == "-") repeat = "-1";
  }

  if (word_list.size() < 1) {
    info_out.error ("Incomplete line or list");
    return false;
  }

  // the next word is either "(" signifying a sub-line_or_list
  // or an element or line/list name

  if (w1 == "(") {
    UAPNode* line = seq_root->addChild("line");
    if (repeat != "1") line->addAttribute("repeat", repeat);
    word_list.push_front("(");  // used by parse_this_line_or_list
    return parse_this_line_or_list (word_list, line); 
  }

  // a tagged line is of the form: line_name[tag_name]

  string tag;
  string delim = next_word(word_list);

  if (delim == "[") {
    if (word_list.size() < 3) {
      info_out.error ("Incomplete line or list");
      return false;
    }
    tag = next_word(word_list);
    delim = next_word(word_list);
    if (delim != "]") {
      info_out.error("Matching \"]\" to end tag not found");
      return false;
    }
    delim = next_word(word_list);
  }

  // a replacement line is of the form: name(arg1, arg2, ...)

  if (delim == "(") {
    UAPNode* line = seq_root->addChild("line");
    line->addAttribute("ref", w1);
    if (repeat != "1") line->addAttribute("repeat", repeat);
    if (tag != "") line->addAttribute("tag", tag);
    string args;
    bool good = get_args (word_list, args);
    if (!good) return false;
    line->addAttribute("args", args);
    return true;
  }

  // must be an element or line_or_list name
  // "item" means that we don't know if it is a element, line, or whatever.

  UAPNode* ele = seq_root->addChild("item");
  ele->addAttribute("ref", w1);
  if (repeat != "1") ele->addAttribute("repeat", repeat);
  if (tag != "") ele->addAttribute("tag", tag);

  // let the calling routine handle the rest

  word_list.push_front(delim);
  return true;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::get_args(StrList& word_list, string& args) {

  args.clear();

  while (true) {
    if (word_list.size() < 3) {
      info_out.error ("End of statement encountered while parsing argument list");
      return false;
    }
    string arg = next_word(word_list);
    if (!valid_variable(arg)) {
      info_out.error ("Malformed argument variable name: " + arg);
      return false;
    }
    args += arg;
    string wrd = next_word(word_list, NO_CONVERT);
    if (wrd == ")") return true;
    if (wrd != ",") {
      info_out.error ("Malformed argument list");
      return false;
    }
    args += ",";
  }
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_add_attributes (StrList& word_list, string ele_class, UAPNode* x_ele_root) {

  // This method is called for statements like:
  //    q: quad, l = 3, tilt, k1 = 0.37
  // It is assumed that the "q: quad" part has been parsed so this method works on the part:
  //    , l = 3, tilt, k1 = 0.37
  // This method parses these attributes and adds them to the x-representation 
  // node x_ele_root.

  while (true) {

    if (word_list.size() == 0) return;
    string w = next_word(word_list, NO_CONVERT);
    if (w != ",") {
      info_out.error ("Expected \",\" in element attribute list but got: " + w);
      return;
    }

    if (word_list.size() == 0) {
      info_out.error ("Statement ended with a \",\".");
      return;
    }

    string attrib_name = next_word(word_list);
    string value, delim;

    // Custom parsing here

    if (custom_x_add_attributes (word_list, ele_class, attrib_name, x_ele_root)) continue;

    // Check for valid attribute

    if (!valid_attribute (ele_class, attrib_name)) {
      info_out.error ("Attribute not recognized: " + attrib_name);
      // Skip to next ","
      while (true) {
        if (word_list.size() == 0) return;
        if (next_word(word_list) == ",") break;
      }
      word_list.push_front(",");
      continue;
    }

    //

    if (word_list.size() == 0) {
      if (!x_attribute_can_have_default(attrib_name)) return;
      x_ele_root->addAttribute(attrib_name, "");
      return;
    }

    w = next_word(word_list);
    if (w == ",") {
      if (!x_attribute_can_have_default(attrib_name)) return;
      x_ele_root->addAttribute(attrib_name, "");
      word_list.push_front(",");
      continue;
    }
    if (!(w == "=" || (c_style_format && w == ":="))) {
      info_out.error ("Confused attribute: " + attrib_name); 
      return;
    }
    if (word_list.size() == 0) {
      info_out.error ("Statement ended with a \"=\"");
      return;
    }

    delim = concat_value_expression (word_list, x_attribute_case(attrib_name), value);
    x_ele_root->addAttribute(attrib_name, value);
    if (delim == "") return;

  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::concat_value_expression (StrList& word_list, 
                                            CaseConvert this_case, string& value) {

  // Concatinate together all the pieces of the value expression

  int ix_parens = 0;
  int ix_curly = 0;
  int ix_square = 0;
  value = "";

  while (true) {
    if (word_list.size() == 0) return "";
    string word = next_word(word_list, this_case);
    if (word == "(") ix_parens++;
    if (word == ")") ix_parens--;
    if (word == "{") ix_curly++;
    if (word == "}") ix_curly--;
    if (word == "{") ix_square++;
    if (word == "}") ix_square--;
    if (word == "," && ix_parens == 0 && ix_curly == 0 && ix_square == 0) {
      word_list.push_front(",");
      return ",";
    }
    value += word;
  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

TranslateCore::CaseConvert TranslateCore::x_attribute_case(const string& attrib_name) {

  CaseConvert this_case = TO_LOWER;
  if (found (x_attributes_to_upper_case, attrib_name)) this_case = TO_UPPER;
  if (found (x_attributes_no_case_change, attrib_name)) this_case = NO_CONVERT;

  return this_case;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::valid_attribute (const string& ele_class, string& attrib) {

  // Remember there can be abbreviations

  int nl = attrib.length();
  int n_match = 0;

  StrVec attribs = map_element_to_attribs[ele_class];
  for (StrVecIter ia = attribs.begin(); ia != attribs.end(); ia++) {
    string this_attrib = *ia;
    if (attrib == this_attrib) return true;  // Exact match
    if (abbreviations_permitted && attrib == this_attrib.substr(0, nl)) n_match++;
  }

  if (n_match == 1) return true;
  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::x_attribute_can_have_default (string attrib_name) {

  if (found(x_attribs_that_can_have_default, attrib_name)) return true;

  info_out.error ("Attribute does not have a default value: " + attrib_name);
  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

UAPNode* TranslateCore::XRepToAMLRep (UAPNode* x_root, UAPNode* aml_root) {

  // Init

  use_parent = NULL;
  name_to_x_class_map.clear();

  info_out.ix_line = -1;
  info_out.statement = "";
  info_out.parsing_status = "Translating from " + language + " rep to AML rep.";

  string str;

  // Check where the x_rep node is.

  UAPNode* x_rep;
  UAPNode* uap_root = NULL;

  if (x_root->getName() == "UAP_root") {
    uap_root = x_root;
    x_rep = x_root->getChildByName(language + "_representation");
    if (!x_rep) {
      info_out.error ("<UAP_root> does not have a <" + language + "_representation> child.");
      return NULL;
    }
  } else if (x_root->getName() == language + "_representation") {
    x_rep = x_root;
    uap_root = x_root->getParent();
  } else {
    info_out.error ("argument is not a <UAP_root> node nor a <" + language + "_representation> node",
                 x_root->toString());
    return NULL;
  }

  // Find or construct the aml_rep if needed

  UAPNode* aml_rep = aml_root;

  if (!aml_rep) {
    if (uap_root) {
      NodeVec reps = uap_root->getChildrenByName("AML_representation");
      for (NodeVecIter ir = reps.begin(); ir != reps.end(); ir++) (*ir)->deleteNode();
      aml_rep = uap_root->addChild("AML_representation");
    } else {
      aml_rep = new UAPNode("AML_representation");
    }    

  } else if (aml_rep->getName() == "UAP_root") {
    NodeVec reps = aml_rep->getChildrenByName("AML_representation");
    for (NodeVecIter ir = reps.begin(); ir != reps.end(); ir++) (*ir)->deleteNode();
    aml_rep = aml_rep->addChild("AML_representation");

  } else if (aml_rep->getName() == "AML_representation") {
    UAPNode* root = aml_rep->getParent();
    aml_rep->deleteNode();
    if (root) aml_rep = root->addChild("AML_representation");
    else      aml_rep = new UAPNode("AML_representation");

  } else {
    info_out.error ("aml_root argument is not a <UAP_root> node nor a <AML_representation> node",
                 aml_root->toString());
    return NULL;
  }

  // Construct laboratory nodes

  aml_rep->addAttribute ("source_language", language);
  
  if(x_rep->getAttribute("filename"))
    aml_rep->addAttribute("filename", x_rep->getAttributeString("filename"));

  aml_lab_root = aml_rep->addChild("laboratory");
  aml_lab_root->addAttribute("xmlns:xi", "http://www.w3.org/2001/XInclude");
  aml_lab_root->addAttribute("aml_version", "1");

  // Transfer information from x to aml

  x_rep_to_aml_init (x_rep);
  x_rep_to_aml (x_rep, aml_lab_root);

  // Translate "use" information

  if (use_parent) {
    UAPNode* machine_node = use_parent->addChild("machine");
    machine_node->addChild("sector")-> addAttribute("ref", use_line);
  }

  // Put in xmlns attributes if non-aml namespaces have been used.

  aml_lab_root->addXMLNSAttributes();

  // And return.

  return aml_rep;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_rep_to_aml_init (UAPNode* x_rep) {

  // Make lists of element names, line names, etc.

  x_set_nodes.clear();
  name_to_aml_type_map.clear();
  name_to_x_type_map.clear();
  name_to_x_node_map.clear();
  name_to_aml_node_map.clear();
  x_rep_make_name_lists (x_rep);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_rep_make_name_lists (UAPNode* x_rep) {

  // Loop over x-rep nodes.

  NodeVec list = x_rep->getChildren();
  for (NodeVecCIter it = list.begin(); it != list.end(); it++) {
    UAPNode* node = *it;

    // Return means stop translating and ignore blank lines.

    string node_type = node->getName();
    if (node_type == "return") return;

    // Set nodes

    if (node_type == "set") {
      x_set_nodes.push_back(node);
      continue;
    }

    // Named nodes

    string ele_name = node->getAttributeString("name");
    x_rep_make_name_lists (node);

    if (ele_name == "") continue;
    name_to_x_node_map[ele_name] = node;

    if (node_type == "line" || node_type == "list" || node_type == "sequence") {
      name_to_x_type_map[ele_name] = node_type;

    } else if (node_type == "overlay" || node_type == "group"){
      name_to_x_type_map[ele_name] = node_type;
      name_to_x_class_map[ele_name] = node_type;

    } else if (node_type == "element") {
      name_to_x_type_map[ele_name] = node_type;
      string inherit = node->getAttributeString("inherit");
      string x_class;
      if (inherit != "") {
        x_class = ele_name_to_x_class(inherit);
      } else {
        x_class = node->getAttributeString("class");
      }
      name_to_x_class_map[ele_name] = x_class;
    }

  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_rep_to_aml (UAPNode* x_rep_root, UAPNode* lab) {

  // Loop over x-rep nodes.

  NodeVec list = x_rep_root->getChildren();
  for (NodeVecCIter it = list.begin(); it != list.end(); it++) {
    // Return means stop translating and ignore blank lines.
    if ((*it)->getName() == "return") return;
    x_node_to_aml (*it, lab, lab);
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_node_to_aml (UAPNode* x_ele, UAPNode* aml_root, UAPNode* aml_ele, 
                const string& ignore_this1, const string& ignore_this2) {

  UAPNode* aml_node;
  string x_node_type = x_ele->getName();
  string aml_class, ele_name;

  // Add a comment to root but only if it exists in x_ele

  string com_str = x_ele->getAttributeString("comment");
  if (com_str != "") {
    UAPNode* x_ele = aml_ele->addChild("comment");
    x_ele->addAttribute("text", com_str);
  }

  // Check for custom conversion

  if (custom_x_node_to_aml (x_ele, aml_root, aml_ele)) return;

  // sequence statement

  if (x_node_type == "sequence") {

    if (x_ele->getAttribute("refpos")) 
      info_out.error (
          "Translation for a sequence with a \"refpos\" attribute not currently implemented: " +
           x_ele->toString());

    // Find the length: must have a length attribute or last element in sequence must be a marker

    string length = x_ele->getAttributeString("l");
    if (length == "") length = x_ele->getAttributeString("length");
    if (length == "") {
      UAPNode* last_ele = x_ele->getChildren().back();

      // If length is not explicit then last element in sequence must be a marker.
      if (last_ele->getName() == "element") {
        if (x_node_to_x_class(last_ele) != "marker")
          info_out.error ("Last element in sequence is not a marker: " +
                                                           last_ele->toString());
      } else if (last_ele->getName() == "class") {
        if (last_ele->getAttributeString("name") != "drift")
          info_out.error ("Last element in sequence is not a marker: " +
                                                           last_ele->toString());
      } else {
        info_out.error ("Last element in sequence is a sub-sequence but should be a drift.");
      }

      length = last_ele->getAttributeString("at");
    }

    string refer  = x_ele->getAttributeString("refer");
    string ele_origin;
    if (refer == "entry")
      ele_origin = "ENTRANCE";
    else if (refer == "centre")
      ele_origin = "CENTER";
    else if (refer == "exit")
      ele_origin = "EXIT";
    else if (refer != "")
      info_out.error ("Bad \"refer\" attribute for sequence: " + x_ele->toString());

    string seq_name = x_ele->getAttributeString("name");

    // Go through the elements and create a constant if the "at" parameter is not a 
    //   simple number or variable.
    // Also create a map from element name to this constant.
    // This is used if "from" is present someplace.

    NodeVec eles = x_ele->getChildren();
    StrVec at_const_vec(eles.size());
    StrMap at_const_map;
    int n(-1);

    for (NodeVecCIter ie = eles.begin(); ie != eles.end(); ie++) {
      UAPNode* x_seq_ele = *ie;
      n++;

      string ele_name = x_seq_ele->getAttributeString("name"); 
      if (ele_name == "") ele_name = x_seq_ele->getAttributeString("ref");

      string at_str = x_seq_ele->getAttributeString("at");
      if (at_str == "") {
        info_out.error ("No \"at\" attribute for sequence element: " + x_seq_ele->toString());
        return;
      }

      if (at_str.find_first_of("+-/*^") == string::npos) {
        at_const_vec[n] = at_str;
      } else {
        at_const_vec[n] = "at" + int_to_string(n) + "_" + seq_name;
        aml_ele->addChild("constant")->addAttribute("name", at_const_vec[n])->addAttribute("design", at_str);
      }
      at_const_map[ele_name] = at_const_vec[n];
    }

    // add elements

    UAPNode* seq_node = aml_ele->addChild("sector");
    seq_node->addAttribute("name", seq_name);
    seq_node->addAttribute("length", length);

    n = -1;
    for (NodeVecCIter ie = eles.begin(); ie != eles.end(); ie++) {
      UAPNode* x_seq_ele = *ie;
      n++;

      string type = x_seq_ele->getName();
      string name = x_seq_ele->getAttributeString("name");
      string ref  = x_seq_ele->getAttributeString("ref");
      string at   = at_const_vec[n];

      // There are four differnt sequence element sytaxes that can be here:
      //    <element name = "" inherit = "" at = "" attributes... />
      //    <element name = "" class = "" at = "" attributes... />
      //    <element ref = "" at = "" />           
      //    <sequence ref = "" at = "" />           
      // Rename the sequence to fool x_node_to_aml

      UAPNode* aml_seq_ele;

      if (ref != "") {
        aml_seq_ele = seq_node->addChild("element");
        if (type == "sequence") aml_seq_ele->setName("sector");
        aml_seq_ele->addAttribute("ref", ref);

      } else {       // has a name attribute
        x_node_to_aml (x_seq_ele, aml_root, seq_node, "at", "from");
        aml_seq_ele = seq_node->getChildren().back();
      }

      // "at", "from" information -> <superimpose>

      UAPNode* super_node = aml_seq_ele->addChild("superimpose");
      string from  = x_seq_ele->getAttributeString("from");
      if (from != "") at = at + " - " + at_const_map[from];
      super_node->addAttribute("offset", at);
      if (ele_origin != "") super_node->addAttribute("ele_origin", ele_origin);
    }

    return;

  }

  // set statement

  if (x_node_type == "set") {

    string ele_name = x_ele->getAttributeString("element");
    string x_attrib = x_ele->getAttributeString("attribute");
    string value    = x_ele->getAttributeString("value");

    string x_class = ele_name_to_x_class(ele_name) ;
    if (x_class == "") {
      info_out.error ("Element class name cannot be resolved in for: " + ele_name);
    }

    attribute_convert_struct attrib_info;
    if (!found_x_attrib(x_class, x_attrib, attrib_info)) {
      info_out.error ("Unknown set attribute: " + x_attrib, "Of: " + x_ele->toString());
      return;
    }

    if (attrib_info.aml_twig.target_attribute == "design")
       attrib_info.aml_twig.target_attribute = "";

    attrib_info.aml_twig.name = ele_name;

    value = x_expression_to_aml(value, attrib_info, ele_name);

    // bend set..
    // The values for e1 and e2 attributes for an rbend must be increased by angle/2

    if (x_class == "rbend" && (x_attrib == "e1" || x_attrib == "e2")) {
      bend_struct& bend = bend_map[ele_name];

      string c_name = ele_name + "_set_" + x_attrib;
      UAPNode* face = aml_ele->addChild("constant");
      face->addAttribute("name", c_name);
      face->addAttribute("design", value);
      if (x_attrib == "e1") bend_map[ele_name].e1 = c_name;
      if (x_attrib == "e2") bend_map[ele_name].e2 = c_name;

      if (bend.complete) {
        UAPNode* aml_node = aml_ele->addChild("set");
        aml_node->addAttribute("attribute", ele_name + "[bend:" + x_attrib + "]");
        aml_node->addAttribute("value", c_name + " + " + bend.angle_const + "/2");
      }

      return;
    }

    // bend: l, angle, rho, or g set.

    if ((x_class == "rbend" || x_class == "sbend") && 
         (x_attrib == "l" || x_attrib == "angle" || x_attrib == "rho" || x_attrib == "g")) {

      // If rho: The conversion of "value" from X to AML has already converted to g = 1/rho
      if (x_attrib == "rho") x_attrib = "g";

      // Define the appropriate <constant> to be used for the <set> and record 
      // the constant name in the bend_map.

      string c_name = ele_name + "_set_" + x_attrib;
      UAPNode* constant = aml_ele->addChild("constant");
      constant->addAttribute("name", c_name);
      constant->addAttribute("design", value);
      if (x_attrib == "g" || x_attrib == "rho") bend_map[ele_name].g = c_name;
      if (x_attrib == "l")      bend_map[ele_name].l = c_name;
      if (x_attrib == "angle") { 
        bend_map[ele_name].angle = c_name;
        bend_map[ele_name].angle_const = c_name;
      }

      // Check if we have complete information now (need to know two of three of k, g, angle)

      bend_struct& bend = bend_map[ele_name];
      int n_defined(0);
      if (bend.l != "")     n_defined++;
      if (bend.g != "")     n_defined++;
      if (bend.angle != "") n_defined++;
      if (n_defined == 3) {
        info_out.error ("Bend is overspecified on set! " + x_ele->toStringTree());
        return;
      }

      if (n_defined == 2) bend.complete = true;

      // Create the <set>. 
      // We only need to create a <set> if we have complete information.

      if (bend.complete) {

        if (x_class == "sbend") { 
          UAPNode* aml_node = aml_ele->addChild("set");
          if (x_attrib == "l") {
            aml_node->addAttribute("attribute", ele_name + "[length]");
            aml_node->addAttribute("value", bend.l);
          } else if (x_attrib == "g") {
            aml_node->addAttribute("attribute", ele_name + "[bend:g]");
            aml_node->addAttribute("value", bend.g);
          } else {   // Must be an angle set
            if (bend.l != "") {   // angle, l defined
              aml_node->addAttribute("attribute", ele_name + "[bend:g]");
              aml_node->addAttribute("value", bend.angle_const + "/" + bend.l);
            } else {              // angle, g defined
              aml_node->addAttribute("attribute", ele_name + "[length]");
              aml_node->addAttribute("value", bend.angle_const + "/" + bend.g);
            }
          }
        }

        // For an rbend set, we will need more than one <set>.
        // Also another constant for the true arc length will be created

        if (x_class == "rbend") {

          bend.l_true = ele_name + "_l_true";
          UAPNode* l_true = aml_ele->addChild("constant");
          l_true->addAttribute("name", bend.l_true);

          UAPNode* aml_set_l = aml_ele->addChild("set");
          aml_set_l->addAttribute("attribute", ele_name + "[length]");
          aml_set_l->addAttribute("value", bend.l_true);


          if (bend.l == "") {     // Must have g and angle
            l_true->addAttribute("design", bend.angle_const + "/" + bend.g);
          } else if (bend.g == "") { // Must have l_chord and angle
            l_true->addAttribute("design", 
                     bend.angle_const + "*" + bend.l + "/(2*sin(" + bend.angle_const + "/2))");
            UAPNode* aml_set_g = aml_ele->addChild("set");
            aml_set_g->addAttribute("attribute", ele_name + "[bend:g]");
            aml_set_g->addAttribute("value", bend.angle_const + "/" + bend.l_true);
          } else {  // Must have l_chord and g
            l_true->addAttribute("design", bend_map[ele_name].angle_const + "/" + bend.g); 
          } 

          // Must redefine e1 and e2

          UAPNode* aml_set_e1 = aml_ele->addChild("set");
          aml_set_e1->addAttribute("attribute", ele_name + "[bend:e1]");
          UAPNode* aml_set_e2 = aml_ele->addChild("set");
          aml_set_e2->addAttribute("attribute", ele_name + "[bend:e2]");

          if (bend.e1 == "") 
            aml_set_e1->addAttribute("value", bend.angle_const + "/2");
          else
            aml_set_e1->addAttribute("value", bend.e1 + " + " + bend.angle_const + "/2");

          if (bend.e2 == "") 
            aml_set_e2->addAttribute("value", bend.angle_const + "/2");
          else
            aml_set_e2->addAttribute("value", bend.e2 + " + " + bend.angle_const + "/2");

        } // if (x_class == "rbend")

      }  // if (bend.complete)

      return;

    }

    //------------------------------------------------------------

    // String or number set is determined by presense of "@string" in attribute string

    if (attrib_info.aml_twig.target_attribute.find("string") == string::npos) {
      UAPNode* aml_node = aml_ele->addChild("set");
      aml_node->addAttribute("attribute", attrib_info.aml_twig.toString());
      aml_node->addAttribute("value", value);
    } else {
      UAPNode* aml_node = aml_ele->addChild("string_set");
      aml_node->addAttribute("attribute", attrib_info.aml_twig.toString());
      aml_node->addAttribute("string", value);
    }

    return;
  }

  // USE statement
  // Save info for later...

  if (x_node_type == "use") {
    use_parent = aml_ele;
    use_line = x_ele->getAttributeString("line");
    return;
  }

  // transfer all lines and lists

  if (x_node_type == "line" || x_node_type == "list") {
    string str = "sector";
    if (x_node_type == "list") str = "list";
    UAPNode* aml_node = aml_ele->addChild(str);
    aml_node->addAttribute("name", x_ele->getAttributeString("name"));
    StrList arg_list;
    AU.getSectorArgList (x_ele, arg_list);
    x_to_aml_sector (x_ele, aml_node, arg_list);
    return;
  }

  // title statement

  if (x_node_type == "title") {
    aml_node = aml_ele->addChild("comment");
    aml_node->addAttribute("type", "title");
    aml_node->addAttribute("text", x_ele->getAttributeString("text"));
    return;
  }

  // constant statement

  if (x_node_type == "constant") {
    aml_node = aml_ele->addChild("constant");
    aml_node->addAttribute ("name", x_ele->getAttributeString("name"));
    aml_node->addAttribute ("design", 
            x_expression_to_aml(x_ele->getAttributeString("design")));
    string type = x_ele->getAttributeString("type");
    if (type != "") aml_node->addAttribute ("type", type);
    return;
  }

  // call statement

  if (x_node_type == "call") {
    aml_node = aml_ele->addChild("{http://www.w3.org/2001/XInclude}xi:include");
    string str = x_ele->getAttributeString("filename");
    if (str != "") aml_node->addAttribute("href", str);
    x_rep_to_aml (x_ele, aml_node);
    return;
  }

  // comment statement

  if (x_node_type == "comment") {
    aml_node = aml_ele->addChild("comment");
    aml_node->addAttribute("text", x_ele->getAttributeString("text"));
    return;
  }

  // parameter, beam, beginning, and beam_start statements

  if (x_node_type == "parameter" || x_node_type == "beam" || 
      x_node_type == "beginning" || x_node_type == "beam_start") {
    x_parameter_to_aml (x_ele, aml_ele);
    return;
  }

  // element.

  UAPNode* aml_class_node;

  if (x_node_type == "element") { 
    string inherit;
    aml_node = aml_ele->addChild("element");
    ele_name = x_ele->getAttributeString("name");
    aml_node->addAttribute ("name", ele_name);
    name_to_aml_node_map[ele_name] = aml_node;
    string x_class = x_ele->getAttributeString("class");

    if (x_class != "") {
      // if class is like "quadrupole:solenoid" then create multiple children.
      // We may need to add node attributes. Eg: "rf_cavity(type=LINAC)".
      aml_class = x_class_to_aml_map[x_class];
      Twig twig;
      twig.fromString(aml_class);
      for (NodeIDVecCIter ni = twig.nodeid_vec.begin(); ni != twig.nodeid_vec.end(); ni++) {
        aml_class_node = aml_node->addChild(ni->name);
        for (AttributeIDVecCIter ai = ni->attribute.begin(); ai != ni->attribute.end(); ai++) 
          aml_class_node->addAttribute(ai->name, ai->value);
      }

    } else {
      inherit = x_ele->getAttributeString("inherit");
      aml_node->addAttribute ("inherit", inherit);
    }

    x_element_attributes_to_aml (x_ele, aml_root, aml_node, ignore_this1, ignore_this2);

    // For bends put in the attributes of length, etc.
    // To avoid problems, define appropriate constants ouside the element proper.
    // But only do this the first time the element is defined. (madx allows multiple defs.)

    x_class = ele_name_to_x_class(ele_name);

    if ((x_class == "rbend" || x_class == "sbend") && !bend_map[ele_name].consts_constructed) {

      if (!found(bend_map, inherit)) inherit = "";
      bend_struct bend_base;
      if (inherit != "") {
        bend_base = bend_map[inherit];
        if (bend_map[ele_name].e1 == "")    bend_map[ele_name].e1  = bend_base.e1;
        if (bend_map[ele_name].e2 == "")    bend_map[ele_name].e2  = bend_base.e2;
      }

      bend_struct& bend = bend_map[ele_name];
      int n_defined(0);
      if (bend.l != "" || bend_base.l != "") n_defined++;
      if (bend.g != "" || bend_base.g != "") n_defined++;
      if (bend.angle != "" || bend_base.angle != "") n_defined++;
      if (n_defined == 3) {
        info_out.error ("Bend is overspecified! " + x_ele->toStringTree());
        return;
      }

      UAPNode* bend_node = aml_node->getChildByName("bend", true);

      if (bend_base.complete || n_defined == 2) bend.complete = true;

      // We only need to do anything if something is defined and we have complete inormation.

      if (bend.complete && (bend.l != "" || bend.g != "" || bend.angle != "")) {

        if (inherit != "") {
          if (bend.l == "")           bend.l           = bend_base.l;
          if (bend.g == "")           bend.g           = bend_base.g;
          if (bend.angle == "")       bend.angle       = bend_base.angle;
          if (bend.angle_const == "") bend.angle_const = bend_base.angle_const;
        }

        if (x_class == "sbend") { 
          UAPNode* last_child = aml_root->getChildren().back();
          // Transfer inherited values
          // Now set appropriate value in the element
          if (bend.l == "") {     // Must have g and angle
            aml_node->addChild("length")->addAttribute("design", bend.angle + "/" + bend.g);
          } else if (bend.g == "") { // Must have l and angle
            bend_node->addChild("g")->addAttribute("design", bend.angle + "/" + bend.l);
          } else {                   // Must have l and g
            bend_map[ele_name].angle_const = ele_name + "_angle";
            UAPNode* angle = aml_root->addChild("constant", last_child);
            angle->addAttribute("name", bend_map[ele_name].angle_const);
            angle->addAttribute("design", bend.l + "/" + bend.g);
          } 
        }

        // Add constant nodes just before the last child of aml_root

        if (x_class == "rbend") {
          UAPNode* last_child = aml_root->getChildren().back();
          bend.l_true = ele_name + "_l_true";
          UAPNode* l_true = aml_root->addChild("constant", last_child);
          l_true->addAttribute("name", bend.l_true);

          if (bend.l == "") {     // Must have g and angle
            l_true->addAttribute("design", bend.angle + "/" + bend.g);
          } else if (bend.g == "") { // Must have l_chord and angle
            string l_str = bend.angle_const + "*" + bend.l + "/(2*sin(" + bend.angle_const + "/2))";
            l_true->addAttribute("design", l_str);
            bend_node->addChild("g")->addAttribute("design", bend.angle + "/" + bend.l_true);
          } else {  // Must have l_chord and g
            bend_map[ele_name].angle_const = ele_name + "_angle";
            UAPNode* angle = aml_root->addChild("constant", last_child);
            angle->addAttribute("name", bend_map[ele_name].angle_const);
            angle->addAttribute("design", "2*asin(" + bend.l + "/2)");
            l_true->addAttribute("design", bend_map[ele_name].angle_const + "/" + bend.g); 
          } 
          aml_node->addChild("length")->addAttribute("design", bend.l_true);

          // Must redefine e1 and e2
          if (bend.e1 == "") 
            bend_node->addChild("e1")->addAttribute("design", bend.angle_const + "/2"); 
          else
            bend_node->addChild("e1")->
                addAttribute("design", bend.e1 + " + " + bend.angle_const + "/2"); 

          if (bend.e2 == "") 
            bend_node->addChild("e2")->addAttribute("design", bend.angle_const + "/2"); 
          else
            bend_node->addChild("e2")->
                          addAttribute("design", bend.e2 + " + " + bend.angle_const + "/2"); 

        }

      // Here is have a complete rbend with no (l, g, or angle) defined in the element.
      // Therefore: Must have inherited stuff.
      // The only worry here if e1 or e2 is set.

      } else if (bend.complete && x_class == "rbend") {
        if (bend.e1 != "") bend_node->addChild("e1")->addAttribute("design", 
                                  bend_base.e1 + " + " + bend.angle_const + "/2"); 
        if (bend.e2 != "") bend_node->addChild("e2")->addAttribute("design", 
                                  bend_base.e2 + " + " + bend.angle_const + "/2"); 
      }

      // Transfer inherited values for future reference.

      if (inherit != "") {
        if (bend.l_true == "")       bend.l_true       = bend_base.l_true;
        if (bend.l == "")            bend.l            = bend_base.l;
        if (bend.g == "")            bend.g            = bend_base.g;
        if (bend.angle == "")        bend.angle        = bend_base.angle;
        if (bend.angle_const == "")  bend.angle_const  = bend_base.angle_const;
        if (bend.e1 == "")           bend.e1           = bend_base.e1;
        if (bend.e2 == "")           bend.e2           = bend_base.e2;
      }

      bend.consts_constructed = true;

    }  // if (x_class == "rbend" || x_class == "sbend") {

    return;

  }   // if (x_node_type == "element") 

  // error

  info_out.error (language + " node not recognized: " + x_ele->toString());
  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_parameter_to_aml (UAPNode* x_param_node, UAPNode* aml_root) {

  // Get the X information

  string x_param_class = x_param_node->getName();
  
  AttributeVec alist = x_param_node->getAttributes();
  for (AttributeVecCIter ia = alist.begin(); ia != alist.end(); ia++) {
    UAPAttribute attrib = *ia;

    string x_param_name = attrib.getName();
    string param_value = attrib.getValue();

    // Ignore comments

    if (x_param_name == "comment") continue;

    // Translate value

    for (ParamValueStructVecIter ip = param_values_list.begin(); 
                                        ip != param_values_list.end(); ip++) {
      if (ip->x_value == param_value) {
        param_value = ip->aml_value;
        break;
      }
    }

    // Look for the conversion structure and get the value of the attribute.

    attribute_convert_struct attrib_info;
    if (!found_x_attrib(x_param_class, x_param_name, attrib_info)) {
      info_out.error ("Unknown parameter attribute: " + x_param_name, " Of: " + x_param_node->toString());
      continue;
    }

    string aml_value = x_expression_to_aml(param_value, attrib_info);

    // Construct an AML class node for this parameter if not already created.
    // The convention is to use the class name for both the AML name and "name" attribute 
    // name. Eg: <beam name = "beam">

    string aml_param_class = attrib_info.aml_twig.name;
    Twig twig;
    twig.fromString(aml_param_class + "(name = '" + aml_param_class + "')");
    UAPNode* aml_class_node = twig.getSubNode (aml_lab_root);
    if (!(aml_class_node)) aml_class_node = aml_root->addChild(aml_param_class);
    aml_class_node->addAttribute("name", aml_param_class);

    // Now create the appropriate parameter subnode

    UAPNode* node = attrib_info.aml_twig.getLocalSubNode(aml_class_node, true);
    node->addAttribute(attrib_info.aml_twig.target_attribute, aml_value);
  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_element_attributes_to_aml (UAPNode* x_node, UAPNode* aml_root, 
            UAPNode* aml_node, const string& ignore_this1, const string& ignore_this2) {

  bool ok;
  string ele_name = x_node->getAttributeString("name");
  string x_class = x_node_to_x_class (x_node);

  // Loop over all attributes that are AML attributes of x_node.
  // [as opposed to attributes that are stored in the children of x_node.]
    
  bool e1_found = false, e2_found = false, fintx_found = false, hgapx_found = false;
  string fint = "", hgap = "";

  AttributeVec a_list = x_node->getAttributes();
  for (AttributeVecCIter ia = a_list.begin(); ia != a_list.end(); ia++) {

    string x_attrib = ia->getName();
    if (x_attrib == ignore_this1 || x_attrib == ignore_this2) continue;

    if (custom_x_element_attribute_to_aml (x_class, *ia, aml_node)) continue;

    if (x_attrib == "name") continue;
    if (x_attrib == "comment") continue;
    if (x_attrib == "inherit") continue;
    if (x_attrib == "attribute") continue;
    if (x_attrib == "class") continue;

    string value0 = ia->getValue();

    // This for attributes that do not fit in the general sorting scheme...
    // Matrix elements get converted to taylor terms.

    string a1 = x_attrib.substr(0,1);
    string a2 = x_attrib.substr(0,2);
    string a4 = x_attrib.substr(0,4);

    if (x_class == "matrix" && (a2 == "rm" || a2 == "tm" || a4 == "kick")) {

      int i, j, k;
      string i_str, exp = "0 0 0 0 0 0";
      bool ok1, ok2, ok3;

      if (a4 == "kick") {

        i_str = x_attrib.substr(4,1);
        i = string_to_int(i_str, ok1);
        if (!ok1 || i < 1 || i > 6) {
          info_out.error ("Malformed matrix kick attribute: " + x_attrib,
                       "In: " + x_node->toString());
          return;
        }
      }

      if (a2 == "rm") {
        i_str = x_attrib.substr(2,1);
        i = string_to_int(i_str, ok1);
        j = string_to_int(x_attrib.substr(3,1), ok2);
        if (!ok1 || i < 1 || i > 6 || !ok2 || j < 1 || j > 6) {
          info_out.error ("Malformed matrix rm attribute: " + x_attrib,
                       "In: " + x_node->toString());
          return;
        }
        exp.replace(2*j-2, 1, "1");
      }

      if (a2 == "tm") {
        i_str = x_attrib.substr(2,1);
        i = string_to_int(i_str, ok1);
        j = string_to_int(x_attrib.substr(3,1), ok2);
        k = string_to_int(x_attrib.substr(4,1), ok3);
        if (!ok1 || i < 1 || i > 6 || !ok2 || j < 1 || j > 6 || !ok3 || k < 0 || k > 6) {
          info_out.error ("Malformed matrix tm attribute: " + x_attrib,
                       "In: " + x_node->toString());
          return;
        }
        exp.replace(2*j-2, 1, "1");
        if (k == j) 
          exp.replace(2*k-2, 1, "2");
        else
          exp.replace(2*k-2, 1, "1");

      }

      string value = x_expression_to_aml(value0);

      UAPNode* term = aml_node->getChildByName("taylor_map")->addChild("term");
      term->addAttribute("i_out", i_str);
      term->addAttribute("coef", value);
      term->addAttribute("exp", exp);

      continue;

    }

    // Regular attribute: Look for the conversion structure and get the value of the attribute.

    attribute_convert_struct attrib_info;
    if (!found_x_attrib(x_class, x_attrib, attrib_info)) {
      info_out.error ("Unknown element attribute: " + x_attrib, "Of: " + x_node->toString());
      continue;
    }

    string value = x_expression_to_aml(value0, attrib_info, ele_name);

    // bend attributes must be recorded (made into constatns) and sorted out later...
    // Constants must be added just before the last child in aml_root
    // Exception: If an element of the same name already exists, assume
    //  that the attributes are the same.

    if (x_class == "sbend") {

      if (found(bend_map, ele_name)) continue;  // Check if already exists.

      UAPNode* last_child = aml_root->getChildren().back();

      if (x_attrib == "l") {
        bend_map[ele_name].l = ele_name + "[length]";  // Value stored in element
      }

      if (x_attrib == "angle") {
        bend_map[ele_name].angle = ele_name + "_angle";
        bend_map[ele_name].angle_const = bend_map[ele_name].angle;
        UAPNode* constant = aml_root->addChild("constant", last_child); 
        constant->addAttribute("name", bend_map[ele_name].angle);
        constant->addAttribute("design", value);
        continue;
      }

      if (x_attrib == "g" || x_attrib == "rho") {
        bend_map[ele_name].g = ele_name + "[g]";
        UAPNode* constant = aml_root->addChild("constant", last_child);
        constant->addAttribute("name", bend_map[ele_name].g);
        constant->addAttribute("design", value);
        continue;
      }
  
    }

    if (x_class == "rbend") {

      if (found(bend_map, ele_name)) continue;  // Check if already exists.

      UAPNode* last_child = aml_root->getChildren().back();

      if (x_attrib == "l") {  // This is the chord length
        bend_map[ele_name].l = ele_name + "_l_chord";
        UAPNode* constant = aml_root->addChild("constant", last_child);
        constant->addAttribute("name", bend_map[ele_name].l);
        constant->addAttribute("design", value);
        continue;
      }

      if (x_attrib == "angle") {
        bend_map[ele_name].angle = ele_name + "_angle";
        bend_map[ele_name].angle_const = bend_map[ele_name].angle;
        UAPNode* constant = aml_root->addChild("constant", last_child);
        constant->addAttribute("name", bend_map[ele_name].angle);
        constant->addAttribute("design", value);
        continue;
      }

      if (x_attrib == "g" || x_attrib == "rho") {
        bend_map[ele_name].g = ele_name + "_g";
        UAPNode* constant = aml_root->addChild("constant", last_child);
        constant->addAttribute("name", bend_map[ele_name].g);
        constant->addAttribute("design", value);
        continue;
      }
  
      if (x_attrib == "e1") {
        bend_map[ele_name].e1 = ele_name + "_e1";
        UAPNode* constant = aml_root->addChild("constant", last_child);
        constant->addAttribute("name", bend_map[ele_name].e1);
        constant->addAttribute("design", value);
        continue;
      }
  
      if (x_attrib == "e2" ) {
        bend_map[ele_name].e2 = ele_name + "_e2";
        UAPNode* constant = aml_root->addChild("constant", last_child); 
        constant->addAttribute("name", bend_map[ele_name].e2);
        constant->addAttribute("design", value);
        continue;
      }
  
    }

    // IGNORE means there is no corresponding aml attribute (this is not an error).

    if (attrib_info.x_to_aml_template == IGNORE) continue;

    // Now for the general attribute conversion...
    // Some special cases for a bend: fint and hgap can set both entrance and exit values.

    if (value == "") {
      if (x_attrib == "tilt") {
        if (x_class == "rbend" || x_class == "sbend") value = "pi/2";
        if (x_class == "quadrupole") value = "pi/4";
        if (x_class == "sextupole") value = "pi/6";
        if (x_class == "octupole") value = "pi/8";
        if (x_class == "sol_quad") value = "pi/4";
      }

      if (x_class == "multipole") {
        bool ok;
        int n = string_to_int(x_attrib.substr(1), ok);
        value = "pi / " + int_to_string((n + 1) * 2, ok);
      }
    }

    if (x_attrib == "fint") {
      if (value == "") value = "0.5";
      fint = value;
    }

    if (x_attrib == "hgap") hgap = value;

    if (x_attrib == "fintx") fintx_found = true;
    if (x_attrib == "hgapx") hgapx_found = true;
    if (x_attrib == "e1")    e1_found    = true;
    if (x_attrib == "e2")    e2_found    = true;

    // Check to see if the parent or grand_parent nodes exists. 
    // If not then we need to create it.

    UAPNode* a_node = attrib_info.aml_twig.getLocalSubNode(aml_node, true);

    // Create the AML node with the proper attributes.

    a_node->addAttribute(attrib_info.aml_twig.target_attribute, value);

  }     // attribute list loop

  // bend stuff. The <bend> child may not exist if the element is 
  // inheriting from another element.

  if (!fintx_found && fint != "") {
    UAPNode* bend_node = aml_node->getChildByName("bend", true);
    bend_node->addChild("f_int2")->addAttribute("design", fint);
  }

  if (!hgapx_found && hgap != "") {
    UAPNode* bend_node = aml_node->getChildByName("bend", true);
    bend_node->addChild("h_gap2")->addAttribute("design", hgap);
  }

  // Custom conversion if needed

  custom2_x_element_attribute_to_aml (x_node, aml_node);

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::x_node_to_x_class (UAPNode* x_ele) {

  // Find the class. There are three places it might be...
  // First try the element name which might be something like "beam".

  if (x_ele->getName() != "element") return x_ele->getName();

  // See if there is a class attribute

  if (x_ele->getAttribute("class")) return x_ele->getAttributeString("class");

  // Otherwise look for an inheritance.

  string inherit = x_ele->getAttributeString("inherit");

  string x_class = ele_name_to_x_class(inherit);
  if (x_class == "")
    info_out.error ("Class name cannot be resolved for element: " + x_ele->toString());

  return x_class;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::x_to_aml_sector (UAPNode* x_line, UAPNode* aml_sector, StrList& arg_list) {

  // Add arguments

  UAPAttribute* attrib;

  transfer_attribute(x_line, "args", aml_sector, "args");
  transfer_attribute(x_line, "multipass", aml_sector, "multipass");

  //

  NodeVec x_eles = x_line->getChildren();
  for (NodeVecCIter nt = x_eles.begin(); nt != x_eles.end(); nt++) {
    UAPNode* x_ele = *nt;
    string ref_str = x_ele->getAttributeString("ref");
    string ele_class = x_ele->getName();
    if (ele_class == "item") {
      if (found(name_to_x_type_map, ref_str)) {
        ele_class = name_to_x_type_map[ref_str];
        if (ele_class == "list") ele_class = "element";
      } else if (found(arg_list, ref_str)) {
        ele_class = "arg";
      } else {
        info_out.error ("CANNOT CONNECT NAME TO A LINE, LIST ELEMENT OR SEQUENCE: ", 
                      x_ele->toString());
        return false;
      }
    }

    UAPNode* aml_ele;
    string args = x_ele->getAttributeString("args");

    // Elements are straight forward

    if (ele_class == "element" || ele_class == "arg") {
      aml_ele = aml_sector->addChild("element");
      aml_ele->addAttribute("ref", ref_str);

    // A line with no args will have a subline.
    // A replacement line has args but no children.

    } else if (ele_class == "line") {
      if (args == "") {
        aml_ele = aml_sector->addChild("sector");
        if (ref_str != "") aml_ele->addAttribute("ref", ref_str);
        x_to_aml_sector (x_ele, aml_ele, arg_list);
      } else {
        aml_ele = aml_sector->addChild("sector");
        aml_ele->addAttribute("ref", ref_str);
        aml_ele->addAttribute("args", args);
      }

    } else {
      info_out.error ("Unknown class: " + x_ele->toString());
      return false;
    }

    if (attrib = x_ele->getAttribute("tag")) 
      aml_ele->addAttribute("tag", attrib->getValue());

    string repeat = x_ele->getAttributeString("repeat");
    if (repeat != "") {
      if (repeat.substr(0,1) == "-") {
        aml_ele->addAttribute("reflection", "TRUE");
        repeat.erase(0,1);
      }
      if (repeat != "1") aml_ele->addAttribute("repeat", repeat);
    }

  }

  return true;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::x_expression_to_aml (const string& x_expression, 
                          attribute_convert_struct attrib_info, const string& ele_name) {


  // Switch conversion

  for (ParamValueStructVecIter ip = param_values_list.begin(); 
                                      ip != param_values_list.end(); ip++) {
    if (ip->x_value == x_expression) return ip->aml_value;
  }

  // Convert attributes like "q[k1]" or "q->k1" to "q[quadrupole:k(n=1)]".
  // As an intermediary, convert "q[k1]" or "q->k1" to "q:k1".
  // i0 points to the first character in a variable.
  // i2 points to the last character in a variable ("]").

  size_t i0, i1, i2, n;
  string aml_exp = x_expression;

  // Substitute: "->"  ->  "[" to not confuse token parser

  if (c_style_format) {
    while (true) {
      if ((i1 = aml_exp.find("->")) == string::npos) break;
      aml_exp.replace(i1, 2, "[");
    }
  }

  // Loop and convert all attributes and constants one-by-one.

  i0 = 0;
  while (true) {
    string token = next_token_in_expression(aml_exp, c_style_format, i0, n);
    if (i0 == aml_exp.size()) break;

    // A "[" indicates an attribute.

    if ((i1 = token.find("[")) != string::npos) {

      // Break, say "beam[energy]" into its components
      if (c_style_format) {
        i2 = token.size();
      } else {
        if (token.find("]") != token.size() - 1) {
          info_out.error ("No matching ']' for opening '[' in expression: " + x_expression);
          return "";
        }
        i2 = token.size() - 1;
      }

      string this_ele_name = token.substr(0, i1);
      string x_attrib = token.substr(i1+1, i2-i1-1);

      string x_class  = ele_name_to_x_class(this_ele_name, true);
      if (x_class == "") {
        info_out.error ("Class name cannot be resolved for: " + this_ele_name, 
                     "In expression: " + x_expression);
        return aml_exp;
      }

      attribute_convert_struct at_info;
      if (!found_x_attrib(x_class, x_attrib, at_info)) {
        info_out.error ("Unknown attribute: " + x_attrib, "In expression: " + x_expression);
        return aml_exp;
      }

      // An explicit aml node name means that this is a parameter like "beam[energy]".
      // In which case use it over the "element name".

      if (at_info.aml_twig.name != "") 
        this_ele_name = at_info.aml_twig.name;

      // Replace x-attribute name with aml-attribute name.
      // Also convert the attribute units *backwards*.
      // Eg: "ele[volt]" -> "ele[rfcavity:voltage] / 1e6".

      aml_exp.erase(i0, n);
      string aml_attrib = this_ele_name + "[" + at_info.aml_twig.toNodeString() + "]";
      aml_attrib = convert_single_attribute (aml_attrib, 
                      at_info.aml_to_x_template, at_info.x_to_aml_template, this_ele_name);
      if (aml_exp.size() != 0) aml_attrib = "(" + aml_attrib + ")";
      aml_exp.insert(i0, aml_attrib);

      i0 += aml_attrib.size();


    // Otherwise it might be a constant

    } else {
  
      for (ConstantsVecIter ic = constants_list.begin(); ic != constants_list.end(); ic++) {
        if (ic->x_to_aml_template == IGNORE) continue;
        if (ic->x_const == token) {
          string aml_const = ic->x_to_aml_template;
          if (aml_const == "") aml_const = ic->aml_const;
          aml_exp.erase(i0, n);
          if (aml_exp.size() != 0 && aml_const.find(" ") != string::npos) 
            aml_const = "(" + aml_const + ")";
          aml_exp.insert(i0, aml_const);
          n = aml_const.size();
          break;
        }
      }

      i0 += n;

    }
  }


  //  Now make a conversion on the attribute associated with this expression.

  return convert_single_attribute (aml_exp, attrib_info.x_to_aml_template, 
                                             attrib_info.aml_to_x_template, ele_name);
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

UAPNode* TranslateCore::AMLRepToXFile(UAPNode* aml_root, 
                      const string& file_name, const Str& out_suffix, bool one_file ) {

  UAPNode* x_rep = AMLRepToXRep (aml_root);
  if (!x_rep) return false;
  return XRepToXFile (x_rep, file_name, out_suffix, one_file);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

UAPNode* TranslateCore::AMLRepToXRep(UAPNode* aml_root, UAPNode* x_root) {

  // Init

  name_to_x_class_map.clear();
  info_out.ix_line = -1;
  info_out.statement = "";
  info_out.parsing_status = "Translating from AML rep to " + language + " rep.";

  // Check where the aml_rep node is.

  UAPNode* aml_rep;
  UAPNode* uap_root = NULL;

  if (aml_root->getName() == "UAP_root") {
    uap_root = aml_root;
    aml_rep = aml_root->getChildByName("AML_representation");
    if (!aml_rep) {
      info_out.error ("<UAP_root> does not have a <AML_representation> child.");
      return NULL;
    }
  } else if (aml_root->getName() == "AML_representation") {
    aml_rep = aml_root;
    uap_root = aml_root->getParent();
  } else {
    info_out.error ("aml_root argument is not a <UAP_root> node nor a <AML_representation> node",
    aml_root->toString());
    return NULL;
  }

  // Find or construct the x_rep if needed

  UAPNode* x_rep = x_root;

  if (!x_rep) {
    if (uap_root) {
      NodeVec reps = uap_root->getChildrenByName(language + "_representation");
      for (NodeVecIter ir = reps.begin(); ir != reps.end(); ir++) (*ir)->deleteNode();
      x_rep = uap_root->addChild(language + "_representation");
    } else {
      x_rep = new UAPNode(language + "_representation");
    }    

  } else if (x_rep->getName() == "UAP_root") {
    NodeVec reps = x_rep->getChildrenByName(language + "_representation");
    for (NodeVecIter ir = reps.begin(); ir != reps.end(); ir++) (*ir)->deleteNode();
    x_rep = x_rep->addChild(language + "_representation");

  } else if (x_rep->getName() == language + "_representation") {
    UAPNode* root = x_rep->getParent();
    x_rep->deleteNode();
    if (root) x_rep = root->addChild(language + "_representation");
    else      x_rep = new UAPNode(language + "_representation");

  } else {
    info_out.error ("Argument is not a <UAP_root> node nor a <" + language + "_representation> node",
    x_root->toString());
    return NULL;
  }

  // Construct aml_rep and laboratory nodes

  x_rep->addAttribute ("source_language", "AML");

  if (aml_rep->getAttribute("filename"))
    x_rep->addAttribute("filename", aml_rep->getAttributeString("filename"));

  // Get the laboratory child

  UAPNode* lab = aml_rep->getChildByName("laboratory");
  if (!lab) {
    info_out.error ("no <laboratory> child found for " + aml_rep->getName() + " node.");
    return NULL;
  }

  // Transfer information from aml to x.

  aml_rep_to_x_init (lab);
  aml_rep_to_x (lab, x_rep);
  custom_aml_rep_to_x (lab, x_rep);

  return x_rep;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::aml_rep_to_x_init (UAPNode* aml_rep) {

  // Make lists of element names, line names, etc.

  name_to_aml_type_map.clear();
  name_to_x_type_map.clear();
  name_to_x_node_map.clear();
  name_to_aml_node_map.clear();
  aml_set_nodes.clear();
  aml_k_map.clear(); aml_ks_map.clear(); aml_tilt_map.clear();

  aml_rep_make_name_lists (aml_rep);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::aml_rep_make_name_lists (UAPNode* aml_rep) {

  // This routine loops over all aml nodes and makes a bunch of lists for later use.

  NodeVec list = aml_rep->getChildren();
  for (NodeVecCIter it = list.begin(); it != list.end(); it++) {
    UAPNode* node = *it;

    string node_name = node->getName();

    if (node_name == "set") {
      aml_set_nodes.push_back(node);
      continue;
    }    

    string name = node->getAttributeString("name");
    aml_rep_make_name_lists (node);
    if (name == "") continue;
    name_to_aml_node_map[name] = node;

    if (node_name == "sector" || node_name == "list" || node_name == "sequence") {
      name_to_aml_type_map[name] = node_name;
      continue;
    }    

    if (node_name == "lattice" || node_name == "beam" || node_name == "parameter") {
      name_to_aml_type_map[name] = node_name;
      continue;
    }    

    if (node_name == "controller") {
      string x_class;
      aml_ele_to_x_class (node, x_class);
      name_to_aml_type_map[name] = x_class;
      name_to_x_class_map[name] = x_class;
      continue;
    }    

    if (node_name == "element") {
      name_to_aml_type_map[name] = node_name;
      string inherit = node->getAttributeString("inherit");
      string x_class;
      if (inherit != "") {
        x_class = ele_name_to_x_class(inherit);
      } else {
        if (!aml_ele_to_x_class(node, x_class)) continue;
      }
      name_to_x_class_map[name] = x_class;
      continue;
    }    

  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::aml_rep_to_x (UAPNode* lab, UAPNode* x_rep) {

  // Loop over all laboratory children and translate.

  NodeVec eles = lab->getChildren();
  for (NodeVecCIter ie = eles.begin(); ie != eles.end(); ie++) {
    UAPNode* aml_ele = *ie;
    aml_node_to_x (aml_ele, x_rep);
  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::aml_node_to_x (UAPNode* aml_ele, UAPNode* x_root, const Str& ignore_this_attribute) {

  string aml_name = aml_ele->getName();
  bool ok;

  // Custom conversions

  if (custom_aml_node_to_x (aml_ele, x_root)) return;

  // include node. This may or may not have a <laboratory> child

  if (aml_name == "include") {
    string file = aml_ele->getAttributeString("href");
    if (file == "") {
      info_out.error ("No href attribute associated with <include> node.");
    }
    UAPNode* x_ele = x_root->addChild("call");
    x_ele->addAttribute ("filename", file);
    UAPNode* sub_lab = aml_ele->getChildByName("laboratory");
    if (sub_lab) aml_ele = sub_lab;
    aml_rep_to_x (aml_ele, x_ele);
    return;
  }

  // comment node

  if (aml_name == "comment") {
    UAPNode* x_ele = x_root->addChild("comment");
    x_ele->addAttribute ("text", aml_ele->getAttributeString("text"));
    return;
  }

  // doc node: There is no X equivalent.

  if (aml_name == "doc") return;

  // constant node

  if (aml_name == "constant") {
    UAPNode* x_ele = x_root->addChildCopy(aml_ele);
    UAPAttribute* design_attrib = x_ele->getAttribute("design");
    if (!design_attrib) {
      info_out.error ("No associated 'design' attribute in <constant> node.", x_ele->toString());
      return;
    }
    string value = aml_expression_to_x(design_attrib->getValue());
    design_attrib->setValue(value);
    return;
  }

  // set node

  if (aml_name == "set" || aml_name == "string_set") {
    Twig twig;
    if (!twig.fromString(aml_ele->getAttributeString("attribute"))) return;
    string ele_name = twig.name;
    string aml_attribute = twig.toNodeString(true);

    string x_class = ele_name_to_x_class(ele_name);

    // A set of k, ks, or tilt for a quadrupole, sextupole, or octupole

    if (twig.nodeid_vec.size() == 2) {
      string n0 = twig.nodeid_vec[0].name, n1 = twig.nodeid_vec[1].name;
      if ((n0 == "quadrupole" || n0 == "sextupole" || n0 == "octupole") &&
            knl_tn_style_multipoles && (n1 == "k" || n1 == "ks" || n1 == "tilt")) {
        string k_set, ks_set, tilt_set, n_str, value;
        value = aml_ele->getAttributeString("value");
        if (n1 == "k")          k_set = value;
        else if (n1 == "ks")    ks_set = value;
        else if (n1 == "tilt")  tilt_set = value;

        if (n0 == "quadrupole")     n_str = "1";
        else if (n0 == "sextupole") n_str = "2";
        else if (n0 == "octupole")  n_str = "3";

        string k_ele, ks_ele, tilt_ele;
        if (found (aml_k_map, ele_name)) {
          k_ele    = aml_k_map[ele_name];
          ks_ele   = aml_ks_map[ele_name];
          tilt_ele = aml_tilt_map[ele_name];
          required_multipole_transfer ("tilt", k_ele, ks_ele, tilt_ele, 
                                               k_set, ks_set, tilt_set);
        }
        
        string k, tilt;
        multipole_to_k_tilt (k_set, ks_set, tilt_set, n_str, k, tilt);


        if (k != "") {
          UAPNode* x_set = x_root->addChild("set");
          x_set->addAttribute("element", ele_name);
          x_set->addAttribute("attribute", "k" + n_str);
          x_set->addAttribute("value", k);
        }
        if (tilt != "") {
          UAPNode* x_set = x_root->addChild("set");
          x_set->addAttribute("element", ele_name);
          x_set->addAttribute("attribute", "tilt");
          x_set->addAttribute("value", tilt);
        }

        // record value for next set.
        if (n1 == "kl")        aml_k_map[ele_name]    = value;
        else if (n1 == "ksl")  aml_ks_map[ele_name]   = value;
        else if (n1 == "tilt") aml_tilt_map[ele_name] = value;

        return;
      }
    }   

    // Multipole

    if (twig.nodeid_vec.size() == 2) {
      string n0 = twig.nodeid_vec[0].name, n1 = twig.nodeid_vec[1].name;
      if (n0 == "multipole" &&
            knl_tn_style_multipoles && (n1 == "kl" || n1 == "ksl" || n1 == "tilt")) {
        string n = twig.nodeid_vec[1].attribute[0].value;
        int n_int = string_to_int(n, ok);
        if (!ok) {
          info_out.error ("Bad multipole integer order: " + n, 
                         "In AML element:", aml_ele->toStringTree());
          return;
        }
        string kl_set, ksl_set, tilt_set, n_str, value;
        value = aml_ele->getAttributeString("value");
        if (n1 == "kl")         kl_set   = value;
        else if (n1 == "ksl")   ksl_set  = value;
        else if (n1 == "tilt")  tilt_set = value;

        string kl_ele, ksl_ele, tilt_ele;
        if (found (aml_multi_tilt_map, ele_name)) {
          kl_ele   = aml_multi_kl_map[ele_name][n_int];
          ksl_ele  = aml_multi_ksl_map[ele_name][n_int];
          tilt_ele = aml_multi_tilt_map[ele_name][n_int];
          required_multipole_transfer ("tilt", kl_ele, ksl_ele, tilt_ele, 
                                               kl_set, ksl_set, tilt_set);
        } else {  // Init if needed
          aml_multi_kl_map[ele_name]   = StrVec(N_MULTIPOLE);
          aml_multi_ksl_map[ele_name]  = StrVec(N_MULTIPOLE);
          aml_multi_tilt_map[ele_name] = StrVec(N_MULTIPOLE);
        }
        

        string knl, tilt;
        multipole_to_k_tilt (kl_set, ksl_set, tilt_set, n, knl, tilt);

        if (knl != "") {
          UAPNode* x_set = x_root->addChild("set");
          x_set->addAttribute("element", ele_name);
          x_set->addAttribute("attribute", "k" + n + "l");
          x_set->addAttribute("value", knl);
        }

        if (tilt != "") {
          UAPNode* x_set = x_root->addChild("set");
          x_set->addAttribute("element", ele_name);
          x_set->addAttribute("attribute", "t" + n);
          x_set->addAttribute("value", tilt);
        }

        // record value for next set.
        if (n1 == "kl")        aml_multi_kl_map[ele_name][n_int]   = value;
        else if (n1 == "ksl")  aml_multi_ksl_map[ele_name][n_int]  = value;
        else if (n1 == "tilt") aml_multi_tilt_map[ele_name][n_int] = value;

        return;
      }

    }

    // Find the attribute information corresponding to this attribute.
    // It is not an error if the info on a non-AML attribute is not found.

    attribute_convert_struct attrib_info;

    if (!found_aml_attrib(x_class, aml_attribute, attrib_info)) {
      if (AMLUtilities::inAMLNameSpace(twig.nodeid_vec.back().xml_uri))
        info_out.error ("Unknown attribute: " + aml_attribute, "Of: " + aml_ele->toString());
      return;
    }
    if (attrib_info.aml_to_x_template == IGNORE) return;

    string value;
    if (aml_name == "set")
      value = aml_ele->getAttributeString("value");
    else
      value = aml_ele->getAttributeString("string");

    value = aml_expression_to_x(value, attrib_info, ele_name);
    UAPNode* x_ele = x_root->addChild("set");
    x_ele->addAttribute("element", ele_name);
    x_ele->addAttribute("attribute", attrib_info.x_name);
    x_ele->addAttribute("value", value);
    return;
  }

  // machine node
  // Skip machines that do not have a sector child. That is, are complex machines.

  if (aml_name == "machine") {
    NodeVec ch = aml_ele->getChildren();
    string name;
    for (NodeVecCIter ic = ch.begin(); ic != ch.end(); ic++) {
      UAPNode* sector = *ic;
      if (sector->getName() != "sector") continue;
      if (sector->getAttributeString("ref") != "") {
        name = sector->getAttributeString("ref");
      } else if (sector->getAttributeString("name") != "") {
        name = sector->getAttributeString("name");
      } else {
        info_out.error("Sector without ref or name attribute found in machine: " + 
                                                             aml_ele->toString());
        continue;
      }
      x_root->addChild("use")->addAttribute("line", name);
      break;
    }

    if (name == "") {
     info_out.error("No sector found for machine: " + aml_ele->toString());
     return;
    }

    aml_rep_to_x (aml_ele, x_root);
    return;
  }

  // beam node, etc.

  if (aml_name == "beam" || aml_name == "floor" || aml_name == "twiss" || 
      aml_name == "geometry" || aml_name == "parameter" || aml_name == "lattice") {
    aml_param_to_x (aml_ele, aml_ele, x_root);
    return;
  }

  // sector
  
  if (aml_name == "sector" || aml_name == "list") {
    if (aml_ele->getAttribute("name"))
      aml_sector_or_element_to_x (aml_ele, x_root);
    return;
  }

  // element.

  if (aml_name == "element") {

    if (!aml_ele->getAttribute("name")) return;

    UAPNode* x_ele = x_root->addChild("element");
    string ele_name = aml_ele->getAttributeString("name");
    x_ele->addAttribute("name", ele_name);
    string inherit = aml_ele->getAttributeString("inherit");
    name_to_x_node_map[ele_name] = x_ele;
    if (inherit == "") {
      x_ele->addAttribute("class", name_to_x_class_map[ele_name]);
    } else {
      x_ele->addAttribute("inherit", inherit);
    }

    aml_element_attributes_to_x (aml_ele, aml_ele, x_ele, ignore_this_attribute);
    string x_class = name_to_x_class_map[ele_name];

    // bend stuff.

    string fint = x_ele->getAttributeString("fint");
    string fintx = x_ele->getAttributeString("fintx");
    if (fint == fintx && fint != "") x_ele->removeAttribute("fintx");

    string hgap = x_ele->getAttributeString("hgap");
    string hgapx = x_ele->getAttributeString("hgapx");
    if (hgap == hgapx && hgap != "") x_ele->removeAttribute("hgapx");

    // Quad, sex, or oct multipole components are transfered to x_ele here.
    // We need to look at any inheritance to see if things need to be combined.
    // Note: Need to check that aml_k_map exists in case no k values were defined.

    if (knl_tn_style_multipoles) {

      if (found(aml_k_map, ele_name) && 
            (x_class == "quadrupole" || x_class == "sextupole" || x_class == "octupole")) {

        // If there is an inherited ks value then to keep things straight we need to update
        // The element's multipole values before transferring to x_ele.

        string inherit = x_ele->getAttributeString("inherit");
        if (found(aml_ks_map, inherit)) inherit = "";

        if (inherit != "") 
          required_multipole_transfer("ks",
                      aml_k_map[inherit], aml_ks_map[inherit], aml_tilt_map[inherit],
                      aml_k_map[ele_name], aml_ks_map[ele_name], aml_tilt_map[ele_name]);

        string k, tilt, n;

        if (x_class == "quadrupole")     n = "1";
        else if (x_class == "sextupole") n = "2";
        else if (x_class == "octupole")  n = "3";

        multipole_to_k_tilt (aml_k_map[ele_name], aml_ks_map[ele_name], 
                             aml_tilt_map[ele_name], n, k, tilt);
        if (k != "")    x_ele->addAttribute("k" + n, k);
        if (tilt != "") x_ele->addAttribute("tilt", tilt);

        // Transfer inherited multipole information to the element for future use.

        if (inherit != "") {
          if (aml_k_map[ele_name] == "")    aml_k_map[ele_name]    = aml_k_map[inherit];
          if (aml_ks_map[ele_name] == "")   aml_ks_map[ele_name]   = aml_ks_map[inherit];
          if (aml_tilt_map[ele_name] == "") aml_tilt_map[ele_name] = aml_tilt_map[inherit];
        }

      }

      // Multipole element.

      if (x_class == "multipole" && found(aml_multi_kl_map, ele_name)) {

        string inherit = x_ele->getAttributeString("inherit");
        if (aml_multi_kl_map.find(inherit) == aml_multi_kl_map.end()) inherit = "";


        for (int n = 0; n < N_MULTIPOLE; n++) {
          string kl_base, ksl_base, tilt_base, kl_ele, ksl_ele, tilt_ele;
          if (inherit != "") {
            kl_base   = aml_multi_kl_map[inherit][n];
            ksl_base  = aml_multi_ksl_map[inherit][n];
            tilt_base = aml_multi_tilt_map[inherit][n];
          }
          kl_ele   = aml_multi_kl_map[ele_name][n];
          ksl_ele  = aml_multi_ksl_map[ele_name][n];
          tilt_ele = aml_multi_tilt_map[ele_name][n];
          string kl, tilt, n_str = int_to_string(n);
          if (inherit != "") required_multipole_transfer ("ks", 
                                  kl_base, ksl_base, tilt_base, kl_ele, ksl_ele, tilt_ele); 

          multipole_to_k_tilt (kl_ele, ksl_ele, tilt_ele, n_str, kl, tilt);
          if (kl != "")   x_ele->addAttribute("k" + n_str + "l", kl);
          if (tilt != "") x_ele->addAttribute("t" + n_str, tilt);

          if (inherit != "") {
            if (kl_ele   == "") aml_multi_kl_map[ele_name][n]   = kl_base;
            if (ksl_ele  == "") aml_multi_ksl_map[ele_name][n]  = ksl_base;
            if (tilt_ele == "") aml_multi_tilt_map[ele_name][n] = tilt_base;
          }

        }

      }
    }

    return;
  }

  // None of the above.

  if (AMLUtilities::inAMLNameSpace(aml_ele))
    info_out.error ("AML node not recognized: " + aml_ele->toString());

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::aml_param_to_x (UAPNode* aml_root, UAPNode* aml_param, UAPNode* x_rep) {

  UAPNode* x_param_root;

  // aml_root is the root of the parameter sub-tree and aml_param is the current
  // node being parsed. 
  // If aml_param has children then parse them otherwise convert the aml_param node.

  // If there are children then recursively call this routine.

  NodeVec children = aml_param->getChildren();
  if (children.size() > 0) {

    for (NodeVecCIter ib = children.begin(); ib != children.end(); ib++)
      aml_param_to_x (aml_root, *ib, x_rep);

    return;

  // Otherwise convert this node.

  } else {

    // aml_param == aml_root means that the parameter sub-tree has no parameters.

    if (aml_param == aml_root) return;

    // Find the corresponding attribute.

    attribute_convert_struct attrib_info;
    if (!found_aml_attrib("", aml_root, aml_param, "", attrib_info)) {
      if (AMLUtilities::inAMLNameSpace(aml_param)) 
        info_out.error ("No corresponding " + language + " parameter for AML parameter: " + 
                                                                        aml_param->getName(),
                        "For: " + aml_param->getParent()->toStringTree());

      return;
    }
    if (attrib_info.aml_to_x_template == IGNORE) return;

    string value = aml_param->getAttributeString(attrib_info.aml_twig.target_attribute);
    if (value == "") 
      info_out.error ("For AML parameter: " + aml_param->toString(), 
                   "expected AML attribute: " + attrib_info.aml_twig.target_attribute);

    value = aml_expression_to_x (value, attrib_info);

    // Create the parameter node.

    x_param_root = x_rep->addChild(attrib_info.x_parent);

    for (ParamValueStructVecIter ip = param_values_list.begin(); 
                                        ip != param_values_list.end(); ip++) {
      if (ip->aml_value == value) {
        value = ip->x_value;
        break;
      }
    }

    x_param_root->addAttribute(attrib_info.x_name, value);

  }

  return;
}


//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::aml_element_attributes_to_x (UAPNode* aml_root, UAPNode* aml_ele, 
          UAPNode* x_ele, const string& ignore_this_attribute) {

  // Note: multipole terms (including terms from quadrupoles, etc.) are just stored but 
  // not transferred to x_ele.

  string aml_parent_name = aml_ele->getName();
  string aml_grand_p_name = aml_ele->getParent()->getName();
  string ele_name = x_ele->getAttributeString("name");
  string x_class = name_to_x_class_map[ele_name];
  bool ok;

  StrVec tilt_vec(N_MULTIPOLE), ksl_vec(N_MULTIPOLE), kl_vec(N_MULTIPOLE);

  // Loop over children.

  NodeVec c = aml_ele->getChildren();
  for (NodeVecCIter ic = c.begin(); ic != c.end(); ic++) {

    UAPNode* aml_attrib_node = *ic;
    string aml_attrib_name = aml_attrib_node->getName();
    if (aml_attrib_name == ignore_this_attribute) continue;

    // If there are subchildren then loop over the children

    if (aml_attrib_node->getChildren().size() > 0) {
      aml_element_attributes_to_x (aml_root, aml_attrib_node, x_ele);
      // continue;
    }

    // Custom attributes

    if (custom_aml_element_attribute_to_x(aml_root, aml_ele, aml_attrib_node, x_ele)) continue;

    // Things to ignore.

    if (aml_attrib_name == "description") continue;
    if (aml_attrib_name == "doc") continue;
    if (aml_attrib_name == "floor") continue;
    if (aml_attrib_name == "s") continue;


    // Multipole. Add this term to kl_vec, ksl_vec, or tilt_vec.

    if (aml_parent_name == "multipole" && (aml_attrib_name == "kl" || aml_attrib_name == "ksl" || 
                                                                       aml_attrib_name == "tilt")) {
      int n = string_to_int(aml_attrib_node->getAttributeString("n"), ok);
      string design = aml_attrib_node->getAttributeString("design");
      if (aml_attrib_name == "kl")        kl_vec[n] = design;
      else if (aml_attrib_name == "ksl")  ksl_vec[n] = design;
      else if (aml_attrib_name == "tilt") tilt_vec[n] = design;
      continue;  // Transfer to x_rep is handled later when all the info has been collected.
    }

    // If quad, sex, or oct element then collect a multipole k, ks, and tilt components.

    if (aml_parent_name == "quadrupole" || aml_parent_name == "sextupole" || aml_parent_name == "octupole") {

      if (aml_attrib_name == "orientation") {
        info_out.error ("Conversion with an <orientation> child of a <" + aml_parent_name + "> not allowed.",
                       "For: " + aml_root->toString());
        continue;
      }

      if (aml_attrib_name == "k") {
        aml_k_map[ele_name] = aml_attrib_node->getAttributeString("design");
        continue;        
      } else if (aml_attrib_name == "ks") {
        aml_ks_map[ele_name] = aml_attrib_node->getAttributeString("design");
        continue;        
      }

    }

    if (x_class == "quadrupole" || x_class == "sextupole" || x_class == "octupole") {
      if (aml_attrib_name == "tilt") {
        aml_tilt_map[ele_name] = aml_attrib_node->getAttributeString("design");
        continue;
      }
    }

    // Taylor -> matrix

    if (aml_parent_name == "taylor_map" && aml_attrib_name == "term") {
      bool ok;
      int i_out = string_to_int(aml_attrib_node->getAttributeString("i_out"), ok);
      if (i_out < 1 || i_out > 6) {
        info_out.error ("Taylor term has bad \"i_out\" index: ", aml_ele->toString(),
                     "In Taylor_map: " + aml_ele->toString());
        continue;;
      }
      string coef = aml_attrib_node->getAttributeString("coef");
      if (coef == "") {
        info_out.error ("Bad Taylor series term coef:", aml_attrib_node->toString(),
                     "In Taylor_map: " + aml_ele->toString());
        continue;;
      }
      string exp = aml_attrib_node->getAttributeString("exp");
      IntVec e(6);
      if (!get_taylor_exponents (exp, e)) return;
      int sum = e[0] + e[1] + e[2] + e[3] + e[4] + e[5];  
      if (sum > 2) {
        info_out.error ("Taylor series term has order > 2:", aml_attrib_node->toString(),
                     "In Taylor_map: " + aml_ele->toString());
        continue;;
      }
      string term;
      if (sum == 0) 
        term = "kick" + int_to_string(i_out, ok);
      else if (sum == 1) 
        term = "rm" + int_to_string(i_out, ok);
      else
        term = "tm" + int_to_string(i_out, ok);

      for (int i = 0; i < 6; i++) {
        if (e[i] == 1) term += int_to_string(i+1, ok);
        if (e[i] == 2) term += int_to_string(i+1, ok) + int_to_string(i+1, ok);
      }

      x_ele->addAttribute(term, coef);
      continue;
    }

    // Loop over all AML attributes

    AttributeVec att_list = aml_attrib_node->getAttributes();
    for (AttributeVecCIter design = att_list.begin(); design != att_list.end(); design++) {

      string design_name = design->getName();
      attribute_convert_struct attrib_info;

      // If an "actual" (which comes from lattice expansion) then ignore.

      if (design_name == "actual") continue;

      // If the attribute is actually the sub_name then ignore. 
      // Eg: aml_attrib_name = "k" and design_name = "n" as in "multipole:kl(n=1)"

      string full_name = aml_attrib_name + "(" +  design_name + "=" + design->getValue() + ")";
      if (found(aml_ignore_these_attribs, full_name)) continue;
      if (found_value(x_class_to_aml_map, full_name)) continue;
      if (aml_parent_name != "element") full_name = aml_parent_name + ":" + full_name;
      if (found_aml_attrib (x_class, full_name, attrib_info)) continue;
      if (aml_parent_name != "element") {
        string aml_grand_parent = aml_ele->getParent()->getName();
        if (aml_grand_parent != "element") {
          full_name = aml_grand_parent + ":" + full_name;
          if (found_aml_attrib (x_class, full_name, attrib_info)) continue;
        }
      }

      // Find corresponding X name.
      // If not found and if this belongs to some non-AML namespace, this is not an error.

      if (!found_aml_attrib(x_class, aml_root, aml_attrib_node, design_name, attrib_info)) {
        if (aml_attrib_node->getXMLURI() == "") info_out.error (
                       "No corresponding " + language + " attribute",
                       "For AML " + design_name + "attribute: " + aml_attrib_node->toString(),
                       "Of: " + aml_root->toString());
        continue;
      }
      if (attrib_info.aml_to_x_template == IGNORE) continue;

      // Create corresponding X attribute.

      string value = design->getValue();
      value = aml_expression_to_x (value, attrib_info, ele_name);
      x_ele->addAttribute(attrib_info.x_name, value);

    }

  }

  // Multipole: Now that we have collected all the terms store them.

  if (aml_parent_name == "multipole") {
    aml_multi_kl_map[ele_name]   = kl_vec;
    aml_multi_ksl_map[ele_name]  = ksl_vec;
    aml_multi_tilt_map[ele_name] = tilt_vec;
  }

  // Custom ending calc

  custom2_aml_element_attribute_to_x (aml_ele, x_ele); 

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::aml_sector_or_element_to_x (UAPNode* aml_sec_or_ele, UAPNode* x_rep) {

  // Check for a custom conversion

  if (custom_aml_sector_or_element_to_x(aml_sec_or_ele, x_rep)) return;

  string aml_name = aml_sec_or_ele->getName();
  string x_name = aml_name;
  bool ok;

  //--------------------------------------------------------------------
  // Case where sector has a length.
  // Create a corresponding line with drifts of the appropriate size inbetween.

  if (aml_name == "sector" && aml_sec_or_ele->getAttribute("length")) {

    string sec_name = aml_sec_or_ele->getAttributeString("name");

    string sec_length = aml_sec_or_ele->getAttributeString("length");
    x_rep->addChild("constant")->addAttribute("name", "len_" + sec_name)->
              addAttribute("design", sec_length);

    int n_drift = 0;

    // Make the line

    UAPNode* x_line = x_rep->addChild("line");
    x_line->addAttribute("name", sec_name);

    // positions is used to save element positions in case ref_element is used in a superimpose.

    UAPNode* positions = new UAPNode("temp"); 
    UAPNode* last_p_child = positions->addChild("zero!");
    last_p_child->addAttribute("EXIT", "");

    // Make up the new elements
    // Possible cases:
    //   <element name = "" inherit = "">  Need to generate new element here
    //   <element name = "">               Need to generate new element here
    //   <element ref = "">
    //   <sector  ref = "">
    // Important: Do not create a new element definition if there is already a 
    // definition for an element of the same name.

    NodeVec eles = aml_sec_or_ele->getChildren();
    for (NodeVecCIter ie = eles.begin(); ie != eles.end(); ie++) {
      UAPNode* aml_seq_ele = *ie;

      // Create the drift. The drift length will be calculated lator...

      string ele_name = aml_seq_ele->getAttributeString("name"); 
      if (ele_name == "") {                                 // Must be a ref
        ele_name = aml_seq_ele->getAttributeString("ref");
      } else if (!found(name_to_x_node_map, ele_name)) {  // Create def if needed
        aml_node_to_x (aml_seq_ele, x_rep, "superimpose");
      }

    }

    // Make up the drifts between the elements

    for (NodeVecCIter ie = eles.begin(); ie != eles.end(); ie++) {
      UAPNode* aml_seq_ele = *ie;

      string d_name = "drft" + int_to_string(n_drift++, ok) + "_" + sec_name;
      UAPNode* drift_node = x_rep->addChild("element");

      string ele_name = aml_seq_ele->getAttributeString("name"); 
      if (ele_name == "") ele_name = aml_seq_ele->getAttributeString("ref");

      // Construct distance to beginning of element

      UAPNode* superimpose = aml_seq_ele->getChildByName("superimpose");
      string offset      = superimpose->getAttributeString("offset");
      string ele_origin  = superimpose->getAttributeString("ele_origin");
      if (ele_origin == "") ele_origin = "CENTER";
      string ref_origin  = superimpose->getAttributeString("ref_origin");
      if (ref_origin == "") ref_origin = "CENTER";
      string ref_element = superimpose->getAttributeString("ref_element");

      string s_ele("");

      if (ref_element == "") {
         s_ele = offset;
        if (offset == "") s_ele = "0";

      } else {
        UAPNode* this_ref = NULL;
        NodeVec refs = positions->getChildren();
        for (NodeVecCIter ir = refs.begin(); ir != refs.end(); ie++) {
          UAPNode* ref = *ir;
          if (ref->getName() == ref_element) {
            this_ref = ref;
            break;
          }
        }

        if (!this_ref) {
          info_out.error ("Cannot file reference element for: " + aml_seq_ele->toString(),
                       "In Sector:", aml_sec_or_ele->toStringTree());
          return;
        }

         s_ele = this_ref->getAttributeString(ref_origin);
        if (offset != "") s_ele = s_ele + " + " + offset;
      }

      // Encode the element length. Markers do not have a length

      string ele_len;
      if (aml_seq_ele->getName() == "element") {
        attribute_convert_struct attrib_info;
        if (!found_x_attrib (name_to_x_class_map[ele_name], "l", attrib_info)) {
          info_out.error ("Information not found for: " + aml_seq_ele->toString());
          return;
        }
        if (attrib_info.aml_to_x_template != IGNORE) ele_len = ele_name + "[length]"; 
      } else {
        ele_len = "len_" + ele_name;
      }

      UAPNode* p_child = positions->addChild(ele_name);
      if (ele_len == "") {
        p_child->addAttribute("ENTRANCE", s_ele);
        p_child->addAttribute("CENTER", s_ele);
        p_child->addAttribute("EXIT", s_ele);
      } else if (ele_origin == "ENTRANCE") {
        p_child->addAttribute("ENTRANCE", s_ele);
        p_child->addAttribute("CENTER", s_ele + " + " + ele_len + "/2");
        p_child->addAttribute("EXIT", s_ele + " + " + ele_len);
      } else if (ele_origin == "CENTER") {
        p_child->addAttribute("ENTRANCE", s_ele + " - " + ele_len + "/2");
        p_child->addAttribute("CENTER", s_ele);
        p_child->addAttribute("EXIT", s_ele + " + " + ele_len + "/2");
      } else {
        p_child->addAttribute("ENTRANCE", s_ele + " - " + ele_len);
        p_child->addAttribute("CENTER", s_ele + " - " + ele_len + "/2");
        p_child->addAttribute("EXIT", s_ele);
      }

      // Make the drift just before the element.

      drift_node->addAttribute("name", d_name);
      drift_node->addAttribute("class", "drift");
      string len = p_child->getAttributeString("ENTRANCE"); 
      string base = add_parens_if_needed(last_p_child->getAttributeString("EXIT"));
      if (base != "") len = len + " - " + base;
      
      drift_node->addAttribute("l", aml_expression_to_x(len));

      // Add the drift and element to the line

      x_line->addChild("element")->addAttribute("ref", d_name);
 
     if (aml_seq_ele->getName() == "element")
        x_line->addChild("element")->addAttribute("ref", ele_name);
      else
        x_line->addChild("line")->addAttribute("ref", ele_name);

      // save p_child pointer.

      last_p_child = p_child;

    }

    // Make the last drift

    bool ok;
    string d_name = "drft" + int_to_string(n_drift++, ok) + "_" + sec_name;
    UAPNode* drift_node = x_rep->addChild("element");
    drift_node->addAttribute("name", d_name);
    drift_node->addAttribute("class", "drift");
    string len = sec_length;
    string base = last_p_child->getAttributeString("EXIT");
    if (base != "") len = len + " - " + add_parens_if_needed(base);
    drift_node->addAttribute("l", aml_expression_to_x(len));
    x_line->addChild("element")->addAttribute("ref", d_name);

    // Move x_line to end of children list

    x_line->detachNode();
    x_rep->addChild(x_line);

    positions->deleteNode();  // Remove

    return;
  }


  //--------------------------------------------------------------------
  // Case where we have an element or a sector without a length attribute.
  // Recursively transfer from aml to X.

  if (aml_name == "sector") x_name = "line";
  if (aml_name == "element") x_name = "element";

  UAPNode* x_ele = x_rep->addChild(x_name);

  // transfer attributes.

  transfer_attribute(aml_sec_or_ele, "name", x_ele, "name");
  transfer_attribute(aml_sec_or_ele, "ref", x_ele, "ref");
  transfer_attribute(aml_sec_or_ele, "tag", x_ele, "tag");
  transfer_attribute(aml_sec_or_ele, "args", x_ele, "args");

  string repeat = aml_sec_or_ele->getAttributeString("repeat");
  string refl =  aml_sec_or_ele->getAttributeString("reflection");
  if (refl == "TRUE") {
    if (repeat == "") repeat = "-1";
    else repeat = "-" + repeat;
  }
  if (repeat != "") x_ele->addAttribute("repeat", repeat);

  // Loop over children.

  NodeVec c = aml_sec_or_ele->getChildren();
  for (NodeVecCIter ic = c.begin(); ic != c.end(); ic++) {
    aml_sector_or_element_to_x (*ic, x_ele);
  }

  return;

}
      
//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::aml_ele_to_x_class (UAPNode* aml_ele, string& x_class) {

  // Since an AML element can be a combination of quadrupole, bend, etc., we
  // Need to see if there is a possible corresponding MAD element.

  x_class = "";

  // First make a list of what element children like <quadrupole> are present.

  StrList names;
  NodeVec children = aml_ele->getChildren();
  for (NodeVecCIter it = children.begin(); it != children.end(); it++) {
    string name = (*it)->getName();
    if (found(aml_class_names, name)) names << name;
  }

  UAPNode* instrument = aml_ele->getChildByName("instrument");

  // If there are no children then must be a drift or a type of instrument.

  if (names.size() == 0) {
    x_class = "drift";
    if (instrument) {
      x_class = "instrument";
      string i_type = instrument->getAttributeString("type");
      if (i_type == "hmonitor" || i_type == "vmonitor" || i_type == "monitor") 
        x_class = i_type;
    }
    return true;
  }

  // Ignore a scaled_multipole or aperture component if there is something else.

  if (names.size() > 1) names.remove("scaled_multipole");
  if (names.size() > 1) names.remove("aperture");

  // Translation where there is exactly one match

  if (names.size() == 1) {

    x_class = names.front();

    if (x_class == "taylor_map") x_class = "matrix";
    if (x_class == "bend") x_class = "sbend";
    if (x_class == "rf_cavity") x_class = "rfcavity";
    if (x_class == "aperture") {
      x_class = "rcollimator";
      string shape = aml_ele->getChildByName("aperture")->getAttributeString("shape");
      if (shape == "ELLIPTICAL") x_class = "ecollimator";
    }

    if (x_class == "patch" || x_class == "wiggler" || x_class == "match") {
      x_class = "BAD!";
      info_out.error ("AML element does not have a corresponding " + language + " type",
                   aml_ele->toStringTree());
      return false;
    }
  }

  // If there is a bend then use that.

  if (found(names, "bend")) x_class = "sbend";

  if (x_class == "") {
    info_out.error ("AML element does not have a corresponding " + language + " type",
                   aml_ele->toStringTree());
    return false;
  }

  return true;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::aml_expression_to_x (const string& aml_expression, 
                          attribute_convert_struct attrib_info, const string& ele_name) {


  // Switch conversion

  for (ParamValueStructVecIter ip = param_values_list.begin(); 
                                      ip != param_values_list.end(); ip++) {
    if (ip->aml_value == aml_expression) return ip->x_value;
  }

  // Find all attributes and constants in the expression and convert them to x-format.
  // Eg: "q[quadrupole:k(n=1)]" -> "q[k1]" or "q->k1"
  
  size_t i0, i1, i2, n;
  string x_exp = aml_expression;

  i0 = 0;
  while (true) {
    string token = next_token_in_expression(x_exp, false, i0, n);

    if (i0 == x_exp.size()) break;

    // A "[" indicates an attribute.

    if ((i1 = token.find("[")) != string::npos) {

      // Break, say "beam[energy]" into its components

      if (token.find("]") != token.size() - 1) {
        info_out.error ("No matching ']' for opening '[' in expression: " + aml_expression);
        return "";
      }
      i2 = token.size() - 1;

      string this_ele_name = token.substr(0, i1);
      string aml_attrib = token.substr(i1+1, i2-i1-1);

      string x_class  = ele_name_to_x_class(this_ele_name);

      attribute_convert_struct at_info;
      if (!found_aml_attrib(x_class, aml_attrib, at_info)) {
        info_out.error ("Unknown attribute: " + aml_attrib, "In AML expression: " + aml_expression);
        return x_exp;
      }
      if (attrib_info.aml_to_x_template == IGNORE) continue;

      // An explicit aml node name means that this is a parameter like "beam[energy]".
      // In which case use it over the "element name".

      if (at_info.aml_twig.name != "") this_ele_name = at_info.x_parent;

      // Replace x-attribute name with aml-attribute name.
      // Also convert the attribute units *backwards*.
      // Eg: "ele[rf_cavity:voltage]" -> "ele[volt] * 1e6".

      x_exp.erase(i0, n);

      string x_attrib;
      if (c_style_format) {
        x_attrib = this_ele_name + "->" + at_info.x_name; 
      } else {
        x_attrib = this_ele_name + "[" + at_info.x_name + "]";
      } 
      x_attrib = convert_single_attribute (x_attrib, 
                 at_info.x_to_aml_template, at_info.aml_to_x_template, this_ele_name);
      if (x_exp.size() != 0) x_attrib = "(" + x_attrib + ")";
      x_exp.insert(i0, x_attrib);

      i0 += x_attrib.size();


    // Otherwise it might be a constant

    } else {
  
      for (ConstantsVecIter ic = constants_list.begin(); ic != constants_list.end(); ic++) {
        if (ic->aml_to_x_template == IGNORE) continue;
        if (ic->aml_const == token) {
          string x_const = ic->aml_to_x_template;
          if (x_const == "") x_const = ic->x_const;
          x_exp.erase(i0, n);
          if (x_exp.size() != 0 && x_const.find(" ") != string::npos) 
            x_const = "(" + x_const + ")";
          x_exp.insert(i0, x_const);
          n = x_const.size();
          break;
        }
      }

      i0 += n;

    }
  }

  //  Now make a conversion on the attribute associated with this expression.

  return convert_single_attribute (x_exp, attrib_info.aml_to_x_template, 
                                             attrib_info.x_to_aml_template, ele_name);

  return x_exp;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::convert_single_attribute (string expression, string forward_template, 
                                          string back_template, string ele_name) {

  // Should not be here for an attribute that is marked IGNORE.

  if (forward_template == IGNORE) {
    info_out.error ("CONVERT_SINGLE_ATTRIBUE: IGNORED ATTRIBUTE CONFUSION!");
    throw;
  }

  // If the template is blank then there is nothing to be done.

  if (forward_template == "") return expression;

  // In a template:
  //   "!" means substitute in element name.
  //   "#" means substitute in value. There should be exactly one of these.
  // Example:
  //   forward_template = "# * ![length]"
  //   back_template    = "# / ![length]"

  // If expression has had the back_template already applied to it then we
  // produce a cleaner result if we just remove the back_template.
  // First substitute in ele_name as needed.

  if (back_template != "") {

    while (true) {
      size_t ix = back_template.find("!");
      if (ix == string::npos) break;
      back_template.replace(ix, 1, ele_name);
    }

    // Now see if back_template has been applied

    size_t n_e = expression.size() - 1;
    size_t n_b = back_template.size() - 1; 
    size_t ix_h = back_template.find("#");
    size_t ix_e = (ix_h + n_e) - n_b;  
    size_t n2 = n_b - ix_h;

    bool found_back = true;
    if (ix_h != 1) {
      if (expression.substr(0,ix_h-1) != back_template.substr(0,ix_h-1)) found_back = false;
    }
    if (n_e < n2) found_back = false;
    if (found_back && ix_h != n_b) {
      if (expression.substr(ix_e+1, n2) != back_template.substr(ix_h+1,n2)) found_back = false;
    }

    // If found then just remove back_template

    if (found_back) {
      expression.erase(ix_e+1, n2);
      expression.erase(0,ix_h);
      return expression;
    }
  }

  // Since the back_template was not found just apply the forward template.
  // If the expression has a "+" or "-" then need to enclose with parenteses.
  // First substitute in ele_name as needed.

  while (true) {
    size_t ix = forward_template.find("!");
    if (ix == string::npos) break;
    forward_template.replace(ix, 1, ele_name);
  }

  // Now substitute the expression.

  size_t ix_h = forward_template.find("#");
  return forward_template.replace(ix_h, 1, add_parens_if_needed(expression));

}



//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::transfer_attribute(UAPNode* ele_in, const string& attrib_in, 
                                    UAPNode* ele_out, const string& attrib_out) {

  if (UAPAttribute* attrib = ele_in->getAttribute(attrib_in))
                       ele_out->addAttribute(attrib_out, attrib->getValue());

  return true;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

UAPNode* TranslateCore::XRepToXFile (UAPNode* x_root, 
                        const string& file_name, const Str& out_suffix, bool one_file) {

  // Init

  name_to_x_class_map.clear();
  info_out.ix_line = -1;
  info_out.statement = "";
  info_out.parsing_status = "Creating a " + language + " lattice file";

  UAPNode* x_rep = x_root;

  if (x_rep->getName() == "UAP_root") 
              x_rep = x_rep->getChildByName(language + "_representation");

  if (!x_rep || (x_rep->getName() != language + "_representation")) {
    info_out.error ("Node argument is not <" + language + "_representation> or its parent.");
    return NULL;
  }

  // Set the file name

  string this_file;

  if (file_name == "*") {
    string old_name = x_rep->getAttributeString("filename");
    size_t n = old_name.find_last_of(".");
    if (n == string::npos) 
      this_file = old_name + out_suffix;
    else
      this_file = old_name.substr(0,n) + out_suffix;
  } else if (file_name != "") {
    this_file = file_name;
  }

  x_rep->addAttribute("filename", this_file);

  // Change all the include files

  if (out_suffix != "") {
    Twig tinfo(include_file_string); 
    include_filename_replace_suffix (x_rep, out_suffix, tinfo);
  }

  // Create the file

  StreamStruct x_out;
  FileStackList file_stack;
  x_rep_to_x_file (x_rep, this_file, one_file, x_out, file_stack);
  x_out.close_file();

  return x_rep;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::include_filename_replace_suffix (UAPNode* node,
                              const string& out_suffix, const Twig& info) {

  if (node->getName() == info.nodeid_vec[0].name && 
                          node->getXMLURI() == info.nodeid_vec[0].xml_uri) {
    UAPAttribute* attrib = node->getAttribute(info.nodeid_vec[1].name);
    if (attrib) {
      string file_name = attrib->getValue();
      size_t n = file_name.find_last_of(".");
      if (n == string::npos) 
        file_name = file_name + out_suffix;
      else
        file_name = file_name.substr(0,n) + out_suffix;

      attrib->setValue(file_name);
    }
  }

  for (NodeVecIter in = node->getChildren().begin(); in != node->getChildren().end(); in++) {
    include_filename_replace_suffix (*in, out_suffix, info);
  } 

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::x_rep_to_x_file (UAPNode* x_rep, const string& file_name,
                   bool one_file, StreamStruct& x_output, FileStackList file_stack) {

  // Create a new file stream if needed

  StreamStruct x_out;

  if (!one_file || !x_output.is_open()) {
    if (file_name == "") {
      info_out.error ("No file name given for creating a " + language + " file.");
      return false;
    }
    file_stack.addFile(file_name);
    string f_name = file_stack.file_list.back().full_name;
    x_out.continuation_char = continuation_char;
    x_out.open_file(f_name);
    if (!x_out.is_open()) {
      info_out.error ("Cannot open file: " + f_name);
      return false;
    }
  } else {
    x_out = x_output;
  }

  // loop over all children of x_rep

  NodeVec children = x_rep->getChildren();
  for (NodeVecCIter it = children.begin(); it != children.end(); it++) {

    UAPNode* x_node = *it;
    AttributeVec x_attribs = x_node->getAttributes();
    string x_name = x_node->getName();

    // Put the comment token in a comment.

    string end = "";
    string comment = x_node->getAttributeString("comment");
    if (comment != "") comment = "  " + add_comment_token (comment);
    if (c_style_format) {
      comment = ";" + comment;
      end = ";";
    }

    // Custom statement

    if (custom_x_element_to_x_file (x_node, comment, x_out)) continue;

    // sequence

    if (x_name == "sequence") {

      x_out << x_node->getAttributeString("name") << ": sequence";
      for (AttributeVecCIter ia = x_attribs.begin(); ia != x_attribs.end(); ia++) {
        if (ia->getName() == "comment") continue;
        if (ia->getName() == "name") continue;
        x_out << ", " << ia->getName() << " = " << ia->getValue();
      }
      x_out << comment << fini;

      NodeVec childs = x_node->getChildren();
      for (NodeVecCIter ic = childs.begin(); ic != childs.end(); ic++) {
        UAPNode* ele = *ic;

        if (ele->getName() == "sequence") {
          x_out << "  " << ele->getAttributeString("ref") << ", at = " 
                << ele->getAttributeString("at") << end << fini;

        } else if (ele->getName() == "element" && ele->getAttribute("ref")) {
          x_out << "  " << ele->getAttributeString("ref") << ", at = " 
                << ele->getAttributeString("at") << end << fini;

        } else if (ele->getName() == "element" && ele->getAttribute("name")) {
          string str = ele->getAttributeString("class");
          if (str == "") str = ele->getAttributeString("inherit");
          x_out << "  " << ele->getAttributeString("name") << ": " 
                << str << ", at = " << ele->getAttributeString("at");
          AttributeVec atts = ele->getAttributes();
          for (AttributeVecCIter ia = atts.begin(); ia != atts.end(); ia++) {
            string a_name = ia->getName();
            string a_value = ia->getValue();
            if (a_name == "name") continue;
            if (a_name == "class") continue;
            if (a_name == "inherit") continue;
            if (a_name == "at") continue;
            custom_x_attrib_to_x_file_translate (a_name, a_value);
            x_out << ", " << a_name << " = " << a_value;
          }
          x_out << end << fini;

        }
      }

      x_out << "endsequence" << end << fini;
      continue;

    }

    // call

    if (x_name == "call") {
      string this_file = x_node->getAttributeString("filename");
      x_out << "call, filename = \"" << this_file << "\"" << comment << fini;
      x_rep_to_x_file (x_node, this_file, one_file, x_output, file_stack);
      continue;
    }
      
    if (x_name == "comment") {
      x_out << add_comment_token(x_node->getAttributeString("text")) << fini;
      continue;
    }
      
    if (x_name == "constant") {
      string type = x_node->getAttributeString("type");
      string equal = " = ";
      if (type != "") equal = " : " + type + " = ";
      x_out << x_node->getAttributeString("name") << 
                equal << x_node->getAttributeString("design") << comment << fini;
      continue;
    }

    if (x_name == "beam") {
      x_out << x_name;
      for (AttributeVecCIter it = x_attribs.begin(); it != x_attribs.end(); it++) {
        if (it->getName() == "comment") continue;
        x_out << ", " << it->getName() << " = " << it->getValue();
      }
      x_out << comment << fini;
      continue;
    }

    if (x_name == "line" || x_name == "list") {
      x_out << x_node->getAttributeString("name");

      string tag = x_node->getAttributeString("tag");
      if (tag != "") x_out << "[" << tag << "]";

      string args = x_node->getAttributeString("args");
      if (args != "") x_out << "(" << args << ")";

      x_out << ": " << x_name;

      bool ok;
      bool multipass = string_to_bool(x_node->getAttributeString("multipass"), ok);
      if (ok && multipass) x_out << "[multipass]";

      x_out << " = ";

      write_line_or_list_to_x_file (x_node, ", ", x_out);
      x_out << comment << fini;
      continue;
    }

    if (x_name == "return") {
      x_out << "return" << comment << fini;
      continue;
    }

    // attribute set

    if (x_name == "set") {
      x_out << x_node->getAttributeString("element") << ", "
            << x_node->getAttributeString("attribute") << " = "
            << x_node->getAttributeString("value") << comment << fini;
      continue;
    }  

    // only thing left is an element def

    if (x_name == "element") { 
      x_out << x_node->getAttributeString("name") << ": "; 
      string ele_class = x_node->getAttributeString("class");
      if (ele_class == "") ele_class = x_node->getAttributeString("inherit");
      x_out << ele_class;
      for (AttributeVecCIter att = x_attribs.begin(); att != x_attribs.end(); att++) {
        string a_name = att->getName();
        string a_value = att->getValue();
        if (a_name == "name") continue;
        if (a_name == "comment") continue;
        if (a_name == "class") continue;
        if (a_name == "inherit") continue;

        custom_x_attrib_to_x_file_translate (a_name, a_value);
        x_out << ", " << a_name;
        x_add_quote_marks (a_name, a_value);
        if (a_value != "") x_out << " = " << a_value;
      }

      custom_x_ele_attributes_to_x_file (x_node, ele_class, x_out); 

      x_out << comment << fini;
      continue;
    }

    // Unknown construct.

    info_out.error (language + " Node not recognized: " + x_node->toString());

  }

  if (!one_file) x_out.close_file();
  return true;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::next_token_in_expression (string expression, bool c_style, 
                                                          size_t& i0, size_t& n) {

  // This routine finds the next possible attribute.
  // We start parsing at i0.
  // First skip separators at beginning

  for ( ; ; i0++) {
    if (i0 == expression.size()) return "";
    char a = expression[i0];
    if (isalpha(a)) break;
  }

  // Find end of token

  bool found_attrib = false;
  size_t i2 = i0;

  for ( ; ; i2++) {
    if (i2 == expression.size()) break;
    char a = expression[i2];
    if (a == '[') found_attrib = true;
    if (found_attrib && !c_style && a != ']') continue;
    if (a == ']') {
      i2++;
      break;
    }
    if (a == '+' || a == '-' || a == '*' || a == '/' || a == '^') break;
    if (a == '(' || a == ')' || a == ',' || a == ' ') break;
  }

  n = i2 - i0;
  return expression.substr(i0, n);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::x_add_quote_marks (const string& name, string& value) {

  // This is for parameters (EG "file" as in "use, file = <value>) whose
  // value is a string. If the value contains a quote mark, then we
  // need to put the whole string in quote marks.

  if (value == "") return;
  if (!found(x_attributes_needing_quote_marks, name)) return;

  // If the string has both single (') and double (") quote marks then
  // we have a problem.

  if (value.find("\'") != string::npos && value.find("\"") != string::npos) {
    info_out.error("String has both \' and \" marks within it: " + value);
    return;
  }

  // Add quote marks if necessary.

  if (value.find("\"") != string::npos)
    value = "\'" + value + "\'";
  else
    value = "\"" + value + "\"";

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

string TranslateCore::add_comment_token (const string& str) {
  if (c_style_format) {
    if (str.find("\n") == string::npos) return "// " + str;
    return "/*" + str + "*/";
  } else {
    return "! " + str;
  }
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::write_line_or_list_to_x_file(UAPNode* line_node,
                                    string separator_str, StreamStruct& x_out) {

  x_out << "(";

  NodeVec children = line_node->getChildren();
  for (NodeVecCIter nt = children.begin(); nt != children.end(); nt++) {
    UAPNode* ele = *nt;

    // output repeat count

    string repeat = ele->getAttributeString("repeat");
    if (repeat != "") {
      repeat += "*";
      if (repeat == "-1*") repeat = "-";
      x_out << repeat;
    }

    // output name

    string name = ele->getAttributeString("ref");
    string who = ele->getName();
    x_out << name;

    // Output tag

    string tag = ele->getAttributeString("tag");
    if (tag != "") x_out << "[" << tag << "]";

    // A replacement line does not have a subline so just print the argument list.
    // Otherwise we must make a recursive call.

    if (who == "line") {
      string args = ele->getAttributeString("args");
      if (args != "") {           // if a replacement line...
        x_out << "(" << args << ")";
      } else if (ele->getChildren().size() > 0) {   // if there is a sub-line
        write_line_or_list_to_x_file (ele, separator_str, x_out);
      }

    } else if (who == "girder") {
      continue;  // Ignore
    } else if (who != "element" && who != "item") {
      info_out.error ("Node is not a \"line\" nor a \"element\": " + ele->toString());
    }

    if (ele != children.back()) x_out << separator_str;

  }

  x_out << ")";
  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

// The x_to_aml_template and aml_to_x_template, arguments are for when the 
// translation between AML and X gets complicated.
// See convert_single_attribute for an expanation of the syntax of the templates.

// Normally, by default, valid_aml_to_x = true.
// However, if there is more than one way to translate a given AML attribute to X,
// valid_aml_to_x needs to be false for those AML to X translations that should *not*
// be used.

void TranslateCore::register_attribute (string x_attribute, string aml_attribute, 
        string x_to_aml_template, string aml_to_x_template) {

  // Put information into attribute_convert_struct variable

  attribute_convert_struct at;

  at.x_to_aml_template = x_to_aml_template;
  at.aml_to_x_template = aml_to_x_template;

  // Parse X side.

  size_t i = x_attribute.find(":");
  if (i == string::npos) {
    at.x_name = x_attribute;
    at.x_parent = "";
  } else {
    at.x_name = x_attribute.substr(i+1);
    at.x_parent = x_attribute.substr(0, i);
  }

  // Parse AML side. Eg: aml_attribute = "description:type@name"

  string element_dummy;
  if (!at.aml_twig.fromString(aml_attribute)) {
    info_out.error ("Bad AML attribute in register_attribute: " + aml_attribute);
    throw;
  }

  if (at.aml_twig.target_attribute == "") at.aml_twig.target_attribute = "design";        // default

  // Fill in x_attribute -> aml_attribute map.

  attribute_list.push_back(at);

  // Look for any attributes to ignore

  for (NodeIDVecCIter ni = at.aml_twig.nodeid_vec.begin(); 
                                      ni != at.aml_twig.nodeid_vec.end(); ni++) {
    if (ni->attribute.size() > 0) aml_ignore_these_attribs << ni->toString();
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::register_constant (const string& x, const string& aml, 
                        const string& x_to_aml_template, const string& aml_to_x_template) {

  constants_struct cs;
  cs.x_const = x;
  cs.aml_const = aml;
  cs.x_to_aml_template = x_to_aml_template;
  cs.aml_to_x_template = aml_to_x_template;

  constants_list.push_back(cs);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::register_param_value_conversion (const string& x_value, const string& aml_value) {

  param_value_struct pvs;
  pvs.x_value = x_value;
  pvs.aml_value = aml_value;

  param_values_list.push_back(pvs);

  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::found_x_attrib (const string& x_class, const string& x_attrib,
                                                            attribute_convert_struct& at) {

  // Look for specific attribute.
  // Remember that attributes can be abbreviated.

  int nl = x_attrib.length(); 
  int n_match = 0;

  for (AttributeConvertVecIter im = attribute_list.begin(); im != attribute_list.end(); im++) {
    if (im->x_parent != x_class) continue;
    if (x_attrib == im->x_name) {
      at = *im;
      return true; // Exact match
    }
    if (abbreviations_permitted && x_attrib == im->x_name.substr(0, nl)) {
      at = *im;
      n_match++;
    }
  }

  if (n_match == 1) return true;
  if (n_match > 1) return false;

  // If not look for general attribute.

  n_match = 0;

  for (AttributeConvertVecIter im = attribute_list.begin(); im != attribute_list.end(); im++) {
    if (im->x_parent != "" && x_class != "" && im->x_parent != x_class) continue;
    if (x_attrib == im->x_name) {
      at = *im;
      return true; // Exact match
    }
    if (abbreviations_permitted && x_attrib == im->x_name.substr(0, nl)) {
      at = *im;
      n_match++;
    }
  }
  
  if (n_match == 1) return true;
  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::found_aml_attrib (const string& x_class, const string& aml_attrib, 
                                                  attribute_convert_struct& attrib_info) {
  Twig aml_twig;
  aml_twig.fromString(aml_attrib);
  if (aml_twig.target_attribute == "") aml_twig.target_attribute = "design";

  // aml_attrib is something like: "quadrupole:k(n=1)".

  for (AttributeConvertVecIter im = attribute_list.begin(); 
                                             im != attribute_list.end(); im++) {
    attribute_convert_struct& this_info = *im;
    // Need to use x_class since, eg, length for a marker is handled differently than length in a quad.
    if (x_class != "" && this_info.x_parent != "" && x_class != this_info.x_parent) continue;
    if (this_info.aml_twig.nodeid_vec == aml_twig.nodeid_vec &&
        this_info.aml_twig.target_attribute == aml_twig.target_attribute) {
      attrib_info = this_info;
      return true;
    }
  }

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::found_aml_attrib (const string& x_class, UAPNode* aml_root,
    UAPNode* aml_attrib_node, const string& design_name, attribute_convert_struct& attrib_info) {

  string aml_parent = aml_attrib_node->getParent()->getName();
  string aml_attrib = aml_attrib_node->getName();

  // Look for element
  // Look for specific attribute.

  for (AttributeConvertVecIter im = attribute_list.begin(); 
                                             im != attribute_list.end(); im++) {
    attribute_convert_struct& this_info = *im;
    if (x_class != "" && this_info.x_parent != "" && x_class != this_info.x_parent) continue;
    if (design_name != "" && design_name != this_info.aml_twig.target_attribute) continue;
    if (aml_attrib_node != this_info.aml_twig.getLocalSubNode(aml_root)) continue;
    attrib_info = this_info;
    return true;
  }

  // Since not found return false.

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::multipole_to_k_tilt (string k_in, string ks_in, string tilt_in, string n,
                                                                        string& k, string& tilt) {

  // Translate from (k, ks, tilt) to (k, tilt) for a given n.
  // First translate "0" -> "".

  if (k_in.find_first_not_of("0. ") == string::npos)    k_in = "";
  if (ks_in.find_first_not_of("0. ") == string::npos)   ks_in = "";
  if (tilt_in.find_first_not_of("0. ") == string::npos) tilt_in = "";

  // On output, a component that is zero is set to blank "". 

  if (ks_in == "") {
    k = k_in;
    tilt = tilt_in;
  } else if (k_in == "" && tilt_in == "") {
    k = ks_in;
    int n2 = 2 * (string_to_int(n) + 1);
    tilt = "-pi/" +  int_to_string(n2);
  } else {
    k_in = add_parens_if_needed(k_in);
    ks_in = add_parens_if_needed(ks_in);
    k = k_in + " * sqrt (1 + (" + ks_in + "/" + k_in + ")^2)";
    int n1 = string_to_int(n) + 1;
    if (tilt_in == "")
      tilt = "-atan(" + ks_in + " / " + k_in + ") / " + int_to_string(n1);
    else
      tilt = tilt_in + "- atan(" + ks_in + " / " + k_in + ") / " + int_to_string(n1);
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::multipole_to_k_ks (string k_in, string ks_in, string tilt_in, string n,
                                                                        string& k, string& ks) {

  // Translate from (k, ks, tilt) to (k, ks) for a given n.
  // First translate "0" -> "".

  if (k_in.find_first_not_of("0. ") == string::npos)    k_in = "";
  if (ks_in.find_first_not_of("0. ") == string::npos)   ks_in = "";
  if (tilt_in.find_first_not_of("0. ") == string::npos) tilt_in = "";

  // On output, a component that is zero is set to blank "". 

  if (tilt_in == "") {
    k  = k_in;
    ks = ks_in;
    return;
  }

  tilt_in = add_parens_if_needed(tilt_in);
  int n1 = string_to_int(n) + 1;
  string arg_str = "(" + tilt_in + "/" + int_to_string(n1) + ")";

  if (k_in == "") {
    ks_in = add_parens_if_needed(ks_in);
    k  = ks_in + " * sin" + arg_str;
    ks = ks_in + " * cos" + arg_str;
  } else if (ks_in == "") {
    k_in = add_parens_if_needed(k_in);
    k  =       k_in + " * cos" + arg_str;
    ks = "-" + k_in + " * sin" + arg_str;
  } else {
    k_in  = add_parens_if_needed(k_in);
    ks_in = add_parens_if_needed(ks_in);
    ks = ks_in + " * cos" + arg_str + " - " + k_in + " * sin" + arg_str;
    k  = ks_in + " * sin" + arg_str + " + " + k_in + " * cos" + arg_str;
  }

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::required_multipole_transfer (const Str& odd_man_out, const Str& k_base, 
           const Str& ks_base, const Str& tilt_base, Str& k_ele, Str& ks_ele, Str& tilt_ele) {

  // If all ele values are blank then no transfer is needed.

  if (k_ele == "" && ks_ele == "" && tilt_ele == "") return;

  // No transfer needed if both ele and base odd_man_out parameters are blank.

  if (odd_man_out == "ks") 
    if (ks_base == "" && ks_ele == "") return;
  else if (odd_man_out == "tilt")
    if (tilt_base == "" && tilt_ele == "") return;
  else
    throw;  // Should not be here

  // Now transfer is required.

  if (k_ele == "")    k_ele    = k_base;
  if (ks_ele == "")   ks_ele   = ks_base;
  if (tilt_ele == "") tilt_ele = tilt_base;

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_x_statement_to_x (StrList word_list, string comment,
                                                              UAPNode* x_rep_root) {
  return false; // Unrecognized
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_x_add_attributes (StrList& word_list, string ele_class, 
                                    string& attrib_name, UAPNode* x_ele_root) {
  return false; // Unrecognized
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_x_node_to_aml (UAPNode* x_node, UAPNode* aml_root, UAPNode* aml_ele) {

  return false;  // Unrecognized
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::custom2_x_element_attribute_to_aml (UAPNode* x_node, UAPNode* aml_node) {
  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::custom_aml_rep_to_x (UAPNode* lab, UAPNode* x_rep) {
  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep) {
  return false;  // Unrecognized
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_ele) {
  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele) {
  return false;  // Unrecognized
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_x_element_to_x_file (UAPNode* x_node, string& comment, 
                                                             StreamStruct& x_out) {
  return false;  // Unrecognized
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_aml_sector_or_element_to_x (UAPNode* aml_sector, 
                                                              UAPNode* x_root) {
  return false;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::custom_x_ele_attributes_to_x_file (UAPNode* x_node, 
                                     const string& ele_class,StreamStruct& x_out) {
  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool TranslateCore::custom_x_element_attribute_to_aml (string x_class, 
                                        UAPAttribute x_attrib, UAPNode* aml_node) {
  return false;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void TranslateCore::custom_x_attrib_to_x_file_translate (string& attrib_name,
                                                            string& attrib_value) {
  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//+
// This is the initialization routine for stuff that is common to Bmad, MAD8 and MADX.
// There are other initialization routines. EG See: TranslateCore::init_lists_mad, etc.
//-

void TranslateCore::init_lists_core() {

  // For a constructs like "particle = ELECTRON", then "ELECTRON" must be uppercase.

  x_attributes_to_upper_case << "particle";  

  // The string associated with the "type" attribute should not have its case changed.

  x_attributes_no_case_change << "type";

  // In AML the beam, lattice and global nodes set beam and lattice and global parameters.

  aml_param_names << "beam" << "lattice" << "global";

  // Translation from MAD to AML element classes.

  x_class_to_aml_map["line"] =             "sector";
  x_class_to_aml_map["list"] =             "list";
  x_class_to_aml_map["marker"] =           "marker";
  x_class_to_aml_map["drift"] =            "";
  x_class_to_aml_map["sbend"] =            "bend";
  x_class_to_aml_map["rbend"] =            "bend";
  x_class_to_aml_map["quadrupole"] =       "quadrupole";
  x_class_to_aml_map["sextupole"] =        "sextupole";
  x_class_to_aml_map["octupole"] =         "octupole";
  x_class_to_aml_map["multipole"] =        "multipole";
  x_class_to_aml_map["solenoid"] =         "solenoid";
  x_class_to_aml_map["hkicker"] =          "kicker";
  x_class_to_aml_map["vkicker"] =          "kicker";
  x_class_to_aml_map["kicker"] =           "kicker";
  x_class_to_aml_map["rfcavity"] =         "rf_cavity";
  x_class_to_aml_map["lcavity"] =          "rf_cavity(type=LINAC)";
  x_class_to_aml_map["elseparator"] =      "electric_kicker";
  x_class_to_aml_map["monitor"] =          "instrument";
  x_class_to_aml_map["ecollimator"] =      "aperture(shape=ELLIPTICAL)";
  x_class_to_aml_map["rcollimator"] =      "aperture";
  x_class_to_aml_map["instrument"] =       "instrument";
  x_class_to_aml_map["beambeam"] =         "beambeam";

  // Make a list of X attributes that can have a default value.

  for (int i = 0; i < 20; i++) {
    ostringstream oss;
    oss << i;
    string k = "k" + oss.str() + "l";
    string t = "t" + oss.str();
    x_attribs_that_can_have_default << t;
  }

  //----------------------------------------------------------------
  // Here we set up translation tables between AML and X ( = MAD8, BMAD, etc) for
  // element attributes, beam attributes, etc.
  // The argument list for register_attribute is:
  //    register_attirbute (x_attribute, aml_attribute, x_to_aml_template, aml_to_x_template)
  // The template arguments are for when the translation between AML and X gets complicated.
  // See convert_single_attribute for an expanation of the syntax of the templates.

  // Note: Some translations  are more complicated than can be handled by templates. 
  // These conversions are handeled by specialized routines.

  // multipole

  if (knl_tn_style_multipoles) {
    for (int i = 0; i < 20; i++) {
      ostringstream order;
      order << i;

      string k = "multipole:k" + order.str() + "l";
      string t = "multipole:t" + order.str();
      string n = "(n=" + order.str() + ")";

      register_attribute(k, "multipole:kl" + n);
      register_attribute(t, "multipole:tilt" + n);
    }
  }

  //

  register_attribute ("marker:l",     "length", "", IGNORE);
  register_attribute ("multipole:l",  "length", "", IGNORE);
  register_attribute ("rbend:l",      "length", "", IGNORE);

  register_attribute("type",       "description:type@string");

  register_attribute("l",          "length");
  register_attribute("k1",         "quadrupole:k");
  register_attribute("k2",         "sextupole:k");
  register_attribute("k3",         "octupole:k");
  register_attribute("ks",         "solenoid:ksol");

  register_attribute("tilt",       "orientation:tilt");

  register_attribute("rfcavity:harmon",  "rf_cavity:harmonic");

  register_attribute("sbend:k1",    "quadrupole:k");
  register_attribute("sbend:k2",    "sextupole:k");
  register_attribute("rbend:k1",    "quadrupole:k");
  register_attribute("rbend:k2",    "sextupole:k");

  register_attribute("rbend:e1",    "bend:e1", "", IGNORE);
  register_attribute("rbend:e2",    "bend:e2", "", IGNORE);
  register_attribute("rbend:angle", "bend:g", "", IGNORE);

  register_attribute("sbend:e1",    "bend:e1");
  register_attribute("sbend:e2",    "bend:e2");

  register_attribute("h1",          "bend:h1");
  register_attribute("h2",          "bend:h2");
  register_attribute("fint",        "bend:f_int1");
  register_attribute("fintx",       "bend:f_int2");
  register_attribute("hgap",        "bend:h_gap1");
  register_attribute("hgapx",       "bend:h_gap2");
 
  register_attribute("hkicker:kick",  "kicker:x_kick");
  register_attribute("vkicker:kick",  "kicker:y_kick");
  register_attribute("hkick",         "kicker:x_kick");
  register_attribute("vkick",         "kicker:y_kick");

  register_attribute("beambeam:charge",     "beambeam:charge");

  register_attribute("xxx", "lattice[geometry@type]", "", IGNORE);

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//+
// This is the initialization routine for stuff that is common to MAD8 and MADX.
// There are other initialization routines. EG see: TranslateCore::init_lists_core, etc.
//-

void TranslateCore::init_lists_mad () {

  // String attributes that need to be quoted.

  x_attributes_needing_quote_marks << "type";

  // In MAD the twiss and beam statements set beam and lattice parameters

  x_param_names << "twiss" << "beam";

  // Translation from MAD to AML element classes.

  x_class_to_aml_map["hmonitor"] =         "instrument";
  x_class_to_aml_map["vmonitor"] =         "instrument";
  x_class_to_aml_map["srotation"] =        "patch";
  x_class_to_aml_map["yrotation"] =        "patch";
  x_class_to_aml_map["sequence"] =         "sequence";
  x_class_to_aml_map["matrix"] =           "taylor_map";

  // Here the lists of valid attributes for a given element type are constructed.

  StrVec seq_attrib;
  seq_attrib << "l" << "refer";
  map_element_to_attribs["sequence"] << seq_attrib;

  StrVec drift_attrib;
  drift_attrib << "l" << "type";
  map_element_to_attribs["drift"] << drift_attrib;
 
  StrVec bend_attrib;
  bend_attrib << "l" << "tilt" << "angle" << "k1" << "k2"
              << "e1" << "e2" << "fint" << "fintx" << "hgap" << "hgapx" 
              << "h1" << "h2" << "type" << "at";
  map_element_to_attribs["sbend"] << bend_attrib;
  map_element_to_attribs["rbend"] << bend_attrib;

  StrVec quadrupole_attrib;
  quadrupole_attrib << "l" << "tilt" << "k1" << "type" << "at";
  map_element_to_attribs["quadrupole"] << quadrupole_attrib;
 
  StrVec sextupole_attrib;
  sextupole_attrib << "l" << "tilt" << "k2" << "type" << "at";
  map_element_to_attribs["sextupole"] << sextupole_attrib;

  StrVec rfcavity_attrib;
  rfcavity_attrib << "l" << "harmon" << "volt" << "lag"
                  << "freq" << "betrf" << "gp" << "shunt" << "tfill" << "type" << "at";
  map_element_to_attribs["rfcavity"] << rfcavity_attrib;
 
  StrVec elseparator_attrib;
  elseparator_attrib << "l" << "tilt" << "e" << "type" << "at";
  map_element_to_attribs["elseparator"] << elseparator_attrib;
 
  StrVec beambeam_attrib;
  beambeam_attrib << "sigx" << "sigy" << "xma" << "yma"
                  << "charge" << "angle" << "slices" << "type" << "at";
  map_element_to_attribs["beambeam"] << beambeam_attrib;

  StrVec marker_attrib;
  marker_attrib << "tilt" << "type" << "at";
  map_element_to_attribs["marker"] << marker_attrib;
 
  StrVec kicker_attrib;
  kicker_attrib << "l"  << "tilt" << "hkick" << "vkick" << "type" << "at";
  map_element_to_attribs["kicker"] << kicker_attrib;
 
  StrVec octupole_attrib;
  octupole_attrib << "l" << "tilt" << "k3" << "type" << "at";
  map_element_to_attribs["octupole"] << octupole_attrib;

  StrVec beam_attrib;
  beam_attrib << "particle" << "mass" << "charge" << "energy" << "pc"
              << "gamma" << "ex" << "exn" << "ey" << "eyn" << "et" << "sigt" << "sige" 
              << "kbunch" << "npart" << "bcurrent" << "bunched" << "radiate";
  map_element_to_attribs["beam"] << beam_attrib;
 
  StrVec twiss_attrib;
  twiss_attrib << "betx" << "alfx" << "mux" << "bety" << "alfy" << "muy" << "dx" 
               << "dpx" << "dy" << "dpy" << "x" << "px" << "y" << "dpy" << "wx" 
               << "phix" << "dmux" << "wy" << "phiy" << "dmuy" << "ddx" << "ddy" 
               << "ddpx" << "ddpy" << "tape" << "save" << "deltap";
  map_element_to_attribs["twiss"] << twiss_attrib;

  StrVec solenoid_attrib;
  solenoid_attrib << "l" << "ks" << "type" << "at";
  map_element_to_attribs["solenoid"] << solenoid_attrib;
 
  StrVec lcavity_attrib;
  lcavity_attrib << "l" << "tilt" << "gradient_err" << "coupler_angle"
                 << "phi0_err" << "lrad" << "dphi0" << "rf_frequency" << "e_loss" 
                 << "gradient" << "phi0" << "delta_e" << "type" << "at";
  map_element_to_attribs["lcavity"] << lcavity_attrib;

  StrVec monitor_attrib;
  monitor_attrib << "l" << "tilt" << "type" << "at";
  map_element_to_attribs["monitor"] << monitor_attrib;
  map_element_to_attribs["hmonitor"] << monitor_attrib;
  map_element_to_attribs["vmonitor"] << monitor_attrib;
  map_element_to_attribs["instrument"] << monitor_attrib;
 
  StrVec hvkicker_attrib;
  hvkicker_attrib << "l" << "tilt" << "kick" << "type" << "at";
  map_element_to_attribs["hkicker"] << hvkicker_attrib;
  map_element_to_attribs["vkicker"] << hvkicker_attrib;
 
  StrVec collimator_attrib;
  collimator_attrib << "l" << "xsize" << "ysize" << "type" << "at";
  map_element_to_attribs["rcollimator"] << collimator_attrib;
  map_element_to_attribs["ecollimator"] << collimator_attrib;

  // Make a list of X attributes that can have a default value.

  x_attribs_that_can_have_default << "tilt" << "fint"
            << "fintx" << "charge" << "radiate" << "bunched";

  //----------------------------------------------------------------
  // Here we set up translation tables between AML and X ( = MAD8, BMAD, etc) for
  // element attributes, beam attributes, etc.
  // The argument list for register_attribute is:
  //    register_attirbute (x_attribute, aml_attribute, 
  //                            x_to_aml_template, aml_to_x_template, valid_aml_to_x)
  // The template arguments are for when the translation between AML and X gets complicated.
  // See convert_single_attribute for an expanation of the syntax of the templates.

  // Note: Some translations  are more complicated than can be handled by templates. 
  // These conversions are handeled by specialized routines.

  // beam statement  

  register_attribute("beam:particle",   "beam[particle@type]");
  register_attribute("beam:energy",     "beam[total_energy]", "# * 1e9", "# / 1e9");
  register_attribute("beam:mass",       "beam[mass]", "# * 1e9", "# / 1e9");
  register_attribute("beam:charge",     "beam[charge]");
  register_attribute("beam:pc",         "beam[pc]");
  register_attribute("beam:gamma",      "beam[gamma]");
  register_attribute("beam:ex",         "beam[emittance_a]");
  register_attribute("beam:exn",        "beam[norm_emittance_a]");
  register_attribute("beam:ey",         "beam[emittance_b]");
  register_attribute("beam:eyn",        "beam[norm_emittance_b]");
  register_attribute("beam:et",         "beam[emittance_z]");
  register_attribute("beam:sigt",       "beam[sig_t]");
  register_attribute("beam:sige",       "beam[sig_e]");
  register_attribute("beam:kbunch",     "beam[n_bunches]");
  register_attribute("beam:npart",      "beam[n_particles]");
  register_attribute("beam:bcurrent",   "beam[bunch_current]");
  register_attribute("beam:bunched",    "beam[bunched@logical]");
  register_attribute("beam:radiate",    "beam[radiate@logical]");

  // twiss statement

  register_attribute("twiss:betx",     "lattice[twiss:beta_a]");
  register_attribute("twiss:alfx",     "lattice[twiss:alpha_a]");
  register_attribute("twiss:mux",      "lattice[twiss:phase_a]");
  register_attribute("twiss:bety",     "lattice[twiss:beta_b]");
  register_attribute("twiss:alfy",     "lattice[twiss:alpha_b]");
  register_attribute("twiss:muy",      "lattice[twiss:phase_b]");
  register_attribute("twiss:dx",       "lattice[twiss:eta_x]");
  register_attribute("twiss:dpx",      "lattice[twiss:etap_x]");
  register_attribute("twiss:dy",       "lattice[twiss:eta_y]");
  register_attribute("twiss:dpy",      "lattice[twiss:etap_y]");
  register_attribute("twiss:x",        "beam[position:x]");
  register_attribute("twiss:px",       "beam[position:p_x]");
  register_attribute("twiss:y",        "beam[position:y]");
  register_attribute("twiss:dy",       "beam[position:p_y]");

  // element attributes

  register_attribute("multipole:lrad", "length");

  register_attribute("lcavity:volt",       "rf_cavity:gradient", "# * 1e6 / ![length]", 
                                                                 "# * ![l] / 1e6");
  register_attribute("lcavity:lag",        "rf_cavity:phase0", "# * twopi", "# / twopi");
  register_attribute("rfcavity:volt",      "rf_cavity:gradient", 
                              "# * 1e6 / ![length]", "# * ![l] / 1e6");
  register_attribute("rfcavity:lag",       "rf_cavity:phase0", "# * twopi", "# / twopi");
  register_attribute("rfcavity:freq",      "rf_cavity:rf_freq", "# * 1e9", "# / 1e9");

  register_attribute("yrot:angle", "patch:x_pitch");
  register_attribute("srot:angle", "patch:tilt");

  register_attribute("e", "electric_kicker:y_kick_u", "# * 1e6 / ![length]", "# * ![l] / 1e6");

  register_attribute("beambeam:xma",        "beambeam:orientation:x_offset");
  register_attribute("beambeam:yma",        "beambeam:orientation:y_offset");
  register_attribute("beambeam:angle",      "beambeam:orientation:x_pitch");
  register_attribute("beambeam:slices",     "methods:n_steps");

  register_attribute("sbend:angle",         "bend:angle");

  register_attribute("beambeam:sigx",       "beambeam:sig_x");
  register_attribute("beambeam:sigy",       "beambeam:sig_y");

  register_attribute("xsize",               "aperture:x_limit");
  register_attribute("ysize",               "aperture:y_limit");

  

  // Here we set up translation tables between AML and X ( = MAD8, BMAD, etc) for constants.

  register_constant("degrad",         "pi", "pi / 180", IGNORE);
  register_constant("raddeg",         "degrees");
  register_constant("emass",          "m_electron", "m_electron * 1e-6", "emass / 1e-6");
  register_constant("pmass",          "m_proton", "m_proton * 1e-6", "pmass / 1e-6"); 
  register_constant("clight",         "c_light");

  register_constant("twopi",          "hz",            IGNORE, "");
  register_constant("sqrt(2)",        "sqrt_2",        "", "");
  register_constant("2.8179380e-15",  "r_e",           "", "");
  register_constant("1.5346980e-18",  "r_p",           "", "");
  register_constant("1.6021892e-19",  "e_charge",      "", "");
  register_constant("6.6021892e-34",  "h_plank",       "", "");
  register_constant("1.054591e-34",   "h_bar_plank",   "", "");


}
