/*
 * MAD8Parser
 * Universal Accelerator Parser
 * Copyright (C) 2006 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 */

#ifndef MAD8Parser_hpp
#define MAD8Parser_hpp 1

#include "Translate/TranslateCore.hpp"

//-----------------------------------------------------------------------

class MAD8Parser : public TranslateCore {
public:

  /** Initializes internal variables.
  */
  MAD8Parser();

protected:

  void init_lists_mad8();

  bool custom_x_statement_to_x (StrList word_list, 
                                  std::string comment, UAPNode* file_root);

  bool custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep);

  bool custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele);

  bool custom_x_add_attributes (StrList& word_list, std::string ele_class, 
                                     std::string& attrib_name, UAPNode* x_ele_root);

  bool custom_x_element_to_x_file (UAPNode* x_node, std::string& comment, 
                                                            StreamStruct& x_out);

  void custom2_aml_element_attribute_to_x(UAPNode* aml_ele, UAPNode* x_ele);

  void custom_x_attrib_to_x_file_translate (std::string& attrib_name, std::string& attrib_value);

};


#endif
