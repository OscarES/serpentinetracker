#include "Translate/XSIFParser.hpp"

using namespace std;
using namespace BasicUtilities;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

XSIFParser::XSIFParser() : TranslateCore() {
  language = "XSIF"; 
  include_file_string = "call:filename";
  continuation_char =  "&";
  c_style_format = false;
  knl_tn_style_multipoles = true;
  abbreviations_permitted = false;
  init_lists_xsif();
  init_lists_mad();
  init_lists_core();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void XSIFParser::init_lists_xsif () {

  x_class_to_aml_map["mtwiss"] =            "match";

  StrVec mtwiss_attrib;
  mtwiss_attrib << "l" << "mux" << "betax" << "alphax" << 
                          "muy" << "betay" << "alphay";
  map_element_to_attribs["mtwiss"] = mtwiss_attrib;

  StrVec multipole_attrib;
  multipole_attrib << "l" << "tilt" << "k0l" << "k1l"
         << "k2l" << "k3l" << "k4l" << "k5l" << "k6l" << "k7l" << "k8l" << "k9l"
         << "k10l" << "k11l" << "k12l" << "k13l" << "k14l" << "k15l" << "k16l" << "k17l"
         << "k18l" << "k19l" << "k20l" << "t0" << "t1" << "t2" << "t3" << "t4"
         << "t5" << "t6" << "t7" << "t8" << "t9" << "t10" << "t11" << "t12"
         << "t13" << "t14" << "t15" << "t16" << "t17" << "t18" << "t19" << "t20" 
         << "lrad" << "type" << "at";
  map_element_to_attribs["multipole"] = multipole_attrib;

  StrVec matrix_attrib;
  matrix_attrib << "type";
  for (int i = 1; i < 7; i++) {
    ostringstream iss; iss << i;
    for (int j = 1; j < 7; j++) {
      ostringstream jss; jss << j;
      matrix_attrib << "r" + iss.str() + jss.str();
      for (int k = 1; k < 7; k++) {
        ostringstream kss; kss << k;
        matrix_attrib << "t" + iss.str() + jss.str() + kss.str();        
      }
    }
  }
  map_element_to_attribs["matrix"] = matrix_attrib;

  for (int i = 1; i < 7; i++) {
    ostringstream iss; iss << i;
    for (int j = 1; j < 7; j++) {
      ostringstream jss; jss << j;
      string rm = "matrix:r" + iss.str() + jss.str();
      string exp = "\"0 0 0 0 0 0\"";
      exp[2*j-1] = '1';
      string taylor = "taylor_map:term(i_out=" + iss.str() + ",exp=" + exp + ")@coef";
      register_attribute (rm, taylor);
      for (int k = 1; k < 7; k++) {
        ostringstream kss; kss << k;
        exp = "\"0 0 0 0 0 0\"";
        exp[2*j-1] = '1';
        if (j == k)
          exp[2*k-1] = '2';
        else
          exp[2*k-1] = '1';
        taylor = "taylor_map:term(i_out=" + iss.str() + ",exp=" + exp + ")@coef";
        string tm = "matrix:t" + iss.str() + jss.str() + kss.str();
        register_attribute (tm, taylor);
      }
    }
  }

  map_element_to_attribs["matrix"] << "aperture";
  map_element_to_attribs["drift"] << "aperture"; 
  map_element_to_attribs["sbend"] << "aperture"; 
  map_element_to_attribs["rbend"] << "aperture"; 
  map_element_to_attribs["quadrupole"] << "aperture";
  map_element_to_attribs["sextupole"] << "aperture"; 
  map_element_to_attribs["octupole"] << "aperture"; 
  map_element_to_attribs["multipole"] << "aperture";
  map_element_to_attribs["solenoid"] << "aperture"; 
  map_element_to_attribs["hkicker"] << "aperture"; 
  map_element_to_attribs["vkicker"] << "aperture";
  map_element_to_attribs["kicker"] << "aperture";
  map_element_to_attribs["rfcavity"] << "aperture";
  map_element_to_attribs["lcavity"] << "aperture"; 
  map_element_to_attribs["elseparator"] << "aperture";
  map_element_to_attribs["monitor"] << "aperture"; 
  map_element_to_attribs["instrument"] << "aperture"; 
  map_element_to_attribs["beambeam"] << "aperture"; 

  register_attribute("aperture",          "aperture:xy_limit");



  return;

}
