#include "Translate/SADParser.hpp"

using namespace std;
using namespace BasicUtilities;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

SADParser::SADParser() : TranslateCore() {
  language = "SAD"; 
  continuation_char =  "@";
  c_style_format = true;
  knl_tn_style_multipoles = false;  // This is a guess. DCS.
  init_lists_sad();
  return;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void SADParser::init_lists_sad () {

  x_class_to_aml_map["bend"] =        "bend";
  x_class_to_aml_map["cavi"] =        "rf_cavity";
  x_class_to_aml_map["quad"] =        "quadrupole";
  x_class_to_aml_map["sext"] =        "sextupole";
  x_class_to_aml_map["mult"] =        "multipole";
  x_class_to_aml_map["mark"] =        "marker";
  x_class_to_aml_map["drift"] =       "";
  x_class_to_aml_map["oct"] =         "octupole";
  x_class_to_aml_map["sol"] =         "solenoid";
  x_class_to_aml_map["kicker"] =     "kicker";
//  x_class_to_aml_map["vkicker"] =     "kicker";
//  x_class_to_aml_map["kicker"] =     "kicker";

  register_attribute("l",          "length");


// DONE. SAD bend face angles definition: e1 = e1 * angle, e2 = e2 * angle
// AML: definition of g=1/rho IS CORRECT.
  register_attribute("bend:g",         "bend:g");
//  register_attribute("bend:g",         "bend:g", "# / ![length]", "# * ![l]", true);
  register_attribute("bend:e1",     "bend:e1");
  register_attribute("bend:e2",     "bend:e2");
  register_attribute("bend:h_gap1",     "bend:h_gap1");
  register_attribute("bend:h_gap2",     "bend:h_gap2");
  register_attribute("bend:f_int1",     "bend:f_int1");
  register_attribute("bend:f_int2",     "bend:f_int2");
  register_attribute("bend:h1",         "bend:f_h1");
  register_attribute("bend:h2",         "bend:f_h2");
  register_attribute("bend:scaled_multipole",  "bend:scaled_multipole");
  register_attribute("bend:k1",    "bend:scaled_multipole:b_coef(n=1)");
  register_attribute("bend:k2",    "bend:scaled_multipole:b_coef(n=2)");

  register_attribute("sextupole:scaled_multipole:a_coef", 
                                    "sextupole:scaled_multipole:a_coef");
  register_attribute("sextupole:scaled_multipole:b_coef", 
                                    "sextupole:scaled_multipole:b_coef");


// DONE. SAD rotate = ?, what correspond to x_pitch in SAD? check all offsets, tilt (see AML and SAD manual) and rools
// AML is this correct?
  register_attribute("rotate",      "orientation:tilt");
  register_attribute("dx",          "orientation:x_offset");
  register_attribute("dy",          "orientation:y_offset");
  register_attribute("rotate",      "kicker:orientation:tilt");      
  register_attribute("dx",          "kicker:orientation:x_offset");
  register_attribute("dy",          "kicker:orientation:y_offset");


  register_attribute("cavi:phi",       "rf_cavity:phase0", "# * twopi", "# / twopi");
  register_attribute("cavi:freq",      "rf_cavity:rf_freq", "# * 1e9", "# / 1e9");
  register_attribute("cavi:harm",      "rf_cavity:harmonic");
  register_attribute("cavi:volt",      "rf_cavity:gradient", "# * 1e6 / ![length]", 
                                                                 "# * ![l] / 1e6");


// DONE. SAD: all K's are integrated values
  register_attribute("k1",         "quadrupole:k");
  register_attribute("k2",         "sextupole:k");
  register_attribute("k3",         "octupole:k");



// SAD: need to introduce Bz = ks * Brho
  register_attribute("ks",         "solenoid:ks");


// SAD: check how APERTURE is implemented in SAD. iT IS PROBABLY NOT AN ATTRIBUTE BUT A SEPARATE ELEMENT BY ITSELF.
  register_attribute("apert",             "aperture");
  register_attribute("dx1",               "aperture:x_limit");
  register_attribute("dy1",               "aperture:y_limit");

  register_attribute("controller",               "controller");
  register_attribute("controller:design",        "controller:design");


// AML: my understanding is that AML x_kick is an angle.
// SAD: need to define vertical kick by rotating the bend.
//      also need to define combined kicker if ever needed. 
  register_attribute("kicker:hkick",    "kicker:x_kick");
  register_attribute("kicker:vkick",    "kicker:y_kick");



// AML: MULTIPOLE: 
//        - in SAD the k1 component is the integrated value over the lenght.


// AML (MAD). MISALIGNMENT. DX, DY, TILT

// AML: comment line come out like this "//". SAD need "!"


// SAD: translate ENERGY in MOMENTUM. Translate sigt in sigz.
// Parameters
  register_attribute("momentum",        "beam[total_energy]");
  register_attribute("mass",            "beam[mass]", "# * 1e9");
  register_attribute("gamma",           "beam[gamma]");
  register_attribute("emitx",           "beam[emittance_a]");
  register_attribute("emity",           "beam[emittance_b]");
  register_attribute("sigz",            "beam[sig_t]");
  register_attribute("sige",            "beam[sig_e]");

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool SADParser::aml_ele_to_x_class (UAPNode* aml_ele, string& x_class) {

  // Since an AML element can be a combination of quadrupole, bend, etc., we
  // Need to see if there is a possible corresponding SAD element.

  // First make a list of what element children like <quadrupole> are present.

  StrList names;
  NodeVec children = aml_ele->getChildren();
  for (NodeVecCIter it = children.begin(); it != children.end(); it++) {
    string name = (*it)->getName();
    if (found(aml_class_names, name)) names << name;
  }

  UAPNode* instrument = aml_ele->getChildByName("instrument");

  // If there are no children then must be a drift or a type of instrument.

  if (names.size() == 0) {
    x_class = "drift";
    if (instrument) {
      x_class = "moni";
      string i_type = instrument->getAttributeString("type");
      if (i_type == "hmonitor" || i_type == "vmonitor" || i_type == "monitor") 
      x_class = "moni";
//    x_class = i_type;
    }
    return true;
  }

  // Ignore a scaled_multipole or aperture component if there is something else.

//  if (names.size() > 1) names.remove("scaled_multipole");
  if (names.size() > 1) names.remove("aperture");

  // Translation where there is exactly one match

  if (names.size() == 1) {

    x_class = names.front();

    if (x_class == "quadrupole") x_class = "quad";

    if (x_class == "bend")       x_class = "bend";

    if (x_class == "rf_cavity")  x_class = "cavi";

    if (x_class == "sextupole")  x_class = "sext";

    if (x_class == "multipole")  x_class = "mult";

    if (x_class == "marker")     x_class = "mark";

    if (x_class == "solenoid")   x_class = "sol";

    if (x_class == "octupole")   x_class = "oct";

    if (x_class == "kicker")     x_class = "kicker";

    if (x_class == "controller") x_class = "controller";

   if (x_class == "instrument") x_class = "moni";

//    if (x_class == "wire") x_class = "moni";

//    if (x_class == "proof") x_class = "moni";

    if (x_class == "patch" || x_class == "wiggler" || x_class == "match") {
      x_class = "BAD!";
      info_out.error ("AML element does not have a corresponding " + language + " type",
                   aml_ele->toStringTree());
      return false;
    }
  }

  return true;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//
// THIS ROUTINE CONVERTS FROM AML TO SAD VARIABLES
//
//--------------------------------------------------------------------
//--------------------------------------------------------------------

void SADParser::custom_aml_rep_to_x (UAPNode* lab, UAPNode* x_rep) {

  bool ok;
  double kvalue, lvalue, K0value ;
  double e1value, e2value, anglevalue ;
  double rotatevalue ;
  double dx1value,dy1value,dx2value,dy2value, powersupplyvalue;

  StrList names;
  NodeVec children = x_rep->getChildren();

//  cout << "---------------------testing area mauro start -----------------" << endl;
  for (NodeVecCIter it = children.begin(); it != children.end(); it++) {
    string name = (*it)->getName();

                   // ATTENTION POWERSUPPLY VALUE FOR KICKERS SET TO 0
                   powersupplyvalue =0;
/* ATTEMPT TO READ CONTROLLER
                   if(name == "controller") {
                   UAPNode* slave = *it;
                   string powersupply = slave->getAttributeString("design");
                   powersupplyvalue  = BasicUtilities::string_to_double(powersupply, ok);
                   powersupply = double_to_string (powersupplyvalue, ok);                    // convert back double to string before updating the field!
//                   slave->addAttribute("powersupply", powersupplyvalue);
    cout << "---------------------testing area mauro: controller-----------------" << endl;
    cout << powersupplyvalue;
                   }
*/
          if (name == "element") {
 
             UAPNode* slave = *it;
             string attrib = slave->getAttributeString("class");

//--------------------------------------------------------------------
// SAD: all K's are integrated values 


             if (attrib == "quad") {
                   string k1 = slave->getAttributeString("k1");
                   string l = slave->getAttributeString("l");
 
                   lvalue  = BasicUtilities::string_to_double(l, ok);
                   kvalue = BasicUtilities::string_to_double(k1, ok);   // convert from string to double
                   kvalue   = kvalue  *  lvalue ;
                   k1 = double_to_string (kvalue, ok);                    // convert back double to string before updating the field!
                   slave->addAttribute("k1", k1);
             };

             if (attrib == "sext") {
                   string k2 = slave->getAttributeString("k2");
                   string l = slave->getAttributeString("l");
 
                   lvalue  = BasicUtilities::string_to_double(l, ok);
                   kvalue  = BasicUtilities::string_to_double(k2, ok);   // convert from string to double
                   kvalue   = kvalue  *  lvalue ;
                   k2 = double_to_string (kvalue, ok);                    // convert back double to string before updating the field!
                   slave->addAttribute("k2", k2);
             };

             if (attrib == "oct") {
                   string k3 = slave->getAttributeString("k3");
                   string l = slave->getAttributeString("l");
 
                   lvalue  = BasicUtilities::string_to_double(l, ok);
                   kvalue  = BasicUtilities::string_to_double(k3, ok);   // convert from string to double
                   kvalue   = kvalue  *  lvalue ;
                   k3 = double_to_string (kvalue, ok);                    // convert back double to string before updating the field!
                   slave->addAttribute("k3", k3);
             };

//--------------------------------------------------------------------
// SAD bend face angles definition: e1 = e1 * angle, e2 = e2 * angle
// AML note that g is the curvature radius 
             if (attrib == "bend") {
                   string l        =    slave->getAttributeString("l");
                   lvalue          =    BasicUtilities::string_to_double(l, ok);   // convert from string to double
                   string g        =    slave->getAttributeString("g");
                   double gvalue   =    BasicUtilities::string_to_double(g, ok);   // convert from string to double
                   anglevalue      =    lvalue * gvalue;
                   string angle    =    double_to_string (anglevalue, ok);                    // convert back double to string before updating the field!
                   slave->addAttribute("angle", angle);
                   slave->removeAttribute("g");

                   if(slave->getAttribute("e1")) {
                           string e1     =    slave->getAttributeString("e1");
                           e1value       =    BasicUtilities::string_to_double(e1, ok);   // convert from string to double
                           e1value       =    e1value  /  anglevalue ;
                           if (e1value == 0) {
                               slave->removeAttribute("e1"); }
                               else {
                               e1            =    double_to_string (e1value, ok);                    // convert back double to string before updating the field!
                               slave->addAttribute("e1", e1);
                           };
                   };

                   if(slave->getAttribute("e2")) {
                           string e2     =    slave->getAttributeString("e2");
                           e2value       =    BasicUtilities::string_to_double(e2, ok);   // convert from string to double
                           e2value       =    e2value  /  anglevalue ;
                           if (e2value == 0) {
                               slave->removeAttribute("e2"); }
                               else {
                               e2            =    double_to_string (e2value, ok);                    // convert back double to string before updating the field!
                               slave->addAttribute("e2", e2);
                               };  
                   };

/*
                   if(slave->getAttribute("f_int1")) {
                           string f1       =    slave->getAttributeString("f_int1");
                           double f1value  =    BasicUtilities::string_to_double(f1, ok);   // convert from string to double
                           f1value         =    f1value  * 1.0 ;
                           f1              =    double_to_string (f1value, ok);                    // convert back double to string before updating the field!
                           slave->addAttribute("f1", f1);
                           slave->removeAttribute("f_int1");
                           int fringevalue = 3 ; 
                           string fringe   =    int_to_string (fringevalue, ok);                    // convert back double to string before updating the field!
                   };
*/

/*                   if(slave->getAttribute("f_int1")) {
                           string f1       =    slave->getAttributeString("f_int1");
                           double f1value  =    BasicUtilities::string_to_double(f1, ok);   // convert from string to double
                           f1value         =    f1value  * 1.0 ;
                           f1              =    double_to_string (f1value, ok);                    // convert back double to string before updating the field!
                           slave->addAttribute("f1", f1);
                           slave->removeAttribute("f_int1");
                           int fringevalue = 3 ; 
                           string fringe   =    int_to_string (f1value, ok);                    // convert back double to string before updating the field!
                   }
*/
             };


//--------------------------------------------------------------------
// SAD tilt = ?! also what correspond to x_pitch ? check all offsets, tilt and rools

             if(slave->getAttribute("rotate")) {
// change rad to degree and concatenate string to show "DEG"
                    string rotate = slave->getAttributeString("rotate");
                    if (rotate == "") {
                            if (attrib == "bend") rotate = "pi/2";
                            if (attrib == "quad") rotate = "pi/4";
                            if (attrib == "sext") rotate = "pi/6";
                            if (attrib == "oct")  rotate = "pi/8";
                            if (attrib == "sol_quad")  rotate = "pi/4";
                    };
                    rotatevalue =  BasicUtilities::string_to_double(rotate, ok);   // convert from string to double and change sign
                    if (rotatevalue == 0) {
                    slave->removeAttribute("rotate");  }
                    else  {
                    rotatevalue =  rotatevalue / 3.14159265 * 180.0;
                    rotate      =  double_to_string(rotatevalue, ok);  
                    rotate = rotate + " DEG";
                    slave->addAttribute("rotate", rotate);
                    };
             };

//--------------------------------------------------------------------
// SAD: APERTURE define dx1, dx2, dy1, dy2. In AML limits are simmetric.

             if (slave->getAttribute("apert")) {

                if (slave->getAttribute("dx1")) {
                       string dx1    =    slave->getAttributeString("dx1");
                       dx1value      =    BasicUtilities::string_to_double(dx1, ok);   // convert from string to double and change sign
                       if (dx1value > 0)  { 
                                    dx1value = - dx1value;
                                    dx1 = double_to_string(dx1value, ok); 
                                    slave->addAttribute("dx1", dx1);
                                    };
                       dx2value      =    fabs(dx1value);                                   // change sign
                       string dx2    =    double_to_string(dx2value, ok);                    // convert back double to string before updating the field!
                       slave->addAttribute("dx2", dx2);
                };

                if (slave->getAttribute("dy1")) {
                       string dy1    =    slave->getAttributeString("dy1");
                       dy1value      =    BasicUtilities::string_to_double(dy1, ok);   // convert from string to double and change sign
                       if (dy1value > 0)  { 
                                    dy1value = - dy1value;
                                    dy1 = double_to_string(dy1value, ok); 
                                    slave->addAttribute("dy1", dy1);
                                    };
                       dy2value      =    fabs(dy1value);                                   // change sign
                       string dy2    =    double_to_string(dy2value, ok);                    // convert back double to string before updating the field!
                       slave->addAttribute("dy2", dy2);
                };

             }; 


//--------------------------------------------------------------------
// SAD: need to define vertical kick by rotating the bend.
//      also need to define combined kicker if ever needed. 

             if (attrib == "kicker") {

                   if(slave->getAttribute("rotate")) {
                           string rotate =  slave->getAttributeString("rotate");
                           rotatevalue   =  BasicUtilities::string_to_double(rotate, ok);   
                           // APPARENTLY IN KICKER THE TILT IS ALREADY TRANSLATED FROM RADIAN TO DEGREES!
                           // rotatevalue   =  rotatevalue / 3.14159265 * 180.0;   
                           //===========================================================
                           // PAY ATTENTION THIS IS "DROTATE" in BENDS!!
                           string drotate      =  double_to_string(rotatevalue, ok);  
                           drotate = drotate + " DEG";
                           slave->addAttribute("drotate", drotate);
                           slave->removeAttribute("rotate"); 
                    };

                   if(slave->getAttribute("hkick")) {
                           string K0 =  slave->getAttributeString("hkick");
                           // SEE AML manual Physics section for explanation of kicker kick
                           // in short the x_kick= - K0 L (negative)
                           K0value   =  BasicUtilities::string_to_double(K0, ok);   
                           K0value   =  - powersupplyvalue * K0value ;   // because x_kick= - K0 L (negative)
                           K0        =  double_to_string(K0value, ok);  
                           slave->addAttribute("K0", K0);
                           slave->removeAttribute("hkick"); 
                     };

                   if(slave->getAttribute("vkick")) {
                           rotatevalue   =  90; 
                           string rotate      =  double_to_string(rotatevalue, ok);  
                           rotate = rotate + " DEG"; 
                           slave->addAttribute("rotate", rotate);
                           string K0 =  slave->getAttributeString("vkick");
                           // SEE AML manual Physics section for explanation of kicker kick
                           // in short the x_kick= - K0 L (negative)
                           K0value   =  BasicUtilities::string_to_double(K0, ok);   
                           K0value   =  - powersupplyvalue * K0value ;   // because x_kick= - K0 L (negative)
                           K0        =  double_to_string(K0value, ok);  
                           slave->addAttribute("K0", K0);
                           slave->removeAttribute("vkick"); 
                  };
              };

// then substitute the element name "kicker" with "bend" 
             if (attrib == "kicker") attrib="bend" ;
             slave->addAttribute("class", attrib);

//--------------------------------------------------------------------
// SAD: need to define vertical kick by rotating the bend.
//      also need to define combined kicker if ever needed. 

             if (attrib == "cavi") {

                   if(slave->getAttribute("volt")) {
                        string volt      =    slave->getAttributeString("volt");
                        double voltvalue =    1e6 * BasicUtilities::string_to_double(volt, ok);   // convert from string to double and change sign
                        volt             =    double_to_string (voltvalue, ok);                    // convert back double to string before updating the field!
                        slave->addAttribute("volt", volt);
                   };

                   if(slave->getAttribute("phi")) {
                        string phi      =    slave->getAttributeString("phi");
                        double phivalue =    BasicUtilities::string_to_double(phi, ok);   // convert from string to double and change sign
                        phi             =    double_to_string (phivalue, ok);                    // convert back double to string before updating the field!
                        slave->addAttribute("phi", phi);
                   };

                   if(slave->getAttribute("freq")) {
                        string freq      =    slave->getAttributeString("freq");
                        double freqvalue =    BasicUtilities::string_to_double(freq, ok);   // convert from string to double and change sign
                        freq             =    double_to_string (freqvalue, ok);                    // convert back double to string before updating the field!
                        slave->addAttribute("freq", freq);
                   };

             };

//--------------------------------------------------------------------
// AML (MAD). MISALIGNMENT. DX, DY, TILT

                   if(slave->getAttribute("dx")) {
                        string dx  =    slave->getAttributeString("dx");
                        double dxvalue =    BasicUtilities::string_to_double(dx, ok);   // convert from string to double and change sign
                        if (dxvalue == 0) {
                        slave->removeAttribute("dx"); }
                        else {
                        dx             =    double_to_string (dxvalue, ok);                    // convert back double to string before updating the field!
                        slave->addAttribute("dx", dx);
                        };
                   };

                   if(slave->getAttribute("dy")) {
                        string dy  =    slave->getAttributeString("dy");
                        double dyvalue =    BasicUtilities::string_to_double(dy, ok);   // convert from string to double and change sign
                        if (dyvalue == 0) {
                        slave->removeAttribute("dy");   }
                        else {
                        dy             =    double_to_string (dyvalue, ok);                    // convert back double to string before updating the field!
                        slave->addAttribute("dy", dy);
                        };
                    };

                   if(slave->getAttribute("s_offset")) {
                        string soffset  =    slave->getAttributeString("s_offset");
                        double soffsetvalue =    BasicUtilities::string_to_double(soffset, ok);   // convert from string to double and change sign
                        soffset             =    double_to_string (soffsetvalue, ok);                    // convert back double to string before updating the field!
                        slave->addAttribute("soffset", soffset);
                   };

/* ROTATE ALREADY DEFINED ABOVE!
                   if(slave->getAttribute("tilt")) {
                    string tilt = slave->getAttributeString("tilt");
                    double tiltvalue =    BasicUtilities::string_to_double(tilt, ok);   // convert from string to double and change sign
                    tilt    =    double_to_string (tiltvalue, ok);                    // convert back double to string before updating the field!
                    slave->addAttribute("tilt", tilt);
                   };
*/

//--------------------------------------------------------------------
//  PREVIOUS ATTEMPT TO add "APERTURE" element
//              UAPNode* x_rep = slave->addChild("aperol");
//              double ref = 1.0;
//              double at = 2.0;
//              node->addAttribute("ref", ref);
//              node->addAttribute("at", at);



//  cout << "---------------------testing area mauro end -----------------" << endl;


        }

  }
  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool SADParser::custom_x_element_to_x_file (UAPNode* x_node, string& comment, 
                                                             StreamStruct& x_out) {

  string x_name = x_node->getName();
  AttributeVec x_attribs = x_node->getAttributes();

  // element

  if (x_name == "element") {
    string ele_class = x_node->getAttributeString("class");
    if (ele_class == "") {
      ele_class = x_node->getAttributeString("inherit");
      info_out.error (language + ": element inheritance translation from AML not yet implemented!");
      throw;
    }
    x_out << ele_class << "  " << x_node->getAttributeString("name") << " = ("; 
    for (AttributeVecCIter att = x_attribs.begin(); att != x_attribs.end(); att++) {
      string a_name = att->getName();
      string a_value = att->getValue();
      if (a_name == "name") continue;
      if (a_name == "comment") continue;
      if (a_name == "class") continue;
      if (a_name == "inherit") continue;

      x_out << a_name;
      x_add_quote_marks (a_name, a_value);
      if (a_value != "") x_out << " = " << a_value << " ";
    }

    x_out << ")" << comment << fini;
    return true;
  }

  // line

    if (x_name == "line") {
      x_out << "line  " << x_node->getAttributeString("name") << " = ";
      write_line_or_list_to_x_file (x_node, " ", x_out);
      x_out << comment << fini;
      return true;
    }


  return false;

}





//--------------------------------------------------------------------
//--------------------------------------------------------------------
/// MULTIPOLE
//--------------------------------------------------------------------
//--------------------------------------------------------------------


//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool SADParser::custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep) {

  // init

  a_vec.resize(21, "");
  b_vec.resize(21, "");

  // We want TranslateCore to keep on going...

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool SADParser::custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele) {

  string aml_parent_name = aml_ele->getName();  
  string ele_name = x_ele->getAttributeString("name");
  string aml_attrib_name = aml_attrib->getName();
  string aml_attrib_value = aml_attrib->getAttributeString("design");

  // Multipole: Collect terms for later use.

  if (aml_parent_name == "multipole" && (aml_attrib_name == "al" || aml_attrib_name == "bl")) {

    string n_str = aml_attrib->getAttributeString("n");
    bool ok;
    int n = string_to_int(n_str, ok);
    if (!ok) {
      info_out.error ("NO OR BAD \"n\" ATTRIBUTE FOUND.", aml_attrib->toString());
      return true;
    }
    
    if (aml_attrib_name == "al") {
      a_vec[n] = aml_attrib_value;
    } else {
      b_vec[n] = aml_attrib_value;
    }

    return true;

  }

  // Unrecognized.

  return false;

}


//--------------------------------------------------------------------
//--------------------------------------------------------------------

void SADParser::custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_rep) {

  string aml_name = aml_ele->getName();
  bool ok;

  // multipole node

  if (x_rep->getAttributeString("class") == "multipole") {

    double f = 1;  // factorial

    for (int nn = 1; nn < a_vec.size(); nn++) {
      if (nn != 1) f = f * (nn - 1);
      if (a_vec[nn] == "" && b_vec[nn] == "") continue;
      string nn_str = int_to_string (nn, ok);
      string n0_str = int_to_string (nn-1, ok);
      string f_str = double_to_string (f, ok);
      string a_str = add_parens_if_needed(a_vec[nn]);
      string b_str = add_parens_if_needed(b_vec[nn]);

      if (a_str == "") {
        x_rep->addAttribute("k" + n0_str + "l", f_str + " * " + b_str);

      } else if (b_str == "") {                 // Skew
        x_rep->addAttribute("k" + n0_str + "l", f_str + " * " + a_str);
        x_rep->addAttribute("t" + n0_str, "");

      } else {
        x_rep->addAttribute("k" + n0_str + "l", 
                 f_str + " * sqrt((" + a_vec[nn] + ")^2 + (" + b_vec[nn] + ")^2)");
        x_rep->addAttribute("t" + n0_str, 
                            "-atan(" + a_vec[nn] + ", " + b_vec[nn] + ")");
      }

    }

  }

  // Unrecognized

  return;

}
