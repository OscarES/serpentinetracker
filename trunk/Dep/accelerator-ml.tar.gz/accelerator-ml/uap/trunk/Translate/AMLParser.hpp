/*
 * AMLParser
 * Universal Accelerator Parser
 * Copyright (C) 2009 David Sagan
 * 
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or (at
 * your option) any later version. 
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
 * for more details. 
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation, Inc., 
 * 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 * 
 * Direct questions, comments, etc to:
 *   David Sagan (dcs16@cornell.edu)
 */

#ifndef AMLParser_hpp
#define AMLParser_hpp 1

#include "Translate/TranslateCore.hpp"

//-----------------------------------------------------------------------

/** This class is a wrapper for the AMLReader class so that AML 
* can be treated on an equal footing with other formats
*/

class AMLParser : public TranslateCore {
public:

  /** Constructor
  */
  AMLParser();

  /** This is the same as AMLReader::AMLFileToAMLRep.
  * @param file_name   The root X file to use.
  * @param uap_root    The root of the UAP tree. If not present then
  *                    a new tree will be formed with the root called &lt;UAP_Root&gt;,
  * @return            The AML representation subtree root.
  */
  UAPNode* XFileToAMLRep (const Str& file_name, UAPNode* uap_root = NULL);

  /** This is the same as AMLReader::AMLFileToAMLRep.
  * @param file_name   The root X file to use.
  * @param uap_root    The root of the subtree (typeically &lt;UAP_Root&gt;)
  * @return            The child of root that is the &lt;_representation&gt;.
  */
  UAPNode* XFileToXRep (const Str& file_name, UAPNode* uap_root = NULL);

  /** This method does nothing.
  * @param x_root   May be a &lt;X_representation&gt; node or a &lt;UAP_root&gt; node.
  * @param aml_root    May be a &lt;AML_representation&gt; node or a 
  *                     &lt;UAP_root&gt; node, or NULL. If it is a &lt;UAP_root&gt; 
  *                     node then all existing &lt;AML_representation&gt; 
  *                     children are deleted. If it is NULL (the default) then, if
  *                     the x_root is a &lt;UAP_root&gt; or has a a &lt;UAP_root&gt;
  *                     parent, a &lt;AML_representation&gt; child is created.
  *                     Otherwise if x_root is NULL a new &lt;AML_representation&gt; 
  *                     node is created.
  * @return            &lt;AML_representation&gt; node.
  */
  UAPNode* XRepToAMLRep (UAPNode* x_root, UAPNode* aml_root = NULL);

  /** This is the same as AMLReader::AMLRepToAMLFile.
  * @param aml_root    May be a &lt;AML_representation&gt; node or 
  *                     a &lt;UAP_root&gt; node.
  * @param file_name   The root X file to create. If not present or "" then
  *                        the original file name will be used.
  * @param one_file    If true then concatinate everything into one file. 
  *                        Default is false.
  * @return            True if everything is OK. False otherwise.
  */
  UAPNode* AMLRepToXFile (UAPNode* aml_root, const Str& file_name = "", 
                                const Str& out_suffix = "", bool one_file = false);

  /** This method does nothing.
  * @param aml_root    May be a &lt;AML_representation&gt; node or 
  *                     a &lt;UAP_root&gt; node.
  * @param x_root   May be a &lt;X_representation&gt; node or a 
  *                     &lt;UAP_root&gt; node, or NULL. If it is a &lt;UAP_root&gt; 
  *                     node then all existing &lt;X_representation&gt; 
  *                     children are deleted. If it is NULL (the default) then, if
  *                     the aml_root is a &lt;UAP_root&gt; or has a a &lt;UAP_root&gt;
  *                     parent, a &lt;X_representation&gt; child is created.
  *                     Otherwise if x_root is NULL a new &lt;X_representation&gt; 
  *                     node is created.
  * @return            X &lt;X_representation&gt; node.
  */
  UAPNode* AMLRepToXRep (UAPNode* aml_root, UAPNode* x_root = NULL);

  /** This is the same as AMLReader::AMLRepToAMLFile.
  * If the argument one_file is set false, then the file names used for each included
  * file are obtained from the href attribute of the &lt;xi:include&gt; node.
  * See the ModifyIncludedFileNames method.
  * @param x_root      May be a &lt;X_representation&gt; node or a &lt;UAP_root&gt; node.
  * @param file_name   The root X file to create. If not present or "" then
  *                        the original file name will be used.
  * @param one_file    If true then concatinate everything into one file. 
  *                        Default is false.
  * @return            True if everything is OK. False otherwise.
  */
  UAPNode* XRepToXFile (UAPNode* x_root, const Str& file_name = "", 
                                const Str& out_suffix = "", bool one_file = false);

};


#endif
