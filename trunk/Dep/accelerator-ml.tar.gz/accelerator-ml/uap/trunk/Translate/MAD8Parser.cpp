#include "Translate/MAD8Parser.hpp"

using namespace std;
using namespace BasicUtilities;

//--------------------------------------------------------------------
//--------------------------------------------------------------------

MAD8Parser::MAD8Parser() : TranslateCore() {
  language = "MAD8"; 
  include_file_string = "call:filename";
  continuation_char =  "&";
  c_style_format = false;
  knl_tn_style_multipoles = true;
  abbreviations_permitted = true;
  init_lists_mad8();
  init_lists_mad();
  init_lists_core();
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MAD8Parser::custom_x_statement_to_x (StrList word_list, string comment,
                                                              UAPNode* x_rep_root) {

  // Called by TranslateCore::x_statement_to_x.
  // No custom statements have less than two words.

  if (word_list.size() < 3) return false; // Unrecognized
  string word1 = next_word(word_list);  
  string word2 = next_word(word_list);  
  string word3 = next_word(word_list);  

  // use statement

  if (word1 == "use") {
    if (!word_list.size() == 0 || word2 != ",") {
      info_out.error ("Malformed USE Statement");
      return true;
    }
    UAPNode* node = x_rep_root->addChild(word1);
    node->addAttribute("line", word3);
    return true;
  } 

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MAD8Parser::custom_aml_node_to_x (UAPNode* aml_ele, UAPNode* x_rep) {

  // init

  // We want TranslateCore to keep on going...

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MAD8Parser::custom_aml_element_attribute_to_x(UAPNode* aml_root, UAPNode* aml_ele, 
                                        UAPNode* aml_attrib, UAPNode* x_ele) {

  string aml_parent_name = aml_ele->getName();  
  string ele_name = x_ele->getAttributeString("name");
  string aml_attrib_name = aml_attrib->getName();
  string aml_attrib_value = aml_attrib->getAttributeString("design");

  // Unrecognized.

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void MAD8Parser::custom2_aml_element_attribute_to_x (UAPNode* aml_ele, UAPNode* x_rep) {

  string aml_name = aml_ele->getName();
  bool ok;

  // 

  return;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MAD8Parser::custom_x_element_to_x_file (UAPNode* x_node, string& comment, 
                                                             StreamStruct& x_out) {

  string x_name = x_node->getName();

  // use

  if (x_name == "use") {
    x_out << "use, " << x_node->getAttributeString("line") << comment << fini;
    return true;
  }

  return false;

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

bool MAD8Parser::custom_x_add_attributes (StrList& word_list, string ele_class, 
                                    string& attrib_name, UAPNode* x_ele_root) {


  // Convert something like "tm(1,2,3)" to "tm123"

  if (ele_class == "matrix" && attrib_name == "tm") {
    if (word_list.size() < 8) {
      info_out.error ("Malformed matrix tm term.");
      return true;
    }
    string p1 = next_word(word_list);
    string i1 = next_word(word_list);
    string c1 = next_word(word_list);
    string i2 = next_word(word_list);
    string c2 = next_word(word_list);
    string i3 = next_word(word_list);
    string p2 = next_word(word_list);

    bool ok1, ok2, ok3;
    int i_1 = string_to_int (i1, ok1);
    int i_2 = string_to_int (i1, ok2);
    int i_3 = string_to_int (i1, ok3);

    if (!ok1 || !ok2 || !ok3 ||
        i_1 < 1 || i_1 > 6 || i_2 < 1 || i_2 > 6 || i_3 < 1 || i_3 > 6 ||
        p1 != "(" || c1 != "," || c2 != "," || p2 != ")") {
      info_out.error ("Bad \"tm(...) =\" in matrix element.");
      return true;  // Recognized;
    }
    attrib_name = "tm" + i1 + i2 + i3;
    return false;
  }

  // Convert something like "rm(1,2)" to "rm12"

  if (ele_class == "matrix" && attrib_name == "rm") {
    if (word_list.size() < 6) {
      info_out.error ("Malformed matrix rm term.");
      return true;
    }
    string p1 = next_word(word_list);
    string i1 = next_word(word_list);
    string c1 = next_word(word_list);
    string i2 = next_word(word_list);
    string p2 = next_word(word_list);

    bool ok1, ok2;
    int i_1 = string_to_int (i1, ok1);
    int i_2 = string_to_int (i1, ok2);

    if (!ok1 || !ok2 ||
        i_1 < 1 || i_1 > 6 || i_2 < 1 || i_2 > 6 ||
        p1 != "(" || c1 != "," || p2 != ")") {
      info_out.error ("Bad \"rm(...) =\" in matrix element.");
      return true;  // Recognized;
    }
    attrib_name = "rm" + i1 + i2;
    return false;
  }

  return false; // Unrecognized

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void MAD8Parser::custom_x_attrib_to_x_file_translate (string& attrib_name,
                                                            string& attrib_value) {

  if (!found(map_element_to_attribs["matrix"], attrib_name)) return;

  if (attrib_name.substr(0,2) == "rm") {
    attrib_name = "rm(" + attrib_name.substr(2,1) + "," + attrib_name.substr(3,1) + ")";
  }

  if (attrib_name.substr(0,2) == "tm") {
    attrib_name = "tm(" + attrib_name.substr(2,1) + "," + 
                          attrib_name.substr(3,1) + "," + attrib_name.substr(4,1) + ")";

  }

}

//--------------------------------------------------------------------
//--------------------------------------------------------------------

void MAD8Parser::init_lists_mad8 () {

  StrVec multipole_attrib;
  multipole_attrib << "l" << "tilt" << "k0l" << "k1l"
         << "k2l" << "k3l" << "k4l" << "k5l" << "k6l" << "k7l" << "k8l" << "k9l"
         << "k10l" << "k11l" << "k12l" << "k13l" << "k14l" << "k15l" << "k16l" << "k17l"
         << "k18l" << "k19l" << "k20l" << "t0" << "t1" << "t2" << "t3" << "t4"
         << "t5" << "t6" << "t7" << "t8" << "t9" << "t10" << "t11" << "t12"
         << "t13" << "t14" << "t15" << "t16" << "t17" << "t18" << "t19" << "t20" 
         << "lrad" << "type" << "at";
  map_element_to_attribs["multipole"] = multipole_attrib;

  StrVec matrix_attrib;
  matrix_attrib << "type";
  for (int i = 1; i < 7; i++) {
    ostringstream iss; iss << i;
    for (int j = 1; j < 7; j++) {
      ostringstream jss; jss << j;
      matrix_attrib << "rm" + iss.str() + jss.str();
      for (int k = 1; k < 7; k++) {
        ostringstream kss; kss << k;
        matrix_attrib << "tm" + iss.str() + jss.str() + kss.str();        
      }
    }
  }
  map_element_to_attribs["matrix"] = matrix_attrib;

  return;

}
